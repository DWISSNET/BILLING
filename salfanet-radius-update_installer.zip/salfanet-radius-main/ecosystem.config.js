module.exports = {
  apps: [
    // Main Next.js Application
    {
      name: 'salfanet-radius',
      script: 'npm',
      args: 'start',
      cwd: '/var/www/salfanet-radius',
      instances: 1,
      exec_mode: 'cluster',
      watch: false,
      max_memory_restart: '1G',
      env: {
        NODE_ENV: 'production',
        PORT: 3000,
        TZ: 'Asia/Jakarta'
      },
      error_file: '/var/www/salfanet-radius/logs/error.log',
      out_file: '/var/www/salfanet-radius/logs/out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s'
    },
    // Standalone Cron Service
    {
      name: 'salfanet-cron',
      script: './cron-service.js',
      cwd: '/var/www/salfanet-radius',
      instances: 1,
      exec_mode: 'fork',
      watch: false,
      max_memory_restart: '256M',
      env: {
        NODE_ENV: 'production',
        API_URL: 'http://localhost:3000',
        TZ: 'Asia/Jakarta'
      },
      error_file: '/var/www/salfanet-radius/logs/cron-error.log',
      out_file: '/var/www/salfanet-radius/logs/cron-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      autorestart: true,
      max_restarts: 5,
      min_uptime: '10s'
    }
  ]
};
