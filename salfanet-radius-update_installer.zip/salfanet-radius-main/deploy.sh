#!/bin/bash
set -e

echo "[*] Deploying SALFANET RADIUS..."

APP_DIR="/var/www/salfanet-radius"
cd ${APP_DIR}

# Pull latest code (if using git)
if [ -d ".git" ]; then
    echo ">> Pulling latest code..."
    git pull origin main
fi

# Install dependencies
echo ">> Installing dependencies..."
npm install --production=false

# Generate Prisma Client
echo "[>] Generating Prisma Client..."
npx prisma generate

# Push database schema (for first time or schema changes)
echo "[>] Updating database schema..."
npx prisma db push --accept-data-loss

# Run migrations (alternative to db push)
# npx prisma migrate deploy

# Build Next.js application
echo "[>] Building application..."
npm run build

# Restart PM2
echo "[>] Restarting application..."
pm2 restart salfanet-radius || pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 save

echo "[OK] Deployment completed!"
echo ""
echo ">> Application status:"
pm2 status

echo ""
echo ">> View logs:"
echo "   pm2 logs salfanet-radius"
