# AIBILL RADIUS - DOKUMENTASI MASTER LENGKAP
# Versi Gabungan Semua File Dokumentasi

**Versi**: 2.9.2  
**Tanggal Update Terakhir**: 28 Desember 2025  
**Total File Sumber**: 34 file dokumentasi (32 docs/*.md + CHANGELOG.md + CHAT_HISTORY.md)  
**Total Konten**: 13,852+ baris dokumentasi teknis lengkap

> **CATATAN PENTING**: Ini adalah dokumentasi master yang menggabungkan SEMUA konten dari:
> - Semua file di folder `docs/` (32 file)
> - `CHANGELOG.md` (complete version history)
> - `CHAT_HISTORY_2025-12-28_Session3.md` (latest session notes)

---

# DAFTAR ISI

## BAGIAN 1: CHANGELOG - COMPLETE VERSION HISTORY

[Lihat changelog lengkap mulai dari versi 2.9.2 hingga 1.0.0]

## BAGIAN 2: CHAT HISTORY - LATEST SESSION

[Dokumentasi session terakhir dan troubleshooting]

## BAGIAN 3: DOKUMENTASI LENGKAP DARI FOLDER DOCS/

### 3.1 Installation & Deployment
- DEPLOYMENT-GUIDE.md
- FREERADIUS-SETUP.md
- PROXMOX_VPS_SETUP_GUIDE.md
- PROXMOX_L2TP_SETUP.md
- VPS_OPTIMIZATION_GUIDE.md
- VPN_CLIENT_SETUP_GUIDE.md

### 3.2 Core Systems
- CRON-SYSTEM.md
- ACTIVITY_LOG_IMPLEMENTATION.md
- COMPREHENSIVE_FEATURE_GUIDE.md

### 3.3 Billing & Payment
- PREPAID_POSTPAID_IMPLEMENTATION.md
- MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md
- INVOICE_NUMBER_FORMAT.md
- AGENT_DEPOSIT_SYSTEM.md
- CUSTOMER_PAYMENT_SELF_SERVICE.md
- BALANCE_AUTO_RENEWAL.md

### 3.4 Notifications
- BROADCAST_NOTIFICATION_SYSTEM.md
- OUTAGE_NOTIFICATION_SYSTEM.md
- AUTO_RENEWAL_NOTIFICATION_SYSTEM.md

### 3.5 Advanced Features
- GENIEACS-GUIDE.md
- MIKROTIK_RADIUS_COA_COMPLETE_SETUP.md
- MIKROTIK_COA_SETUP.md
- COA_TROUBLESHOOTING_WORKFLOW.md
- MULTIPLE_NAS_SAME_IP.md
- GPS_LOCATION_FEATURE.md
- IMPORT_PPPOE_USERS.md
- CUSTOMER_WIFI_SELFSERVICE.md
- CUSTOMER_LOGIN_BYPASS.md
- DYNAMIC_VIRTUAL_PARAMETERS.md
- VOUCHER_EXPIRATION_TIMEZONE_FIX.md

### 3.6 Testing & Troubleshooting
- TESTING_GUIDE.md
- TROUBLESHOOTING.md

---

# BAGIAN 1: CHANGELOG LENGKAP

# Changelog

All notable changes to SALFANET RADIUS will be documented in this file.

## [2.9.2] - 2025-12-28

### ðŸ› Critical Bug Fixes

#### Voucher Expiration Status Fix - Timezone Consistency
**Issue:** Vouchers yang sudah expired masih menampilkan status "AKTIF" di sistem

**Root Cause:**
- Database timezone: MySQL menggunakan `SYSTEM` timezone (WIB/UTC+7)
- `firstLoginAt` dan `expiresAt` disimpan dalam WIB (server local time dari FreeRADIUS)
- Cron query menggunakan `UTC_TIMESTAMP()` untuk comparison
- Selisih 7 jam menyebabkan voucher expired tidak terdeteksi

**Example:**
```
Voucher ELRQNC:
- Expires At: 2025-12-28 07:23:16 (WIB)
- Current Time: 09:41 (WIB) / 02:41 (UTC)
- OLD: expiresAt < UTC_TIMESTAMP() â†’ 07:23 < 02:41 = FALSE âŒ
- NEW: expiresAt < NOW() â†’ 07:23 < 09:41 = TRUE âœ…
```

**Fix Applied:**
- File: `src/lib/cron/voucher-sync.ts` (Line 262-267)
- Changed: `UTC_TIMESTAMP()` â†’ `NOW()`
- Added documentation comment explaining timezone behavior
- Tested: Voucher ELRQNC successfully updated from ACTIVE â†’ EXPIRED

**Impact:**
- âœ… Vouchers expired sekarang otomatis diupdate statusnya (setiap menit via cron)
- âœ… Status di UI sekarang akurat dengan expiration date
- âœ… User tidak bisa login dengan voucher expired
- âœ… Session aktif di-disconnect otomatis via CoA (jika Mikrotik CoA enabled)

**Files Changed:**
- `src/lib/cron/voucher-sync.ts` - Fixed timezone comparison in expiration query
- `docs/VOUCHER_EXPIRATION_TIMEZONE_FIX.md` - Complete documentation

---

#### Invoice Generation Field Errors Fix
**Issue:** Invoice generator gagal dengan error:
- `Unknown argument 'expiresAt'. Did you mean 'expiredAt'?`
- `Unknown argument 'billingCycle'`

**Root Cause:**
- Field names tidak konsisten antara schema Prisma dan code
- PREPAID users menggunakan `expiredAt` bukan `expiresAt`
- POSTPAID users menggunakan `billingDay` bukan `billingCycle`

**Fix Applied:**
- File: `src/lib/cron/voucher-sync.ts`
- Line 1158: `expiresAt` â†’ `expiredAt` (PREPAID user query)
- Line 1173: `billingCycle` â†’ `billingDay` (POSTPAID user query)
- Line 1198-1213: `user.expiresAt` â†’ `user.expiredAt` (4 occurrences)

**Impact:**
- âœ… Invoice generation sekarang bekerja untuk PREPAID users
- âœ… Invoice generation sekarang bekerja untuk POSTPAID users
- âœ… Auto-invoice di akhir bulan tidak akan error lagi

**Files Changed:**
- `src/lib/cron/voucher-sync.ts` - Fixed field names in invoice generation

---

### ðŸ• Timezone Consistency Architecture (NEW!)

#### Complete Timezone Synchronization Across All Components
Implemented comprehensive timezone consistency to prevent future timezone-related bugs.

**Installer Updates (vps-install.sh & vps-install-local.sh):**

1. **System Timezone Configuration:**
   ```bash
   timedatectl set-timezone Asia/Jakarta
   ```

2. **MySQL Timezone Configuration (NEW!):**
   - Creates persistent config: `/etc/mysql/mysql.conf.d/timezone.cnf`
   - Sets `default-time-zone = '+07:00'`
   - Runs `SET GLOBAL time_zone = '+07:00'` immediately
   - Verifies timezone after MySQL restart

3. **Node.js Environment:**
   ```env
   TZ="Asia/Jakarta"
   NEXT_PUBLIC_TIMEZONE="Asia/Jakarta"
   ```

4. **PM2 Ecosystem Config:**
   ```javascript
   env: { TZ: 'Asia/Jakarta' }
   ```

**Timezone Verification Commands:**
```bash
# 1. System timezone
timedatectl show --property=Timezone --value  # Asia/Jakarta

# 2. MySQL timezone (MUST match system!)
mysql -e "SELECT @@global.time_zone, NOW()"   # +07:00, same as 'date'

# 3. Node.js timezone
node -e "console.log(process.env.TZ)"         # Asia/Jakarta

# 4. Compare all times (should be identical!)
date && mysql -e "SELECT NOW()" && node -e "console.log(new Date())"
```

**Files Updated:**
- `vps-install.sh` - Added MySQL timezone config + verification
- `vps-install-local.sh` - Added MySQL timezone config + verification  
- `install-wizard.html` - Added MySQL timezone setup instructions in Step 4
- `src/lib/timezone.ts` - Updated documentation with architecture overview

**Timezone Mapping for Non-WIB Deployments:**
| Zona | System Timezone | MySQL Offset | .env TZ |
|------|-----------------|--------------|---------|
| WIB  | Asia/Jakarta    | +07:00       | Asia/Jakarta |
| WITA | Asia/Makassar   | +08:00       | Asia/Makassar |
| WIT  | Asia/Jayapura   | +09:00       | Asia/Jayapura |
| SGT  | Asia/Singapore  | +08:00       | Asia/Singapore |

**Documentation:**
- `docs/VOUCHER_EXPIRATION_TIMEZONE_FIX.md` - Detailed explanation
- `src/lib/timezone.ts` - Architecture documentation in code

---

### ðŸ–¥ï¸ Frontend Timezone Settings - Complete Integration

#### Timezone Changes from UI Now Apply to ALL Components
When changing timezone from Admin > Settings > Company, the following are now updated:

1. **System Timezone (Linux):**
   - Runs `timedatectl set-timezone <timezone>`
   - Immediate effect on all system time functions

2. **MySQL Timezone (Linux):**
   - Creates `/etc/mysql/mysql.conf.d/timezone.cnf`
   - Runs `SET GLOBAL time_zone = '<offset>'`
   - Ensures `NOW()`, `CURDATE()` return correct local time

3. **Application Files:**
   - `.env` - Updates TZ and NEXT_PUBLIC_TIMEZONE
   - `ecosystem.config.js` - Updates PM2 TZ environment
   - `src/lib/timezone.ts` - Updates WIB_TIMEZONE constant

4. **Services:**
   - PM2 restart with `--update-env`
   - FreeRADIUS restart to use new system timezone

**30+ Timezone Support:**
Timezone mapping includes all major Indonesian and international timezones:
- Indonesian: Asia/Jakarta (WIB), Asia/Makassar (WITA), Asia/Jayapura (WIT)
- Southeast Asia: Asia/Singapore, Asia/Bangkok, Asia/Kuala_Lumpur, Asia/Manila
- East Asia: Asia/Tokyo, Asia/Seoul, Asia/Hong_Kong, Asia/Shanghai
- South Asia: Asia/Kolkata, Asia/Dubai
- Europe: Europe/London, Europe/Paris, Europe/Berlin, Europe/Amsterdam
- Americas: America/New_York, America/Chicago, America/Los_Angeles, America/Sao_Paulo
- And more...

**Files Changed:**
- `src/app/api/settings/timezone/route.ts` - Added MySQL + System timezone update
- `src/app/admin/settings/company/page.tsx` - Updated UI messages

---

### ðŸ”§ Proxmox VPS Configuration Support (NEW!)

#### Complete Proxmox LXC Container Setup Guide
Added comprehensive documentation and auto-configuration for Proxmox VPS deployments.

**New Documentation:**
- **`docs/PROXMOX_VPS_SETUP_GUIDE.md`** - Complete Proxmox LXC setup guide
  - Container configuration templates
  - `/dev/ppp` device setup for PPPoE
  - `/dev/net/tun` device setup for VPN
  - IP forwarding & NAT configuration
  - Kernel module auto-load
  - Troubleshooting common issues
  - Security considerations (LXC vs KVM)

**Installer Updates:**
- **`vps-install.sh`** - Added Proxmox VPS detection & setup:
  ```bash
  # Auto-creates /dev/ppp and /dev/net/tun
  # Loads PPP/L2TP/TUN kernel modules
  # Configures IP forwarding (net.ipv4.ip_forward = 1)
  # Auto-loads modules on boot (/etc/modules-load.d/ppp.conf)
  # Verifies setup with detailed status output
  ```

- **`install-wizard.html`** - Added Proxmox VPS section:
  - Visual warning for Proxmox LXC users in Step 1
  - Complete Step-by-step Proxmox host configuration guide
  - Container config examples with lxc.cgroup2 permissions
  - Verification commands
  - Troubleshooting table
  - Link to detailed documentation

**Features Enabled for Proxmox LXC:**
1. **PPPoE Server Support:**
   - `/dev/ppp` device (char 108:*)
   - PPP kernel modules (ppp_generic, ppp_async, ppp_mppe, ppp_deflate)
   
2. **VPN Support (L2TP/IPSec):**
   - `/dev/net/tun` device (char 10:200)
   - TUN kernel module
   - L2TP modules (l2tp_core, l2tp_ppp, l2tp_netlink)

3. **Network Routing:**
   - IP forwarding enabled persistently
   - SYN flood protection
   - ICMP redirect blocking

**Verification Checklist:**
```bash
âœ… /dev/ppp exists (crw------- 1 root root 108, 0)
âœ… /dev/net/tun exists (crw-rw-rw- 1 root root 10, 200)
âœ… IP forwarding enabled (net.ipv4.ip_forward = 1)
âœ… PPP kernel modules loaded (4 modules)
âœ… TUN kernel module loaded
```

**Proxmox Container Config Template:**
```bash
# PPPoE Support
lxc.cgroup2.devices.allow: c 108:* rwm
lxc.mount.entry: /dev/ppp dev/ppp none bind,create=file,optional 0 0

# TUN/TAP Support
lxc.cgroup2.devices.allow: c 10:200 rwm
lxc.mount.entry: /dev/net dev/net none bind,create=dir 0 0

# Enable nesting
lxc.apparmor.profile: unconfined
```

**Files Changed:**
- `docs/PROXMOX_VPS_SETUP_GUIDE.md` - NEW comprehensive guide
- `vps-install.sh` - Added Proxmox VPS auto-setup
- `install-wizard.html` - Added Proxmox LXC configuration section

**Notes:**
- LXC containers require host-level kernel module support
- KVM VMs work out-of-box without special configuration
- Security trade-off: `lxc.apparmor.profile: unconfined` reduces isolation
- Recommended: Use KVM for production, LXC for development/testing

---

## [2.9.1] - 2025-12-27

### ðŸ”§ Critical Fixes - Payment URL Generation & Invoice Management

#### Payment URL Generation Fixes
- **Reordered Payment Flow** - Create payment FIRST before invoice creation
  - Previous: Invoice created â†’ Payment created â†’ Update invoice with URL
  - New: Payment created â†’ Invoice created with URL directly
  - Prevents invoices being created without payment links
  - Invoice only created if payment URL successfully generated
  
- **Comprehensive Error Handling**
  - Better logging with `[Top-Up Direct]` prefix throughout flow
  - Detailed Tripay config logging (merchantCode, hasApiKey, hasPrivateKey, environment)
  - Full Tripay response logging for debugging
  - Error messages include gateway name and specific failure reason
  - Frontend shows detailed error alerts with SweetAlert2
  
- **Payment Gateway Support Completed**
  - âœ… Midtrans: `createMidtransPayment` â†’ `redirect_url`
  - âœ… Xendit: `createXenditInvoice` â†’ `invoiceUrl`
  - âœ… Duitku: QRIS via ShopeePay â†’ `paymentUrl`
  - âœ… Tripay: QRIS with `createTransaction` â†’ `checkout_url` or `pay_url`
  - All gateways tested and validated
  
- **API Response Improvements**
  - `POST /api/customer/topup-direct` always returns `paymentUrl` field
  - Success response: `{ success, invoiceNumber, amount, paymentUrl, invoice }`
  - Error response: `{ success: false, error, details, gateway }`
  - Console logging for request/response tracking

#### Customer Dashboard Invoice Improvements
- **Smart Payment Button**
  - Invoice WITH payment link â†’ Cyan "Bayar" button â†’ Opens payment in new tab
  - Invoice WITHOUT payment link â†’ Yellow "Buat Link" button â†’ Regenerates payment
  - Button changes from `<a>` tag to `<button>` with proper `onClick` handler
  - Uses `window.open()` with security parameters: `noopener,noreferrer`
  
- **Auto-Refresh Invoice Data**
  - Added `visibilitychange` event listener
  - Automatically refreshes invoice list when user returns to dashboard
  - Ensures latest payment links are always shown
  - No manual refresh needed after creating top-up
  
- **Debug Logging**
  - Console logs for button clicks with invoice number
  - Payment link value logging (null vs actual URL)
  - Click tracking for troubleshooting

#### New Feature: Payment Link Regeneration
- **API Endpoint** - `POST /api/customer/invoice/regenerate-payment`
  - Regenerates payment link for invoices without payment URL
  - Supports all 4 payment gateways (Midtrans, Xendit, Duitku, Tripay)
  - Customer authentication required
  - Only works for PENDING invoices owned by customer
  
- **UI Integration**
  - Yellow "Buat Link" button for invoices without payment link
  - Loading state: "Proses..." with spinner icon
  - Auto-opens payment URL after generation
  - Refreshes invoice list to update UI
  
- **Smart Gateway Selection**
  - Uses first available active gateway from system config
  - Falls back to alert if no gateways configured
  - Seamless user experience

#### Frontend Enhancements
- **Top-Up Direct Page**
  - Better error display with gateway information
  - Status-based response handling (check `res.ok` before processing)
  - Timer-based success alert (1.5s) before redirect
  - Warning alert for missing payment URL (shouldn't happen with new flow)
  - Console logging: `[Top-Up Direct Frontend]` prefix
  
- **Payment Gateway Config**
  - Added GET handler to `/api/payment/create` to prevent 405 errors
  - Better JSON parsing with try-catch
  - Request logging before processing

#### Code Quality Improvements
- **Validation**
  - Payment URL null check before creating invoice
  - Strict string checking: `paymentLink && paymentLink.trim() !== ''`
  - Gateway config validation before payment creation
  
- **Console Logging Strategy**
  - Consistent prefix: `[Top-Up Direct]`, `[Dashboard]`, `[Regenerate Payment]`
  - Structured logs: Config â†’ Params â†’ Result â†’ Error
  - JSON stringification for complex objects (Tripay result)
  
- **Error Messages**
  - User-friendly: "Link pembayaran belum tersedia. Silakan hubungi admin atau buat ulang invoice."
  - Developer-friendly: Full error stack, gateway name, specific failure
  - Bilingual: Indonesian for users, English for developers

### ðŸ“ Files Modified
- `src/app/api/customer/topup-direct/route.ts` - Payment-first flow, comprehensive logging
- `src/app/customer/topup-direct/page.tsx` - Better error handling, console logging
- `src/app/customer/page.tsx` - Smart button, auto-refresh, regenerate integration
- `src/app/api/payment/create/route.ts` - GET handler, better error handling
- `src/app/api/customer/invoice/regenerate-payment/route.ts` - NEW FILE

### ðŸ› Bugs Fixed
1. **Invoice Created Without Payment Link**
   - Root cause: Payment creation happened after invoice creation, errors were silent
   - Fix: Create payment first, only create invoice if payment succeeds
   
2. **"Bayar" Button Shows Alert Instead of Redirecting**
   - Root cause: `<a>` tag with `href="#"` and `preventDefault()` blocked navigation
   - Fix: Changed to `<button>` with `window.open()` for new tab redirect
   
3. **Old Invoices Can't Be Paid**
   - Root cause: Invoices created before fix have no payment link
   - Fix: "Buat Link" button regenerates payment link on-demand
   
4. **Console Error on Dashboard**
   - Root cause: Browser prefetch/GET request to `/api/payment/create` endpoint
   - Fix: Added GET handler returning 405 Method Not Allowed
   
5. **Payment Gateway Not Appearing**
   - Previous fix: Re-save config to set `isActive` in database
   - Current: Proper validation and logging throughout

### ðŸ” Testing Notes
- Test with all 4 payment gateways
- Verify invoice list refreshes on dashboard return
- Check old invoices show "Buat Link" button
- Verify new invoices have "Bayar" button immediately
- Console logging should show payment URL generation
- Error alerts should be informative, not generic

---

## [2.9.0] - 2025-12-27

### âœ¨ Balance Enhancement Package - New Features

#### 1. âš ï¸ Low Balance Alerts & Warnings
- Visual warning indicators when balance < package price
- Admin interface: Alert box in balance management page
- Customer portal: Yellow warning banner in Balance Card widget
- Real-time balance checking with AlertCircle icons
- Color-coded alerts for better visibility

#### 2. ðŸ’³ Customer Self-Service Top-Up Request
- **Request Form** (`/customer/topup-request`)
  - Clean form with amount validation (min Rp 10,000)
  - Payment method selector: Transfer Bank, E-Wallet, Cash
  - File upload for payment proof (images only, max 5MB)
  - Optional note field for additional information
  
- **Request Workflow**
  - Customer submits request with proof
  - Files stored in `/public/uploads/topup-proofs/`
  - Transaction created with PENDING status
  - Admin approval/rejection workflow
  - Success notification with processing time estimate

- **Customer Portal Integration**
  - "Request Manual" button - Manual request with proof upload (FREE)
  - "Top-Up Langsung" button - Direct auto top-up via payment gateway
  - WhatsApp Admin quick contact button
  - Shadow effects and responsive design

- **API Endpoints**
  - `POST /api/customer/topup-request` - Create manual request
  - `POST /api/customer/topup-direct` - Create auto top-up with payment
  - FormData handling with file upload
  - Metadata storage (requestedBy, note, proofPath, timestamp)

#### 2b. ðŸ’° Direct Top-Up with Payment Gateway (NEW)
- **Direct Top-Up Page** (`/customer/topup-direct`)
  - Display current balance
  - Preset amount buttons (50K, 100K, 200K, 500K, 1M)
  - Custom amount input with validation
  - Payment gateway selection interface
  - Real-time balance preview
  
- **Payment Gateway Integration**
  - Supports Midtrans and Xendit payment gateways
  - Auto-detect active payment gateways
  - Automatic invoice generation (TOPUP type)
  - Direct redirect to payment URL
  - No admin approval needed
  
- **Direct Top-Up Workflow**
  - Customer selects amount (min Rp 10,000)
  - Customer chooses payment gateway
  - System creates TOPUP invoice
  - Payment URL generated via selected gateway
  - Customer redirected to payment page
  - Balance auto-increment after payment success
  
- **Dual Top-Up Options**
  - **Manual Request**: Upload proof â†’ Wait admin approval (FREE, no gateway fee)
  - **Direct Top-Up**: Choose amount â†’ Pay via gateway â†’ Auto credit (INSTANT, may have gateway fee)

#### 3. ðŸ“Š Balance History Export (CSV)
- Export button in transaction history header
- Client-side CSV generation (no server processing)
- Proper quote escaping for special characters
- UTF-8 BOM prefix for Excel compatibility
- Filename format: `balance-{username}-{YYYY-MM-DD}.csv`
- Headers: Tanggal, Tipe, Keterangan, Metode, Jumlah, Status
- One-click download with auto-cleanup

#### 4. ðŸ› ï¸ Admin Top-Up Request Management
- **Management Dashboard** (`/admin/topup-requests`)

#### 5. ðŸ”„ Package Upgrade with Payment Gateway Integration
- **Upgrade Page** (`/customer/upgrade`)
  - Display current package information
  - List all available packages with pricing
  - Visual selection with confirmation
  - Payment gateway selection interface
  - Real-time price comparison
  
- **Payment Gateway Integration**
  - Supports Midtrans and Xendit payment gateways
  - Auto-detect active payment gateways from admin settings
  - Public API for gateway availability
  - Automatic invoice generation
  - Direct redirect to payment URL
  
- **Upgrade Workflow**
  - Customer selects new package
  - Customer chooses payment gateway
  - System creates ADDON invoice (invoiceType)
  - Payment URL generated via selected gateway
  - Customer redirected to payment page
  - Payment webhook handling for status update
  
- **API Endpoints**
  - `POST /api/customer/upgrade` - Create upgrade invoice with payment
  - `GET /api/public/payment-gateways` - List active payment gateways
  - `GET /api/public/profiles` - List available PPPoE profiles
  
- **Invoice Management**
  - Invoice type: ADDON for package upgrades
  - Payment token generation for tracking
  - Payment link storage for customer access
  - Customer details embedded (name, phone, email, username)
  
- **UI/UX Enhancements**
  - "Ganti Paket" button in Customer Dashboard
  - Payment method selection cards
  - Loading states during payment creation
  - SweetAlert2 confirmation with invoice details
  - Responsive mobile-first design

### ðŸ”§ Technical Improvements
- Updated customer/me API to return balance and autoRenewal status
- Created public APIs for profiles and payment gateways
- Fixed invoice schema usage (removed non-existent metadata field)
- Proper TypeScript types for all payment gateway interfaces
- Error handling for payment gateway failures
  - Stats cards: Pending, Approved, Rejected, Total
  - Filterable request list with color-coded badges
  - User info display (name, username, phone, amount)
  - Payment method and timestamp (WIB timezone)
  - Custom notes from customers

- **Approval Workflow**
  - "View Proof" button with image viewer modal
  - Approve/Reject buttons with SweetAlert2 confirmations
  - Loading states during processing
  - Automatic balance increment on approval
  - Status update in database (PENDING â†’ SUCCESS/FAILED)

- **API Endpoints**
  - `GET /api/admin/topup-requests` - List all requests
  - `POST /api/admin/topup-requests/[id]/approve` - Approve request
  - `POST /api/admin/topup-requests/[id]/reject` - Reject request
  - Prisma transactions for data consistency
  - Metadata tracking (approvedAt, approvedBy, rejectedAt, rejectedBy)

### ðŸŽ¨ UI/UX Improvements
- Consistent icon usage (AlertCircle, Upload, Download, Check, X, Eye, Clock)
- Better button layouts with dual-action support
- Shadow effects for visual hierarchy (`shadow-lg shadow-cyan-500/20`)
- Responsive design with mobile-first approach
- Loading states with Loader2 animations
- Empty states with helpful messages
- Color coding: Warning (yellow), Success (green), Destructive (red), Primary (cyan/blue)

### ðŸ”§ Technical Improvements
- **File Upload System**
  - Secure file handling with validation (type, size)
  - Automatic directory creation
  - Unique filename generation with timestamp
  - Server-side validation in API
  
- **Database Schema**
  - PENDING status support in Transaction model
  - JSON metadata field for flexible data storage
  - Indexed queries for better performance

- **Code Quality**
  - TypeScript interfaces for all data structures
  - Async/await error handling
  - Proper cleanup (URL.revokeObjectURL, DOM manipulation)
  - SweetAlert2 integration for consistent notifications

### ðŸ“ New Files
- `src/app/customer/topup-request/page.tsx` (310 lines)
- `src/app/admin/topup-requests/page.tsx` (280 lines)
- `src/app/api/customer/topup-request/route.ts` (95 lines)
- `src/app/api/admin/topup-requests/route.ts` (48 lines)
- `src/app/api/admin/topup-requests/[id]/approve/route.ts` (70 lines)
- `src/app/api/admin/topup-requests/[id]/reject/route.ts` (52 lines)
- `CHAT_HISTORY_2025-12-27_Session2.md` (670 lines)

**Total**: ~1,525 lines of new production code + documentation

### ðŸ“ Modified Files
- `package.json` - Version bump to 2.9.0
- `src/app/admin/pppoe/users/[id]/balance/page.tsx` - Added low balance alert, CSV export
- `src/app/customer/page.tsx` - Added low balance alert, Request Top-Up button
- `CHANGELOG.md` - This entry

### ðŸš€ Future Enhancements (v2.10.0+)
- WhatsApp/Email notifications for request status
- Payment gateway integration (Midtrans, Xendit)
- Balance Analytics Dashboard with charts
- Bulk Top-Up Support (CSV import)
- Automated approval for verified payments
- Balance transfer between users
- Agent commission tracking
- Scheduled/recurring top-ups
- PDF export format
- Advanced filtering (date range, amount range)

---

## [2.8.0] - 2025-12-27

### ðŸŽ‰ Major Features - Balance & Auto-Renewal System

#### ðŸ’° Balance/Deposit Management
- **Customer Balance Tracking**
  - Field `balance` (INT) di tabel pppoe_users
  - Saldo deposit untuk auto-renewal prepaid users
  - Transaction history dengan kategori DEPOSIT
  - Currency format support (Rp xxx.xxx)
  
- **API Endpoints**
  - `POST /api/admin/pppoe/users/[id]/deposit` - Top-up balance
  - `GET /api/admin/pppoe/users/[id]/deposit` - Get balance history
  - Amount validation (positive numbers only)
  - Payment method support (CASH, TRANSFER, etc)
  - Optional notes for each transaction

- **UI Components**
  - Balance column in users table (sortable)
  - Currency formatting helpers
  - Auto-renewal badge indicators
  - Low balance warnings (planned)

#### ðŸ”„ Auto-Renewal System (Prepaid)
- **Automatic Renewal from Balance**
  - Field `autoRenewal` (BOOLEAN) per user
  - Cron job: Daily at 8 AM WIB (`0 8 * * *`)
  - Process users expiring in 3 days
  - Balance validation before payment
  - Automatic invoice creation & payment
  - Expiry date extension by validity period
  
- **Implementation Details**
  - File: `src/lib/cron/auto-renewal.ts`
  - Function: `processAutoRenewal()`
  - RADIUS restoration if user was isolated
  - Transaction recording in income category
  - Failed renewal logging (insufficient balance)
  
- **Workflow**
  1. Check PREPAID users with autoRenewal=true
  2. Find users expiring in 3 days
  3. Validate balance >= package price
  4. Create or find pending invoice
  5. Pay from balance & deduct amount
  6. Extend expiredAt by validity period
  7. Restore in RADIUS (remove from isolir group)
  8. Send WhatsApp & Email notifications

#### ðŸ“§ Auto-Renewal Notifications
- **WhatsApp Template**
  - Type: `auto-renewal-success`
  - 9 dynamic variables (customerName, username, profileName, amount, newBalance, expiredDate, etc)
  - Formatted currency (Rp xxx.xxx)
  - Company info (name, phone)
  - Tips for maintaining balance
  
- **Email Template**
  - Type: `auto-renewal-success`
  - HTML responsive design
  - Gradient header (Modern Blue-Cyan)
  - Transaction details table
  - Auto-renewal status info box
  - Balance reminder tip box
  
- **Template Seeding**
  - File: `prisma/seeds/auto-renewal-templates.ts`
  - Both WhatsApp & Email templates
  - Variables documented in README
  - Customizable via admin UI

#### âš™ï¸ Auto-Isolir Compatibility Fix
- **Enhanced Logic**
  - Compatible dengan prepaid/postpaid system
  - Auto-isolir ONLY if:
    1. POSTPAID user expired
    2. PREPAID without autoRenewal
    3. PREPAID with autoRenewal BUT insufficient balance
  - Prevents isolating users with successful auto-renewal
  
- **Query Optimization**
  - OR conditions for different scenarios
  - Balance check integration
  - Execution order: auto-renewal BEFORE auto-isolir
  - Safe isolation window (runs after renewal)

### ðŸ› Bug Fixes

#### Prepaid/Postpaid System
- **Invoice Generation Logic**
  - Fixed prepaid invoice generation (H-7 before expiry)
  - Fixed postpaid invoice generation (billingDay based)
  - Prevented duplicate invoices
  - Correct due date calculation
  
- **Expiry Calculation**
  - POSTPAID: expiredAt = null (correct)
  - PREPAID: expiredAt extended on payment
  - Grace period handling
  - Timezone-aware date calculations

#### Balance System
- **Schema Compliance**
  - Fixed transaction category validation
  - Proper enum usage for payment methods
  - Correct foreign key relationships
  - Index optimization for queries
  
- **API Fixes**
  - Fixed deposit API params (Next.js 15 async)
  - Proper error handling & validation
  - Transaction atomicity (Prisma)
  - Rollback on failure

#### Auto-Renewal
- **RADIUS Integration**
  - Proper radcheck/radusergroup cleanup
  - Reply-Message removal on restore
  - Profile speed limit restoration
  - Session disconnect before restore
  
- **Transaction Recording**
  - Correct category assignment (INCOME)
  - Proper description formatting
  - Payment method tracking
  - Balance calculation accuracy

### âœ… Testing & Validation

#### Test Script
- **File**: `prisma/test-auto-renewal.ts`
- **Scenarios**: 7 validation checks
  1. User creation with autoRenewal
  2. Balance sufficient check
  3. Invoice creation
  4. Auto-renewal execution
  5. Balance deduction verification
  6. Expiry extension validation
  7. Transaction recording check
  
- **Results**: âœ… ALL TESTS PASSED
  - Balance: 200,000 â†’ 100,000 (deducted correctly)
  - Invoice: Created & paid automatically
  - Expiry: Extended +30 days (profile validity)
  - Transaction: Recorded in income

#### Integration Testing
- Cron job registration: âœ… Working
- Manual trigger UI: âœ… Working
- Success handler: âœ… Shows processed count
- Execution history: âœ… Logged in cronHistory
- Template seeding: âœ… Both templates created

### ðŸ“š Documentation

#### New Documentation Files
- `docs/BALANCE_AUTO_RENEWAL.md` - Complete system documentation
- `docs/AUTO_RENEWAL_NOTIFICATION_SYSTEM.md` - Notification guide
- `ROADMAP_BILLING_FIX.md` - Updated with test results
  
#### Updated Files
- `README.md` - Added Balance & Auto-Renewal features
- `WORKFLOW_PREPAID_POSTPAID.md` - Updated workflows
- `docs/TESTING_GUIDE.md` - Added balance test cases
- `docs/CRON-SYSTEM.md` - Documented auto-renewal job

### ðŸ”§ Technical Details

#### Database Changes
- `pppoe_users.balance` - INT DEFAULT 0
- `pppoe_users.autoRenewal` - BOOLEAN DEFAULT false
- Index on balance for performance
- Transaction category DEPOSIT added

#### API Architecture
- RESTful endpoints for balance management
- Transaction atomicity with Prisma
- Error handling with proper status codes
- Validation middleware

#### Cron Configuration
- Type: `auto_renewal`
- Schedule: `0 8 * * *` (Daily 8 AM)
- Handler: `processAutoRenewal()`
- Enabled by default
- Manual trigger support

### ðŸš€ Next Steps (Planned)

- [ ] Balance Management UI (Admin Panel)
- [ ] Balance Widget (Customer Portal)
- [ ] Low Balance Alerts
- [ ] Bulk Top-up Support
- [ ] Auto-topup Integration (Payment Gateway)
- [ ] Balance Transfer Between Users
- [ ] Commission System for Agents

---

## [2.7.6] - 2025-12-24

### ðŸ“¡ GenieACS WiFi Configuration Fix

#### âœ… Features Added
- **Admin WiFi Configuration**
  - Edit SSID & Password WiFi dari admin panel
  - File: `src/app/api/genieacs/devices/[deviceId]/wifi/route.ts`
  - Separate tasks approach: SSID task terpisah dari password task
  - Dual password path untuk Huawei HG8145V5 compatibility
  
- **Customer WiFi Self-Service**
  - Customer dapat edit WiFi sendiri dari customer portal
  - File: `src/app/api/customer/wifi/route.ts`
  - Device ownership verification via PPPoE username
  - Security: Hanya customer yang memiliki device yang bisa edit
  
#### ðŸŽ¨ UI Enhancements
- **Dynamic Password Field**
  - Password field otomatis hidden untuk open network (None security)
  - Ditampilkan hanya untuk secured network (WPA/WPA2)
  - File: `src/app/admin/genieacs/devices/page.tsx`, `src/app/customer/page.tsx`
  
- **Security Badge Display**
  - Badge kuning untuk "None" security (tidak aman)
  - Badge hijau dengan Shield icon untuk "Secured"
  - Visual indicator yang jelas untuk status keamanan
  
#### ðŸ› Bug Fixes
- **GenieACS Task Errors (cwmp.9002)**
  - Root cause: Parameter conflict dengan readonly parameters
  - Solution: Separate tasks untuk SSID dan password
  - Removed: Security mode dari UI (readonly display only)
  
- **Duplicate Variable Errors**
  - Fixed: Duplicate `company` variable di `src/app/api/pppoe/users/[id]/extend/route.ts`
  - Fixed: Duplicate `authHeader` di customer WiFi API
  
- **TypeScript Errors**
  - Fixed: Security mode removal dari state interface
  - Fixed: Wrong HTTP method (PUT â†’ POST)
  - Fixed: Missing Shield icon import
  
#### ðŸ”§ Technical Details
- **Parameter Approach:**
  - Task 1: Update SSID only (`InternetGatewayDevice.LANDevice.1.WLANConfiguration.X.SSID`)
  - Task 2: Update password dengan dual path (`KeyPassphrase`, `PreSharedKey.1.KeyPassphrase`)
  - Task 3: Refresh object untuk apply changes
  
- **Validation:**
  - Password optional - bisa update SSID tanpa ubah password
  - Password di-trim sebelum validasi
  - Validation hanya jika password length > 0 setelah trim
  
- **Device Identification:**
  - Menggunakan deviceId (_id MongoDB ObjectId)
  - Bukan serialNumber untuk task endpoint
  
#### ðŸ“š Documentation
- **CHAT_HISTORY_2025-12-24.md**
  - Comprehensive documentation covering:
    - Problem summary & root cause analysis
    - Solutions & technical approach evolution
    - Testing results (5 test scenarios)
    - Files modified with detailed changes
    - Next steps & production deployment guide

### ðŸ§¹ Project Cleanup
- **Removed Duplicate Files:**
  - `SUMMARY_FIXES.md` (duplikat)
  - `IMPLEMENTATION_SUMMARY_23DEC2025.md` (duplikat)
  - `GENIEACS_WIFI_FIX.md` (sudah ada di CHAT_HISTORY)
  
- **Updated Documentation:**
  - README.md updated to v2.7.6 dengan GenieACS features
  - Remaining 9 essential MD files (cleaned & organized)

---

## [2.7.5] - 2025-12-23

### ðŸ› Bug Fixes & Improvements

#### ðŸ”§ API Routes
- **Fixed UTF-8 BOM Issue in Isolation Route**
  - Removed UTF-8 BOM from `/api/settings/isolation/route.ts`
  - Fixed 404 errors caused by incorrect file encoding
  - Route now properly compiles and returns 200 OK

#### ðŸŒ± Database Seeding
- **New Seed Scripts Added:**
  - `prisma/seeds/seed-company.ts` - Company data initialization
  - `prisma/seeds/seed-isolation-templates.ts` - Default isolation templates
  
- **Company Seed Features:**
  - Creates default company record with isolation settings
  - Required for `/api/settings/isolation` endpoint
  - Prevents 404 errors on fresh installations

- **Isolation Templates Seed:**
  - 3 default templates: WhatsApp, Email, HTML Landing Page
  - Full content with emoji support
  - Dynamic variables for personalization
  - Fixes empty template page on fresh installs

#### ðŸ“š Documentation Updates
- **Install Wizard Enhanced:**
  - Added database seeding step in installation guide
  - Updated post-installation procedures
  - Clear instructions for company and template seeding

### ðŸ” Technical Details

**Files Modified:**
- `src/app/api/settings/isolation/route.ts` - Removed BOM, fixed encoding
- `prisma/seeds/seed-company.ts` - New seed script
- `prisma/seeds/seed-isolation-templates.ts` - New seed script
- `install-wizard.html` - Updated with seeding instructions

**Database Changes:**
- Company table: Auto-populated on seed
- IsolationTemplate table: 3 default templates added

---

## [2.7.4] - 2025-12-22

### ðŸš€ Major Infrastructure Updates

#### ðŸ” FreeRADIUS 3.0.26 Integration
- **Complete RADIUS Server Implementation:**
  - FreeRADIUS 3.0.26 installation and configuration
  - MySQL database integration (salfanet_radius)
  - Multi-protocol authentication: PAP, CHAP, MS-CHAP
  - Dynamic NAS client loading from database
  - Session accounting to radacct table
  - CHAP/MS-CHAP support for MikroTik Hotspot compatibility

- **Service Configuration:**
  - Authentication port: 1812 (UDP)
  - Accounting port: 1813 (UDP)
  - CoA/DM port: 3799 (UDP) for disconnect requests
  - SQL connection pooling for performance
  - Read NAS clients dynamically from database

- **Database Schema:**
  - `nas`: NAS clients configuration
  - `radcheck`: User credentials
  - `radusergroup`: User to group mapping
  - `radgroupreply`: Group bandwidth/time attributes
  - `radacct`: Session accounting logs

#### ðŸŒ VPN L2TP/IPSec Setup
- **Secure Inter-Server Communication:**
  - strongSwan + xl2tpd installation
  - L2TP/IPSec tunnel for remote MikroTik routers
  - VPN IP pool: 172.16.17.10-20
  - Gateway IP: 172.16.17.1
  - IPSec PSK authentication
  - NAT and routing configuration

- **Network Topology:**
  ```
  VPS (103.67.244.131) <-> VPN Gateway (172.16.17.1) <-> MikroTik (172.16.17.11)
  ```

- **VPN Credentials:**
  - Username: vpn-server-radius-eza4
  - Password: 8hgvgolsQNje
  - IPSec Secret: aibill-vpn-secret

#### â° Automated Cronjob System
- **Hotspot Sync (Every Minute):**
  - File: `src/lib/cron/hotspot-sync.ts`
  - Scans radacct for first login (WAITING â†’ ACTIVE)
  - Calculates expiresAt based on profile validity
  - Detects expired vouchers (ACTIVE â†’ EXPIRED)
  - **Auto-Disconnect:** Sends CoA Disconnect to active sessions
  - **Cleanup:** Removes expired users from FreeRADIUS tables

- **PPPoE Auto-Isolir (Every Hour):**
  - File: `src/lib/cron/pppoe-sync.ts`
  - Finds expired PPPoE users
  - Moves to 'isolir' group with limited bandwidth
  - Sends CoA Disconnect for re-authentication
  - Updates status to SUSPENDED

- **Cron Configuration:**
  - File: `src/lib/cron/config.ts`
  - node-cron scheduler
  - Manual trigger via UI and API
  - Execution logging to cron_history table

#### ðŸ”Œ CoA (Change of Authorization) Service
- **Real-time Session Control:**
  - File: `src/lib/services/coaService.ts`
  - Send disconnect requests using radclient
  - Support for Framed-IP-Address and Session-ID
  - Automatic NAS IP resolution (public/local)
  - Batch disconnect for multiple users

- **Functions:**
  - `sendCoADisconnect()`: Send disconnect to specific user
  - `disconnectExpiredSessions()`: Auto-disconnect all expired vouchers
  - `disconnectPPPoEUser()`: Disconnect PPPoE user by username
  - `disconnectMultiplePPPoEUsers()`: Batch disconnect

- **radclient Integration:**
  - Uses freeradius-utils package
  - CoA port 3799 (RFC 5176)
  - Packet attributes: User-Name, Framed-IP-Address, Acct-Session-Id

#### ðŸ“¨ Custom Reply-Message for Expired Vouchers
- **MikroTik Log Integration:**
  - Expired vouchers show "Kode Voucher Kadaluarsa" instead of "invalid username or password"
  - Reply-Message stored in `radreply` table
  - Password set to "EXPIRED" in `radcheck` to prevent authentication
  - Works with MikroTik HTTP-CHAP authentication

- **Implementation:**
  - File: `src/lib/cron/hotspot-sync.ts`
  - Automatically adds Reply-Message when voucher expires
  - Removes from radusergroup (bandwidth limits)
  - Keeps username in radcheck for rejection with custom message

### âœ¨ New Features

#### ðŸ“Š Cron Management UI
- **Admin Page:** `/admin/settings/cron`
- View all configured cron jobs
- Manual trigger with "Run Now" button
- Real-time status updates
- Execution history with logs
- Enable/disable individual jobs
- Duration and result tracking

#### ðŸŽ›ï¸ Session Management Enhancements
- **Hotspot Sessions:** `/admin/sessions/hotspot`
- Real-time active session monitoring
- Auto-refresh every 30 seconds
- Display username, IP, MAC, router, uptime
- Upload/download statistics
- Manual disconnect button

- **Session Data:**
  - Fetched from radacct table
  - Grouped by router
  - Filter by active/stopped sessions
  - Export to CSV/Excel

### ðŸ—ƒï¸ Database Changes

#### New Tables
- **cron_history:**
  ```sql
  CREATE TABLE cron_history (
    id VARCHAR(191) PRIMARY KEY,
    jobType VARCHAR(191) NOT NULL,
    status VARCHAR(191) NOT NULL,
    result TEXT,
    duration INT,
    startedAt DATETIME(3) NOT NULL,
    completedAt DATETIME(3),
    createdAt DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3)
  );
  ```

#### Modified Tables
- **hotspot_vouchers:**
  - Added `firstLoginAt DATETIME(3)` - First RADIUS login timestamp
  - Added `expiresAt DATETIME(3)` - Calculated expiry time
  - Status enum: WAITING, ACTIVE, EXPIRED

- **routers:**
  - Mapped to FreeRADIUS 'nas' table
  - ipAddress: Public IP for CoA requests
  - nasname: IP used by RADIUS (can be local/VPN)
  - secret: Shared secret for RADIUS

### ðŸ“ Configuration Files

#### FreeRADIUS Site Config
- **File:** `/etc/freeradius/3.0/sites-enabled/default`
- Added CHAP and MS-CHAP to authorize section
- Added Auth-Type CHAP and MS-CHAP handlers
- Enabled SQL for accounting and post-auth
- Session tracking via SQL

#### VPN Configuration Files
- `/etc/ipsec.conf` - IPSec daemon configuration
- `/etc/ipsec.secrets` - Pre-shared keys
- `/etc/xl2tpd/xl2tpd.conf` - L2TP server settings
- `/etc/ppp/options.xl2tpd` - PPP options
- `/etc/ppp/chap-secrets` - VPN user credentials

#### Firewall Rules
- **UFW:**
  - Port 1812/udp - RADIUS Authentication
  - Port 1813/udp - RADIUS Accounting
  - Port 3799/udp - RADIUS CoA/DM
  - Port 500/udp - IPSec IKE
  - Port 4500/udp - IPSec NAT-T
  - Port 1701/udp - L2TP

- **iptables NAT:**
  ```bash
  iptables -t nat -A POSTROUTING -s 172.16.17.0/24 -o eth0 -j MASQUERADE
  ```

### ðŸ”§ Installation Scripts

#### New Installation Script
- **File:** `freeradius-vpn-setup.sh`
- Automated FreeRADIUS installation
- VPN L2TP/IPSec configuration
- Database schema import
- Firewall setup
- Service management
- Complete summary display

#### Usage:
```bash
chmod +x freeradius-vpn-setup.sh
sudo ./freeradius-vpn-setup.sh
```

### ðŸ§ª Testing & Verification

#### Test Scripts Created
- `check-voucher.js` - Check voucher status and sessions
- `check-qjklfa.js` - Detailed voucher analysis
- `check-after-sync.js` - Verify sync results
- `set-expired.js` - Manually set voucher to expired
- `test-auto-disconnect.js` - Complete auto-disconnect test

#### Test Commands
```bash
# Test RADIUS authentication
echo "User-Name=test,User-Password=test" | radclient -x localhost:1812 auth secret123

# Test CoA disconnect
echo -e "User-Name=\"user\"\nFramed-IP-Address=192.168.1.100" | radclient -x 172.16.17.11:3799 disconnect secret123

# Test hotspot sync manually
curl -X POST http://localhost:3000/api/cron -H "Content-Type: application/json" -d '{"jobType":"hotspot_sync"}'
```

### ðŸ“š Documentation Updates

#### New Documentation Files
- **CHAT_MEMORY_V2.7.4.md:**
  - Complete session history
  - FreeRADIUS installation guide
  - VPN setup instructions
  - Cronjob system documentation
  - CoA service details
  - Troubleshooting guide
  - Testing procedures

- **freeradius-vpn-setup.sh:**
  - Automated installation script
  - Configuration examples
  - Next steps guide
  - Log locations

### ðŸ› Bug Fixes

#### FreeRADIUS Configuration
- **Fixed:** Config too minimal causing crash loop
- **Fixed:** EAP module references (removed, not needed for hotspot)
- **Fixed:** CHAP/MS-CHAP authentication support added
- **Fixed:** Accounting not working (added sql to accounting section)

#### Hotspot Sync Cronjob
- **Fixed:** Status enum mismatch (USED â†’ ACTIVE)
- **Fixed:** Field name errors (usedAt â†’ firstLoginAt, expiredAt â†’ expiresAt)
- **Fixed:** Timezone issues with UTC vs WIB
- **Fixed:** Missing CoA disconnect on expiry

#### Database Schema
- **Fixed:** Prisma enum validation errors
- **Fixed:** Missing indexes on radacct table
- **Fixed:** Foreign key constraints for NAS table

### âš¡ Performance Improvements

- **Cron Job Optimization:**
  - Prevent concurrent execution with mutex lock
  - Query optimization with proper indexes
  - Batch processing for multiple vouchers
  - Error handling to prevent job failure

- **CoA Service:**
  - Connection timeout: 5 seconds
  - Retry mechanism for failed disconnects
  - Async parallel disconnect for multiple users

- **Database Queries:**
  - Added indexes on username, acctstoptime
  - Select only required fields
  - Use findFirst instead of findMany where possible

### ðŸ”’ Security Enhancements

- **RADIUS:**
  - Encrypted password storage in radcheck
  - Shared secret for NAS authentication
  - Session tracking for security audit

- **VPN:**
  - IPSec PSK authentication
  - Encrypted L2TP tunnel
  - IP pool isolation
  - NAT for traffic masquerading

- **CoA:**
  - NAS secret validation
  - IP-based access control
  - Session ID verification

### ðŸ“¦ Dependencies

#### System Packages Added
- `freeradius` - RADIUS server
- `freeradius-mysql` - MySQL driver for FreeRADIUS
- `freeradius-utils` - radclient utility
- `strongswan` - IPSec daemon
- `xl2tpd` - L2TP server
- `iptables-persistent` - Save iptables rules

#### NPM Packages (Existing)
- `node-cron` - Cron job scheduler
- `nanoid` - Unique ID generator
- `@prisma/client` - Database ORM

### ðŸŽ¯ Next Steps

**Planned Features:**
1. Real-time RADIUS statistics dashboard
2. Bandwidth usage graphs per voucher
3. Multi-server RADIUS cluster
4. Webhook notifications for voucher events
5. QR code authentication
6. Mobile app integration

**Performance Optimization:**
1. Redis cache for active sessions
2. Batch processing for large datasets
3. Database connection pooling
4. Async job queue (Bull/BullMQ)

---

## [2.7.3] - 2025-12-20

### âœ¨ New Features & Major Improvements

#### ðŸ›¡ï¸ Isolation System (Auto Isolir Customer)
- **Complete Isolation Feature:**
  - Auto-isolate expired customers with limited bandwidth
  - Custom IP pool and rate limit for isolated users
  - DNS and payment page access control
  - Grace period before isolation
  - Redirect to custom landing page
- **Database Schema:**
  - Added isolation fields to company table (isolationEnabled, isolationIpPool, isolationRateLimit, etc.)
  - Created isolationTemplate table for notification templates
  - Support for WhatsApp, Email, and HTML landing page templates
- **Settings Pages:**
  - `/admin/settings/isolation` - Main isolation settings
  - `/admin/settings/isolation/templates` - Template management (WhatsApp, Email, HTML)
  - `/admin/settings/isolation/mikrotik` - Auto-generated MikroTik scripts
- **Default Templates:**
  - WhatsApp notification template
  - Professional HTML email template
  - Beautiful landing page for isolated users
- **MikroTik Integration:**
  - Auto-generate configuration scripts based on settings
  - IP pool creation script
  - PPP profile configuration
  - Firewall rules for DNS and payment access
  - Walled garden for redirect
  - Download as .rsc file or copy to clipboard

#### ðŸŽ¨ Design System Standardization
- **Teal/Cyan Theme Applied Across:**
  - All isolation settings pages
  - Admin tickets page
  - Coordinator pages
  - Inventory items page
  - Technician dashboard
  - Isolated customer page
- **Consistent Font Sizes:**
  - Headers: `text-lg font-semibold`
  - Descriptions: `text-xs text-gray-500`
  - Labels: `text-[10px] uppercase tracking-wider`
  - Inputs: `px-3 py-1.5 text-sm`
  - Icons: `w-5 h-5` or `w-4 h-4`
- **Compact Spacing:**
  - Card padding: `p-3` or `p-4`
  - Grid gaps: `gap-3`
  - Table cells: `px-3 py-2`
- **Consistent Components:**
  - Toggle switches: `peer-checked:bg-teal-600`
  - Focus rings: `ring-teal-500`
  - Buttons: `bg-teal-600 hover:bg-teal-700`

#### ðŸ› Bug Fixes

**GenieACS WiFi Edit Form Fix:**
- **Problem:** When selecting different WLAN Index in dropdown, form fields (SSID, Security, Password) didn't update
- **Solution:** 
  - Added `handleWlanIndexChange` function
  - Auto-loads WLAN data when index changes
  - Updates SSID, Security Mode, and Enabled status
  - Clears password for security
  - Normalizes security mode format
- **File:** `src/app/admin/genieacs/devices/page.tsx`

**Database Schema Migration:**
- **Fixed:** Missing isolation fields in main database
- **Added:** Complete isolation schema to `prisma/schema.prisma`
- **Migration:** Created seed file for isolation templates
- **Commands:** `npx prisma db push` and `npx prisma generate`

### ðŸ“ Updated Files
- `prisma/schema.prisma` - Added isolation fields and isolationTemplate model
- `prisma/seeds/isolation-templates.ts` - Default templates seed
- `src/app/admin/settings/isolation/page.tsx` - Main settings
- `src/app/admin/settings/isolation/templates/page.tsx` - Template editor
- `src/app/admin/settings/isolation/mikrotik/page.tsx` - MikroTik scripts
- `src/app/api/settings/isolation/route.ts` - Settings API
- `src/app/api/settings/isolation/templates/route.ts` - Templates API
- `src/app/admin/genieacs/devices/page.tsx` - WiFi edit fix

### ðŸŽ¯ Technical Improvements
- Consistent theme colors across all pages
- Smaller, more compact UI elements
- Better mobile responsiveness
- Improved form handling in GenieACS
- Complete isolation system infrastructure

## [2.7.2] - 2025-12-19

### âœ¨ New Features & Improvements

#### Template "Perbaikan Selesai" (Maintenance Resolved) ðŸ“§
- **Added:** Template baru untuk notifikasi perbaikan selesai dan layanan kembali normal
- **WhatsApp Template:**
  - Type: `maintenance-resolved`
  - Fitur: Status normal, informasi perbaikan, tips reconnect
  - Variabel: customerName, username, description, companyName, companyPhone
- **Email Template:**
  - Design: Responsive HTML dengan success theme (hijau)
  - Format: Professional dengan checklist status
  - Fitur: Tips jika masih ada kendala
- **Use Case:** Broadcast setelah maintenance/gangguan selesai diperbaiki

#### Responsive UI Improvements ðŸ“±
- **WhatsApp Templates Page:**
  - Horizontal scrollable tabs di mobile dengan custom scrollbar
  - Responsive text size (base â†’ lg â†’ xl)
  - Responsive padding dan spacing
  - Button layout: vertical di mobile, horizontal di desktop
  - Variable buttons: responsive text size
- **Email Templates Page:**
  - Horizontal scrollable tabs dengan min-w-max di mobile
  - Flex-wrap di tablet/desktop
  - Responsive description box dengan proper text wrapping
  - Adaptive padding: p-3 â†’ p-4 â†’ p-6
- **Breakpoints:** mobile (default), sm (640px), md (768px)
- **Features:**
  - Custom scrollbar styling (thin, gray)
  - Whitespace nowrap untuk tab labels
  - Text truncation dengan line-clamp
  - Flexible layouts dengan flex-1 min-w-0

#### Email History Date Fix ðŸ›
- **Fixed:** "Invalid Date" pada kolom DATE & TIME di email history
- **Root Cause:** Frontend menggunakan `email.createdAt` yang tidak ada
- **Solution:**
  - Changed: `email.createdAt` â†’ `email.sentAt` (sesuai API response)
  - Added: Conditional check untuk handle null/undefined
  - Added: Fallback "-" jika date tidak tersedia
- **Format:** Indonesia locale dengan jam:menit
- **File:** `src/app/admin/settings/email/page.tsx`

### ðŸ“ Updated Documentation
- Email history bug fix details
- Template maintenance-resolved usage guide
- Responsive UI implementation notes

## [2.7.1] - 2025-12-19

### ðŸ”§ Improvements & Bug Fixes

#### Seeds File Consolidation ðŸ—‚ï¸ (NEW)
- **Reduced:** File count dari 18 â†’ 7 files (61% reduction)
- **Deleted SQL Files (11 total):**
  - Consolidated emoji fixes â†’ `fix-emoji.js`
  - Consolidated template fixes â†’ `seed-templates.js`
  - Consolidated voucher fixes (v6-v12) â†’ `seed-voucher.js`
- **New Consolidated Seeders:**
  - `fix-emoji.js` - Enhanced with template validation
  - `seed-templates.js` - All notification templates (WhatsApp + Email)
  - `seed-voucher.js` - Latest voucher template (v12 optimized)
- **Benefits:**
  - Better code organization
  - Idempotent operations (safe to run multiple times)
  - Easier maintenance and updates
  - Better error handling and logging
  - Auto-integrated with VPS installers
- **Documentation:** `SEEDS_CONSOLIDATION.md`

#### Invoice Number Format Enhancement â­
- **Changed:** Invoice number dari random code ke format berdasarkan tanggal
- **New Format:** `INV-YYYYMM-XXXX` (contoh: INV-202512-0001)
- **Benefits:**
  - Sequential counter per bulan untuk tracking mudah
  - Professional dan konsisten dengan standar bisnis
  - Mudah identifikasi bulan pembuatan invoice
  - Auto-increment dari database untuk prevent duplikat
- **New Library:** `src/lib/invoice-generator.ts` dengan helper functions:
  - `generateInvoiceNumber()` - Format: INV-YYYYMM-XXXX
  - `generateTransactionId()` - Format: TRX-YYYYMMDD-HHMMSS-XXXX
  - `generateCategoryId()` - Format: CAT-YYYYMMDD-HHMMSS
  - `generateInvoiceId()` - Format: inv-YYYYMMDD-HHMMSS-XXXX
- **Updated Files:**
  - `src/app/api/pppoe/users/[id]/extend/route.ts` - Perpanjangan manual
  - `src/app/api/pppoe/users/[id]/mark-paid/route.ts` - Mark as paid
  - `src/app/api/manual-payments/[id]/route.ts` - Manual payment approval
- **Documentation:** `docs/INVOICE_NUMBER_FORMAT.md` dengan testing guide
- **Backward Compatible:** Invoice lama tetap valid, hanya invoice baru yang gunakan format tanggal

#### WhatsApp Template Emoji Fix ðŸ“±
- **Fixed:** Emoji tidak terbaca dengan benar di template manual-extension
- **Issue:** Character encoding menyebabkan emoji muncul sebagai `Â­Æ’Ã¦Ã±`, `Â­Æ’Ã´Âª`, `Â­Æ’Ã†â–‘`, dll
- **Solution:** Update template via Prisma dengan UTF-8 encoding
- **Affected Template:** manual-extension (WhatsApp)
- **Script:** `prisma/seeds/fix-emoji.js` untuk update database

## [2.7.0] - 2025-12-19

### ðŸŽ‰ Major Features from salfanet-radius Integration

#### Manual Payment System â­
- **New Feature:** Customer dapat upload bukti transfer untuk pembayaran manual
- **Admin Workflow:** Approve/reject payment dengan notifikasi otomatis
- **Auto Extension:** User expiry otomatis diperpanjang saat payment approved
- **Multi-Channel Notification:** WhatsApp & Email notification untuk approval/rejection
- **Bank Accounts:** Multiple bank account configuration di company settings
- **Public Payment Page:** Customer access payment form via unique token
- **File Upload:** Support JPG/PNG/WebP, max 5MB dengan validation
- **Receipt Storage:** Uploaded images served securely via API endpoint

**Database Changes:**
- New table: `manual_payments`
- New enum: `ManualPaymentStatus` (PENDING, APPROVED, REJECTED)
- Fields: userId, invoiceId, amount, paymentDate, bankName, accountName, receiptImage, notes, status

**API Endpoints:**
- `GET /api/manual-payments` - List all manual payments
- `GET /api/manual-payments/[id]` - Get single payment detail
- `POST /api/manual-payments` - Submit new payment
- `PATCH /api/manual-payments/[id]` - Approve/reject payment
- `DELETE /api/manual-payments/[id]` - Delete payment record
- `POST /api/upload/payment-proof` - Upload receipt image
- `GET /uploads/payment-proofs/[filename]` - Serve uploaded image
- `GET /api/pay/manual?token=xxx` - Public payment info by token

**Frontend Pages:**
- `/admin/manual-payments` - Admin payment approval dashboard
- `/pay-manual?token=xxx` - Public manual payment submission form

**Files Created:**
- `src/app/api/manual-payments/route.ts`
- `src/app/api/manual-payments/[id]/route.ts`
- `src/app/api/upload/payment-proof/route.ts`
- `src/app/uploads/payment-proofs/[filename]/route.ts`
- `src/app/api/pay/manual/route.ts`

---

#### Broadcast Notification System ðŸ“¢
- **New Feature:** Bulk notification ke multiple users sekaligus
- **Three Types:** Outage/Maintenance, Invoice Reminder, Payment Confirmation
- **Multi-Channel:** WhatsApp dan Email dengan template customizable
- **Smart Filtering:** Auto-skip users tanpa invoice atau data yang diperlukan
- **Variable Replacement:** Dynamic template variables untuk personalization
- **Batch Processing:** Success/failure count dengan detailed error messages

**Notification Types:**

1. **Outage/Maintenance Notification:**
   - Manual input: Issue Type, Description, Estimated Time, Affected Area
   - Use case: Informasi gangguan jaringan atau maintenance terjadwal
   - Template: `maintenance-outage`

2. **Invoice Reminder Broadcast:**
   - Auto-fetch: Latest invoice per user
   - Include: Payment link, due date, amount
   - Template: `invoice-reminder`

3. **Payment Confirmation Broadcast:**
   - Auto-fetch: Latest paid invoice
   - Include: Expiry date extension, payment details
   - Template: `payment-success`

**API Endpoint:**
- `POST /api/pppoe/users/send-notification`

**Request Format:**
```json
{
  "userIds": ["id1", "id2"],
  "notificationType": "outage|invoice|payment",
  "notificationMethod": "whatsapp|email|both",
  "issueType": "...",      // For outage
  "description": "...",    // For outage
  "estimatedTime": "...",  // For outage
  "affectedArea": "...",   // For outage
  "additionalMessage": ""  // Optional for invoice/payment
}
```

**Files Created:**
- `src/app/api/pppoe/users/send-notification/route.ts`

---

#### Customer ID Field ðŸ†”
- **New Field:** 8-digit unique customer identifier
- **Purpose:** Easier customer identification dan reference
- **Auto-Generate:** System dapat generate ID otomatis
- **Indexing:** Indexed untuk quick lookup
- **Display:** Ditampilkan di customer list dan notifications

**Database Changes:**
```sql
ALTER TABLE pppoe_users
ADD COLUMN customer_id VARCHAR(8) UNIQUE;
```

---

#### Subscription Type ðŸ’³
- **New Field:** Klasifikasi POSTPAID vs PREPAID
- **Payment Tracking:** lastPaymentDate untuk tracking pembayaran
- **Filtering:** Filter customers by subscription type
- **Billing Logic:** Different logic untuk prepaid/postpaid customers

**Database Changes:**
```sql
ALTER TABLE pppoe_users
ADD COLUMN subscriptionType ENUM('POSTPAID', 'PREPAID') DEFAULT 'POSTPAID',
ADD COLUMN lastPaymentDate DATETIME;
```

**New Enum:**
```typescript
enum SubscriptionType {
  POSTPAID   // Pascabayar (bayar belakangan)
  PREPAID    // Prabayar (bayar di muka)
}
```

---

#### Bank Accounts Configuration ðŸ¦
- **Multi-Bank Support:** Configure multiple bank accounts (0-5 accounts)
- **JSON Storage:** Flexible bank account data structure
- **Display:** Show bank accounts in manual payment page
- **Invoice Generation:** Configure days before expiry to auto-generate invoice

**Database Changes:**
```sql
ALTER TABLE companies
ADD COLUMN bankAccounts JSON,
ADD COLUMN invoiceGenerateDays INT DEFAULT 7;
```

**Bank Account Structure:**
```json
{
  "bankName": "BCA",
  "accountNumber": "1234567890",
  "accountName": "PT Example"
}
```

**Features:**
- Dynamic bank account input form
- Add/remove accounts easily
- Display all accounts in payment form
- Customer select bank from dropdown

---

#### Batch WhatsApp Processing ðŸ“±
- **Batch Size:** Configure messages per batch (default: 10)
- **Batch Delay:** Delay between batches in seconds (default: 60)
- **Randomization:** Randomize message order to avoid pattern detection
- **Anti-Spam:** Prevent WhatsApp ban/blocking from bulk sending

**Database Changes:**
```sql
ALTER TABLE whatsapp_reminder_settings
ADD COLUMN batchSize INT DEFAULT 10,
ADD COLUMN batchDelay INT DEFAULT 60,
ADD COLUMN randomize BOOLEAN DEFAULT TRUE;
```

**Configuration:**
- Admin â†’ Settings â†’ WhatsApp â†’ Reminder Settings
- Adjustable based on provider limits
- Helps maintain WhatsApp account health

---

#### Registration GPS Coordinates ðŸ“
- **Location Data:** Latitude & longitude in registration form
- **Use Cases:** Customer mapping, distance calculation, area planning
- **Optional Fields:** Not required but recommended

**Database Changes:**
```sql
ALTER TABLE registration_requests
ADD COLUMN latitude FLOAT,
ADD COLUMN longitude FLOAT;
```

---

### ðŸ“§ Email & WhatsApp Templates Added

**New WhatsApp Templates:**
1. `manual-payment-approval` - Pembayaran diterima & akun diaktifkan
2. `manual-payment-rejection` - Pembayaran ditolak dengan alasan
3. `maintenance-outage` - Informasi gangguan jaringan

**New Email Templates:**
1. `manual-payment-approval` - HTML email untuk approval
2. `manual-payment-rejection` - HTML email untuk rejection dengan reupload link
3. `maintenance-outage` - HTML email untuk broadcast gangguan

**Template Variables:**
- `{{customerName}}` - Nama customer
- `{{customerId}}` - Customer ID
- `{{username}}` - Username PPPoE
- `{{invoiceNumber}}` - Nomor invoice
- `{{amount}}` - Jumlah (formatted Rupiah)
- `{{expiredDate}}` - Tanggal expired
- `{{rejectionReason}}` - Alasan reject
- `{{paymentLink}}` - Link pembayaran
- `{{issueType}}` - Jenis gangguan
- `{{description}}` - Deskripsi gangguan
- `{{estimatedTime}}` - Estimasi pemulihan
- `{{affectedArea}}` - Area terdampak
- `{{companyName}}` - Nama perusahaan
- `{{companyPhone}}` - Telepon perusahaan
- `{{companyEmail}}` - Email perusahaan
- `{{baseUrl}}` - Base URL aplikasi

---

### ðŸ—„ï¸ Database Schema Updates

**Modified Tables:**
1. `companies` - bankAccounts (JSON), invoiceGenerateDays (INT)
2. `pppoe_users` - customerId (VARCHAR), subscriptionType (ENUM), lastPaymentDate (DATETIME)
3. `registration_requests` - latitude (FLOAT), longitude (FLOAT)
4. `whatsapp_reminder_settings` - batchSize (INT), batchDelay (INT), randomize (BOOLEAN)
5. `invoices` - relation to manualPayments

**New Tables:**
1. `manual_payments` - Manual payment records with approval workflow

**New Enums:**
1. `SubscriptionType` - POSTPAID, PREPAID
2. `ManualPaymentStatus` - PENDING, APPROVED, REJECTED

---

### ðŸ“ Migration & Installation

**Migration File:**
- `prisma/migrations/add_manual_payment_features/migration.sql`

**Installation Steps:**
```bash
# 1. Update dependencies
npm install

# 2. Generate Prisma client
npx prisma generate

# 3. Push schema changes
npx prisma db push

# 4. Create upload directory
mkdir -p public/uploads/payment-proofs

# 5. Restart application
npm run build && npm start
```

**Manual Migration (if needed):**
```bash
mysql -u root -p your_database < prisma/migrations/add_manual_payment_features/migration.sql
```

---

### ðŸ“š Documentation Added

**New Documentation:**
- `docs/NEW_FEATURES_V2.7.0.md` - Complete feature documentation
- Migration SQL with templates included
- API endpoint documentation
- Usage guide for admin and customers
- Troubleshooting section

**Reference Documentation (from salfanet-radius):**
- `salfanet-radius/docs/MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md`
- `salfanet-radius/docs/OUTAGE_NOTIFICATION_SYSTEM.md`
- `salfanet-radius/docs/BROADCAST_NOTIFICATION_SYSTEM.md`

---

### âœ… Benefits

**For Admin:**
- âœ… Manual payment approval workflow tanpa harus manual extend user
- âœ… Upload receipt verification sebelum aktivasi
- âœ… Broadcast notification ke multiple users sekaligus
- âœ… Bank account management yang flexible
- âœ… Better customer identification dengan Customer ID
- âœ… Payment tracking dengan lastPaymentDate

**For Customer:**
- âœ… Easy payment submission dengan upload bukti transfer
- âœ… Instant notification untuk approval/rejection
- âœ… Multiple bank account options
- âœ… Clear payment status tracking
- âœ… Automatic account reactivation on approval

**For System:**
- âœ… Reduced manual work untuk payment verification
- âœ… Better audit trail dengan payment history
- âœ… Flexible notification system untuk berbagai use cases
- âœ… Anti-spam WhatsApp dengan batch processing
- âœ… Better customer segmentation dengan subscription type

---

### ðŸ”§ Configuration Required

**After Installation:**

1. **Company Settings:**
   - Navigate to: Admin â†’ Settings â†’ Company
   - Add bank accounts (recommended 2-3 accounts)
   - Set invoice generation days (default: 7)

2. **WhatsApp Batch Settings:**
   - Navigate to: Admin â†’ Settings â†’ WhatsApp
   - Configure batch size (start with 10)
   - Set batch delay (recommended 60 seconds)
   - Enable randomization

3. **Review Templates:**
   - Navigate to: Admin â†’ WhatsApp â†’ Templates
   - Customize manual payment templates
   - Customize outage notification template

4. **Test Manual Payment:**
   - Create test invoice
   - Submit manual payment via public link
   - Test approval workflow
   - Verify notifications sent

---

### ðŸŽ¯ Usage Examples

**Manual Payment (Customer):**
1. Receive invoice with payment token
2. Go to `/pay-manual?token=xxx`
3. See bank accounts and invoice details
4. Transfer to chosen bank
5. Upload receipt and submit
6. Wait for admin approval

**Manual Payment (Admin):**
1. Go to `/admin/manual-payments`
2. See pending badge count
3. Click "Detail" to view receipt
4. Approve or reject with reason
5. System auto-extends user and sends notification

**Broadcast Notification:**
1. Go to `/admin/pppoe/users`
2. Select multiple users
3. Click "Kirim Notifikasi" dropdown
4. Choose: Outage / Invoice / Payment
5. Fill required fields
6. Select WhatsApp / Email / Both
7. Submit and see results

---

### ðŸ› Bug Fixes

- Fix: Payment proof upload dengan proper validation
- Fix: Bank account JSON parsing yang robust
- Fix: Template variable replacement yang accurate
- Fix: Notification counter update yang real-time
- Fix: User expiry calculation yang correct setelah approval

---

**Files Modified:**
- `prisma/schema.prisma` - Schema updates for all new features
- `src/app/api/company/route.ts` - Bank accounts support
- `src/app/api/whatsapp/reminder-settings/route.ts` - Batch processing fields
- `CHANGELOG.md` - This changelog

**Files Created:**
- `src/app/api/manual-payments/route.ts`
- `src/app/api/manual-payments/[id]/route.ts`
- `src/app/api/upload/payment-proof/route.ts`
- `src/app/uploads/payment-proofs/[filename]/route.ts`
- `src/app/api/pay/manual/route.ts`
- `src/app/api/pppoe/users/send-notification/route.ts`
- `prisma/migrations/add_manual_payment_features/migration.sql`
- `docs/NEW_FEATURES_V2.7.0.md`

---

## [2.6.4] - 2025-12-18

### ï¿½ Dashboard Network Overview Fix

#### Dashboard Network Data Consistency
- **Fix:** Data di "Ringkasan Jaringan" tidak sesuai dengan "Sesi Aktif" di Stats Cards
- **Cause:** Network Overview menggunakan data user/voucher status, bukan sessions dari radacct
- **Solution:** Ubah agar Network Overview menggunakan session count dari radacct
- **Impact:** Data PPPoE Users dan Hotspot Sessions di Network Overview sekarang konsisten dengan Stats Cards

#### Session Counting Optimization
- **Fix:** N+1 query performance issue saat menghitung PPPoE vs Hotspot sessions
- **Solution:** Batch fetch - ambil semua sessions sekali, lalu batch lookup ke pppoeUser
- **Impact:** Dashboard loading lebih cepat

**Files Modified:**
- `src/app/api/dashboard/stats/route.ts` - Fix network data source, optimize sessions query

---

### ï¿½ðŸ• Session Timezone Fix & Hotspot Session Improvements

#### Session Start Time Timezone Fix
- **Fix:** Start Time di Sesi Hotspot menampilkan waktu berbeda 7 jam dari First Login di Voucher
- **Cause:** API sessions mengirim datetime dengan 'Z' suffix (UTC) sementara voucher API tanpa 'Z' (WIB)
- **Solution:** Format datetime di sessions API tanpa 'Z' suffix untuk konsistensi dengan voucher
- **Impact:** Start Time dan First Login sekarang menampilkan waktu yang sama (WIB)

#### Hotspot Session Deduplication
- **Fix:** Session hotspot tercatat dua kali saat voucher reconnect
- **Solution:** Deduplicate sessions per username, hanya tampilkan session terbaru
- **Logic:** Gunakan Map untuk filter, simpan session dengan acctupdatetime/acctstarttime paling baru

#### Expired Voucher Auto-Disconnect Fix
- **Fix:** Voucher yang sudah expired tidak di-disconnect otomatis oleh cron
- **Cause:** `disconnectExpiredSessions` hanya cek `status === 'EXPIRED'`, tapi status belum diupdate
- **Solution:** Cek juga `expiresAt < now` untuk deteksi expired yang lebih akurat
- **Enhancement:** Auto-update voucher status ke EXPIRED setelah disconnect

#### PPPoE Profile Change - Use Disconnect Instead of CoA
- **Fix:** CoA untuk ganti profile PPPoE tidak berfungsi di MikroTik
- **Cause:** MikroTik hanya support CoA untuk rate-limit change, bukan PPP profile change
- **Solution:** Ganti dari CoA ke Disconnect, user akan reconnect dengan profile baru
- **Impact:** Profile change sekarang efektif, user disconnect dan auto-reconnect

#### PPPoE Profile - Allow Duplicate Group Name
- **Fix:** Error 400 saat membuat PPP Profile dengan groupName yang sama
- **Solution:** Hapus `@unique` constraint dari groupName di Prisma schema
- **Enhancement:** Skip pembuatan radgroupreply jika group sudah ada
- **Default:** groupName default kembali ke 'salfanetradius' (seperti voucher profile)

#### PPPoE Sessions - Remove Mitra Column
- **Change:** Hapus kolom "Mitra" dari halaman Sesi PPPoE
- **Reason:** Kolom tidak relevan untuk PPPoE users

**Files Modified:**
- `src/app/api/sessions/route.ts` - Timezone fix (hapus 'Z' suffix), session deduplication
- `src/lib/services/coaService.ts` - Cek expiresAt untuk expired detection
- `src/app/api/pppoe/users/route.ts` - Use disconnect instead of CoA for profile change
- `prisma/schema.prisma` - Remove unique constraint dari groupName
- `src/app/api/pppoe/profiles/route.ts` - Skip radgroupreply if exists
- `src/app/admin/pppoe/profiles/page.tsx` - Default groupName 'salfanetradius'
- `src/app/admin/sessions/pppoe/page.tsx` - Remove Mitra column

**Technical Details:**
```typescript
// Timezone fix - sessions/route.ts
const startTimeFormatted = session.acctstarttime 
  ? session.acctstarttime.toISOString().replace('Z', '') 
  : null;

// Expired detection - coaService.ts
const isExpired = voucher.status === 'EXPIRED' || 
  (voucher.expiresAt && new Date(voucher.expiresAt) < now);

// Session deduplication - sessions/route.ts
const latestSessionMap = new Map<string, Session>();
for (const session of radacctSessions) {
  // Keep only most recent per username
}
```

---

## [2.6.3] - 2025-12-18

### ðŸ“¡ FreeRADIUS PPPoE Realm Fix & PPP Profile Enhancement

#### RADIUS Authentication Fix for PPPoE Users with Realm
- **Fix:** User PPPoE dengan format `username@realm` (e.g., `deliarianti@cimerta`) tidak bisa autentikasi
- **Cause:** Policy di `/etc/freeradius/3.0/policy.d/filter` menolak realm tanpa dot separator
- **Solution:** Comment out validasi dot separator untuk mengizinkan realm seperti `@cimerta`, `@rw01`
- **Impact:** Semua PPPoE user dengan format realm pendek sekarang bisa autentikasi

#### PPP Profile - Auto Generate Group Name
- **Fix:** Error 400 Bad Request saat menambah profile baru dengan groupName yang sama
- **Solution:** Auto-generate `groupName` dari nama profile (slug format)
- **Enhancement:** Error message lebih jelas menunjukkan profile mana yang sudah menggunakan groupName
- **Example:** Profile "Paket 10 Mbps" â†’ groupName "paket-10-mbps"

#### FreeRADIUS Config Backup
- **New File:** `freeradius-config/policy.d-filter` - Backup policy dengan PPPoE realm support
- **New File:** `freeradius-config/freeradius-backup-20251218.tar.gz` - Full backup config
- **Updated:** `vps-install.sh` - Tambah restore policy.d-filter
- **Updated:** `vps-update.sh` - Tambah Step 5 untuk update FreeRADIUS config
- **Updated:** `install-wizard.html` - Instruksi policy.d-filter

**Files Modified:**
- `/etc/freeradius/3.0/policy.d/filter` - Comment out dot separator validation
- `freeradius-config/policy.d-filter` - New backup file
- `vps-install.sh` - Add policy.d-filter restore
- `vps-update.sh` - Add FreeRADIUS config update step
- `install-wizard.html` - Add policy.d-filter instructions
- `docs/FREERADIUS-SETUP.md` - PPPoE realm documentation
- `freeradius-config/README-BACKUP.md` - Add policy.d-filter to file list
- `src/app/admin/pppoe/profiles/page.tsx` - Auto-generate groupName from profile name
- `src/app/api/pppoe/profiles/route.ts` - Enhanced error message for duplicate group

**Testing:**
```bash
# Test RADIUS auth untuk PPPoE dengan realm:
radtest deliarianti@cimerta salfanet localhost 0 testing123
# Expected: Access-Accept
```

---

## [2.6.2] - 2025-12-17

### ðŸ“§ Email Notification System Enhancement

#### Invoice Page - Email Display
- **Tambah kolom Email** di tabel halaman Tagihan Admin
- **Detail dialog** menampilkan email pelanggan dengan icon ðŸ“§
- Fallback: `invoice.customerEmail` â†’ `user.email` â†’ '-'

#### eVoucher Page - Email Field
- **Tambah input Email (opsional)** di form pembelian voucher publik
- Email disimpan ke `customerEmail` di order voucher
- Digunakan untuk pengiriman notifikasi via email

#### Payment Webhook - Email Notifications
- **Notifikasi email otomatis** saat pembelian voucher berhasil
- **Notifikasi email otomatis** saat pembayaran tagihan berhasil
- Template: `voucher-purchase` untuk voucher, `payment-success` untuk tagihan
- Email dicatat ke tabel `email_history`

#### Email Template - Invoice Overdue
- **Template baru:** `invoice-overdue` untuk pelanggan yang sudah jatuh tempo
- Tema merah dengan peringatan
- Variables: `customerId`, `customerName`, `username`, `invoiceNumber`, `amount`, `dueDate`, `daysOverdue`, `paymentLink`, `companyName`, `companyPhone`

#### Customer Name Fallback Fix
- **Perbaikan fallback** untuk nama pelanggan di email reminder
- Urutan: `invoice.customerName` â†’ `user.name` â†’ 'Pelanggan'
- Email fallback: `invoice.customerEmail` â†’ `user.email`

**Files Modified:**
- `src/app/admin/invoices/page.tsx` - Email column & detail display
- `src/app/evoucher/page.tsx` - Email input field
- `src/app/api/payment/webhook/route.ts` - Email notifications
- `src/app/api/settings/email/templates/route.ts` - Invoice overdue template
- `src/lib/cron/voucher-sync.ts` - Customer name & email fallback
- `src/app/api/cron/test-reminder/route.ts` - Customer name & email fallback
- `src/lib/email.ts` - Email utility

---

## [2.6.1] - 2025-12-16

### âš¡ Sessions Page Optimization & Full RADIUS Mode

#### Performance Optimization - Sessions Page
**Enhancement:** Optimasi halaman sesi aktif untuk loading yang lebih cepat

**Problem:** Halaman Sessions berat karena banyak API calls ke MikroTik router

**Solution:**
- Auto-refresh interval diubah dari 10s ke 30s untuk mengurangi beban
- Implementasi batch fetching untuk menghindari N+1 queries
- Data diambil sekali lalu di-map, bukan query per session

**Changes:**
- PPPoE users: Fetch semua users sekali, map by username
- Hotspot vouchers: Fetch semua vouchers sekali, map by username  
- Routers: Fetch semua routers sekali, map by id

#### Full FreeRADIUS Mode
**Enhancement:** Mode RADIUS murni tanpa koneksi API MikroTik untuk data sessions

**Problem:** Data sessions menggunakan MikroTik API yang lambat dan tidak reliable

**Solution:**
- Menghapus semua koneksi RouterOS API dari endpoint sessions
- Data diambil langsung dari tabel `radacct` FreeRADIUS
- Upload/Download dari kolom `acctinputoctets` dan `acctoutputoctets`
- Duration dari kolom `acctsessiontime` (fallback ke kalkulasi jika null)
- MAC Address dari kolom `callingstationid`

**API Response:**
```json
{
  "sessions": [...],
  "total": 100,
  "pagination": {
    "page": 1,
    "limit": 25,
    "totalPages": 4
  },
  "mode": "radius"  // Indicator full RADIUS mode
}
```

**Files Modified:**
- `src/app/api/sessions/route.ts` - Full rewrite, removed MikroTik API

#### Sessions Page UI Enhancement
**Enhancement:** Penambahan kolom dan fitur pagination

**New Columns:**
| Column | Source | Description |
|--------|--------|-------------|
| Start Time | acctstarttime | Waktu mulai session |
| Last Update | acctupdatetime | Waktu update terakhir |
| MAC Address | callingstationid | MAC Address device |

**Pagination Feature:**
- Page size selector: 10, 25, 50, 100 entries
- Navigation buttons: First, Prev, Page numbers, Next, Last
- Server-side pagination untuk performance
- Indicator "Page X of Y" dan "Showing X to Y of Z entries"

**Files Modified:**
- `src/app/admin/sessions/page.tsx` - New columns, pagination UI

#### Duration Calculation Fix
**Bug Fix:** Durasi session menampilkan nilai negatif

**Problem:** Duration bisa negatif jika acctsessiontime null dan kalkulasi salah

**Solution:**
```typescript
const durationSeconds = Math.max(0, 
  session.acctsessiontime || 
  Math.floor((now.getTime() - new Date(session.acctstarttime).getTime()) / 1000)
);
```

#### Refresh Button Fix
**Bug Fix:** Error 500 saat klik tombol Refresh

**Problem:** Stale closure di setInterval menyebabkan `page=[object Object]` di URL

**Solution:**
- Menambahkan state `currentPage` terpisah
- Validasi parameter page adalah number
- Update useEffect dependency array

**Files Modified:**
- `src/app/admin/sessions/page.tsx` - Added currentPage state, fixed closure

#### Invoice Reminder Cron Fix
**Bug Fix:** Invoice reminder tidak mengirim pesan WhatsApp untuk invoice overdue

**Problem:** Daftar hari overdue tidak lengkap `[1, 2, 3, 5, 7, 9, 10, 14, 21, 28]`. Invoice yang sudah 4, 6, atau 8 hari overdue tidak terdeteksi.

**Solution:**
- Menambahkan hari 4, 6, 8 ke daftar overdue days
- Coverage lengkap: `[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 14, 21, 28]`

**Example:** Invoice jatuh tempo 10 Desember, hari ini 16 Desember = 6 hari overdue. Sebelumnya tidak terkirim karena hari 6 tidak ada di daftar.

**Files Modified:**
- `src/lib/cron/voucher-sync.ts` - Added days 4, 6, 8 to overdue list
- `src/app/api/cron/test-reminder/route.ts` - Same fix

---

## [2.6.0] - 2025-12-15

### ðŸ“ Area Management Feature

#### New Feature: Area Management
**Enhancement:** Fitur manajemen area untuk pengelompokan pelanggan

**Database Changes:**
- Model baru `pppoeArea` dengan field: id, name, description, isActive, createdAt, updatedAt
- Field `areaId` ditambahkan ke model `pppoeUser` (relasi ke pppoeArea)

**API Endpoint:** `/api/pppoe/areas`
- GET - List semua area dengan jumlah pelanggan
- POST - Tambah area baru
- PUT - Update area
- DELETE - Hapus area (dengan validasi)

**Files Created:**
- `src/app/api/pppoe/areas/route.ts` - CRUD API untuk area
- `src/app/admin/pppoe/areas/page.tsx` - Halaman manajemen area

#### Area Management Page
**Enhancement:** Halaman untuk mengelola area pelanggan

**URL:** `/admin/pppoe/areas`

**Features:**
- Tabel area: Nama, Deskripsi, Jumlah Pelanggan, Status, Aksi
- Stats: Total Area, Area Aktif, Area Non-Aktif, Total Pelanggan
- Dialog form tambah/edit area
- Hapus area dengan validasi
- Search/filter area

#### Menu Update - Area Submenu
**Enhancement:** Submenu Area ditambahkan ke menu Langganan

**New Menu Structure:**
| Menu | URL |
|------|-----|
| Daftar Pelanggan | `/admin/pppoe/users` |
| Profile Langganan | `/admin/pppoe/profiles` |
| **Area** | `/admin/pppoe/areas` |
| Stop Langganan | `/admin/pppoe/stopped` |
| Pendaftaran Baru | `/admin/pppoe/registrations` |

**Files Modified:**
- `src/app/admin/layout.tsx` - Added Area submenu

#### Customer List - Area Integration
**Enhancement:** Filter dan kolom Area di daftar pelanggan

**Changes:**
- Dropdown filter "Semua Area" di header
- Kolom "Area" di tabel pelanggan
- Field Area di form Tambah Pelanggan
- Dropdown Area di modal Edit Pelanggan

**Files Modified:**
- `src/app/admin/pppoe/users/page.tsx` - Area filter, column, form field
- `src/app/api/pppoe/users/route.ts` - Include area relation
- `src/components/UserDetailModal.tsx` - Area dropdown in edit form

#### Fix: MapPicker z-index
**Bug Fix:** Pop up Map Picker tampil di belakang modal Edit Pelanggan

**Problem:** MapPicker dan UserDetailModal sama-sama memiliki z-index 9999
**Solution:** z-index MapPicker dinaikkan ke 10001

**Files Modified:**
- `src/components/MapPicker.tsx` - z-index: 10001

---

## [2.5.9] - 2025-12-15

### ðŸ›‘ Stop Langganan Feature - Subscription Management

#### New Feature: Stop Langganan Page
**Enhancement:** Halaman terpisah untuk mengelola pelanggan yang berhenti berlangganan

**Features:**
- URL: `/admin/pppoe/stopped`
- Tabel dengan kolom: No Layanan, Pelanggan, Profile, Telepon, Tgl Daftar, Tgl Stop, Note
- Tombol EXPORT untuk export CSV
- Tombol HAPUS untuk bulk delete
- Tombol Aktifkan Kembali untuk reaktivasi pelanggan
- Pagination dengan Show entries & Search
- Stats TOTAL DATA

**Files Created:**
- `src/app/admin/pppoe/stopped/page.tsx` - New stop subscription page

#### Menu Restructure - Langganan
**Enhancement:** Reorganisasi menu PPPoE (Langganan)

**New Menu Structure:**
| Menu | URL | Description |
|------|-----|-------------|
| Daftar Pelanggan | `/admin/pppoe/users` | Pelanggan active, isolated, blocked |
| Profile Langganan | `/admin/pppoe/profiles` | Manajemen profil PPPoE |
| Stop Langganan | `/admin/pppoe/stopped` | **NEW** - Pelanggan yang berhenti |
| Pendaftaran Baru | `/admin/pppoe/registrations` | Registrasi pending |

**Files Modified:**
- `src/app/admin/layout.tsx` - Updated menu href

#### Status "Stop" Implementation
**Enhancement:** Status baru untuk pelanggan berhenti berlangganan

**Changes:**
- Pelanggan dengan status "stop" tidak tampil di Daftar Pelanggan
- Pelanggan "stop" hanya tampil di halaman Stop Langganan
- Filter status di Daftar Pelanggan: Semua, Aktif, Isolir, Blokir (tanpa Stop)
- Tombol Stop di dropdown status individual
- Tombol bulk Stop untuk multi-select

**Files Modified:**
- `src/app/admin/pppoe/users/page.tsx` - Filter out stop status, add Stop button

#### API Updates
**Enhancement:** Support filter status di API

**Changes:**
- GET `/api/pppoe/users?status=stop` - Filter by status
- PUT `/api/pppoe/users/status` - Support "stop" status
- PUT `/api/pppoe/users/bulk-status` - Support bulk "stop"

**Files Modified:**
- `src/app/api/pppoe/users/route.ts` - Added status filter parameter

#### Translations
**Enhancement:** Added translations for stop subscription feature

| Key | Indonesian | English |
|-----|------------|---------|
| `pppoe.stoppedSubscriptions` | Berhenti Langganan | Stopped Subscriptions |
| `pppoe.stoppedSubscriptionsDesc` | Daftar pelanggan yang sudah berhenti berlangganan | List of customers who have stopped subscribing |

**Files Modified:**
- `src/locales/id.json` - Added Indonesian translations
- `src/locales/en.json` - Added English translations

---

## [2.5.8] - 2025-12-14

### ðŸŒ Multi-language Support & Invoice Overdue System

#### Payment Page Indonesian Translation
**Enhancement:** Halaman pembayaran (`/pay/[token]`) sekarang full bahasa Indonesia

**Translations:**
| English | Indonesia |
|---------|-----------|
| Payment Invoice | Tagihan Pembayaran |
| Invoice Details | Detail Tagihan |
| Customer Information | Informasi Pelanggan |
| Total Amount | Total Tagihan |
| Issue Date / Due Date | Tanggal Terbit / Jatuh Tempo |
| Payment Overdue | Pembayaran Terlambat |
| Payment Methods | Metode Pembayaran |
| Pay Now | Bayar Sekarang |
| Invoice Not Found | Tagihan Tidak Ditemukan |
| Payment Received | Pembayaran Diterima |

**Files Modified:**
- `src/app/pay/[token]/page.tsx` - Full Indonesian translation

#### User Detail Modal Indonesian Translation
**Enhancement:** Modal detail pengguna di halaman PPPoE Users sekarang full bahasa Indonesia

**Translations:**
| English | Indonesia |
|---------|-----------|
| User Details | Detail Pengguna |
| User Info / Sessions / Auth Logs / Invoices | Info Pengguna / Sesi / Log Autentikasi / Tagihan |
| Leave empty to keep current | Kosongkan untuk tetap menggunakan password saat ini |
| Name / Phone / Profile | Nama / Telepon / Paket |
| Auto-assign | Otomatis |
| IP Address (Auto-assign if empty) | Alamat IP (Otomatis jika kosong) |
| Address | Alamat |
| GPS Location (Optional) | Lokasi GPS (Opsional) |
| Expired At | Tanggal Kadaluarsa |
| Cancel / Save Changes | Batal / Simpan |
| No session history found | Tidak ada riwayat sesi |
| Success / Rejected | Berhasil / Ditolak |
| Due: / Paid: | Jatuh Tempo: / Dibayar: |

**Files Modified:**
- `src/components/UserDetailModal.tsx` - Full Indonesian translation

#### Customer Portal Speed Format Fix
**Problem:** Speed ditampilkan sebagai "5/5 Mbps" tidak konsisten dengan format admin "5M/5M"

**Solution:** Changed format dari `{download}/{upload} Mbps` ke `{download}M/{upload}M`

**Files Modified:**
- `src/app/customer/page.tsx` - Speed format fix

#### Invoice Overdue System Enhancements
**Enhancement:** Support lengkap untuk invoice overdue dan pelanggan ter-blokir

**Features:**
1. **Invoice List** - Tab "Tertunda" sekarang menampilkan PENDING dan OVERDUE
2. **Generate Invoice** - Include users dengan status: active, isolated, blocked
3. **Invoice-Overdue Template** - Template WhatsApp khusus untuk tagihan terlambat
4. **Send Reminder** - Auto-detect overdue dan gunakan template yang sesuai
5. **Cron Manual Trigger** - Force parameter untuk bypass time check
6. **Payment Webhook** - Support reactivation untuk blocked users

**Database Changes:**
```sql
INSERT INTO whatsapp_templates (type, name, message, isActive, createdAt, updatedAt)
VALUES ('invoice-overdue', 'Invoice Overdue (Auto)', 
'ðŸš¨ *TAGIHAN TERLAMBAT*\n\nYth. {{customerName}},\n\nTagihan Anda sudah melewati jatuh tempo {{daysOverdue}} hari.\n\nðŸ“‹ No. Invoice: {{invoiceNumber}}\nðŸ’° Total: Rp {{amount}}\nðŸ“… Jatuh Tempo: {{dueDate}}\n\nâš ï¸ Layanan internet Anda dapat diputus sewaktu-waktu.\n\nSegera lakukan pembayaran:\n{{paymentLink}}\n\nAbaikan jika sudah membayar.\n\nTerima kasih.\n{{companyName}}',
true, NOW(), NOW());
```

**Files Modified:**
- `src/app/api/invoices/route.ts` - Include OVERDUE in unpaid filter
- `src/app/api/invoices/generate/route.ts` - Include isolated, blocked users
- `src/app/api/invoices/send-reminder/route.ts` - Auto-detect overdue
- `src/lib/cron/voucher-sync.ts` - Added force parameter
- `src/app/api/cron/route.ts` - Pass force=true for manual trigger
- `src/app/api/payment/webhook/route.ts` - Added blocked status support
- `src/app/admin/invoices/page.tsx` - Button "Lunas" â†’ "Tandai Lunas"

**Deployed To:**
- âœ… VPS Production (103.67.244.131)
- âœ… VPS Lokal (103.191.165.156)

---

## [2.5.7] - 2025-12-14

### ðŸ› WhatsApp Broadcast API Fix & Search Enhancement

#### Fixed /api/users/list 500 Error
**Problem:** WhatsApp Broadcast page gagal load dengan error 500 pada API `/api/users/list`

**Root Cause:**
1. Query Prisma mencoba mengakses relasi `odcId` dan `odc` pada model `networkODP` yang tidak ada di schema
2. Nested filtering untuk ODP/ODC assignments tidak compatible dengan struktur schema

**Solution:**
1. Refactored ODP assignments query - sekarang dilakukan secara terpisah untuk menghindari nested relation errors
2. Removed ODC filter (tidak ada di current schema)
3. Added `odcs: []` ke response untuk backward compatibility dengan frontend
4. Added validation untuk empty userIds sebelum query ODP assignments

#### Added Customer Name Search
**Enhancement:** Menambahkan kemampuan pencarian berdasarkan nama pelanggan untuk fitur WhatsApp Broadcast

**New Parameters:**
- `name` - Cari berdasarkan nama pelanggan saja
- `search` - Cari generik (mencari di name, username, address, phone sekaligus)

**Usage Examples:**
```bash
# Search by name/username/address/phone
/api/users/list?search=tian

# Filter by status + search
/api/users/list?status=active&search=subang

# Search by name only
/api/users/list?name=tian
```

**Files Modified:**
- `src/app/api/users/list/route.ts` - Complete refactor of filtering and ODP handling

**Deployed To:**
- âœ… VPS Production (103.67.244.131)
- âœ… VPS Lokal (103.191.165.156)

---

## [2.5.6] - 2025-12-14

### ðŸ”§ Agent Dashboard Enhancement & Theme Fix

#### Fixed Admin Default Theme
**Problem:** Admin dashboard default ke dark mode, user ingin default light mode

**Solution:**
- Changed default theme dari `dark` ke `light` di `src/app/admin/layout.tsx`
- Added theme initialization pada login page untuk konsistensi

**Files Modified:**
- `src/app/admin/layout.tsx` - Default theme changed to light
- `src/app/admin/login/page.tsx` - Added theme initialization

#### Fixed Agent Sales History
**Problem:** Riwayat penjualan agent tidak muncul di dashboard agent

**Root Cause:** API mencari dari tabel yang salah

**Solution:** Changed query dari `agent_sales` ke `hotspot_vouchers` table langsung dengan filter:
- `agentId` = current agent
- `status` IN (ACTIVE, EXPIRED)
- `firstLoginAt` IS NOT NULL (sudah terjual)

**Files Modified:**
- `src/app/api/hotspot/agents/[id]/history/route.ts` - Changed data source

#### Added Agent Dashboard Filter & Pagination
**Enhancement:** Agent dashboard sekarang memiliki filter dan pagination

**New Features:**
- ðŸ” Search by voucher code
- ðŸ“Š Filter by status (WAITING, ACTIVE, EXPIRED)
- ðŸ“¦ Filter by profile
- ðŸ“„ Pagination (20 items per page)

**Files Modified:**
- `src/app/agent/dashboard/page.tsx` - Added filter UI components
- `src/app/api/agent/dashboard/route.ts` - Added pagination and filter params

---

## [2.5.5] - 2025-12-14

### ðŸ”§ Installer Nginx Port Configuration & VPS Update Script

#### Configurable Nginx Port in Installer
**Problem:** Fresh install VPS selalu listen di port 80 (hardcoded)

**Solution:** Added `NGINX_PORT` configuration variable ke installer script

**Files Modified:**
- `vps-install-local.sh` - Added NGINX_PORT prompt and configuration
- `vps-install.sh` - Added helpful comment for port customization

#### Created VPS Update Script
**New Files:**
- `vps-update.sh` - Script untuk update production tanpa fresh install
- `docs/UPDATE-GUIDE.md` - Panduan lengkap proses update

**Features:**
- Backup database otomatis sebelum update
- Git pull atau manual file transfer
- Prisma migration
- Build dan restart PM2
- Rollback support jika gagal

---

## [2.5.4] - 2025-12-14

### ðŸ”§ Project Cleanup & RADIUS NAS Fix

#### Fixed RADIUS Authentication
**Problem:** RADIUS authentication failed with "server not responding"

**Solution:**
- Added gateway NAS entry (192.168.54.1) to database
- FreeRADIUS now accepts requests from all configured NAS

**NAS Entries Added:**
```sql
INSERT INTO nas (nasname, shortname, type, secret, description) VALUES
('192.168.54.1', 'gateway', 'other', 'secret123', 'Gateway NAS'),
('172.16.66.1', 'mikrotik-chr', 'other', 'secret123', 'MikroTik CHR'),
('172.16.66.2', 'salfa-rb750', 'other', 'secret123', 'Salfa RB750'),
('0.0.0.0/0', 'catchall', 'other', 'secret123', 'Catch-all NAS');
```

#### Project Cleanup
**Deleted Files:**
- `test-api.js`, `test-delete.js`, `test-mikrotik.js`
- `check-users.sql`, `update-nas.sql`, `update-radius-main.zip`

**Deleted Folders:**
- `salfanet-radius-main/` - Duplicate folder
- `AIBILL-FIX-CLEAN/` - Old backup folder

#### Code Cleanup
**Files Cleaned:**
- `src/app/admin/layout.tsx` - Cleaned navigation menu
- `src/app/api/network/routers/route.ts` - Removed unused includes
- `src/locales/*.json` - Removed unused translation keys
- `src/lib/translations.ts` - Removed unused translations

---

## [2.5.2] - 2025-12-13

### ðŸ”§ Installer Scripts Encoding Fix

#### Fixed Character Encoding in vps-install.sh
**Files Modified:**
- `vps-install.sh` - Production VPS installer

**Changes:**
1. **Fixed Double-Encoded UTF-8 Characters**
   - Replaced corrupted emoji sequences with clean ASCII text
   - Removed UTF-8 BOM marker from file
   - Fixed corrupted arrow symbols (`ÃƒÂ¢Ã¢â‚¬ Ã¢â‚¬â„¢` â†’ `->`)
   - Fixed corrupted error icon (`ÃƒÂ¢Ã‚Ã…'` â†’ `[X]`)
   - Fixed various corrupted prefix markers

2. **Improved Readability**
   - Installer script now displays correctly on all terminal encodings
   - No more garbled characters when running on VPS

---

## [2.5.1] - 2025-12-13

### ðŸ”§ Installer Scripts Update

#### Updated VPS Installation Scripts
**Files Modified:**
- `vps-install.sh` - Production VPS installer (with root access)
- `vps-install-local.sh` - Local VPS installer (with sudo)

**Changes:**
1. **Added REST Authorize Endpoint to FreeRADIUS Config**
   - Include `authorize` section in REST module configuration
   - Enable voucher validation BEFORE password authentication
   - Timeout set to 2 seconds for authorize endpoint
   - Prevents expired vouchers from authenticating

2. **Updated REST Module Configuration**
   ```bash
   rest {
       authorize {
           uri = "${..connect_uri}/api/radius/authorize"
           method = "post"
           body = "json"
           data = '{"username": "%{User-Name}", "nasIp": "%{NAS-IP-Address}"}'
           timeout = 2
       }
       post-auth { ... }
       accounting { ... }
   }
   ```

3. **Benefits:**
   - âœ… New installations automatically get voucher authorization feature
   - âœ… Expired vouchers blocked at FreeRADIUS level
   - âœ… Consistent with production configuration (Dec 13, 2025)
   - âœ… Security hardening out-of-the-box

**Installation Flow Updated:**
- Both scripts now configure REST authorize during FreeRADIUS setup
- Authorize endpoint called in FreeRADIUS `sites-enabled/default` authorize section
- Complete voucher validation system ready to use after installation

---

## [2.5.0] - 2025-12-13

### ðŸ”’ Security Enhancement: FreeRADIUS Authorization Pre-Check for Expired Vouchers

#### Critical Bug Fix: Expired Vouchers Could Still Login
**Problem:**
- Voucher dengan status EXPIRED masih bisa login ke hotspot
- FreeRADIUS hanya check username/password di `radcheck` table
- Tidak ada validasi `expiresAt` sebelum authentication
- User melihat pesan "invalid username or password" bukan "account expired"
- Voucher expired tidak auto-disconnect dari active session
- Active sessions dari voucher tidak muncul di dashboard admin

**Impact:**
- ðŸ”´ **CRITICAL SECURITY ISSUE**: User bisa tetap online dengan voucher kadaluarsa
- ðŸ”´ **Poor UX**: Pesan error tidak jelas untuk user
- ðŸ”´ **Revenue Loss**: Voucher gratis karena bisa digunakan selamanya
- ðŸ”´ **Dashboard Inaccurate**: Admin tidak bisa monitor real sessions

---

### ðŸ› ï¸ Solution Implemented

#### 1. REST Authorization Endpoint (Pre-Authentication Check)
**File Created:** `src/app/api/radius/authorize/route.ts`

FreeRADIUS sekarang call REST API **SEBELUM** proses authentication untuk validate voucher:

```typescript
export async function POST(request: NextRequest) {
  const { username } = await request.json();
  
  const voucher = await prisma.hotspotVoucher.findUnique({
    where: { code: username },
    include: { profile: true },
  });
  
  if (!voucher) {
    return NextResponse.json({
      success: true,
      action: "allow",
      message: "Not a voucher"
    });
  }
  
  const now = new Date();
  
  // Check 1: Status EXPIRED
  if (voucher.status === 'EXPIRED') {
    await logRejection(username, 'Your account has expired');
    return NextResponse.json({
      "control:Auth-Type": "Reject",
      "reply:Reply-Message": "Your account has expired"
    }, { status: 200 });
  }
  
  // Check 2: expiresAt in the past
  if (voucher.expiresAt && now > voucher.expiresAt) {
    await prisma.hotspotVoucher.update({
      where: { id: voucher.id },
      data: { status: "EXPIRED" },
    });
    await logRejection(username, 'Your account has expired');
    return NextResponse.json({
      "control:Auth-Type": "Reject",
      "reply:Reply-Message": "Your account has expired"
    }, { status: 200 });
  }
  
  // Check 3: Active session timeout exceeded
  if (voucher.firstLoginAt && voucher.expiresAt) {
    const activeSession = await prisma.radacct.findFirst({
      where: { username: voucher.code, acctstoptime: null },
    });
    
    if (activeSession && now > voucher.expiresAt) {
      await logRejection(username, 'Session timeout');
      return NextResponse.json({
        "control:Auth-Type": "Reject",
        "reply:Reply-Message": "Session timeout"
      }, { status: 200 });
    }
  }
  
  return NextResponse.json({
    success: true,
    action: "allow",
    status: voucher.status,
    expiresAt: voucher.expiresAt,
  });
}
```

**Key Features:**
- âœ… Check voucher status BEFORE password validation
- âœ… Auto-update status to EXPIRED if expiresAt passed
- âœ… Session timeout detection for active sessions
- âœ… Log rejection to `radpostauth` table for audit trail
- âœ… Return proper RADIUS attributes for MikroTik display

---

#### 2. FreeRADIUS REST Module Configuration
**File Modified:** `freeradius-config/mods-enabled-rest`

Added `authorize` section to REST module:

```
rest {
    tls {
        check_cert = no
        check_cert_cn = no
    }
    
    connect_uri = "http://localhost:3000"
    
    # NEW: Authorize pre-check
    authorize {
        uri = "${..connect_uri}/api/radius/authorize"
        method = "post"
        body = "json"
        data = "{ \"username\": \"%{User-Name}\", \"nasIp\": \"%{NAS-IP-Address}\" }"
        tls = ${..tls}
        timeout = 2
    }
    
    post-auth {
        uri = "${..connect_uri}/api/radius/post-auth"
        method = "post"
        body = "json"
        data = "{ \"username\": \"%{User-Name}\", \"reply\": \"%{reply:Packet-Type}\", \"nasIp\": \"%{NAS-IP-Address}\", \"framedIp\": \"%{Framed-IP-Address}\" }"
        tls = ${..tls}
    }
    
    accounting {
        uri = "${..connect_uri}/api/radius/accounting"
        method = "post"
        body = "json"
        data = "{ \"username\": \"%{User-Name}\", \"statusType\": \"%{Acct-Status-Type}\", \"sessionId\": \"%{Acct-Session-Id}\", \"nasIp\": \"%{NAS-IP-Address}\", \"framedIp\": \"%{Framed-IP-Address}\", \"sessionTime\": \"%{Acct-Session-Time}\", \"inputOctets\": \"%{Acct-Input-Octets}\", \"outputOctets\": \"%{Acct-Output-Octets}\" }"
        tls = ${..tls}
    }
    
    pool {
        start = 0
        min = 0
        max = 32
        spare = 1
        uses = 0
        lifetime = 0
        idle_timeout = 60
        connect_timeout = 3
    }
}
```

---

#### 3. FreeRADIUS Authorization Flow
**File Modified:** `freeradius-config/sites-enabled-default`

Added REST call in `authorize` section (after SQL, before PAP):

```
authorize {
    filter_username
    preprocess
    chap
    mschap
    digest
    suffix
    eap {
        ok = return
    }
    files
    -sql
    
    # CRITICAL: Call REST API to check voucher expiry
    rest
    
    -ldap
    expiration
    logintime
    pap
}
```

**Authentication Flow:**
```
1. User login â†’ FreeRADIUS receives Access-Request
2. SQL check â†’ Load user from radcheck (username/password)
3. REST authorize â†’ Call /api/radius/authorize
   â”œâ”€ If expired â†’ Return Auth-Type=Reject + Reply-Message
   â””â”€ If valid â†’ Continue to next step
4. PAP authentication â†’ Validate password
5. Post-Auth â†’ Log success/failure
6. Send Access-Accept/Reject to MikroTik
```

---

#### 4. Dashboard Active Sessions Fix
**File Modified:** `src/app/api/dashboard/stats/route.ts`

**Problem:** Query menggunakan `nasporttype = 'Wireless-802.11'` yang tidak selalu ada di radacct.

**Solution:** Check username di tabel `pppoeUser` vs `hotspotVoucher`:

```typescript
// OLD (BROKEN):
activeSessionsHotspot = await prisma.radacct.count({
  where: {
    acctstoptime: null,
    acctupdatetime: { gte: tenMinutesAgo },
    nasporttype: 'Wireless-802.11', // âŒ Not reliable
  },
});

// NEW (FIXED):
const pppoeSessions = await prisma.radacct.findMany({
  where: {
    acctstoptime: null,
    acctupdatetime: { gte: tenMinutesAgo },
  },
  select: { username: true },
});

for (const session of pppoeSessions) {
  const isPPPoE = await prisma.pppoeUser.findUnique({
    where: { username: session.username },
    select: { id: true },
  });
  
  if (isPPPoE) {
    activeSessionsPPPoE++;
  } else {
    activeSessionsHotspot++;
  }
}
```

**Result:**
- âœ… Semua hotspot sessions sekarang muncul di dashboard
- âœ… Accurate PPPoE vs Hotspot session count
- âœ… No dependency on nasporttype field

---

#### 5. Enhanced Voucher Sync Cronjob
**File Modified:** `src/lib/cron/voucher-sync.ts`

**Improvements:**
1. **Better Logging Per Voucher:**
```typescript
const expiredVouchers = await prisma.$queryRaw<Array<{code: string; id: string}>>`
  SELECT code, id FROM hotspot_vouchers
  WHERE status = 'ACTIVE'
    AND expiresAt < UTC_TIMESTAMP()
`

console.log(`[CRON] Found ${expiredVouchers.length} expired vouchers to process`)

let expiredCount = 0
for (const voucher of expiredVouchers) {
  try {
    // 1. Remove from RADIUS authentication tables
    await prisma.radcheck.deleteMany({
      where: { username: voucher.code }
    })
    await prisma.radusergroup.deleteMany({
      where: { username: voucher.code }
    })
    
    // 2. Check for active session
    const activeSession = await prisma.radacct.findFirst({
      where: { username: voucher.code, acctstoptime: null },
    })
    
    if (activeSession) {
      console.log(`[CRON] Voucher ${voucher.code} has active session, will be disconnected by CoA`)
    }
    
    expiredCount++
    console.log(`[CRON] Voucher ${voucher.code} removed from RADIUS (expired)`)
  } catch (err) {
    console.error(`[CRON] Error processing expired voucher ${voucher.code}:`, err)
  }
}
```

2. **Auto-Disconnect via CoA:**
```typescript
// Update status to EXPIRED
const expiredResult = await prisma.$executeRaw`
  UPDATE hotspot_vouchers
  SET status = 'EXPIRED'
  WHERE status = 'ACTIVE'
    AND expiresAt < NOW()
`

// Disconnect expired sessions via CoA
let disconnectedCount = 0
try {
  const coaResult = await disconnectExpiredSessions()
  disconnectedCount = coaResult.disconnected
} catch (coaErr) {
  console.error('[CoA] Error:', coaErr)
}
```

3. **Improved History Logging:**
```typescript
await prisma.cronHistory.update({
  where: { id: history.id },
  data: {
    status: 'success',
    completedAt,
    duration: completedAt.getTime() - startedAt.getTime(),
    result: `Synced ${syncedCount} vouchers, expired ${expiredCount} vouchers, disconnected ${disconnectedCount} sessions`,
  },
})
```

---

### ðŸ“Š MikroTik Log Messages

**Before Fix:**
```
login failed: invalid username or password
```

**After Fix:**
```
login failed: Your account has expired
login failed: Session timeout
```

---

### ðŸŽ¯ Technical Implementation Details

#### FreeRADIUS Package Requirements
```bash
apt-get install freeradius-rest
```

#### REST Module Loading
Module `rlm_rest.so` must be available at:
```
/usr/lib/freeradius/rlm_rest.so
```

#### Configuration Files
1. `/etc/freeradius/3.0/mods-enabled/rest` - REST API endpoints
2. `/etc/freeradius/3.0/sites-enabled/default` - Authorization flow
3. `/var/www/salfanet-radius/src/app/api/radius/authorize/route.ts` - Validation logic

#### Database Tables Used
- `hotspot_vouchers` - Voucher status, expiresAt
- `radcheck` - RADIUS username/password
- `radusergroup` - User group membership
- `radacct` - Active sessions tracking
- `radpostauth` - Authentication log (success/failure)

---

### âœ… Testing Checklist

- [x] Expired voucher rejected before authentication
- [x] Reply-Message "Your account has expired" sent to MikroTik
- [x] Message displayed in MikroTik log
- [x] Active sessions visible in admin dashboard
- [x] Voucher sync cronjob processes expired vouchers
- [x] CoA disconnect for expired active sessions
- [x] radpostauth logging for audit trail
- [x] No false positives (valid vouchers still work)
- [x] Performance: 2-second timeout for authorize check

---

### ðŸ“ Files Modified Summary

| File | Change Type | Description |
|------|-------------|-------------|
| `src/app/api/radius/authorize/route.ts` | **CREATED** | Pre-authentication voucher validation endpoint |
| `freeradius-config/mods-enabled-rest` | Modified | Added authorize section with 2s timeout |
| `freeradius-config/sites-enabled-default` | Modified | Call REST in authorize flow after SQL |
| `src/app/api/dashboard/stats/route.ts` | Modified | Fixed hotspot session counting logic |
| `src/lib/cron/voucher-sync.ts` | Enhanced | Better logging, cleanup, and disconnect |

---

### ðŸš€ Deployment Notes

**VPS Environment:**
- IP: 103.67.244.131
- FreeRADIUS: v3.0.26 (with rlm_rest module)
- Next.js: v16.0.7
- PM2: Process manager
- MySQL: 8.0.44

**Restart Sequence:**
```bash
# 1. Update Next.js code
cd /var/www/salfanet-radius
npm run build

# 2. Update FreeRADIUS config
cp freeradius-config/mods-enabled-rest /etc/freeradius/3.0/mods-enabled/rest
cp freeradius-config/sites-enabled-default /etc/freeradius/3.0/sites-enabled/default

# 3. Test FreeRADIUS config
freeradius -CX

# 4. Restart services
systemctl restart freeradius
pm2 restart all --update-env
```

---

### ðŸ” Monitoring & Debugging

**Check Authorization Logs:**
```sql
SELECT * FROM radpostauth 
WHERE authdate > NOW() - INTERVAL 1 HOUR 
ORDER BY authdate DESC;
```

**Check Expired Vouchers:**
```sql
SELECT code, status, expiresAt 
FROM hotspot_vouchers 
WHERE status = 'EXPIRED' 
AND expiresAt > NOW() - INTERVAL 1 DAY;
```

**FreeRADIUS Debug Mode:**
```bash
systemctl stop freeradius
freeradius -X
```

**REST API Test:**
```bash
curl -X POST http://localhost:3000/api/radius/authorize \
  -H "Content-Type: application/json" \
  -d '{"username": "553944"}'
```

---

## [2.4.5] - 2025-12-10

### ðŸŽ¨ UI/UX Improvements: Voucher Template Preview & Dashboard Traffic Monitor

#### 1. Mobile Responsive Voucher Template Preview
**Problem:**
- Preview voucher pada tampilan mobile tidak responsif
- Voucher cards terlalu kecil dan terpotong di layar mobile
- Layout voucher tidak optimal untuk mobile viewing
- Posisi voucher tidak berurutan (single code vs username/password)

**Solution:**
Optimized voucher template preview for mobile devices with responsive CSS and better layout handling.

**Changes:**

1. **Mobile Media Queries (â‰¤640px):**
   ```css
   @media (max-width: 640px) {
     .voucher-preview-container { 
       display: flex !important; 
       flex-direction: column !important; 
       padding: 0 8px !important; 
       gap: 10px !important; 
     }
     .voucher-card { 
       display: block !important; 
       width: calc(100% - 16px) !important; 
       max-width: none !important; 
       margin: 0 auto 10px auto !important; 
     }
     .voucher-single { order: 1; }
     .voucher-dual { order: 2; }
   }
   ```

2. **Tablet Media Queries (641px - 1024px):**
   ```css
   @media (min-width: 641px) and (max-width: 1024px) {
     .voucher-card { width: calc(33.33% - 8px) !important; }
   }
   ```

3. **Desktop (â‰¥1025px):**
   ```css
   @media (min-width: 1025px) {
     .voucher-card { width: 155px !important; }
   }
   ```

4. **React State for Mobile Detection:**
   ```typescript
   const [isMobile, setIsMobile] = useState(false);
   
   useEffect(() => {
     const handleResize = () => setIsMobile(window.innerWidth <= 640);
     handleResize();
     window.addEventListener('resize', handleResize);
     return () => window.removeEventListener('resize', handleResize);
   }, []);
   ```

5. **Dynamic Container Styles:**
   ```typescript
   style={{
     display: 'flex',
     flexDirection: isMobile ? 'column' : 'row',
     flexWrap: isMobile ? 'nowrap' : 'wrap',
     gap: isMobile ? '12px' : '6px',
   }}
   ```

**Files Modified:**
- `src/app/admin/hotspot/template/page.tsx` - Mobile responsive DEFAULT_TEMPLATE & preview container

**Result:**
- âœ… Voucher preview responsive di semua device
- âœ… Voucher cards tidak terpotong di mobile
- âœ… Layout vertikal di mobile dengan gap yang tepat
- âœ… Single-code voucher tampil di atas, dual (username/password) di bawah
- âœ… Preview button tetap tampil di semua device

---

#### 2. Dashboard Traffic Monitor UI Improvements
**Problem:**
- Font judul "Traffic Monitor MikroTik" terlalu besar
- Indikator "Live" tidak diperlukan
- Dropdown Router dan Interface terlalu besar dan horizontal
- Layout selector tidak optimal

**Solution:**
Optimized Traffic Monitor section with smaller fonts and vertical selector layout.

**Changes:**

1. **Title Font Size Reduced:**
   ```tsx
   // Before
   <h3 className="text-lg font-semibold">Traffic Monitor MikroTik</h3>
   
   // After  
   <h3 className="text-base font-semibold">Traffic Monitor MikroTik</h3>
   ```

2. **Live Indicator Removed:**
   ```tsx
   // Removed completely
   <div className="flex items-center gap-2">
     <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
     <span className="text-xs text-gray-500">Live</span>
   </div>
   ```

3. **Dropdown Selectors - Vertical Layout:**
   ```tsx
   // Before: Horizontal layout
   <div className="flex items-center gap-3">
   
   // After: Vertical layout (Router above, Interface below)
   <div className="flex flex-col items-start gap-2">
   ```

4. **Dropdown Styling Optimized:**
   ```tsx
   // Before
   className="text-xs px-3 py-1.5 ..."
   
   // After
   className="text-[11px] px-2.5 py-1.5 ..."
   ```

**Files Modified:**
- `src/components/TrafficChartMonitor.tsx` - Header title, selectors layout, Live indicator removed

**Result:**
- âœ… Judul lebih compact dengan font-size base
- âœ… Live indicator dihilangkan (cleaner UI)
- âœ… Dropdown Router di atas, Interface di bawah (vertikal)
- âœ… Dropdown lebih kecil dengan font 11px
- âœ… Layout lebih rapi dan profesional

---

## [2.4.4] - 2025-12-09

### ðŸŽ¨ Voucher Template Print Optimization

#### Enhanced Print Layout & Voucher Sizing
**Problem:**
- Voucher template print size was too small and hard to read
- Print preview didn't match template preview
- Space between vouchers was inconsistent
- Font sizes were too small for printing
- Cards didn't fill A4 page properly

**Solution:**
Optimized voucher template for A4 portrait printing with better sizing and readability.

**Changes:**

1. **Template Default Sizing:**
   - Card height: 70px â†’ 100px (30% larger)
   - Header font: 8px â†’ 12px
   - Code label: 6px â†’ 8px
   - Code text: 11px â†’ 13px
   - Username/Password label: 6px â†’ 10px
   - Footer padding: 2px 4px â†’ 10px 15px
   - Footer font: 8px â†’ 10px

2. **Print Layout:**
   - Portrait A4 optimization: 5 columns Ã— 10 rows
   - Margin adjusted: 0.5% horizontal, 0.2% vertical bottom
   - Space-between distribution for full page coverage
   - Consistent voucher spacing across all rows

3. **Database Template Update:**
   - Default template updated to match new sizing
   - Router name display from actual NAS/router database
   - Support for username/password different credentials

**Files Modified:**
- `src/app/admin/hotspot/template/page.tsx` - Updated DEFAULT_TEMPLATE
- `src/lib/utils/templateRenderer.ts` - Enhanced print CSS with space-between
- Database: `voucher_templates` - Updated default compact template

**Print Preview:**
- 50 vouchers per A4 page (5Ã—10 grid)
- Better readability with larger fonts
- Consistent card heights and spacing
- Full page coverage from top to bottom

---

## [2.4.3] - 2025-12-09

### ðŸš€ MikroTik Rate Limit Format Support

#### Full Burst Limit Configuration
**Problem:**
- Hotspot and PPPoE profiles only supported simple rate format (e.g., "5M/5M")
- No way to configure burst rate, burst threshold, priority, or minimum rate
- Admins had to manually configure advanced QoS in MikroTik after sync

**Solution:**
Both profile types now support full MikroTik rate limit format with all advanced parameters.

**Format Specification:**
```
rx-rate[/tx-rate] [rx-burst-rate[/tx-burst-rate]] [rx-burst-threshold[/tx-burst-threshold]] [rx-burst-time[/tx-burst-time]] [priority] [rx-rate-min[/tx-rate-min]]
```

**Examples:**
- Simple: `5M/5M` (basic download/upload speed)
- With burst: `2M/2M 4M/4M 2M/2M 8 0/0` (burst to 4M when below 2M threshold)
- Full format: `10M/10M 15M/15M 8M/8M 5 1M/1M` (all parameters configured)

**Changes:**

1. **Hotspot Profile Form**
   - Replaced separate `downloadSpeed` and `uploadSpeed` number inputs
   - Single `speed` text input with monospace font
   - Placeholder: "1M/1500k 0/0 0/0 8 0/0"
   - Helper text explaining full format

2. **PPPoE Profile Form**
   - Added optional `rateLimit` field to interface
   - Replaced `downloadSpeed`/`uploadSpeed` grid with single `rateLimit` input
   - Monospace font for better readability
   - Placeholder: "1M/1500k 0/0 0/0 8 0/0"
   - Helper text with format documentation
   - Backward compatible with existing profiles (auto-converts to new format)

**Technical Details:**
```typescript
// PPPoE Profile Interface
interface PPPoEProfile {
  rateLimit?: string; // Full MikroTik format
  downloadSpeed: number; // Legacy field (still used for backward compatibility)
  uploadSpeed: number;   // Legacy field
}

// Edit handler converts legacy to new format
rateLimit: profile.rateLimit || `${profile.downloadSpeed}M/${profile.uploadSpeed}M`
```

**Files Modified:**
- `src/app/admin/hotspot/profile/page.tsx` - Rate limit input with full format support
- `src/app/admin/pppoe/profiles/page.tsx` - Added rateLimit field and input

**Benefits:**
- âœ… Complete control over bandwidth management from web interface
- âœ… Support for burst speed configurations
- âœ… Priority and minimum rate guarantees
- âœ… No manual MikroTik configuration needed after sync
- âœ… Backward compatible with simple format
- âœ… Matches MikroTik RouterOS native format

**MikroTik Parameters Explained:**
- **rx-rate/tx-rate**: Normal download/upload speed (required)
- **rx-burst-rate/tx-burst-rate**: Maximum burst speed when allowed
- **rx-burst-threshold/tx-burst-threshold**: Traffic threshold to allow burst
- **rx-burst-time**: How long burst can be sustained (seconds)
- **priority**: QoS priority (1-8, lower = higher priority)
- **rx-rate-min/tx-rate-min**: Guaranteed minimum bandwidth

---

## [2.4.2] - 2025-12-08

### ðŸŽ¯ Agent Management Enhancement

#### Bulk Operations & Enhanced Tracking
**New Features:**

1. **Bulk Selection with Checkboxes**
   - Checkbox "Select All" in table header
   - Individual checkbox for each agent
   - Counter displays number of selected agents
   - Visual feedback for selections

2. **Bulk Delete Agents**
   - Delete multiple agents simultaneously
   - Confirmation modal before deletion
   - Parallel deletion for better performance
   - Success/failure notifications

3. **Bulk Status Change**
   - Change status of multiple agents at once
   - Modal with Active/Inactive options
   - Applies to all selected agents
   - Instant UI update after change

4. **Login Tracking Column**
   - New "Login Terakhir" column in agent table
   - Shows last login timestamp from agent portal
   - Format: DD MMM YYYY, HH:MM
   - Displays "Belum login" if never logged in
   - Auto-updates when agent logs in

5. **Voucher Stock Column**
   - New "Stock" column showing available vouchers
   - Real-time count of vouchers with WAITING status
   - Format: "X voucher"
   - Helps monitor agent inventory

6. **Status Management in Edit Modal**
   - Dropdown to change agent status when editing
   - Options: Active or Inactive
   - Only visible in edit mode (not create mode)
   - Integrated with existing edit form

**Technical Implementation:**
```typescript
// Bulk operations with parallel processing
Promise.all(selectedAgents.map(id => 
  fetch(`/api/hotspot/agents?id=${id}`, { method: 'DELETE' })
));

// Stock calculation
voucherStock = vouchers.filter(v => v.status === 'WAITING').length;

// Login tracking
await prisma.agent.update({
  where: { id },
  data: { lastLogin: new Date() }
});
```

**Database Changes:**
```sql
-- New column added to agents table
ALTER TABLE `agents` ADD COLUMN `lastLogin` DATETIME(3) NULL;
```

**Files Modified:**
- `src/app/admin/hotspot/agent/page.tsx` - UI with bulk operations
- `src/app/api/hotspot/agents/route.ts` - API with lastLogin & voucherStock
- `src/app/api/agent/login/route.ts` - Login timestamp tracking
- `prisma/schema.prisma` - Added lastLogin field
- `prisma/migrations/20251208135232_add_agent_last_login/migration.sql`

**Deployment:**
- âœ… VPS Production: 103.67.244.131
- âœ… Database migration successful
- âœ… Build: 142 routes compiled
- âœ… PM2: Online (57.4mb memory)
- âœ… API tested and verified

**Benefits:**
- ðŸš€ Faster agent management with bulk operations
- ðŸ“Š Better visibility of agent activity and inventory
- ðŸŽ¯ Improved UX for admin operations
- âš¡ No performance impact on existing features

---

## [2.4.1] - 2025-12-08

### ðŸ”’ Security Updates

#### Critical Security Patch - React Server Components
**Issue:**
- Critical security vulnerability in React Server Components (CVE-2024-XXXXX)
- Affects Next.js applications using React 19.x
- Potential XSS and data exposure risks

**Solution:**
- Updated Next.js from 16.0.6 â†’ **16.0.7** (includes security patches)
- Updated React from 19.2.0 â†’ **19.2.1** (patched version)
- Updated React-DOM from 19.2.0 â†’ **19.2.1** (patched version)

**Reference:**
- https://react.dev/blog/2025/12/03/critical-security-vulnerability-in-react-server-components

**Files Modified:**
- `package.json` - Updated dependency versions
- `package-lock.json` - Updated dependency tree

**Build Status:**
- âœ… Local build: Compiled successfully in 29.0s
- âœ… VPS build: Compiled successfully in 18.3s
- âœ… PM2 status: Online (60.8mb memory)
- âœ… All 142 routes working correctly

**Result:**
- âœ… Application secured against critical vulnerability
- âœ… Turbopack optimization maintained
- âœ… No breaking changes
- âœ… Production deployment successful

---

## [2.4.0] - 2025-12-08

### ðŸŽ¨ UI/UX Improvements

#### 1. Dashboard Layout Optimization
**Changes:**
- Stats cards grid changed from 4 columns to 5 columns for better space utilization
- Card sizes reduced with optimized padding (p-3 â†’ p-2.5) and smaller fonts
- Traffic Monitor repositioned from bottom to top (directly below stats cards)
- Gap between cards reduced for more compact layout

**Result:**
- âœ… All 5 stat cards visible in one row on desktop
- âœ… Traffic monitoring more prominent and accessible
- âœ… Cleaner, more efficient dashboard layout

#### 2. Dark Mode as Default Theme
**Changes:**
- Default theme changed from light to dark mode
- Theme preference saved in localStorage for persistence
- First-time users automatically see dark mode
- Toggle theme functionality preserved with localStorage sync

**Implementation:**
```typescript
// Default state changed to true
const [darkMode, setDarkMode] = useState(true);

// Initialize with dark mode if no preference saved
if (!savedTheme) {
  setDarkMode(true);
  document.documentElement.classList.add('dark');
  localStorage.setItem('theme', 'dark');
}
```

**Files Modified:**
- `src/app/admin/layout.tsx` - Dark mode default initialization
- `src/app/admin/page.tsx` - Stats grid layout (5 columns)

### ðŸ› Bug Fixes

#### 3. Hotspot Voucher Count Accuracy
**Problem:** 
- Expired vouchers incorrectly counted as active users
- Total voucher count included kadaluarsa (expired) vouchers
- Misleading statistics showing higher user counts

**Solution:**
```typescript
// Only count non-expired vouchers
hotspotUserCount = await prisma.hotspotVoucher.count({
  where: {
    OR: [
      { expiresAt: null }, // No expiry date
      { expiresAt: { gte: now } } // Not yet expired
    ]
  }
});

// Active vouchers: Used AND not expired
hotspotActiveUserCount = await prisma.hotspotVoucher.count({
  where: {
    firstLoginAt: { not: null },
    OR: [
      { expiresAt: null },
      { expiresAt: { gte: now } }
    ]
  }
});
```

**Files Modified:**
- `src/app/api/dashboard/stats/route.ts` - Voucher counting logic

**Result:**
- âœ… Total vouchers: Only valid (non-expired) vouchers
- âœ… Active vouchers: Only used AND valid vouchers
- âœ… Accurate business statistics

### ðŸ“Š Features

#### 4. Real-Time Traffic Monitoring with Charts
**New Feature:**
- MikroTik interface traffic monitoring with real-time graphs
- Area charts showing Download/Upload bandwidth in Mbps
- Router and interface selection filters
- Auto-refresh every 3 seconds with 60-second history

**Implementation:**
- Created `TrafficChartMonitor.tsx` component with Recharts
- Traffic API at `/api/dashboard/traffic` using node-routeros
- Interface selection required before displaying graphs
- Supports multiple routers with dropdown selection

**Features:**
- ðŸ“ˆ Real-time bandwidth graphs (Download: blue, Upload: red)
- ðŸ”„ Auto-refresh every 3 seconds
- ðŸŽ¯ Router and interface selectors
- ðŸ“Š Shows last 20 data points (1 minute history)
- ðŸ’¾ Traffic rate calculation (RX/TX in Mbps)
- ðŸ“± Responsive layout with activity sidebar

**Files Added:**
- `src/components/TrafficChartMonitor.tsx` - Main component
- Updated `src/app/admin/page.tsx` - Dashboard integration

**Result:**
- âœ… Visual bandwidth monitoring
- âœ… Easy interface selection
- âœ… Historical traffic trends
- âœ… Professional monitoring UI

#### 5. Separated PPPoE and Hotspot Statistics
**Enhancement:**
- Dashboard now shows separate counts for PPPoE users and Hotspot vouchers
- Active sessions separated by type (PPPoE vs Hotspot)
- Clearer business intelligence for different service types

**Implementation:**
```typescript
// Separate user counts
pppoeUsers: { value: number, change: null },
hotspotVouchers: { value: number, active: number, change: null },

// Separate active sessions
activeSessions: { 
  value: number, 
  pppoe: number, 
  hotspot: number, 
  change: null 
}
```

**Result:**
- âœ… PPPoE Users: Separate card
- âœ… Hotspot Vouchers: Shows total and active count
- âœ… Active Sessions: Breakdown by type (using nasporttype field)

### ðŸ”§ Technical Improvements

#### 6. MikroTik API Integration
**Implementation:**
- Router configuration uses custom API port from database (router.port field)
- Connection handling with proper error management
- Support for multiple routers in single deployment
- 5-second connection timeout for reliability

**Database Schema:**
```typescript
router.port // API port (default 8728)
router.apiPort // SSL API port (default 8729)
```

**Files Modified:**
- `src/app/api/dashboard/traffic/route.ts` - API implementation

---

## [2.3.1] - 2025-12-07

### ðŸ› Bug Fixes

#### 1. Voucher Timezone Display Issues
**Problem:** 
- Voucher `createdAt` showing UTC time (05:01) instead of WIB (12:01)
- Voucher `firstLoginAt` and `expiresAt` showing +7 hours offset (19:24 instead of 12:24)

**Root Cause:**
1. **createdAt Issue:** PM2 environment missing `TZ` variable â†’ `new Date()` returns UTC
2. **firstLoginAt/expiresAt Issue:** Prisma adds 'Z' suffix â†’ browser interprets as UTC â†’ adds +7 hours
3. Database stores UTC (Prisma default), FreeRADIUS stores WIB (server local time)

**Solution:**
1. **PM2 Environment Fix:**
   - Added `TZ: 'Asia/Jakarta'` to `ecosystem.config.js` env block
   - Result: `new Date()` now returns WIB time correctly

2. **API Timezone Conversion:**
   - `createdAt`/`updatedAt`: Convert from UTC to WIB using `formatInTimeZone`
   - `firstLoginAt`/`expiresAt`: Already WIB from FreeRADIUS, remove 'Z' suffix only
   
**Files Modified:**
- `ecosystem.config.js` - Added `TZ: 'Asia/Jakarta'` to env
- `src/app/api/hotspot/voucher/route.ts` - Timezone-aware date formatting

**Result:**
- âœ… Voucher Generated time: Shows correct WIB
- âœ… Voucher First Login: Shows correct WIB (no +7 offset)
- âœ… Voucher Valid Until: Shows correct WIB

#### 2. Cron Job System Improvements
**Problems Fixed:**

1. **Auto Isolir Error:** "nowWIB is not defined"
   - Missing timezone utility imports in `voucher-sync.ts`
   
2. **No Disconnect Sessions Job:** 
   - Expired vouchers remained active in RADIUS
   - No automatic CoA (Change of Authorization) disconnect

3. **Activity Log Cleanup Missing Result:**
   - Execution history showed no result message

**Solutions Implemented:**

1. **Fixed Auto Isolir:**
   - Added imports: `nowWIB, formatWIB, startOfDayWIBtoUTC, endOfDayWIBtoUTC`

2. **Created Disconnect Sessions Job:**
   - New function `disconnectExpiredVoucherSessions()`
   - Runs every 5 minutes
   - Sends CoA Disconnect-Request to RADIUS for expired vouchers
   - Records cron history with result count

3. **Fixed Activity Log Cleanup:**
   - Modified `cleanOldActivities()` to record cron_history
   - Returns message: "Cleaned X old activities (older than 30 days)"

4. **Enhanced Frontend Cron Page:**
   - Added `typeLabels` for all 10 job types
   - Added success notification handlers
   - Improved Execution History table

**Files Modified:**
- `src/lib/cron/voucher-sync.ts` - Fixed imports, added disconnect function
- `src/lib/cron/config.ts` - Added disconnect_sessions job
- `src/lib/activity-log.ts` - Modified cleanOldActivities
- `src/app/api/cron/route.ts` - Added disconnect_sessions handler
- `src/app/admin/settings/cron/page.tsx` - Enhanced UI

**Cron Jobs Status (10 Total):**
- âœ… `voucher_sync` - Sync vouchers (every 5 min)
- âœ… `disconnect_sessions` - Disconnect expired sessions (every 5 min) **NEW**
- âœ… `agent_sales` - Update agent sales (daily 1 AM)
- âœ… `auto_isolir` - Auto suspend overdue (hourly)
- âœ… `invoice_generation` - Generate invoices (daily 2 AM)
- âœ… `payment_reminder` - Payment reminders (daily 8 AM)
- âœ… `whatsapp_queue` - WA message queue (every 10 min)
- âœ… `expired_voucher_cleanup` - Delete old vouchers (daily 3 AM)
- âœ… `activity_log_cleanup` - Clean old logs (daily 2 AM)
- âœ… `session_cleanup` - Clean old sessions (daily 4 AM)

#### 3. Dashboard Statistics Not Showing (Revenue Rp 0, Users 0)
**Problem:** Dashboard menampilkan Rp 0 revenue dan 0 total users padahal ada transaksi di database.

**Root Cause:**
- Date range calculation menggunakan timezone conversion yang kompleks dan tidak konsisten
- Query menggunakan `date: { gte: startOfMonth, lte: now }` yang tidak match dengan timestamp UTC di database
- JavaScript `new Date(2025, 11, 1)` di server WIB (UTC+7) membuat "Dec 1 00:00 WIB" â†’ internally "Nov 30 17:00 UTC"
- Transaksi stored sebagai UTC (e.g., `2025-12-06T14:15:17.000Z`) tidak ter-capture dengan benar

**Solution:**
- Simplified date boundary calculation tanpa complex offset
- Changed query dari `lte: now` menjadi `lt: startOfNextMonth` untuk consistent month boundaries
- Updated last month query menggunakan `lt: startOfMonth` instead of `lte: endOfLastMonth`
- Removed manual timezone offset calculations, let JavaScript handle localâ†’UTC conversion

**Files Modified:**
- `src/app/api/dashboard/stats/route.ts` (Lines 24-47, 161-185, 197-207)

**Result:**
- âœ… Revenue: Rp 0 â†’ Rp 3,000
- âœ… Total Users: 0 â†’ 1
- âœ… Transaction Count: 0 â†’ 1
- âœ… Date Range: Nov 30 17:00 UTC - Dec 31 17:00 UTC (Dec 1-31 WIB)

**Technical Details:**
```typescript
// Before (WRONG):
const startOfMonth = new Date(year, month, 1, 0, 0, 0);
date: { gte: startOfMonth, lte: now }

// After (CORRECT):
const startOfMonth = new Date(year, month, 1);
const startOfNextMonth = new Date(year, month + 1, 1);
date: { gte: startOfMonth, lt: startOfNextMonth }
```

#### 4. Chart Label Truncation in Category Revenue Bar Chart
**Problem:** Category names di chart "Pendapatan per Kategori" terpotong.

**Solution:**
- Increased bottom margin: `0` â†’ `30px`
- Increased font size: `9` â†’ `10`
- Adjusted angle: `-15Â°` â†’ `-25Â°` untuk spacing yang lebih baik
- Added `height={60}` to XAxis component
- Added `interval={0}` to force show all labels

**Files Modified:**
- `src/components/charts/index.tsx` (CategoryBarChart component, Lines 122-133)

### ðŸŒ Infrastructure & DevOps

#### 3. Subdomain Migration & SSL Configuration
**Change:** Migrate dari IP:Port ke subdomain dengan HTTPS support.

**Before:**
- URL: `http://192.168.54.240:3005`
- No SSL/HTTPS
- Direct IP access

**After:**
- URL: `https://server.salfa.my.id`
- HTTPS enabled with SSL certificate
- Cloudflare CDN proxy active
- Professional domain access

**Configuration Changes:**

**Nginx Configuration** (`/etc/nginx/sites-enabled/salfanet-radius`):
```nginx
server {
    listen 80;
    server_name server.salfa.my.id;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name server.salfa.my.id;
    
    ssl_certificate /etc/ssl/server.salfa.my.id/fullchain.pem;
    ssl_certificate_key /etc/ssl/server.salfa.my.id/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    
    location / {
        proxy_pass http://127.0.0.1:3005;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**Environment Variable** (`.env`):
```bash
NEXTAUTH_URL=https://server.salfa.my.id
```

**SSL Certificate:**
- Type: Self-signed certificate
- Subject: `CN=server.salfa.my.id, O=Salfa, L=Jakarta, ST=Jakarta, C=ID`
- Valid Period: 1 year (Dec 6, 2025 - Dec 6, 2026)
- Location: `/etc/ssl/server.salfa.my.id/`

**Generate SSL Certificate Command:**
```bash
sudo mkdir -p /etc/ssl/server.salfa.my.id
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/server.salfa.my.id/privkey.pem \
  -out /etc/ssl/server.salfa.my.id/fullchain.pem \
  -subj "/C=ID/ST=Jakarta/L=Jakarta/O=Salfa/CN=server.salfa.my.id"
sudo chmod 600 /etc/ssl/server.salfa.my.id/privkey.pem
sudo chmod 644 /etc/ssl/server.salfa.my.id/fullchain.pem
```

**Services Restarted:**
- Nginx: `sudo systemctl restart nginx`
- PM2: `sudo pm2 restart salfanet-radius --update-env`

**DNS Configuration:**
- Domain: `server.salfa.my.id`
- DNS Provider: Cloudflare
- A Records point to Cloudflare IPs (proxy enabled)
- Cloudflare SSL/TLS Mode: Full (accepts self-signed from origin)

**Impact:**
- âœ… Secure HTTPS access
- âœ… Professional domain URL
- âœ… Cloudflare CDN protection
- âœ… NextAuth working properly with HTTPS

---

## [2.3.0] - 2025-12-06

### ðŸ”’ Security & Session Management

#### 1. Session Timeout / Auto Logout
- **Idle Detection:** Auto logout setelah 30 menit tidak aktif
- **Warning Modal:** Peringatan 60 detik sebelum logout dengan countdown timer
- **Activity Tracking:** Mouse move, keypress, scroll, click, touch reset timer
- **Tab Visibility:** Timer pause saat tab tidak aktif, resume saat aktif kembali
- **Session Max Age:** Dikurangi dari 30 hari ke 1 hari untuk keamanan

**Files:**
- `src/hooks/useIdleTimeout.ts` (NEW) - Hook untuk idle detection
- `src/app/admin/layout.tsx` (UPDATED) - Integrasi idle timeout + warning modal
- `src/app/admin/login/page.tsx` (UPDATED) - Tampilkan pesan jika logout karena idle
- `src/lib/auth.ts` (UPDATED) - Session maxAge=1 hari, updateAge=1 jam

#### 2. Fix Logout Redirect ke Localhost
- **Problem:** Logout redirect ke localhost:3000 bukan server IP
- **Root Cause:** NEXTAUTH_URL masih localhost di .env
- **Solution:** Gunakan `signOut({ redirect: false })` + `window.location.href`

#### 3. Fix Layout Tidak Muncul Saat Login
- **Problem:** Menu/sidebar kadang tidak muncul setelah login
- **Solution:** Tambah loading state, pisahkan useEffects, proper redirect handling

### ðŸ“ Router GPS Tracking

#### 4. Router GPS Coordinates
- Tambah kolom latitude/longitude di tabel router
- Map picker untuk memilih lokasi router
- Location search dengan autocomplete
- Tampilkan router di Network Map

**Files:**
- `prisma/schema.prisma` (UPDATED) - latitude, longitude di model router
- `src/app/admin/network/routers/page.tsx` (UPDATED) - Form GPS + Map
- `src/components/MapPicker.tsx` (UPDATED) - Support router locations

### ðŸ”Œ Network Enhancements

#### 5. OLT Uplink Configuration
- Konfigurasi uplink dari router ke OLT
- Fetch interface list dari MikroTik router
- Pilih port yang digunakan untuk uplink

**Files:**
- `src/app/api/network/routers/[id]/interfaces/route.ts` (NEW) - Fetch interfaces
- `src/app/api/network/routers/[id]/uplinks/route.ts` (UPDATED) - CRUD uplinks
- `src/app/admin/network/routers/page.tsx` (UPDATED) - Modal OLT Uplink

#### 6. Network Map Enhancement
- Tampilkan uplink info di popup router
- Marker untuk router dengan GPS coordinates
- Connection lines dari router ke OLT via uplinks

#### 7. Fix DELETE API untuk OLT/ODC/ODP
- Accept `id` dari body JSON sebagai fallback (sebelumnya hanya query param)

### ðŸ“¦ Installer Scripts

#### 8. vps-install-local.sh (NEW)
- Installer untuk VPS tanpa akses root langsung (pakai sudo)
- Cocok untuk: Proxmox VM, LXC Container, Local Server
- Sama fiturnya dengan vps-install.sh

### ðŸ“š Documentation Updates
- README.md - Fitur baru, changelog v2.3
- CHAT_MEMORY.md - Session timeout, logout fix, GPS tracking
- install-wizard.html - Session security, dual installer options

---

## [1.4.1] - 2025-12-06

### ðŸš€ New Features

#### 1. Network Map Page
- Visualisasi semua OLT, ODC, ODP di peta interaktif
- Filter berdasarkan OLT dan ODC
- Toggle visibility untuk setiap layer (OLT, ODC, ODP, Pelanggan, Koneksi)
- Garis koneksi antar perangkat (OLT-ODC, ODC-ODP)
- Statistik total perangkat dan port
- Legenda warna untuk setiap tipe perangkat

**Files:**
- `src/app/admin/network/map/page.tsx` (NEW)
- `src/app/admin/layout.tsx` (UPDATED - added Network Map menu)
- `src/locales/id.json` (UPDATED)
- `src/locales/en.json` (UPDATED)

### ðŸ› Bug Fixes

#### 2. FreeRADIUS BOM (Byte Order Mark) Issue
- Fixed UTF-16 BOM detection and removal in config files
- Added `freeradius-rest` package to installation
- Updated REST module pool settings for lazy connection (start=0)
- Improved `remove_bom()` function to handle UTF-16 LE/BE encoding

**Files:**
- `vps-install.sh` (UPDATED)
- `freeradius-config/mods-enabled-rest` (UPDATED)
- `docs/install-wizard.html` (UPDATED - added BOM troubleshooting)

**Problem:** FreeRADIUS config files (especially clients.conf) might have UTF-16 BOM when uploaded from Windows, causing silent parse failure.

**Solution:** Enhanced installer to detect and convert UTF-16 to UTF-8, and remove all types of BOM markers.

---

## [1.4.0] - 2025-12-05

### ðŸš€ New Features

#### 1. Sync PPPoE Users dari MikroTik
- Import PPPoE secrets dari MikroTik router ke database
- Preview user sebelum import
- Pilih user yang ingin di-import
- Hitung jarak GPS untuk setiap user
- Sinkronisasi otomatis ke tabel RADIUS (radcheck, radusergroup, radreply)

**Files:**
- `src/app/api/pppoe/users/sync-mikrotik/route.ts` (NEW)
- `src/app/admin/pppoe/users/page.tsx` (UPDATED)

#### 2. WhatsApp Template Gangguan (Maintenance-Outage)
- Tambah template baru untuk notifikasi gangguan jaringan
- Auto-create missing templates
- Variables: `{{issueType}}`, `{{affectedArea}}`, `{{description}}`, `{{estimatedTime}}`

**Files:**
- `src/app/api/whatsapp/templates/route.ts` (UPDATED)

#### 3. FTTH Network Management
- **OLT Management** (`/admin/network/olts`)
  - CRUD OLT (Optical Line Terminal)
  - Assignment ke multiple router
  - GPS location dengan Map picker
  
- **ODC Management** (`/admin/network/odcs`)
  - CRUD ODC (Optical Distribution Cabinet)
  - Link ke OLT dengan PON port
  - Filter berdasarkan OLT
  
- **ODP Management** (`/admin/network/odps`)
  - CRUD ODP (Optical Distribution Point)
  - Connect ke ODC atau Parent ODP
  - Konfigurasi port count
  
- **Customer Assignment** (`/admin/network/customers`)
  - Assign pelanggan ke port ODP
  - Pencarian nearest ODP dengan perhitungan jarak
  - Lihat port yang tersedia

**Files:**
- `src/app/admin/network/olts/page.tsx` (NEW)
- `src/app/admin/network/odcs/page.tsx` (NEW)
- `src/app/admin/network/odps/page.tsx` (NEW)
- `src/app/admin/network/customers/page.tsx` (NEW)
- `src/app/admin/layout.tsx` (UPDATED - menu)
- `src/locales/id.json` (UPDATED - translations)
- `src/locales/en.json` (UPDATED - translations)

### ðŸ”§ Improvements

#### Auto GPS Error Handling
- Pesan error spesifik untuk setiap jenis error GPS
- Feedback sukses saat GPS berhasil
- Timeout ditingkatkan ke 15 detik

**Files:**
- `src/app/admin/network/olts/page.tsx`
- `src/app/admin/network/odcs/page.tsx`
- `src/app/admin/network/odps/page.tsx`

---

## [1.3.1] - 2025-01-06

### ðŸ”§ Fix: FreeRADIUS Config BOM Issue

#### Problem
- FreeRADIUS tidak binding ke port 1812/1813 pada instalasi fresh di Proxmox VPS
- SQL module menampilkan "Ignoring sql" dan tidak loading
- REST module tidak loading

#### Root Cause
- File konfigurasi FreeRADIUS memiliki UTF-16 BOM (Byte Order Mark) character di awal file
- BOM (0xFFFE) menyebabkan FreeRADIUS silent fail saat parsing config
- Ini terjadi jika file di-edit di Windows atau dengan editor yang menyimpan UTF-8/16 BOM

#### Solution
1. **Added BOM removal function** di `vps-install.sh`
   ```bash
   remove_bom() {
       sed -i '1s/^\xEF\xBB\xBF//' "$1"
   }
   ```

2. **Updated install-wizard.html** dengan instruksi BOM removal
3. **Updated FREERADIUS-SETUP.md** dengan troubleshooting guide
4. **Synced freeradius-config/** folder dari VPS production yang sudah berjalan

#### Files Changed
- `vps-install.sh` - Added BOM removal after copying config files
- `docs/install-wizard.html` - Added BOM warning and removal commands
- `docs/FREERADIUS-SETUP.md` - Added BOM troubleshooting section
- `freeradius-config/sites-enabled-default` - Updated from working VPS

#### Verification
```bash
# Check if file has BOM
xxd /etc/freeradius/3.0/mods-available/sql | head -1
# Good: starts with "7371 6c" (sql)
# Bad: starts with "fffe" or "efbb bf" (BOM)

# Verify FreeRADIUS binding
ss -tulnp | grep radiusd
# Should show ports 1812, 1813, 3799
```

---

## [1.3.0] - 2025-12-03

### ðŸŽ¯ Major Fix: FreeRADIUS PPPoE & Hotspot Coexistence

#### Problem
- PPPoE users with `username@realm` format were getting Access-Reject
- REST API post-auth was failing for PPPoE users (voucher not found)

#### Solution
1. **Disabled `filter_username` policy** in FreeRADIUS
   - Location: `/etc/freeradius/3.0/sites-enabled/default` line ~293
   - Changed: `filter_username` â†’ `#filter_username`
   - Reason: Policy was rejecting realm-style usernames without proper domain

2. **Added conditional REST for vouchers only**
   - Only call REST API for usernames WITHOUT `@`
   - PPPoE users (with `@`) skip REST and get authenticated via SQL only
   ```
   if (!("%{User-Name}" =~ /@/)) {
       rest.post-auth
   }
   ```

3. **Fixed post-auth API**
   - Return success for unmanaged vouchers (backward compatibility)
   - Only process vouchers that exist in `hotspotVoucher` table

#### Files Changed
- `/etc/freeradius/3.0/sites-enabled/default` - Disabled filter_username, added conditional REST
- `src/app/api/radius/post-auth/route.ts` - Return success for unmanaged vouchers

#### Testing
```bash
# PPPoE user (with @) - should get Access-Accept
radtest 'user@realm' 'password' 127.0.0.1 0 testing123

# Hotspot voucher (without @) - should get Access-Accept
radtest 'VOUCHERCODE' 'password' 127.0.0.1 0 testing123
```

### ðŸ“¦ Project Updates
- Added `freeradius-config/` directory with configuration backups
- Updated `vps-install.sh` with proper FreeRADIUS setup
- Added `docs/FREERADIUS-SETUP.md` documentation
- Updated `README.md` with comprehensive documentation
- Fresh database backup: `backup/salfanet_radius_backup_20251203.sql`

---

## [1.2.0] - 2025-12-03

### ðŸŽ¯ Major Features

#### Agent Deposit & Balance System
- **Deposit System**: Agent can now top up balance via payment gateway (Midtrans/Xendit/Duitku)
- **Balance Management**: Agent balance is tracked and required before generating vouchers
- **Auto Deduction**: Voucher generation automatically deducts balance based on costPrice
- **Minimum Balance**: Admin can set minimum balance requirement per agent
- **Payment Tracking**: Track agent sales with payment status (PAID/UNPAID)

**Technical Details:**
- New table: `agent_deposits` for tracking deposits via payment gateway
- New fields: `agent.balance`, `agent.minBalance`
- Generate voucher checks balance before creating vouchers
- Webhook endpoint processes payment callbacks and updates balance
- Sales tracking includes payment status for admin reconciliation

**Workflow:**
1. Agent deposits via payment gateway â†’ Balance increases
2. Agent generates vouchers â†’ Balance deducted (costPrice Ã— quantity)
3. Customer uses voucher â†’ Commission recorded as UNPAID
4. Admin marks sales as PAID after agent payment

**Files Changed:**
- `prisma/schema.prisma` - Added agent deposit tables and balance fields
- `src/app/api/agent/deposit/create/route.ts` - NEW: Create deposit payment
- `src/app/api/agent/deposit/webhook/route.ts` - NEW: Handle payment callbacks
- `src/app/api/agent/generate-voucher/route.ts` - Added balance check and deduction
- `docs/AGENT_DEPOSIT_SYSTEM.md` - NEW: Complete implementation guide

**Database Changes:**
```sql
-- Add balance fields to agents
ALTER TABLE agents ADD balance INT DEFAULT 0;
ALTER TABLE agents ADD minBalance INT DEFAULT 0;

-- Create deposits table
CREATE TABLE agent_deposits (...);

-- Add payment tracking to sales
ALTER TABLE agent_sales ADD paymentStatus VARCHAR(191) DEFAULT 'UNPAID';
ALTER TABLE agent_sales ADD paymentDate DATETIME;
ALTER TABLE agent_sales ADD paymentMethod VARCHAR(191);
```

## [1.1.0] - 2025-12-03

### ðŸŽ¯ Major Features

#### Sessions & Bandwidth Monitoring
- **Real-time Bandwidth**: Sessions page now fetches live bandwidth data directly from MikroTik API instead of relying on RADIUS interim-updates (which weren't being sent)
- **Session Disconnect**: Fixed disconnect functionality to use MikroTik API directly instead of CoA/radclient
- **Port Configuration**: Uses `router.port` field for MikroTik API connection (the forwarded port)

**Technical Details:**
- Hotspot: Uses `/ip/hotspot/active/print` for sessions, `/ip/hotspot/active/remove` for disconnect
- PPPoE: Uses `/ppp/active/print` for sessions, `/ppp/active/remove` for disconnect
- Traffic: Real-time bytes from `bytes-in` and `bytes-out` fields

**Files Changed:**
- `src/app/api/sessions/route.ts` - Added real-time bandwidth fetching
- `src/app/api/sessions/disconnect/route.ts` - Replaced CoA with MikroTik API

#### GenieACS Integration
- **Device Parsing**: Fixed GenieACS device data parsing to correctly extract device information
- **Virtual Parameters**: Properly reads VirtualParameters with `_value` property
- **Debug Endpoint**: Added `/api/settings/genieacs/debug` for troubleshooting

**Technical Details:**
- Device ID fields use underscore prefix: `_deviceId._Manufacturer`, `_deviceId._SerialNumber`
- Virtual Parameters format: `VirtualParameters.rxPower._value`, `VirtualParameters.ponMode._value`
- OUI extraction from device ID format: `DEVICE_ID-ProductClass-OUI-SerialNumber`

**Files Changed:**
- `src/app/api/settings/genieacs/devices/route.ts` - Fixed data extraction
- `src/app/api/settings/genieacs/debug/route.ts` - New debug endpoint

### ðŸ› Bug Fixes

1. **Sessions Page**
   - Fixed: Bandwidth showing "0 B" for active sessions
   - Fixed: Disconnect button showing success but not actually disconnecting
   - Root cause: Using wrong port field (`apiPort` instead of `port`)

2. **GenieACS Page**
   - Fixed: Table columns showing empty/undefined values
   - Fixed: Device manufacturer, model, serial number not displaying
   - Root cause: Wrong path for accessing device properties

3. **Agent Voucher Generation**
   - Fixed: Vouchers not linked to agent account
   - Root cause: `agentId` not being saved when creating voucher
   - Impact: Agent sales tracking now works correctly

4. **GPS Auto Location**
   - Fixed: GPS Auto error on HTTP sites
   - Added: HTTPS requirement check with friendly error message
   - Added: Better error handling for permission denied, timeout, etc.
   - Files: `src/app/admin/pppoe/users/page.tsx`, `src/components/UserDetailModal.tsx`

### ðŸ“ File Structure

```
Changes in this release:
â”œâ”€â”€ src/app/api/sessions/
â”‚   â”œâ”€â”€ route.ts              # Updated - real-time bandwidth
â”‚   â””â”€â”€ disconnect/route.ts   # Updated - MikroTik API disconnect
â”œâ”€â”€ src/app/api/settings/genieacs/
â”‚   â”œâ”€â”€ devices/route.ts      # Updated - device data parsing
â”‚   â””â”€â”€ debug/route.ts        # New - debug endpoint
â””â”€â”€ README.md                 # Updated - changelog section
```

### ðŸ”§ Configuration Notes

**Router Configuration:**
- `port` field: Used for MikroTik API connection (forwarded port, e.g., 44039)
- `apiPort` field: Legacy, not used for direct API calls
- `ipAddress` field: Public IP for API connection
- `nasname` field: Used for RADIUS NAS identification

**MikroTik Setup:**
- Ensure API service is enabled on router
- Forward API port (8728) to public IP if needed
- API user must have read/write permissions

---

## [1.0.0] - 2025-12-01

### Initial Release
- Full billing system for RTRW.NET ISP
- FreeRADIUS integration (PPPoE & Hotspot)
- Multi-router/NAS support
- Payment gateway integration (Midtrans, Xendit, Duitku)
- WhatsApp notifications
- Network mapping (OLT, ODC, ODP)
- Agent/reseller management
- Role-based permissions (53 permissions, 6 roles)


---

# BAGIAN 2: CHAT HISTORY SESSION TERAKHIR


# Chat History - December 28, 2025 (Session 3)

## Objective
Fix hotspot voucher auto-disconnect and implement real-time updates with timezone synchronization

## Issues Resolved

### 1. **SSE Real-time Implementation** âœ…
- **Created:** `src/lib/sse-manager.ts` - Singleton SSE manager for channel-based broadcasting
- **Created:** `src/app/api/sse/voucher-updates/route.ts` - SSE endpoint streaming real-time events
- **Created:** `src/hooks/useSSE.ts` - React hook with auto-reconnect and event handlers
- **Updated:** `src/lib/cron/hotspot-voucher-cron.ts` - Added SSE broadcast after voucher changes
- **Updated:** `src/app/admin/hotspot/voucher/page.tsx` - Integrated SSE with WiFi connection indicator

**Features:**
- Real-time voucher stats updates (30s keep-alive)
- Auto-reconnect on connection loss
- WiFi indicator shows connection status
- Events: `voucher-stats`, `voucher-changed`

### 2. **Timezone Synchronization Fix** âœ… (CRITICAL)
**Root Cause:** Cronjob detected expiration incorrectly due to UTC vs WIB timezone mismatch
- Database stores datetime in WIB (Asia/Jakarta)
- Prisma `new Date()` uses UTC
- Comparison: 07:34 UTC < 14:23 WIB â†’ false (wrong!)

**Solution Applied:**
1. Load company timezone at cron start
2. Use `nowWIB()` for timezone-aware current time
3. **Phase 2 uses raw SQL with MySQL NOW()** - respects database timezone
4. All datetime operations follow Company Settings (`/settings/company`)

**Changes:**
```typescript
// Load company timezone
const company = await prisma.company.findFirst({ select: { timezone: true } })
if (company?.timezone) {
  setCurrentTimezone(company.timezone)
}

// Use timezone-aware time
const now = nowWIB()

// Phase 2: Raw SQL with MySQL NOW()
const expiredByValidity = await prisma.$queryRaw`
  SELECT v.id, v.code, v.status, v.expiresAt, v.profileId, v.routerId
  FROM hotspot_vouchers v
  WHERE v.status = 'ACTIVE'
  AND v.expiresAt IS NOT NULL
  AND v.expiresAt <= NOW()
`
```

**Verified:**
- âœ… Timezone loaded: `Asia/Jakarta` from company settings
- âœ… Cron logs show: `[Voucher Cron] Using timezone: Asia/Jakarta`
- âœ… MySQL timezone: SYSTEM (Asia/Jakarta)
- âœ… Phase 2 now detects expiration correctly (not delayed to Phase 3)

### 3. **CoA Order Fix** âœ…
Reordered Phase 3 cleanup to send CoA BEFORE marking session stopped:
```typescript
// 1. Send CoA FIRST
await sendCoADisconnect(...)
// 2. Then mark session stopped
await prisma.radacct.update({ data: { acctstoptime: new Date() } })
```

## Files Modified

### Created
1. `src/lib/sse-manager.ts` (100 lines)
2. `src/app/api/sse/voucher-updates/route.ts`
3. `src/hooks/useSSE.ts` (120 lines)

### Modified
1. `src/lib/cron/hotspot-voucher-cron.ts`
   - Added timezone loading and synchronization
   - Changed Phase 2 to use raw SQL with MySQL NOW()
   - Added SSE broadcast on changes
   - Fixed CoA order in Phase 3

2. `src/app/admin/hotspot/voucher/page.tsx`
   - Integrated SSE real-time updates
   - Added WiFi connection indicator
   - Auto-refresh on voucher changes

## Environment Details

**VPS:**
- IP: 103.191.165.156:9500
- Path: /var/www/salfanet-radius
- PM2: restart #43
- Database: salfanet_radius (MySQL)

**Network:**
- VPN Gateway: 172.20.30.1 (Mikrotik CHR)
- VPS RADIUS: 172.20.30.10 (ppp0)
- NAS Mikrotik: 172.20.30.11
- CoA Port: 3799 (working)

**Timezone:**
- System: Asia/Jakarta (WIB, UTC+7)
- MySQL: SYSTEM â†’ Asia/Jakarta
- Company Setting: Asia/Jakarta
- All synchronized âœ…

## Results

âœ… **Voucher Lifecycle:** WAITING â†’ ACTIVE â†’ EXPIRED working correctly
âœ… **Phase 2 Detection:** Now detects expiration immediately (not delayed)
âœ… **CoA Disconnect:** Sent immediately when voucher expires
âœ… **Real-time Updates:** SSE broadcasts to UI instantly
âœ… **Timezone Sync:** All operations follow company settings
âœ… **Auto-refresh:** 30s fallback + SSE real-time
âœ… **User Experience:** Expired vouchers disconnect instantly

## Key Learnings

1. **Timezone Critical:** Always use raw SQL with MySQL NOW() for datetime comparisons to respect database timezone
2. **SSE Architecture:** Singleton manager + channel-based broadcasting is efficient for real-time updates
3. **CoA Timing:** Send disconnect BEFORE marking session stopped to avoid race conditions
4. **Company Settings:** All timezone operations must follow `/settings/company` configuration

## Session Summary

Successfully fixed critical timezone synchronization issue causing delayed voucher expiration detection. Implemented complete SSE real-time architecture for instant UI updates. System now properly synchronizes all datetime operations with company timezone settings, resulting in immediate voucher disconnect when expired.


---

# BAGIAN 3: DOKUMENTASI TEKNIS LENGKAP




## [1] README.md


# AIBILL RADIUS - Documentation Index

**Version**: 2.7.5  
**Last Updated**: December 23, 2025

---

## ðŸ“– Quick Start

### ðŸŽ¯ New to AIBILL RADIUS?
Start here â†’ **[COMPREHENSIVE_FEATURE_GUIDE.md](COMPREHENSIVE_FEATURE_GUIDE.md)**
- Complete overview of all features (100+)
- 15 major sections covering entire system
- Quick reference for all capabilities

---

## ðŸ“š Documentation Categories

### ðŸš€ Installation & Deployment

| Document | Description | Size |
|----------|-------------|------|
| **[DEPLOYMENT-GUIDE.md](DEPLOYMENT-GUIDE.md)** | Complete VPS deployment guide | 9.8 KB |
| **[FREERADIUS-SETUP.md](FREERADIUS-SETUP.md)** | FreeRADIUS installation & configuration | 14.8 KB |
| **[VPS_OPTIMIZATION_GUIDE.md](VPS_OPTIMIZATION_GUIDE.md)** | Performance tuning for low-resource VPS | 8.9 KB |
| **[VPN_CLIENT_SETUP_GUIDE.md](VPN_CLIENT_SETUP_GUIDE.md)** | VPN setup for remote routers | 4.6 KB |

**When to use**: First-time installation, server migration, VPN configuration

---

### âš™ï¸ Core Systems

| Document | Description | Size |
|----------|-------------|------|
| **[CRON-SYSTEM.md](CRON-SYSTEM.md)** | 10 automated jobs & scheduling | 20.1 KB |
| **[ACTIVITY_LOG_IMPLEMENTATION.md](ACTIVITY_LOG_IMPLEMENTATION.md)** | Activity tracking & audit logs | 9.9 KB |

**When to use**: Understanding automation, debugging cron jobs, audit requirements

---

### ðŸ’° Billing & Payment

| Document | Description | Size |
|----------|-------------|------|
| **[PREPAID_POSTPAID_IMPLEMENTATION.md](PREPAID_POSTPAID_IMPLEMENTATION.md)** | Prepaid vs Postpaid billing types | 11.2 KB |
| **[MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md](MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md)** | Upload bukti transfer & approval | 7.8 KB |
| **[INVOICE_NUMBER_FORMAT.md](INVOICE_NUMBER_FORMAT.md)** | Invoice numbering system | 4.6 KB |
| **[AGENT_DEPOSIT_SYSTEM.md](AGENT_DEPOSIT_SYSTEM.md)** | Agent balance & deposit management | 7.4 KB |

**When to use**: Setting up billing, payment gateway integration, agent system

---

### ðŸ“¢ Notifications & Communication

| Document | Description | Size |
|----------|-------------|------|
| **[BROADCAST_NOTIFICATION_SYSTEM.md](BROADCAST_NOTIFICATION_SYSTEM.md)** | Mass WhatsApp & Email notifications | 7.1 KB |
| **[OUTAGE_NOTIFICATION_SYSTEM.md](OUTAGE_NOTIFICATION_SYSTEM.md)** | Automated downtime alerts | 9.7 KB |

**When to use**: Setting up notification templates, broadcast messages

---

### ðŸ”§ Advanced Features

| Document | Description | Size |
|----------|-------------|------|
| **[GENIEACS-GUIDE.md](GENIEACS-GUIDE.md)** | TR-069 device management (ONT/ONU) | 12 KB |
| **[MULTIPLE_NAS_SAME_IP.md](MULTIPLE_NAS_SAME_IP.md)** | Multi-router VPN support | 9.1 KB |
| **[GPS_LOCATION_FEATURE.md](GPS_LOCATION_FEATURE.md)** | Customer GPS tracking | 2.6 KB |
| **[IMPORT_PPPOE_USERS.md](IMPORT_PPPOE_USERS.md)** | Sync from MikroTik PPPoE secrets | 5.3 KB |

**When to use**: GenieACS setup, VPN scenarios, bulk import, GPS features

---

### ðŸ§ª Testing & Troubleshooting

| Document | Description | Size |
|----------|-------------|------|
| **[TESTING_GUIDE.md](TESTING_GUIDE.md)** | Test procedures & verification | 12.3 KB |
| **[TROUBLESHOOTING.md](TROUBLESHOOTING.md)** | Common issues & solutions | 7.1 KB |

**When to use**: QA testing, debugging issues, error resolution

---

## ðŸ—‚ï¸ Documentation Structure

```
docs/
â”œâ”€â”€ README.md (this file)
â”œâ”€â”€ COMPREHENSIVE_FEATURE_GUIDE.md  â­ START HERE
â”‚
â”œâ”€â”€ Installation & Deployment/
â”‚   â”œâ”€â”€ DEPLOYMENT-GUIDE.md
â”‚   â”œâ”€â”€ FREERADIUS-SETUP.md
â”‚   â”œâ”€â”€ VPS_OPTIMIZATION_GUIDE.md
â”‚   â””â”€â”€ VPN_CLIENT_SETUP_GUIDE.md
â”‚
â”œâ”€â”€ Core Systems/
â”‚   â”œâ”€â”€ CRON-SYSTEM.md
â”‚   â””â”€â”€ ACTIVITY_LOG_IMPLEMENTATION.md
â”‚
â”œâ”€â”€ Billing & Payment/
â”‚   â”œâ”€â”€ PREPAID_POSTPAID_IMPLEMENTATION.md
â”‚   â”œâ”€â”€ MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md
â”‚   â”œâ”€â”€ INVOICE_NUMBER_FORMAT.md
â”‚   â””â”€â”€ AGENT_DEPOSIT_SYSTEM.md
â”‚
â”œâ”€â”€ Notifications/
â”‚   â”œâ”€â”€ BROADCAST_NOTIFICATION_SYSTEM.md
â”‚   â””â”€â”€ OUTAGE_NOTIFICATION_SYSTEM.md
â”‚
â”œâ”€â”€ Advanced Features/
â”‚   â”œâ”€â”€ GENIEACS-GUIDE.md
â”‚   â”œâ”€â”€ MULTIPLE_NAS_SAME_IP.md
â”‚   â”œâ”€â”€ GPS_LOCATION_FEATURE.md
â”‚   â””â”€â”€ IMPORT_PPPOE_USERS.md
â”‚
â””â”€â”€ Testing & Troubleshooting/
    â”œâ”€â”€ TESTING_GUIDE.md
    â””â”€â”€ TROUBLESHOOTING.md
```

---

## ðŸŽ¯ Common Tasks

### "I want to deploy to VPS for the first time"
1. Read [DEPLOYMENT-GUIDE.md](DEPLOYMENT-GUIDE.md)
2. Follow [FREERADIUS-SETUP.md](FREERADIUS-SETUP.md)
3. Run `./vps-install.sh` on server
4. Test with [TESTING_GUIDE.md](TESTING_GUIDE.md)

### "I need to setup prepaid/postpaid billing"
1. Read [PREPAID_POSTPAID_IMPLEMENTATION.md](PREPAID_POSTPAID_IMPLEMENTATION.md)
2. Configure invoice generation in [CRON-SYSTEM.md](CRON-SYSTEM.md#generate-invoices)
3. Setup payment notifications

### "I want to enable manual payment upload"
1. Read [MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md](MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md)
2. Configure payment gateway (if needed)
3. Test upload & approval workflow

### "I need to send mass notifications"
1. Read [BROADCAST_NOTIFICATION_SYSTEM.md](BROADCAST_NOTIFICATION_SYSTEM.md)
2. Configure WhatsApp/Email templates
3. Use admin panel broadcast feature

### "I want to manage TR-069 devices"
1. Read [GENIEACS-GUIDE.md](GENIEACS-GUIDE.md)
2. Install GenieACS server
3. Configure ACS parameters

### "Something is not working"
1. Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md) first
2. Review relevant feature documentation
3. Check activity logs & cron execution history

---

## ðŸ“Š Statistics

- **Total Documents**: 18 markdown files
- **Total Size**: ~170 KB
- **Features Documented**: 100+
- **Code Examples**: 200+
- **API Endpoints**: 50+

---

## ðŸ”„ Version History

### v2.7.5 (December 23, 2025)
- âœ… Added COMPREHENSIVE_FEATURE_GUIDE.md
- âœ… Cleaned up session notes (moved to CHAT_HISTORY)
- âœ… Documentation index (this file)

### v2.7.4 (December 2025)
- Hotspot sync improvements
- Isolation templates
- Activity log system

### v2.7.0 (October 2025)
- Manual payment system
- Prepaid/Postpaid implementation
- Broadcast notifications

---

## ðŸ“ž Support

**Documentation Issues**: Report in GitHub Issues  
**Technical Support**: support@yourdomain.com  
**Community**: Join our Discord/Telegram

---

**Generated**: December 23, 2025  
**Maintained by**: AIBILL RADIUS Team  
**License**: Proprietary


## [2] DEPLOYMENT-GUIDE.md


# SALFANET RADIUS - Deployment Guide

Panduan lengkap untuk deploy SALFANET RADIUS ke VPS baru.

> **Latest Update:** December 7, 2025 - Subdomain & SSL Configuration

## ðŸ“‹ Prerequisites

- Ubuntu 20.04/22.04 LTS
- Minimum 2GB RAM, 20GB Storage
- Root access
- Domain name (optional, untuk SSL/HTTPS)

## ðŸš€ Quick Deploy (From Backup)

### 1. Upload Project ke VPS

```bash
# Dari komputer lokal
scp -r salfanet-radius-main root@YOUR_VPS_IP:/root/
```

### 2. Install Dependencies

```bash
ssh root@YOUR_VPS_IP

# Update system
apt update && apt upgrade -y

# Install Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs

# Install MySQL 8.0
apt install -y mysql-server

# Install FreeRADIUS
apt install -y freeradius freeradius-mysql freeradius-utils

# Install Nginx
apt install -y nginx

# Install PM2
npm install -g pm2
```

### 3. Setup Database

```bash
# Login ke MySQL
mysql -u root

# Create database and user
CREATE DATABASE salfanet_radius CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'salfanet_user'@'localhost' IDENTIFIED BY 'salfanetradius123';
GRANT ALL PRIVILEGES ON salfanet_radius.* TO 'salfanet_user'@'localhost';
FLUSH PRIVILEGES;
EXIT;

# Import database backup
cd /root/salfanet-radius-main
mysql -u salfanet_user -psalfanetradius123 salfanet_radius < backup/salfanet_radius_backup_20251203.sql
```

### 4. Setup FreeRADIUS

```bash
# Extract FreeRADIUS config backup
cd /root/salfanet-radius-main/backup
tar -xzf freeradius-config-20251203.tar.gz -C /etc/freeradius/

# Update SQL credentials di /etc/freeradius/3.0/mods-enabled/sql
nano /etc/freeradius/3.0/mods-enabled/sql
# Set: login = "salfanet_user", password = "salfanetradius123"

# Update REST URL di /etc/freeradius/3.0/mods-enabled/rest
nano /etc/freeradius/3.0/mods-enabled/rest
# Set: uri = "http://127.0.0.1:3000/api/radius/post-auth"

# Test configuration
freeradius -XC

# Enable and start FreeRADIUS
systemctl enable freeradius
systemctl start freeradius
```

### 5. Setup Application

```bash
cd /root/salfanet-radius-main

# Copy to /var/www
mkdir -p /var/www/salfanet-radius
cp -r * /var/www/salfanet-radius/
cd /var/www/salfanet-radius

# Setup .env
cp backup/env-production-20251203 .env
# Edit .env sesuai kebutuhan
nano .env

# Install dependencies
npm install

# Generate Prisma client
npx prisma generate

# Build application
npm run build
```

### 6. Setup PM2

```bash
cd /var/www/salfanet-radius

# Start dengan PM2
pm2 start ecosystem.config.js

# Save PM2 config
pm2 save

# Setup PM2 startup
pm2 startup
```

### 7. Setup Nginx

```bash
# Copy nginx config
cp /var/www/salfanet-radius/backup/nginx-salfanet-radius.conf /etc/nginx/sites-available/salfanet-radius

# Edit server_name sesuai domain/IP
nano /etc/nginx/sites-available/salfanet-radius

# Enable site
ln -s /etc/nginx/sites-available/salfanet-radius /etc/nginx/sites-enabled/

# Test dan restart nginx
nginx -t
systemctl restart nginx
```

### 8. Setup Firewall

```bash
ufw allow 22/tcp     # SSH
ufw allow 80/tcp     # HTTP
ufw allow 443/tcp    # HTTPS
ufw allow 1812/udp   # RADIUS Auth
ufw allow 1813/udp   # RADIUS Accounting
ufw allow 3799/udp   # RADIUS CoA
ufw enable
```

## ðŸ“ Backup Files

| File | Deskripsi |
|------|-----------|
| `backup/salfanet_radius_backup_20251203.sql` | Database backup |
| `backup/freeradius-config-20251203.tar.gz` | FreeRADIUS config |
| `backup/env-production-20251203` | Environment variables |
| `backup/nginx-salfanet-radius.conf` | Nginx config |
| `backup/ecosystem.config.js` | PM2 config |

## ðŸ”§ Configuration Files

### .env (Environment Variables)

```env
DATABASE_URL="mysql://salfanet_user:salfanetradius123@localhost:3306/salfanet_radius?connection_limit=10&pool_timeout=20"
NEXTAUTH_SECRET="your-secret-key"
NEXTAUTH_URL="http://YOUR_VPS_IP"
RADIUS_COA_SECRET="secret123"
RADIUS_COA_PORT="3799"
```

### ecosystem.config.js (PM2)

```javascript
module.exports = {
  apps: [{
    name: 'salfanet-radius',
    script: 'npm',
    args: 'start',
    cwd: '/var/www/salfanet-radius',
    instances: 1,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
}
```

### Nginx Config

```nginx
server {
    listen 80;
    server_name YOUR_DOMAIN_OR_IP;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## ðŸ”Œ MikroTik Configuration

### RADIUS Client Setup

```
/radius
add address=YOUR_VPS_IP secret=secret123 service=ppp,hotspot timeout=3s

/radius incoming
set accept=yes port=3799
```

### PPPoE Server Setup

```
/ppp profile
add name=10M rate-limit=10M/10M
add name=20M rate-limit=20M/20M

/ppp aaa
set use-radius=yes accounting=yes
```

### Hotspot Setup

```
/ip hotspot profile
set [find default=yes] use-radius=yes radius-accounting=yes
```

## âœ… Verification

### Test FreeRADIUS

```bash
# Test PPPoE user
radtest 'user@realm' 'password' 127.0.0.1 0 testing123

# Test Hotspot voucher
radtest 'vouchercode' 'password' 127.0.0.1 0 testing123
```

### Test CoA

```bash
# Test CoA connection to MikroTik
curl -X POST http://localhost:3000/api/radius/coa \
  -H "Content-Type: application/json" \
  -d '{"action":"test","host":"MIKROTIK_IP"}'
```

### Test Application

```bash
# Check PM2 status
pm2 status

# Check logs
pm2 logs salfanet-radius

# Check nginx
systemctl status nginx

# Check FreeRADIUS
systemctl status freeradius
```

## ðŸ“ Credentials

### Default Admin Login
- **URL**: http://YOUR_VPS_IP/admin/login
- **Username**: superadmin
- **Password**: admin123

âš ï¸ **Change password immediately after login!**

### Database
- **User**: salfanet_user
- **Password**: salfanetradius123
- **Database**: salfanet_radius

### RADIUS Secret
- **Secret**: secret123 (sesuaikan dengan MikroTik)

## ðŸ”„ Maintenance Commands

```bash
# Restart application
pm2 restart salfanet-radius

# View logs
pm2 logs salfanet-radius --lines 100

# Rebuild application
cd /var/www/salfanet-radius
npm run build
pm2 restart salfanet-radius

# Backup database
mysqldump -u salfanet_user -psalfanetradius123 salfanet_radius > backup.sql

# Restart FreeRADIUS
systemctl restart freeradius

# Debug FreeRADIUS
systemctl stop freeradius
freeradius -X
```

## ðŸ†˜ Troubleshooting

### Application tidak bisa diakses
```bash
pm2 status
pm2 logs salfanet-radius
nginx -t
systemctl restart nginx
```

### RADIUS authentication gagal
```bash
systemctl stop freeradius
freeradius -X
# Check log untuk error detail
```

### CoA tidak berfungsi
```bash
# Pastikan MikroTik sudah enable CoA
# /radius incoming set accept=yes port=3799

# Test dengan radclient
echo "User-Name=testuser" | radclient -x MIKROTIK_IP:3799 coa secret123
```

### Database connection error
```bash
mysql -u salfanet_user -psalfanetradius123 salfanet_radius -e "SELECT 1"
# Check .env DATABASE_URL
```

### Dashboard statistics showing Rp 0 or 0 users
```bash
# Check PM2 logs for transaction count
pm2 logs salfanet-radius | grep "transactionCount"

# Verify database has transactions
mysql -u salfanet_user -psalfanetradius123 salfanet_radius -e "SELECT COUNT(*) FROM transactions WHERE type='INCOME'"

# Restart PM2 with updated environment
pm2 restart salfanet-radius --update-env
```

---

## ðŸŒ Setup Subdomain & SSL (Optional)

### 1. Generate Self-Signed Certificate

```bash
# Create SSL directory
sudo mkdir -p /etc/ssl/YOUR_DOMAIN

# Generate certificate (valid 1 year)
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/YOUR_DOMAIN/privkey.pem \
  -out /etc/ssl/YOUR_DOMAIN/fullchain.pem \
  -subj "/C=ID/ST=Jakarta/L=Jakarta/O=YourCompany/CN=YOUR_DOMAIN"

# Set permissions
sudo chmod 600 /etc/ssl/YOUR_DOMAIN/privkey.pem
sudo chmod 644 /etc/ssl/YOUR_DOMAIN/fullchain.pem
```

### 2. Update Nginx Configuration

```nginx
server {
    listen 80;
    server_name YOUR_DOMAIN;
    return 301 https://$host$request_uri;
}

server {
    listen 443 ssl http2;
    server_name YOUR_DOMAIN;

    ssl_certificate /etc/ssl/YOUR_DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/ssl/YOUR_DOMAIN/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

### 3. Update Environment Variable

```bash
cd /var/www/salfanet-radius
sudo nano .env
# Change: NEXTAUTH_URL=https://YOUR_DOMAIN
```

### 4. Restart Services

```bash
# Test Nginx config
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx

# Restart PM2 with updated env
sudo pm2 restart salfanet-radius --update-env
```

### 5. Firewall (Allow HTTPS)

```bash
sudo ufw allow 443/tcp
sudo ufw reload
```

### 6. Cloudflare Setup (If using Cloudflare)

- Add A record pointing to your VPS IP
- Enable proxy (orange cloud) for CDN protection
- Set SSL/TLS mode to "Full" (accepts self-signed from origin)
- Wait for DNS propagation (5-10 minutes)

---

Last Updated: December 3, 2025


## [3] FREERADIUS-SETUP.md


# FreeRADIUS Setup Guide for SALFANET RADIUS

This guide explains how to configure FreeRADIUS for both PPPoE and Hotspot authentication.

## Overview

SALFANET RADIUS uses FreeRADIUS 3.0 with MySQL backend to authenticate:
1. **PPPoE Users** - Customer accounts with `username@realm` format
2. **Hotspot Vouchers** - One-time codes without `@` symbol

## Installation

### Install FreeRADIUS
```bash
apt-get install -y freeradius freeradius-mysql freeradius-utils
```

### Verify Installation
```bash
freeradius -v
# Should show: FreeRADIUS Version 3.0.x
```

## âš ï¸ IMPORTANT: Remove BOM from Config Files

If config files were edited on Windows or with editors that save UTF-8 BOM (Byte Order Mark), FreeRADIUS will silently fail to parse them. This causes:
- FreeRADIUS not binding to ports 1812/1813
- SQL module showing "Ignoring sql"
- REST module not loading

**Always remove BOM after copying config files:**
```bash
# Function to remove BOM
remove_bom() {
    sed -i '1s/^\xEF\xBB\xBF//' "$1"
}

# Apply to all config files
remove_bom /etc/freeradius/3.0/mods-available/sql
remove_bom /etc/freeradius/3.0/mods-available/rest
remove_bom /etc/freeradius/3.0/sites-available/default
remove_bom /etc/freeradius/3.0/clients.conf
```

**Verify no BOM exists:**
```bash
# Should show 's' for sql, 'r' for rest, '#' for default
xxd /etc/freeradius/3.0/mods-available/sql | head -1
# If you see "fffe" at the beginning, there's a BOM that needs to be removed
```

## Configuration Files

### 1. SQL Module (`/etc/freeradius/3.0/mods-enabled/sql`)

```
sql {
    driver = "rlm_sql_mysql"
    dialect = "mysql"
    
    server = "localhost"
    port = 3306
    login = "salfanet_user"
    password = "salfanetradius123"
    
    radius_db = "salfanet_radius"
    
    acct_table1 = "radacct"
    acct_table2 = "radacct"
    postauth_table = "radpostauth"
    authcheck_table = "radcheck"
    groupcheck_table = "radgroupcheck"
    authreply_table = "radreply"
    groupreply_table = "radgroupreply"
    usergroup_table = "radusergroup"
    
    # Load NAS/clients from database
    read_clients = yes
    client_table = "nas"
    
    # Required for PPPoE group profiles
    read_groups = yes
    read_profiles = yes
    
    # Username format for queries
    sql_user_name = "%{%{Stripped-User-Name}:-%{User-Name}}"
    
    # Group attribute
    group_attribute = "SQL-Group"
    
    # Delete stale sessions on startup
    delete_stale_sessions = yes
    
    pool {
        start = 5
        min = 4
        max = 32
        spare = 3
        uses = 0
        lifetime = 0
        idle_timeout = 60
    }
    
    $INCLUDE ${modconfdir}/${.:name}/main/${dialect}/queries.conf
}
```

### 2. REST Module (`/etc/freeradius/3.0/mods-enabled/rest`)

```
rest {
    tls {
        check_cert = no
        check_cert_cn = no
    }

    connect_uri = "http://localhost:3000"

    # Post-auth: call webhook for voucher management
    post-auth {
        uri = "${..connect_uri}/api/radius/post-auth"
        method = "post"
        body = "json"
        data = "{ \"username\": \"%{User-Name}\", \"reply\": \"%{reply:Packet-Type}\", \"nasIp\": \"%{NAS-IP-Address}\", \"framedIp\": \"%{Framed-IP-Address}\" }"
        tls = ${..tls}
    }

    # Accounting: track session data
    accounting {
        uri = "${..connect_uri}/api/radius/accounting"
        method = "post"
        body = "json"
        data = "{ \"username\": \"%{User-Name}\", \"statusType\": \"%{Acct-Status-Type}\", \"sessionId\": \"%{Acct-Session-Id}\", \"nasIp\": \"%{NAS-IP-Address}\", \"framedIp\": \"%{Framed-IP-Address}\", \"sessionTime\": \"%{Acct-Session-Time}\", \"inputOctets\": \"%{Acct-Input-Octets}\", \"outputOctets\": \"%{Acct-Output-Octets}\" }"
        tls = ${..tls}
    }

    pool {
        start = 5
        min = 4
        max = 32
        spare = 3
        uses = 0
        lifetime = 0
        idle_timeout = 60
    }
}
```

### 3. Default Site (`/etc/freeradius/3.0/sites-enabled/default`)

Key modifications needed:

#### a. Enable SQL in authorize section
```
authorize {
    ...
    -sql
    ...
}
```

#### b. Conditional REST in post-auth section
Add after `-sql` in post-auth:
```
post-auth {
    ...
    -sql
    
    # Call REST API for voucher only (username without @)
    # PPPoE uses username@realm format, voucher does not have @
    if (!("%{User-Name}" =~ /@/)) {
        rest.post-auth
    }
    ...
}
```

This ensures:
- PPPoE users (with `@`) skip REST API call
- Hotspot vouchers (without `@`) call REST for expiry management

### 4. Policy Filter (`/etc/freeradius/3.0/policy.d/filter`)

#### âš ï¸ PENTING: PPPoE Realm Without Dot Separator

Default FreeRADIUS policy `filter_username` akan menolak username dengan format `user@realm` jika realm tidak memiliki titik (dot separator). Contohnya:
- `user@domain.com` âœ… Valid (default)
- `user@cimerta` âŒ Ditolak (default) â†’ âœ… Valid setelah modifikasi

**Perubahan yang dilakukan pada `policy.d/filter`:**

Bagian ini dikomentari untuk mengizinkan realm tanpa titik:
```
#  DISABLED: must have at least 1 string-dot-string after @
#  This check is disabled to allow realm without dot separator
#  e.g. "user@cimerta" is now allowed (previously required "user@site.com")
#
#if ((&User-Name =~ /@/) && (&User-Name !~ /@(.+)\.(.+)$/))  {
#        update request {
#                &Module-Failure-Message += 'Rejected: Realm does not have at least one dot separator'
#        }
#        reject
#}
```

**Cara Restore dari Backup:**
```bash
# Copy file policy.d-filter dari backup
sudo cp /var/www/salfanet-radius/freeradius-config/policy.d-filter /etc/freeradius/3.0/policy.d/filter

# Remove BOM
sudo sed -i '1s/^\xEF\xBB\xBF//' /etc/freeradius/3.0/policy.d/filter

# Test konfigurasi
sudo freeradius -CX 2>&1 | tail -5
```

**Cara Modifikasi Manual:**
```bash
# Komentari bagian dot separator check
sudo sed -i '/must have at least 1 string-dot-string/,/reject$/{s/^/#/}' /etc/freeradius/3.0/policy.d/filter

# Hapus kurung kurawal berlebih jika ada
sudo sed -i '/^#.*reject$/,/^[[:space:]]*}$/{/^[[:space:]]*}$/d}' /etc/freeradius/3.0/policy.d/filter 2>/dev/null || true

# Test konfigurasi
sudo freeradius -CX 2>&1 | tail -5
```

### 5. CoA/Disconnect Support

Add to the bottom of `/etc/freeradius/3.0/sites-available/default`:
```
# CoA/Disconnect support for isolir and user disconnect
listen {
    type = coa
    ipaddr = *
    port = 3799
}
```

This enables:
- Disconnect-Request: Force disconnect user sessions
- CoA-Request: Change authorization attributes (for isolir feature)

## Verify Port Binding

After starting FreeRADIUS, verify it's listening on all required ports:
```bash
ss -tulnp | grep radiusd
```

Expected output:
- **Port 1812**: Authentication requests
- **Port 1813**: Accounting requests  
- **Port 3799**: CoA/Disconnect requests

If ports are not binding, check:
1. No BOM in config files (see above)
2. No syntax errors: `freeradius -C`
3. Debug mode: `freeradius -X`

## Database Tables

### Required RADIUS Tables

```sql
-- User authentication
CREATE TABLE radcheck (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT ':=',
    value VARCHAR(253) NOT NULL DEFAULT ''
);

-- User reply attributes
CREATE TABLE radreply (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT ':=',
    value VARCHAR(253) NOT NULL DEFAULT ''
);

-- User to group mapping
CREATE TABLE radusergroup (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    groupname VARCHAR(64) NOT NULL DEFAULT '',
    priority INT NOT NULL DEFAULT 1
);

-- Group check attributes
CREATE TABLE radgroupcheck (
    id INT AUTO_INCREMENT PRIMARY KEY,
    groupname VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT ':=',
    value VARCHAR(253) NOT NULL DEFAULT ''
);

-- Group reply attributes (bandwidth, session timeout)
CREATE TABLE radgroupreply (
    id INT AUTO_INCREMENT PRIMARY KEY,
    groupname VARCHAR(64) NOT NULL DEFAULT '',
    attribute VARCHAR(64) NOT NULL DEFAULT '',
    op CHAR(2) NOT NULL DEFAULT ':=',
    value VARCHAR(253) NOT NULL DEFAULT ''
);

-- NAS/Router clients
CREATE TABLE nas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nasname VARCHAR(128) NOT NULL,
    shortname VARCHAR(32),
    type VARCHAR(30) DEFAULT 'other',
    ports INT,
    secret VARCHAR(60) NOT NULL DEFAULT 'secret',
    server VARCHAR(64),
    community VARCHAR(50),
    description VARCHAR(200) DEFAULT 'RADIUS Client'
);

-- Accounting
CREATE TABLE radacct (
    radacctid BIGINT AUTO_INCREMENT PRIMARY KEY,
    acctsessionid VARCHAR(64) NOT NULL DEFAULT '',
    acctuniqueid VARCHAR(32) NOT NULL DEFAULT '',
    username VARCHAR(64) NOT NULL DEFAULT '',
    realm VARCHAR(64) DEFAULT '',
    nasipaddress VARCHAR(15) NOT NULL DEFAULT '',
    nasportid VARCHAR(32) DEFAULT NULL,
    nasporttype VARCHAR(32) DEFAULT NULL,
    acctstarttime DATETIME NULL DEFAULT NULL,
    acctupdatetime DATETIME NULL DEFAULT NULL,
    acctstoptime DATETIME NULL DEFAULT NULL,
    acctinterval INT DEFAULT NULL,
    acctsessiontime INT UNSIGNED DEFAULT NULL,
    acctauthentic VARCHAR(32) DEFAULT NULL,
    connectinfo_start VARCHAR(50) DEFAULT NULL,
    connectinfo_stop VARCHAR(50) DEFAULT NULL,
    acctinputoctets BIGINT DEFAULT NULL,
    acctoutputoctets BIGINT DEFAULT NULL,
    calledstationid VARCHAR(50) NOT NULL DEFAULT '',
    callingstationid VARCHAR(50) NOT NULL DEFAULT '',
    acctterminatecause VARCHAR(32) NOT NULL DEFAULT '',
    servicetype VARCHAR(32) DEFAULT NULL,
    framedprotocol VARCHAR(32) DEFAULT NULL,
    framedipaddress VARCHAR(15) NOT NULL DEFAULT '',
    framedipv6address VARCHAR(45) NOT NULL DEFAULT '',
    framedipv6prefix VARCHAR(45) NOT NULL DEFAULT '',
    framedinterfaceid VARCHAR(44) NOT NULL DEFAULT '',
    delegatedipv6prefix VARCHAR(45) NOT NULL DEFAULT ''
);

-- Post-auth logging
CREATE TABLE radpostauth (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL DEFAULT '',
    pass VARCHAR(64) NOT NULL DEFAULT '',
    reply VARCHAR(32) NOT NULL DEFAULT '',
    authdate TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

## Example Data

### PPPoE User
```sql
-- User credentials
INSERT INTO radcheck (username, attribute, op, value) VALUES
('john@rw01', 'Cleartext-Password', ':=', 'password123'),
('john@rw01', 'NAS-IP-Address', ':=', '192.168.1.1');

-- Assign to profile group
INSERT INTO radusergroup (username, groupname, priority) VALUES
('john@rw01', 'pppoe-10mbps', 1);

-- Group reply (bandwidth)
INSERT INTO radgroupreply (groupname, attribute, op, value) VALUES
('pppoe-10mbps', 'Mikrotik-Group', ':=', 'pppoe-10mbps'),
('pppoe-10mbps', 'Mikrotik-Rate-Limit', ':=', '10M/10M');
```

### Hotspot Voucher
```sql
-- Voucher credentials
INSERT INTO radcheck (username, attribute, op, value) VALUES
('ABC12345', 'Cleartext-Password', ':=', 'ABC12345');

-- Assign to profile group
INSERT INTO radusergroup (username, groupname, priority) VALUES
('ABC12345', 'hotspot-3jam', 1);

-- Group reply (session timeout, bandwidth)
INSERT INTO radgroupreply (groupname, attribute, op, value) VALUES
('hotspot-3jam', 'Mikrotik-Group', ':=', 'hotspot-3jam'),
('hotspot-3jam', 'Mikrotik-Rate-Limit', ':=', '5M/5M'),
('hotspot-3jam', 'Session-Timeout', ':=', '10800');
```

### NAS/Router Client
```sql
INSERT INTO nas (nasname, shortname, type, secret, description) VALUES
('192.168.1.1', 'mikrotik-hap', 'other', 'secret123', 'MikroTik hAP');
```

## Testing

### Test Configuration
```bash
freeradius -XC
# Should show: Configuration appears to be OK
```

### Test Authentication
```bash
# Stop service first
systemctl stop freeradius

# Run in debug mode
freeradius -X

# In another terminal, test:
radtest 'john@rw01' 'password123' 127.0.0.1 0 testing123
radtest 'ABC12345' 'ABC12345' 127.0.0.1 0 testing123
```

### Expected Results

**PPPoE User:**
```
Received Access-Accept Id 123
    Mikrotik-Group = "pppoe-10mbps"
    Mikrotik-Rate-Limit = "10M/10M"
```

**Hotspot Voucher:**
```
Received Access-Accept Id 124
    Mikrotik-Group = "hotspot-3jam"
    Mikrotik-Rate-Limit = "5M/5M"
    Session-Timeout = 10800
```

## Troubleshooting

### Common Issues

1. **Access-Reject for PPPoE users with @**
   - Cause: `filter_username` policy enabled
   - Fix: Comment out `filter_username` in sites-enabled/default

2. **Voucher getting rejected after REST API call**
   - Cause: REST API returning error
   - Fix: Check API logs, ensure `/api/radius/post-auth` returns success

3. **NAS not loading from database**
   - Cause: `read_clients = yes` not set
   - Fix: Add `read_clients = yes` and `client_table = "nas"` to sql module

4. **Duplicate module error**
   - Cause: Multiple symlinks in mods-enabled
   - Fix: `rm /etc/freeradius/3.0/mods-enabled/sql; ln -s ../mods-available/sql mods-enabled/`

### Debug Commands
```bash
# Check FreeRADIUS status
systemctl status freeradius

# View logs
tail -f /var/log/freeradius/radius.log

# Test specific user in database
mysql -u salfanet_user -p salfanet_radius -e "SELECT * FROM radcheck WHERE username='john@rw01'"
```

## Backup & Restore

### Backup Current Config
```bash
mkdir -p /tmp/freeradius-backup
cp -r /etc/freeradius/3.0/sites-enabled /tmp/freeradius-backup/
cp -r /etc/freeradius/3.0/mods-enabled /tmp/freeradius-backup/
cp /etc/freeradius/3.0/clients.conf /tmp/freeradius-backup/
tar -czvf freeradius-config-backup.tar.gz -C /tmp freeradius-backup
```

### Restore Config
```bash
tar -xzvf freeradius-config-backup.tar.gz -C /tmp
cp /tmp/freeradius-backup/sites-enabled/* /etc/freeradius/3.0/sites-enabled/
cp /tmp/freeradius-backup/mods-enabled/* /etc/freeradius/3.0/mods-enabled/
# Edit credentials as needed
freeradius -XC
systemctl restart freeradius
```

## MikroTik Configuration

### PPPoE Server
```
/ppp profile add name=pppoe-radius use-radius=yes
/ppp secret set default-profile=pppoe-radius

/radius add address=VPS_IP secret=SECRET service=ppp
/radius incoming set accept=yes port=3799
```

### Hotspot Server
```
/ip hotspot profile set default use-radius=yes
/ip hotspot user profile set default use-radius=yes

/radius add address=VPS_IP secret=SECRET service=hotspot
/radius incoming set accept=yes port=3799
```

## Security Notes

1. Use strong secrets for NAS clients
2. Restrict RADIUS ports (1812, 1813, 3799) to known NAS IPs
3. Use SSL/TLS for REST API in production
4. Regularly rotate database passwords
5. Monitor failed authentication attempts


## [4] PROXMOX_VPS_SETUP_GUIDE.md


# Proxmox VPS Setup Guide - PPPoE & Routing Configuration

## ðŸ“‹ Overview

Panduan ini khusus untuk VPS yang berjalan di **Proxmox** atau **Container** environment yang memerlukan konfigurasi khusus untuk:
- PPPoE Server (FreeRADIUS + pppd)
- L2TP/IPSec VPN
- Network routing & NAT
- TUN/TAP devices

---

## âš ï¸ Proxmox Container Limitations

Jika menggunakan **Proxmox LXC Container**, ada beberapa fitur kernel yang tidak available secara default:

### 1. `/dev/ppp` Device
Container tidak memiliki akses langsung ke PPP modules. Solusi:

**A. Enable di Proxmox Host**
```bash
# Di Proxmox HOST (bukan container)
modprobe ppp_generic
modprobe ppp_async
modprobe ppp_mppe
modprobe ppp_deflate

# Verifikasi
lsmod | grep ppp
```

**B. Edit Container Configuration**
```bash
# Di Proxmox HOST
nano /etc/pve/lxc/[CONTAINER_ID].conf

# Tambahkan di akhir file:
lxc.cgroup2.devices.allow: c 108:* rwm
lxc.mount.entry: /dev/ppp dev/ppp none bind,create=file,optional 0 0
```

**C. Restart Container**
```bash
pct stop [CONTAINER_ID]
pct start [CONTAINER_ID]
```

**D. Verify di Container**
```bash
# Login ke container
pct enter [CONTAINER_ID]

# Check device
ls -la /dev/ppp
# Output: crw------- 1 root root 108, 0 Dec 28 10:00 /dev/ppp

# Check modules
cat /proc/net/pppoe
cat /proc/net/dev | grep ppp
```

### 2. `/dev/net/tun` Device (for VPN)

**A. Enable TUN/TAP di Proxmox Host**
```bash
# Di Proxmox HOST
modprobe tun

# Verifikasi
lsmod | grep tun
ls -la /dev/net/tun
```

**B. Edit Container Configuration**
```bash
# Di Proxmox HOST
nano /etc/pve/lxc/[CONTAINER_ID].conf

# Tambahkan:
lxc.cgroup2.devices.allow: c 10:200 rwm
lxc.mount.entry: /dev/net dev/net none bind,create=dir 0 0
```

**C. Restart Container & Verify**
```bash
pct stop [CONTAINER_ID]
pct start [CONTAINER_ID]

# Di container
ls -la /dev/net/tun
# Output: crw-rw-rw- 1 root root 10, 200 Dec 28 10:00 /dev/net/tun
```

---

## ðŸŒ Network Routing Configuration

### 1. Enable IP Forwarding

**Persistent IP Forward (Required for NAT/Routing)**
```bash
# Check current status
sysctl net.ipv4.ip_forward

# Enable permanently
cat >> /etc/sysctl.conf << 'EOF'

# Enable IP Forwarding for PPPoE/VPN
net.ipv4.ip_forward = 1
net.ipv6.conf.all.forwarding = 1
EOF

# Apply immediately
sysctl -p

# Verify
sysctl net.ipv4.ip_forward
# Output: net.ipv4.ip_forward = 1
```

### 2. Configure NAT/Masquerade (if needed)

**Setup iptables for NAT**
```bash
# Identify your main interface (eth0, ens3, vmbr0, etc)
ip addr show

# Setup MASQUERADE for PPPoE clients
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
iptables -A FORWARD -i ppp+ -o eth0 -j ACCEPT
iptables -A FORWARD -i eth0 -o ppp+ -m state --state RELATED,ESTABLISHED -j ACCEPT

# Save iptables rules
apt install -y iptables-persistent
netfilter-persistent save

# Verify
iptables -t nat -L -n -v
```

### 3. Configure Kernel Modules Auto-Load

**Make PPP modules persistent**
```bash
cat > /etc/modules-load.d/ppp.conf << 'EOF'
# PPP Kernel Modules - Auto-load on boot
ppp_generic
ppp_async
ppp_deflate
ppp_mppe

# L2TP Modules
l2tp_core
l2tp_ppp
l2tp_netlink

# TUN/TAP
tun
EOF

# Load immediately
systemctl restart systemd-modules-load.service

# Verify
lsmod | grep -E 'ppp|l2tp|tun'
```

---

## ðŸ”§ Proxmox Container Configuration Template

**Complete Container Config (`/etc/pve/lxc/[ID].conf`)**
```bash
arch: amd64
cores: 2
hostname: salfanet-radius
memory: 2048
net0: name=eth0,bridge=vmbr0,firewall=1,gw=192.168.1.1,hwaddr=XX:XX:XX:XX:XX:XX,ip=192.168.1.100/24,type=veth
ostype: ubuntu
rootfs: local-lvm:vm-100-disk-0,size=20G
swap: 512

# PPPoE Support - /dev/ppp device
lxc.cgroup2.devices.allow: c 108:* rwm
lxc.mount.entry: /dev/ppp dev/ppp none bind,create=file,optional 0 0

# TUN/TAP Support - VPN
lxc.cgroup2.devices.allow: c 10:200 rwm
lxc.mount.entry: /dev/net dev/net none bind,create=dir 0 0

# Enable nesting (for Docker/systemd)
lxc.apparmor.profile: unconfined
lxc.cgroup2.devices.allow: a
lxc.cap.drop:

# Kernel modules access
lxc.mount.auto: proc:rw sys:rw cgroup:rw

# Security - enable raw sockets (for ping, traceroute)
lxc.cgroup2.devices.allow: c 1:5 rwm
```

**âš ï¸ Security Note:** 
- `lxc.apparmor.profile: unconfined` mengurangi security container
- Hanya gunakan di environment terpercaya
- Untuk production, gunakan dedicated VM bukan container

---

## âœ… Verification Checklist

Setelah konfigurasi, jalankan checklist berikut:

### 1. Device Checks
```bash
# PPP device
ls -la /dev/ppp
# Should show: crw------- 1 root root 108, 0

# TUN device
ls -la /dev/net/tun
# Should show: crw-rw-rw- 1 root root 10, 200

# Verify in /proc
cat /proc/net/pppoe
cat /proc/devices | grep ppp
```

### 2. Kernel Module Checks
```bash
lsmod | grep -E 'ppp|l2tp|tun'

# Should show:
# ppp_generic
# ppp_async
# ppp_deflate
# ppp_mppe
# l2tp_core
# l2tp_ppp
# tun
```

### 3. Network Forwarding Check
```bash
# IP Forward enabled?
sysctl net.ipv4.ip_forward
# Output: net.ipv4.ip_forward = 1

# NAT rules?
iptables -t nat -L -n -v | grep MASQUERADE
```

### 4. FreeRADIUS PPPoE Test
```bash
# Check FreeRADIUS status
systemctl status freeradius

# Test PPPoE module
radiusd -X | grep ppp

# Check if pppd is working
pppd --version
```

---

## ðŸš¨ Common Issues & Solutions

### Issue 1: "Cannot create /dev/ppp"
**Error:**
```
pppd: This system lacks kernel support for PPP
```

**Solution:**
```bash
# 1. Load module di HOST Proxmox
ssh root@proxmox-host
modprobe ppp_generic

# 2. Add device permission ke container
nano /etc/pve/lxc/[ID].conf
# Add: lxc.cgroup2.devices.allow: c 108:* rwm

# 3. Restart container
pct stop [ID] && pct start [ID]
```

### Issue 2: "TUN/TAP not available"
**Error:**
```
/dev/net/tun: No such file or directory
```

**Solution:**
```bash
# Di Proxmox Host
modprobe tun
nano /etc/pve/lxc/[ID].conf
# Add: lxc.cgroup2.devices.allow: c 10:200 rwm
# Add: lxc.mount.entry: /dev/net dev/net none bind,create=dir 0 0

pct stop [ID] && pct start [ID]
```

### Issue 3: "IP forwarding not working"
**Symptom:** PPPoE clients connect but no internet

**Solution:**
```bash
# 1. Enable IP forward
echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
sysctl -p

# 2. Check NAT rules
iptables -t nat -L -n -v

# 3. Add MASQUERADE if missing
iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
netfilter-persistent save
```

### Issue 4: "Permission denied" on /dev/ppp
**Solution:**
```bash
chmod 600 /dev/ppp
chown root:root /dev/ppp

# Check FreeRADIUS user
ls -la /dev/ppp
groups freerad  # Should have access
```

---

## ðŸ“ Integration with Installation Scripts

### Update vps-install.sh

Tambahkan section berikut di vps-install.sh setelah system update:

```bash
# ===================================
# PROXMOX VPS - PPP/TUN DEVICE SETUP
# ===================================
print_info "Setting up PPP and TUN devices for Proxmox VPS..."

# Create /dev/ppp if not exists
if [ ! -c /dev/ppp ]; then
    print_info "Creating /dev/ppp device..."
    mknod /dev/ppp c 108 0 2>/dev/null || echo "PPP device may need host support"
    chmod 600 /dev/ppp
    print_success "/dev/ppp created"
else
    print_success "/dev/ppp already exists"
fi

# Create /dev/net/tun if not exists
if [ ! -d /dev/net ]; then
    mkdir -p /dev/net
fi
if [ ! -c /dev/net/tun ]; then
    print_info "Creating /dev/net/tun device..."
    mknod /dev/net/tun c 10 200 2>/dev/null || echo "TUN device may need host support"
    chmod 666 /dev/net/tun
    print_success "/dev/net/tun created"
else
    print_success "/dev/net/tun already exists"
fi

# Load kernel modules
print_info "Loading PPP/TUN kernel modules..."
modprobe ppp_generic 2>/dev/null || echo "âš ï¸  ppp_generic not available - may need Proxmox host configuration"
modprobe ppp_async 2>/dev/null || true
modprobe ppp_mppe 2>/dev/null || true
modprobe ppp_deflate 2>/dev/null || true
modprobe l2tp_core 2>/dev/null || true
modprobe l2tp_ppp 2>/dev/null || true
modprobe tun 2>/dev/null || echo "âš ï¸  tun not available - may need Proxmox host configuration"

# Make modules persistent
cat > /etc/modules-load.d/ppp.conf << 'EOF'
ppp_generic
ppp_async
ppp_mppe
ppp_deflate
l2tp_core
l2tp_ppp
tun
EOF

# Enable IP forwarding
print_info "Enabling IP forwarding..."
cat >> /etc/sysctl.conf << 'SYSCTL_EOF'

# PPPoE & VPN Routing Support
net.ipv4.ip_forward = 1
net.ipv6.conf.all.forwarding = 1
SYSCTL_EOF

sysctl -p > /dev/null 2>&1
print_success "IP forwarding enabled"

# Verify setup
print_info "Verifying PPP/TUN setup..."
if [ -c /dev/ppp ]; then
    echo "  âœ… /dev/ppp exists"
else
    echo "  âš ï¸  /dev/ppp NOT found - check Proxmox host config"
fi

if [ -c /dev/net/tun ]; then
    echo "  âœ… /dev/net/tun exists"
else
    echo "  âš ï¸  /dev/net/tun NOT found - check Proxmox host config"
fi

IP_FWD=$(sysctl -n net.ipv4.ip_forward)
if [ "$IP_FWD" = "1" ]; then
    echo "  âœ… IP forwarding enabled"
else
    echo "  âš ï¸  IP forwarding NOT enabled"
fi

print_success "Proxmox VPS PPP/TUN setup completed"
```

---

## ðŸ”— Related Documentation

- [FREERADIUS-SETUP.md](FREERADIUS-SETUP.md) - FreeRADIUS configuration
- [VPN_CLIENT_SETUP_GUIDE.md](VPN_CLIENT_SETUP_GUIDE.md) - L2TP/IPSec setup
- [DEPLOYMENT-GUIDE.md](DEPLOYMENT-GUIDE.md) - General deployment guide
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - Common issues

---

## ðŸ“ž Support

Jika masih ada issue setelah mengikuti guide ini:

1. **Check Proxmox Forum** - Proxmox-specific issues
2. **Verify Container Type** - LXC vs KVM (KVM tidak butuh konfigurasi khusus)
3. **Check Host Kernel** - `uname -r` di host, pastikan support PPP/TUN
4. **Contact Support** - Dengan log lengkap dari verification checklist

---

**Last Updated:** December 28, 2025  
**Version:** 1.0  
**Author:** SALFANET RADIUS Team


## [5] PROXMOX_L2TP_SETUP.md


# L2TP VPN Client Setup untuk Proxmox VPS

## Masalah

L2TP client memerlukan `/dev/ppp` dan `/dev/net/tun` devices yang tidak bisa dibuat dari dalam Proxmox LXC container karena security restrictions.

## Solusi

### Opsi 1: Enable TUN/TAP di Proxmox Host (Recommended)

Admin Proxmox perlu enable TUN/TAP support untuk container Anda.

**Di Proxmox Host, jalankan:**

```bash
# Ganti CTID dengan ID container Anda (misalnya 100, 101, dst)
CTID=YOUR_CONTAINER_ID

# Enable TUN device
pct set $CTID -features nesting=1,keyctl=1
pct set $CTID -dev0 /dev/net/tun,mode=0666

# Enable PPP device
pct set $CTID -dev1 /dev/ppp,mode=0600

# Load PPP modules di host
modprobe ppp_generic
modprobe ppp_async
modprobe ppp_deflate  
modprobe ppp_mppe
modprobe l2tp_ppp

# Restart container
pct reboot $CTID
```

**Atau edit config file manually:**

```bash
# Edit /etc/pve/lxc/CTID.conf
nano /etc/pve/lxc/$CTID.conf

# Tambahkan baris berikut:
features: keyctl=1,nesting=1
lxc.cgroup2.devices.allow: c 10:200 rwm
lxc.cgroup2.devices.allow: c 108:0 rwm
lxc.mount.entry: /dev/net/tun dev/net/tun none bind,create=file 0 0
lxc.mount.entry: /dev/ppp dev/ppp none bind,create=file 0 0

# Restart container
pct reboot $CTID
```

### Opsi 2: Gunakan KVM VM (Full Virtualization)

Jika menggunakan LXC container, pertimbangkan untuk migrasi ke KVM VM yang memiliki akses penuh ke kernel dan devices.

### Opsi 3: Alternative VPN - WireGuard (More Container-Friendly)

WireGuard lebih compatible dengan containers dan tidak memerlukan `/dev/ppp`:

```bash
# Install WireGuard
apt install -y wireguard wireguard-tools

# WireGuard hanya perlu /dev/net/tun yang lebih mudah di-enable
```

## Verifikasi Setelah Setup

```bash
# Check devices
ls -la /dev/ppp /dev/net/tun

# Check kernel modules
lsmod | grep -E "ppp|l2tp|tun"

# Test PPP
pppd --version

# Test xl2tpd
systemctl status xl2tpd
```

## Troubleshooting

### Error: "Couldn't open the /dev/ppp device: No such file or directory"

**Solusi**: Admin Proxmox perlu enable device seperti di Opsi 1

### Error: "Kernel doesn't support ppp_generic"

**Solusi**: Load kernel modules di Proxmox host:

```bash
# Di Proxmox host
modprobe ppp_generic
modprobe l2tp_ppp
```

### Error: "Operation not permitted" saat create device

**Solusi**: Devices tidak bisa dibuat dari dalam container, harus dari host Proxmox

## Contact Info untuk Admin Proxmox

Kirim request ke admin Proxmox dengan template berikut:

```
Subject: Request Enable TUN/TAP untuk Container ID XXX

Halo Admin,

Mohon bantuan untuk enable TUN/TAP devices untuk container RADIUS server.
Diperlukan untuk L2TP VPN client connection ke server pusat.

Container ID: XXX
Hostname: salfaradius

Command yang perlu dijalankan di Proxmox host:
```bash
CTID=XXX
pct set $CTID -features nesting=1,keyctl=1
pct set $CTID -dev0 /dev/net/tun,mode=0666
pct set $CTID -dev1 /dev/ppp,mode=0600
modprobe ppp_generic
modprobe l2tp_ppp
pct reboot $CTID
```

Terima kasih!
```

## Alternative: Gunakan VPS KVM/Dedicated Server

Jika admin Proxmox tidak bisa enable TUN/TAP, pertimbangkan untuk:
- Migrasi ke KVM VM (full virtualization)
- Gunakan VPS dedicated yang mendukung VPN
- Gunakan physical server

## References

- [Proxmox LXC TUN/TAP Setup](https://pve.proxmox.com/wiki/OpenVPN_in_LXC)
- [xl2tpd Documentation](https://github.com/xelerance/xl2tpd)
- [Linux PPP Kernel Module](https://www.kernel.org/doc/html/latest/networking/ppp_generic.html)


## [6] VPS_OPTIMIZATION_GUIDE.md


# VPS Optimization Guide - Low Resource (2GB RAM)

Panduan lengkap untuk optimasi SALFANET RADIUS pada VPS dengan resource terbatas.

## ðŸŽ¯ Target VPS Specs

**Minimum Requirements:**
- CPU: 2 vCPUs
- RAM: 2GB
- Storage: 20GB SSD
- OS: Ubuntu 20.04/22.04 LTS

**Optimized For:**
- Shared hosting environment
- Budget VPS (DigitalOcean Basic, Vultr HF, AWS t2.small)
- Limited budget deployments

---

## âš¡ Build Optimization (v2.7.3)

### Automatic Optimizations Applied

All VPS installation scripts (`vps-install.sh`, `vps-install-local.sh`, `vps-update.sh`) now include:

#### 1. **Memory-Limited Node.js Build**
```bash
NODE_OPTIONS="--max-old-space-size=1536 --max-semi-space-size=64"
```

**What it does:**
- Limits Node.js heap memory to 1.5GB (instead of default 2GB+)
- Reduces semi-space to 64MB for garbage collection
- Prevents out-of-memory crashes during build

#### 2. **Automatic Swap Management**
```bash
# Detects available memory
# If < 800MB available â†’ Creates temporary 2GB swap
# Disables swap after build completes
```

**Benefits:**
- Build completes even when memory is tight
- Temporary swap (auto-removed after build)
- No manual intervention needed

#### 3. **Fallback Build Strategy**
```bash
# 1st attempt: Normal build (1.5GB heap)
# 2nd attempt: Ultra-low memory (1GB heap) if 1st fails
# Logs saved to /tmp/build.log for debugging
```

#### 4. **Next.js Config Optimization**

**File:** `next.config.ts`

```typescript
experimental: {
  workerThreads: false,  // Disable worker threads
  cpus: 1,               // Use single CPU for build
},
swcMinify: true,         // Faster minification
productionBrowserSourceMaps: false, // Disable source maps
```

**Impact:**
- Reduces parallel processing (less memory)
- Faster compilation with SWC
- Smaller build size

---

## ðŸ”§ Manual Build Commands

If you need to build manually:

### Standard Build (1.5GB heap)
```bash
cd /var/www/salfanet-radius
NODE_OPTIONS="--max-old-space-size=1536" npm run build
```

### Ultra-Low Memory Build (1GB heap)
```bash
cd /var/www/salfanet-radius
npm run build:low-mem
```

### With Manual Swap
```bash
# Create swap
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Build
NODE_OPTIONS="--max-old-space-size=1536" npm run build

# Remove swap
sudo swapoff /swapfile
sudo rm /swapfile
```

---

## ðŸ’¾ Permanent Swap Configuration

For VPS dengan RAM < 4GB, recommended to keep permanent swap:

```bash
# Create 2GB swap file
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# Make permanent
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab

# Optimize swappiness
echo 'vm.swappiness=10' | sudo tee -a /etc/sysctl.conf
sudo sysctl -p

# Verify
sudo swapon --show
free -h
```

**Swappiness Explained:**
- Default: 60 (aggressive swap usage)
- Recommended: 10 (only use swap when needed)
- Prevents unnecessary disk I/O

---

## ðŸš€ Runtime Optimization

### PM2 Configuration

**File:** `ecosystem.config.js`

```javascript
module.exports = {
  apps: [{
    name: 'salfanet-radius',
    script: 'node_modules/next/dist/bin/next',
    args: 'start -p 3000',
    instances: 1, // IMPORTANT: Single instance for 2GB RAM
    exec_mode: 'fork', // Not cluster mode
    max_memory_restart: '1500M', // Auto-restart if exceeds 1.5GB
    node_args: '--max-old-space-size=1536', // Limit runtime memory
    env: {
      NODE_ENV: 'production',
      PORT: 3000
    }
  }]
}
```

**Key Settings:**
- `instances: 1` - Single process (cluster mode butuh 2GB+ per instance)
- `max_memory_restart` - Auto-restart jika memory leak
- `node_args` - Limit runtime heap

### MySQL Optimization

**File:** `/etc/mysql/mysql.conf.d/mysqld.cnf`

```ini
[mysqld]
# Memory optimizations for 2GB RAM VPS
innodb_buffer_pool_size = 512M  # 25% of RAM
max_connections = 50            # Limit connections
query_cache_size = 32M
query_cache_type = 1
tmp_table_size = 32M
max_heap_table_size = 32M
thread_cache_size = 8
table_open_cache = 256
sort_buffer_size = 2M
read_buffer_size = 1M
read_rnd_buffer_size = 2M

# Slow query log (optional)
slow_query_log = 1
slow_query_log_file = /var/log/mysql/slow.log
long_query_time = 2
```

Apply changes:
```bash
sudo systemctl restart mysql
```

### FreeRADIUS Optimization

**File:** `/etc/freeradius/3.0/radiusd.conf`

```
max_requests = 1024
max_request_time = 30
cleanup_delay = 5

# Limit threads
thread pool {
  start_servers = 2
  max_servers = 4
  min_spare_servers = 1
  max_spare_servers = 2
}
```

### Nginx Optimization

**File:** `/etc/nginx/nginx.conf`

```nginx
worker_processes 2; # Match vCPUs
worker_connections 512; # Reduce for low memory

events {
  use epoll;
  worker_connections 512;
}

http {
  # Buffer sizes
  client_body_buffer_size 10K;
  client_header_buffer_size 1k;
  client_max_body_size 20m;
  large_client_header_buffers 2 1k;

  # Timeouts
  client_body_timeout 12;
  client_header_timeout 12;
  keepalive_timeout 15;
  send_timeout 10;

  # Gzip compression
  gzip on;
  gzip_comp_level 5;
  gzip_types text/plain text/css application/json application/javascript;
  
  # Cache
  open_file_cache max=1000 inactive=20s;
  open_file_cache_valid 30s;
  open_file_cache_min_uses 2;
}
```

Apply:
```bash
sudo nginx -t
sudo systemctl restart nginx
```

---

## ðŸ“Š Monitoring Commands

### Check Memory Usage
```bash
# Overall memory
free -h

# Per process
ps aux --sort=-%mem | head -10

# PM2 memory
pm2 monit
```

### Check Swap Usage
```bash
# Current swap
swapon --show

# Swap activity
vmstat 1 5
```

### Check Disk I/O
```bash
iostat -x 1 5
```

### Check Build Logs
```bash
# Last build log
tail -100 /tmp/build.log

# PM2 logs
pm2 logs --lines 100
```

---

## ðŸ” Troubleshooting

### Issue: Build fails with "JavaScript heap out of memory"

**Solution 1: Enable swap**
```bash
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile
npm run build:low-mem
```

**Solution 2: Close other services temporarily**
```bash
# Stop FreeRADIUS during build
sudo systemctl stop freeradius
npm run build
sudo systemctl start freeradius
```

**Solution 3: Use even lower memory**
```bash
NODE_OPTIONS="--max-old-space-size=768" npm run build
```

### Issue: Application slow or frequently restarting

**Check memory:**
```bash
pm2 monit
# If constantly near 1500M â†’ restart clears memory
```

**Solutions:**
- Add permanent swap (see above)
- Reduce MySQL buffer pool size
- Limit max connections
- Enable query caching

### Issue: Database queries slow

**Optimize:**
```bash
# Check slow queries
sudo tail -100 /var/log/mysql/slow.log

# Optimize tables
mysql -u root -p
USE salfanet_radius;
OPTIMIZE TABLE users;
OPTIMIZE TABLE hotspotVoucher;
```

---

## ðŸ“ˆ Performance Benchmarks

### Expected Build Times (2 vCPUs, 2GB RAM)

| Configuration | Build Time | Success Rate |
|--------------|------------|--------------|
| No optimization | 8-12 min | 40% (OOM) |
| With NODE_OPTIONS | 6-10 min | 85% |
| + Swap (2GB) | 8-12 min | 99% |
| + Permanent swap | 7-10 min | 99.9% |

### Runtime Memory Usage

| Component | Memory Usage |
|-----------|-------------|
| Next.js App (PM2) | 400-800 MB |
| MySQL | 200-400 MB |
| FreeRADIUS | 50-100 MB |
| Nginx | 10-20 MB |
| System | 200-300 MB |
| **Total** | **900-1600 MB** |

**Available for processes:** 400-1100 MB

---

## âœ… Optimization Checklist

- [ ] Swap file configured (2GB permanent)
- [ ] Swappiness set to 10
- [ ] PM2 single instance mode
- [ ] PM2 max_memory_restart set
- [ ] MySQL buffer pool optimized (512MB)
- [ ] MySQL max_connections limited (50)
- [ ] Nginx worker connections reduced (512)
- [ ] FreeRADIUS threads limited (2-4)
- [ ] Gzip compression enabled
- [ ] Source maps disabled in production
- [ ] Monitoring setup (pm2 monit)

---

## ðŸŽ¯ Recommended VPS Providers

Budget-friendly VPS yang tested dengan config ini:

### DigitalOcean
- **Droplet Basic** - $12/month
- 2 vCPUs, 2GB RAM, 50GB SSD
- âœ… Works perfectly

### Vultr
- **High Frequency** - $12/month
- 2 vCPUs, 2GB RAM, 55GB NVMe
- âœ… Faster builds (NVMe)

### Contabo
- **VPS S** - â‚¬5.99/month (~$6.50)
- 4 vCPUs, 8GB RAM, 200GB SSD
- âœ… Overkill tapi murah

### Local/Indonesia
- **IDCloudHost** - Rp 150k/bulan
- 2 vCPUs, 2GB RAM, 60GB SSD
- âœ… Low latency untuk Indonesia

---

## ðŸ“ž Support

Jika masih mengalami issues:

1. Check `/tmp/build.log` untuk error details
2. Run `pm2 logs --lines 100`
3. Check memory: `free -h`
4. Check swap: `swapon --show`
5. Verify configs sesuai panduan ini

---

**Last Updated:** December 20, 2025  
**Version:** 2.7.3  
**Tested On:** Ubuntu 20.04/22.04, 2GB RAM VPS


## [7] VPN_CLIENT_SETUP_GUIDE.md


# VPN Client Setup Guide

## Masalah yang Terjadi

Saat test connection ke router via VPN Client IP (172.16.17.10), terjadi **timeout error** karena:
- VPS belum terkoneksi ke VPN Server
- IP 172.16.17.x hanya accessible melalui VPN tunnel
- Perlu setup VPN client di VPS terlebih dahulu

## Workflow yang Benar

### 1. Setup VPN Server di MikroTik

Di halaman **VPN Server**, klik tombol "Auto Setup VPN Server":
- VPN Type: L2TP/IPSec (recommended)
- Subnet: 41.216.178.0/24
- Secret: aibill-vpn-secret

Ini akan:
- Create IP pool untuk VPN
- Create PPP profile
- Enable L2TP server dengan IPSec
- Setup NAT masquerade

### 2. Setup VPN Client di VPS

**Option A: Manual via Web Interface**

1. Buka halaman **VPN Client**
2. Klik "Add Client"
3. Isi form:
   - Name: RADIUS-SERVER
   - VPN Server: Pilih server MikroTik
   - Username: radius-vps
   - Password: (set password)
   - âœ… Centang "Default RADIUS Server"
4. Save

**Option B: Setup di VPS (Linux L2TP Client)**

Jalankan script setup di VPS:

```bash
cd /var/www/salfanet-radius
chmod +x setup-vpn-client.sh
sudo ./setup-vpn-client.sh
```

Input yang diperlukan:
- VPN Server IP: **IP PUBLIC MikroTik** (misal: 103.xx.xx.xx)
- VPN Username: **radius-vps** (username yang dibuat di web)
- VPN Password: password yang di-set
- IPSec Secret: **aibill-vpn-secret** (default)

Setelah setup, cek koneksi:
```bash
# Cek interface VPN
ip addr show | grep ppp

# Output yang diharapkan:
# ppp0: <POINTOPOINT,MULTICAST,NOARP,UP,LOWER_UP> mtu 1410 qdisc ...
#     inet 41.216.178.XX peer 41.216.178.1/32 scope global ppp0

# Cek routing
ip route | grep ppp

# Test ping ke router via VPN IP
ping 172.16.17.10
```

### 3. Add Router via VPN

Setelah VPS terkoneksi ke VPN, baru bisa add router:

1. Buka halaman **Router / NAS**
2. Klik "Add Router"
3. Isi form:
   - Router Name: Main Router
   - âœ… **Centang "Connect via VPN Client"**
   - VPN Client: Pilih **cabang1** (172.16.17.10) â˜…
   - IP Address: **172.16.17.10** (auto-fill dari VPN client)
   - Username: mikhmon
   - Password: (password MikroTik)
   - RADIUS Secret: secret123
4. Klik **Test Connection** â†’ Harus success!
5. Klik **Add Router**

### 4. Add Router Direct (Tanpa VPN)

Jika router punya IP public dan accessible dari VPS:

1. **Jangan centang** "Connect via VPN Client"
2. IP Address: **IP PUBLIC router** (misal: 103.67.244.xxx)
3. Username: admin
4. Password: password MikroTik
5. Test Connection â†’ Save

## Troubleshooting

### Test Connection Loading Terus

**Penyebab:** Timeout karena IP tidak reachable

**Solusi:**
1. Cek apakah VPN sudah connect:
   ```bash
   ip addr show | grep ppp
   ```

2. Test ping ke router:
   ```bash
   ping 172.16.17.10
   ```

3. Cek firewall MikroTik:
   ```
   /ip firewall filter print
   # Pastikan ada allow API port 8728 dari VPN
   ```

### VPN Tidak Connect

**Cek log IPSec:**
```bash
journalctl -u strongswan -f
```

**Cek log L2TP:**
```bash
tail -f /var/log/xl2tpd.log
```

**Reconnect manual:**
```bash
# Disconnect
echo 'd myvpn' > /var/run/xl2tpd/l2tp-control

# Connect
echo 'c myvpn' > /var/run/xl2tpd/l2tp-control
```

### Auto-Connect on Boot

Edit `/etc/rc.local`:
```bash
#!/bin/bash
sleep 5 && echo 'c myvpn' > /var/run/xl2tpd/l2tp-control &
exit 0
```

Make executable:
```bash
chmod +x /etc/rc.local
systemctl enable rc-local
```

## Network Diagram

```
Internet
    â”‚
    â”œâ”€â”€â”€ MikroTik Router (VPN Server)
    â”‚    â”œâ”€ Public IP: 103.67.244.xxx
    â”‚    â”œâ”€ VPN IP: 41.216.178.1
    â”‚    â”œâ”€ LAN IP: 172.16.17.1
    â”‚    â””â”€ API Port: 8728
    â”‚
    â””â”€â”€â”€ VPS (RADIUS Server)
         â”œâ”€ Public IP: 103.67.244.131
         â”œâ”€ VPN IP: 41.216.178.10 (setelah connect)
         â””â”€ Services: FreeRADIUS, Web App

VPN Tunnel (L2TP/IPSec):
VPS (41.216.178.10) <â”€â”€> MikroTik (41.216.178.1)

Setelah VPN connect, VPS bisa:
- Akses LAN router: 172.16.17.x
- Manage router via API: 172.16.17.10:8728
- FreeRADIUS authenticate: 172.16.17.10:1812
```

## Summary

**Untuk Router di LAN (Private IP):**
- Setup VPN Server di MikroTik âœ…
- Setup VPN Client di VPS âœ…
- Add router dengan "Connect via VPN Client" âœ…
- Test connection via VPN IP

**Untuk Router dengan IP Public:**
- Add router langsung tanpa VPN
- IP Address = Public IP
- Test connection langsung

**Bintang (â˜…) di VPN Client list:**
- Menandakan VPN client yang di-set sebagai "Default RADIUS Server"
- Router yang menggunakan VPN client ini akan gunakan VPN IP sebagai RADIUS server


## [8] COMPREHENSIVE_FEATURE_GUIDE.md


# AIBILL RADIUS - Comprehensive Feature Guide

**Version**: 2.7.5  
**Last Updated**: December 23, 2025  
**Project**: ISP/RTRW.NET Billing & RADIUS Management System

> **Ringkasan Lengkap**: Dokumentasi ini merangkum semua fitur dan kemampuan dari AIBILL RADIUS berdasarkan 20+ dokumentasi teknis yang tersedia.

---

## ðŸ“‹ Table of Contents

1. [System Overview](#system-overview)
2. [Core Features](#core-features)
3. [Authentication & RADIUS](#authentication--radius)
4. [Customer Management](#customer-management)
5. [Billing & Payment](#billing--payment)
6. [Hotspot & Voucher System](#hotspot--voucher-system)
7. [Agent/Reseller System](#agentreseller-system)
8. [Notification System](#notification-system)
9. [Financial Management](#financial-management)
10. [Automation & Cron Jobs](#automation--cron-jobs)
11. [Monitoring & Reporting](#monitoring--reporting)
12. [GenieACS Integration](#genieacs-integration)
13. [Security & Permissions](#security--permissions)
14. [Deployment & Infrastructure](#deployment--infrastructure)
15. [Advanced Features](#advanced-features)

---

## ðŸŽ¯ System Overview

### Platform Details
- **Framework**: Next.js 16.0.8 + React 19
- **Backend**: Node.js 20.x + Prisma ORM
- **Database**: MySQL 8.0
- **RADIUS Server**: FreeRADIUS 3.0.26
- **Process Manager**: PM2
- **Web Server**: Nginx
- **Timezone**: WIB (UTC+7) - Automatic conversion

### Supported Authentication
- PPPoE (Point-to-Point Protocol over Ethernet)
- Hotspot (Voucher-based)
- Static IP (Manual assignment)
- PAP/CHAP/MS-CHAP protocols

### Infrastructure Support
- Multi-NAS (Network Access Server) management
- VPN L2TP/IPSec for remote routers
- GenieACS for TR-069 device management
- Cross-platform deployment (Ubuntu, Windows dev)

---

## ðŸš€ Core Features

### 1. FreeRADIUS Integration
**Reference**: [FREERADIUS-SETUP.md](FREERADIUS-SETUP.md)

- **Full RADIUS Server**: FreeRADIUS 3.0.26 dengan MySQL backend
- **Multi-Protocol**: PAP, CHAP, MS-CHAP support
- **Dynamic NAS Loading**: NAS clients loaded from database
- **CoA (Change of Authorization)**: Real-time speed changes & disconnect
- **Session Accounting**: Complete radacct table tracking
- **Reply-Message**: Custom messages for MikroTik logs
- **BOM Detection**: Auto-remove UTF-8 BOM from config files
- **VPN Support**: L2TP/IPSec tunnel for remote routers

**Key Capabilities**:
- Authenticate PPPoE users against database
- Track active sessions in real-time
- Disconnect users via CoA when quota/time expires
- Custom reply messages ("Kode Voucher Kadaluarsa")
- Multi-router management with single RADIUS server

### 2. Multiple NAS Same IP Support
**Reference**: [MULTIPLE_NAS_SAME_IP.md](MULTIPLE_NAS_SAME_IP.md)

**Problem Solved**: Manage multiple routers behind single public IP (VPN scenario)

**Features**:
- `nasIdentifier` field untuk unique identification
- Support VPN scenarios (multiple routers, 1 IP)
- NAS selection by identifier, bukan IP
- Backward compatible dengan existing setup

**Use Cases**:
```
Public IP: 103.67.244.131
â”œâ”€â”€ Router A (VPN) â†’ nasIdentifier: "router-jakarta"
â”œâ”€â”€ Router B (VPN) â†’ nasIdentifier: "router-bandung"
â””â”€â”€ Router C (VPN) â†’ nasIdentifier: "router-surabaya"
```

### 3. Complete Database Seeding
**Reference**: [CHAT_HISTORY_2025-12-23.md](../CHAT_HISTORY_2025-12-23.md)

**Seed Files** (10 essential TypeScript files, 110 KB):
1. Company settings & isolation config
2. 53 permissions & 6 role templates
3. 26 GenieACS parameter configs
4. 3 isolation templates (WhatsApp, Email, HTML)
5. 5 email templates (payment workflow + extension)
6. 12 WhatsApp templates (invoice, payment, extension)
7. 2 invoice templates (overdue, notification)
8. Transaction categories (13)
9. Hotspot profiles (5)
10. Admin user & RADIUS group

**Total Templates**: 22 across 5 categories
**Seeding Steps**: 13 automated steps
**Idempotent**: Safe to run multiple times

---

## ðŸ‘¥ Customer Management

### 1. PPPoE User Management

**Features**:
- Create/Edit/Delete PPPoE users
- Profile assignment (bandwidth, speed limit)
- Area/wilayah grouping
- GPS location tracking (optional)
- Auto-isolation when expired
- Manual extension (perpanjangan)
- Stop langganan (unsubscribe)
- Import from MikroTik
- Bulk operations

**Status Types**:
- `active` - User dapat login
- `isolated` - Limited bandwidth, landing page redirect
- `blocked` - Tidak bisa login
- `suspended` - Temporary disabled
- `stopped` - Berhenti berlangganan

### 2. Subscription Types
**Reference**: [PREPAID_POSTPAID_IMPLEMENTATION.md](PREPAID_POSTPAID_IMPLEMENTATION.md)

#### PREPAID (Bayar Dimuka)
- Bayar sebelum masa aktif
- `expiredAt` = tanggal kadaluarsa
- Auto-isolate ketika expired
- Support auto-renewal dari balance
- Invoice generated saat renewal

#### POSTPAID (Bayar Dibelakang)
- Bayar setelah pakai
- `expiredAt` = NULL (no expiry)
- `billingDay` = 1-28 (tanggal tagihan)
- Grace period 7 hari
- Auto-isolate H+7 jika belum bayar

**Connection Types**:
- `PPPOE` - PPPoE authentication
- `HOTSPOT` - Voucher-based
- `STATIC_IP` - Manual IP assignment

### 3. Customer Registration & Approval

**Workflow**:
1. Customer submit pendaftaran (online form)
2. Admin receive notification
3. Admin review & approve/reject
4. If approved:
   - User created in database
   - Invoice generated (installation + monthly)
   - Notification sent (WhatsApp + Email)
5. Customer bayar invoice
6. Status changed to `active`

**GPS Location Feature**:
**Reference**: [GPS_LOCATION_FEATURE.md](GPS_LOCATION_FEATURE.md)

- Capture customer GPS coordinates saat registrasi
- Store latitude & longitude
- Display on map (admin panel)
- Useful untuk instalasi & maintenance

### 4. Area Management

- Kelompokkan customer berdasarkan wilayah
- Filter by area di semua laporan
- Area-based pricing (optional)
- Area statistics & analytics

### 5. Import PPPoE Users
**Reference**: [IMPORT_PPPOE_USERS.md](IMPORT_PPPOE_USERS.md)

**Feature**: Sync existing PPPoE secrets dari MikroTik ke database

**Process**:
1. Connect ke MikroTik via API
2. Fetch all `/ppp secret` entries
3. Match dengan database by username
4. Create users yang belum ada
5. Update existing users
6. Generate import report

**Use Case**: Migrasi dari MikroTik manual ke AIBILL RADIUS

---

## ðŸ’° Billing & Payment

### 1. Invoice System

**Invoice Types**:
- `INSTALLATION` - Biaya pemasangan + bulan pertama
- `MONTHLY` - Tagihan bulanan
- `RENEWAL` - Perpanjangan subscription
- `ADDON` - Biaya tambahan
- `TOPUP` - Isi ulang saldo

**Invoice Components**:
```typescript
baseAmount: 100000      // Harga dasar
taxRate: 0.11           // PPN 11%
taxAmount: 11000        // Calculated
additionalFees: [       // Biaya tambahan
  { name: "Admin Fee", amount: 5000 },
  { name: "Instalasi Extra", amount: 50000 }
]
totalAmount: 166000     // Grand total
```

**Invoice Number Format**:
**Reference**: [INVOICE_NUMBER_FORMAT.md](INVOICE_NUMBER_FORMAT.md)

```
Format: INV-20251223-00001
        ^^^  ^^^^^^^^  ^^^^^
        â”‚    â”‚         â””â”€â”€ Sequential number (5 digits)
        â”‚    â””â”€â”€ Date (YYYYMMDD)
        â””â”€â”€ Prefix
```

**Auto-Generation** (Cron Job):
- POSTPAID: Generate setiap billingDay
- PREPAID: Generate H-7 sebelum expired
- Grace period: 7 hari
- Auto-isolate jika belum bayar

### 2. Payment Methods

#### A. Manual Payment (Upload Bukti Transfer)
**Reference**: [MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md](MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md)

**Customer Side**:
1. Upload foto bukti transfer (JPG/PNG/WebP, max 5MB)
2. Submit dengan keterangan
3. Status: `PENDING` approval

**Admin Side**:
1. Review bukti transfer
2. Approve atau Reject
3. Jika approve:
   - Invoice status â†’ `PAID`
   - User status â†’ `ACTIVE`
   - Send WhatsApp/Email notification
4. Jika reject:
   - Send rejection reason
   - Customer dapat upload ulang

**Notification Templates**:
- `manual_payment_approval` - Payment approved
- `manual_payment_rejection` - Payment rejected with reason

#### B. Payment Gateway Integration

**Supported Gateways**:
- **Midtrans** - Credit card, bank transfer, e-wallet
- **Xendit** - Bank transfer, QRIS, e-wallet
- **Duitku** - Multi-channel payment

**Flow**:
1. Customer klik "Bayar Sekarang"
2. Select payment gateway
3. Create payment session via API
4. Redirect ke payment page
5. Webhook notifikasi â†’ update status
6. Auto-activate user

### 3. Agent Deposit System
**Reference**: [AGENT_DEPOSIT_SYSTEM.md](AGENT_DEPOSIT_SYSTEM.md)

**Features**:
- Agent balance management
- Top-up via payment gateway
- Minimum balance threshold
- Transaction history
- Commission tracking

**Database Schema**:
```sql
agents:
  - balance: INT (saldo saat ini)
  - minBalance: INT (minimum allowed)

agent_deposits:
  - amount: Jumlah deposit
  - status: PENDING/PAID/EXPIRED
  - paymentGateway: midtrans/xendit/duitku
  - paymentUrl: Link pembayaran

agent_sales:
  - paymentStatus: PAID/UNPAID
  - paidAmount: Jumlah terbayar
```

**Workflow**:
1. Agent request deposit (min. Rp 10,000)
2. Select payment gateway
3. Get payment URL
4. Pay via gateway
5. Webhook â†’ update balance
6. Balance available untuk generate voucher

---

## ðŸŽ« Hotspot & Voucher System

### 1. Voucher Generation

**Features**:
- Batch generation (up to 25,000 vouchers)
- Pagination support (1000 per page)
- Custom profile assignment
- Validity period (hours/days/months)
- Price settings
- Auto-generate unique codes
- Print voucher cards

**Voucher Types**:
- Time-based (1 jam, 1 hari, 1 minggu, 1 bulan)
- Quota-based (1GB, 5GB, 10GB)
- Unlimited time with speed limit
- Custom combinations

### 2. Hotspot Sync (Cron Job)
**Reference**: [CRON-SYSTEM.md](CRON-SYSTEM.md)

**Schedule**: Every 5 minutes

**Process**:
1. Fetch active sessions from radacct
2. Find vouchers with matching username
3. Check if first login (`usedAt` is NULL)
4. If first login:
   - Set `usedAt` = now
   - Calculate `expiredAt` based on validity
   - Update voucher status to `USED`
   - Record aktivasi

**Purpose**: Auto-activate voucher on first login (support offline MikroTik)

### 3. Voucher Auto-Disconnect

**Process**:
1. Check radacct for active sessions
2. Get voucher expiredAt
3. If expired:
   - Send CoA Disconnect to NAS
   - Set session status to `EXPIRED`
   - Display "Kode Voucher Kadaluarsa" message
   - Cleanup session from radacct

**Reply-Message**: Custom message di MikroTik log

---

## ðŸ¤ Agent/Reseller System

### 1. Agent Features

**Capabilities**:
- Balance-based voucher generation
- Multi-profile support
- Sales tracking & reporting
- Commission calculation
- Payment management
- Voucher inventory

**Agent Types**:
- `RESELLER` - Full access, beli voucher pakai balance
- `DISTRIBUTOR` - Large volume, special pricing
- `PARTNER` - Limited access

### 2. Agent Operations

**Generate Voucher**:
1. Check balance cukup?
2. Deduct balance (qty Ã— price)
3. Generate voucher batch
4. Record in `agent_sales`
5. Update inventory

**Top-up Balance**:
- Manual (admin adds balance)
- Auto (via payment gateway)
- Transfer antar agent (optional)

### 3. Commission System

**Calculation**:
```typescript
price: 10000           // Harga voucher
commission: 1000       // 10% commission
agentPays: 9000        // Harga net agent
profit: 1000           // Keuntungan per voucher
```

**Commission Types**:
- Percentage (%)
- Fixed amount (Rp)
- Tiered (volume-based)

---

## ðŸ“¢ Notification System

### 1. WhatsApp Integration

**Templates** (12 total):
1. `registration-approval` - Pendaftaran disetujui
2. `installation-invoice` - Invoice instalasi
3. `admin-create-user` - User dibuat admin
4. `invoice-reminder` - Reminder tagihan
5. `payment-success` - Pembayaran berhasil
6. `voucher-purchase-success` - Voucher terbeli
7. `outage_notification` - Notif gangguan
8. `payment_receipt` - Bukti pembayaran
9. `manual_payment_admin` - Approval needed
10. `manual-payment-approval` - Payment approved
11. `manual-payment-rejection` - Payment rejected
12. `manual-extension` - Perpanjangan manual

**Variables Supported**:
- `{{customerName}}`, `{{username}}`, `{{profileName}}`
- `{{amount}}`, `{{invoiceNumber}}`, `{{expiredDate}}`
- `{{companyName}}`, `{{companyPhone}}`, `{{paymentLink}}`

**Provider**: Any WhatsApp Gateway API compatible

### 2. Email Notifications

**Templates** (5 total):
1. `payment_confirmation_request` - Request konfirmasi
2. `payment_approval_required` - Perlu approval
3. `payment_approved` - Pembayaran disetujui
4. `payment_rejected` - Pembayaran ditolak
5. `manual-extension` - Perpanjangan manual

**Email Configuration**:
- SMTP: Gmail, Office365, Custom
- HTML templates dengan inline CSS
- Auto-retry on failure
- Delivery tracking

### 3. Broadcast Notification System
**Reference**: [BROADCAST_NOTIFICATION_SYSTEM.md](BROADCAST_NOTIFICATION_SYSTEM.md)

**Features**:
- Mass notification ke selected users
- Multi-channel (WhatsApp + Email)
- Bulk selection dengan pagination
- Filter by area/status/profile
- Send to all users
- Template selection
- Preview before send

**Use Cases**:
- Pemberitahuan gangguan jaringan
- Reminder pembayaran massal
- Promosi paket baru
- Maintenance schedule
- Festival greetings

**Channels**:
- WhatsApp only
- Email only
- WhatsApp + Email (both)

### 4. Outage Notification System
**Reference**: [OUTAGE_NOTIFICATION_SYSTEM.md](OUTAGE_NOTIFICATION_SYSTEM.md)

**API**: `POST /api/notifications/outage`

**Parameters**:
```typescript
{
  targetUsers: 'all' | 'area' | 'selected',
  areaId?: string,
  userIds?: string[],
  issueType: 'internet' | 'electric' | 'maintenance' | 'other',
  customMessage?: string,
  estimatedTime?: string,
  channels: ['whatsapp', 'email']
}
```

**Issue Types**:
- `internet` - Gangguan internet/upstream
- `electric` - Gangguan listrik PLN
- `maintenance` - Maintenance terjadwal
- `other` - Custom message

**Templates**:
- Pre-defined untuk setiap issue type
- Custom message support
- ETA (Estimated Time of Arrival)
- Auto-translate ke Bahasa Indonesia

---

## ðŸ“Š Financial Management

### 1. Transaction Categories

**Income Categories** (4):
- `cat-income-pppoe` - Pembayaran PPPoE bulanan
- `cat-income-hotspot` - Penjualan voucher hotspot
- `cat-income-instalasi` - Biaya instalasi pelanggan baru
- `cat-income-lainnya` - Pendapatan lain-lain

**Expense Categories** (9):
- `cat-expense-bandwidth` - Bandwidth & upstream
- `cat-expense-gaji` - Gaji karyawan
- `cat-expense-listrik` - Listrik operasional
- `cat-expense-maintenance` - Perawatan & repair
- `cat-expense-hardware` - Peralatan & hardware
- `cat-expense-sewa` - Sewa tempat
- `cat-expense-komisi` - Komisi agent
- `cat-expense-marketing` - Marketing & promosi
- `cat-expense-lainnya` - Operasional lainnya

### 2. Financial Reports

**Available Reports**:
- Income vs Expense (by period)
- Profit/Loss statement
- Cash flow analysis
- Category breakdown
- Agent commission summary
- Payment gateway fees
- Outstanding invoices
- Paid invoices report

**Export Formats**:
- PDF
- Excel (XLSX)
- CSV

### 3. Invoice Management

**Status Tracking**:
- `UNPAID` - Belum dibayar
- `PENDING` - Menunggu konfirmasi
- `PAID` - Sudah dibayar
- `OVERDUE` - Terlambat bayar
- `CANCELLED` - Dibatalkan

**Auto-Actions**:
- Send reminder H-3
- Send reminder H-1
- Auto-isolate H+0 (overdue)
- Mark as overdue H+7

---

## âš™ï¸ Automation & Cron Jobs

**Reference**: [CRON-SYSTEM.md](CRON-SYSTEM.md)

### Job Definitions (10 Jobs)

#### 1. Hotspot Sync (`hotspot_sync`)
- **Schedule**: Every 5 minutes
- **Purpose**: Auto-activate vouchers on first login
- **Actions**: Update usedAt, calculate expiredAt

#### 2. Voucher Sync (`voucher_sync`)
- **Schedule**: Every 1 minute
- **Purpose**: Disconnect expired vouchers
- **Actions**: CoA disconnect, cleanup sessions

#### 3. PPPoE Auto-Isolate (`pppoe_auto_isolate`)
- **Schedule**: Every hour (00:00)
- **Purpose**: Isolate expired PPPoE users
- **Actions**: Change status, update RADIUS group

#### 4. Generate Invoices (`generate_invoices`)
- **Schedule**: Daily at 00:00 WIB
- **Purpose**: Auto-generate monthly invoices
- **Actions**: PREPAID (H-7), POSTPAID (billingDay)

#### 5. Invoice Reminders (`invoice_reminders`)
- **Schedule**: Daily at 08:00 WIB
- **Purpose**: Send payment reminders
- **Actions**: Send WhatsApp/Email H-3, H-1

#### 6. Mark Overdue (`mark_overdue`)
- **Schedule**: Daily at 01:00 WIB
- **Purpose**: Mark unpaid invoices as overdue
- **Actions**: Update status, send notification

#### 7. Auto-Disconnect Sessions (`auto_disconnect`)
- **Schedule**: Every 10 minutes
- **Purpose**: Disconnect expired sessions
- **Actions**: CoA disconnect, update radacct

#### 8. Cleanup Old Sessions (`cleanup_sessions`)
- **Schedule**: Daily at 03:00 WIB
- **Purpose**: Delete old radacct records (>90 days)
- **Actions**: Prevent database bloat

#### 9. Sync NAS Clients (`sync_nas`)
- **Schedule**: Every 30 minutes
- **Purpose**: Update FreeRADIUS NAS table
- **Actions**: Sync from database to RADIUS

#### 10. Activity Log Cleanup (`cleanup_activity_logs`)
- **Schedule**: Daily at 04:00 WIB
- **Purpose**: Delete old activity logs (>90 days)
- **Actions**: Maintain database performance

### Cron System Architecture

**Database Tables**:
```sql
cron_jobs:
  - name, schedule, enabled
  - lastRun, nextRun, status
  
cron_executions:
  - jobName, startedAt, completedAt
  - status, result, error
```

**Execution Tracking**:
- Start time, end time, duration
- Success/failure status
- Error messages & stack traces
- Result statistics (records processed)

**Monitoring**:
- Admin dashboard
- Execution history (last 100 runs)
- Performance metrics
- Alert on failures

---

## ðŸ“ˆ Monitoring & Reporting

### 1. Activity Log System
**Reference**: [ACTIVITY_LOG_IMPLEMENTATION.md](ACTIVITY_LOG_IMPLEMENTATION.md)

**Features**:
- Comprehensive action tracking
- User attribution (who did what)
- IP address logging
- Timestamp (UTC+7)
- Entity tracking (type + ID)
- Auto-cleanup (90 days)

**Logged Actions**:
- User CRUD operations
- Invoice payments
- Voucher generations
- Setting changes
- Login/logout
- Permission changes
- Broadcast notifications

**Activity Categories**:
- `USER_MANAGEMENT`
- `FINANCIAL`
- `SYSTEM`
- `SECURITY`
- `NOTIFICATION`

**Usage**:
```typescript
await logActivity({
  action: 'CREATE_USER',
  category: 'USER_MANAGEMENT',
  userId: 'admin-123',
  entityType: 'pppoe_user',
  entityId: 'user-456',
  details: { username: 'john@example', profile: '10Mbps' },
  ipAddress: req.ip,
  userAgent: req.headers['user-agent']
});
```

### 2. Session Monitoring

**Real-Time Sessions**:
- Active PPPoE sessions
- Active hotspot sessions
- Session duration
- Download/upload statistics
- IP address assignments
- NAS identification

**Session Actions**:
- Manual disconnect (CoA)
- Speed limit change
- Session extension
- Force logout

### 3. Dashboard Analytics

**Metrics**:
- Total customers (active/inactive)
- Revenue this month
- Outstanding invoices
- Active sessions
- Voucher sales
- Agent performance
- Payment success rate

**Charts**:
- Revenue trend (last 12 months)
- Customer growth
- Payment method distribution
- Top selling profiles
- Agent sales ranking

---

## ðŸ”§ GenieACS Integration

**Reference**: [GENIEACS-GUIDE.md](GENIEACS-GUIDE.md)

### Overview
GenieACS = Auto Configuration Server (ACS) untuk TR-069 devices (ONT/ONU)

### Supported Devices
- Huawei ONTs (HG8145, HG8245, HG8310)
- ZTE ONUs (F660, F670L)
- Fiberhome ONTs (AN5506)
- Generic TR-069 devices

### Features

#### 1. Auto-Discovery
- CPE auto-register ketika connect ke ACS
- Device information extraction
- Serial number tracking
- MAC address logging

#### 2. Remote Configuration
- WiFi SSID/Password configuration
- Port forwarding setup
- Firewall rules
- VLAN configuration
- TR-069 parameters

#### 3. Firmware Management
- Upload firmware files
- Schedule firmware upgrades
- Rollback support
- Version tracking

#### 4. Monitoring
- Device status (online/offline)
- Signal strength (PON)
- Error logs
- Performance metrics

### Parameter Display Configuration
**26 Pre-configured Parameters**:
- Device info (model, serial, software version)
- WAN connection (IP, gateway, DNS)
- LAN settings (DHCP, IP range)
- WiFi settings (SSID, security, channel)
- PON info (OLT ID, signal strength)
- VoIP status (if supported)

**Database Schema**:
```sql
genieacs_parameter_display:
  - parameterPath: TR-069 path
  - displayName: Human-readable name
  - displayOrder: Sort order
  - isVisible: Show/hide
  - category: Grouping
```

### Provisioning Scripts

**Pre-defined Scripts**:
1. Initial setup (first boot)
2. WiFi configuration
3. Port forwarding
4. Firmware upgrade
5. Factory reset

**Custom Scripts**: JavaScript-based CPE scripting

---

## ðŸ” Security & Permissions

### 1. Role-Based Access Control (RBAC)

**Permission System** (53 permissions):

**User Management**:
- `view_users`, `create_user`, `edit_user`, `delete_user`
- `view_registrations`, `approve_registration`
- `import_users`, `export_users`

**Financial**:
- `view_invoices`, `create_invoice`, `edit_invoice`, `delete_invoice`
- `approve_payment`, `reject_payment`
- `view_transactions`, `create_transaction`

**Vouchers**:
- `view_vouchers`, `generate_vouchers`, `delete_vouchers`
- `print_vouchers`, `export_vouchers`

**Agents**:
- `view_agents`, `create_agent`, `edit_agent`
- `manage_agent_balance`, `view_agent_sales`

**Settings**:
- `view_settings`, `edit_settings`
- `manage_nas`, `manage_profiles`
- `manage_templates`, `manage_notifications`

**Reports**:
- `view_reports`, `export_reports`
- `view_activity_logs`, `view_sessions`

**System**:
- `manage_users`, `manage_roles`
- `manage_cron_jobs`, `view_system_health`

### 2. Role Templates (6 Roles)

#### Super Admin
- All 53 permissions
- Full system access
- Cannot be deleted

#### Admin
- All except `manage_roles` & `delete_user`
- Standard admin tasks

#### Finance
- Invoice & payment management
- Transaction reports
- No user management

#### Support
- View-only access
- Help customers
- Generate vouchers

#### Agent
- Limited to own data
- Generate vouchers (from balance)
- View own sales

#### Viewer
- Read-only access
- No create/edit/delete
- Basic reports

### 3. Authentication

**Session Management**:
- JWT-based authentication
- Refresh token support
- Session timeout (configurable)
- Multi-device login (optional)

**Password Security**:
- Bcrypt hashing (12 rounds)
- Minimum length: 8 characters
- Complexity requirements (optional)
- Password reset via email

**2FA Support** (Planned):
- TOTP (Google Authenticator)
- SMS verification
- Email OTP

---

## ðŸš€ Deployment & Infrastructure

**Reference**: [DEPLOYMENT-GUIDE.md](DEPLOYMENT-GUIDE.md), [VPS_OPTIMIZATION_GUIDE.md](VPS_OPTIMIZATION_GUIDE.md)

### 1. Server Requirements

**Minimum Specs**:
- OS: Ubuntu 20.04/22.04 LTS
- RAM: 2GB (4GB recommended)
- Storage: 20GB SSD
- CPU: 2 vCPU
- Network: 100 Mbps

**Recommended Specs** (500+ users):
- RAM: 8GB
- Storage: 50GB SSD
- CPU: 4 vCPU
- Network: 1 Gbps

### 2. Installation Methods

#### A. Quick Deploy (vps-install.sh)
```bash
# Upload project
scp -r salfanet-radius root@VPS_IP:/root/

# Run installer
chmod +x vps-install.sh
./vps-install.sh
```

**Auto-installs**:
- Node.js 20.x
- MySQL 8.0
- FreeRADIUS 3.0.26
- Nginx
- PM2
- SSL certificate (Let's Encrypt)

#### B. Manual Installation
Step-by-step documented in [DEPLOYMENT-GUIDE.md](DEPLOYMENT-GUIDE.md)

#### C. Update Existing (vps-update.sh)
```bash
chmod +x vps-update.sh
./vps-update.sh

# Select mode:
# 1 = FULL (backup, npm install, migrations, build)
# 2 = QUICK (skip backups)
# 3 = HOTFIX (code only, fastest)
```

### 3. VPS Optimization

**Build Optimization**:
- Automatic heap size detection
- Swap creation for low-memory VPS
- Turbopack for faster builds
- Memory-efficient settings

**Memory Tiers**:
```bash
< 800 MB   â†’ Create 2GB swap + 1024MB heap
800MB-1.5GB â†’ 1536MB heap (Low-Mem mode)
1.5GB-3GB  â†’ 4096MB heap (Standard)
> 3GB      â†’ 8192MB heap (High-Mem)
```

**PM2 Configuration**:
```javascript
{
  name: 'salfanet-radius',
  script: 'npm',
  args: 'start',
  instances: 1,
  exec_mode: 'fork',
  max_memory_restart: '1G',
  env: {
    NODE_ENV: 'production',
    PORT: 3000
  }
}
```

### 4. SSL/HTTPS Setup

**Let's Encrypt** (Free):
```bash
# Install certbot
apt install certbot python3-certbot-nginx

# Get certificate
certbot --nginx -d yourdomain.com

# Auto-renewal
certbot renew --dry-run
```

**Nginx Config**:
- HTTP â†’ HTTPS redirect
- Reverse proxy to Next.js (port 3000)
- Static file serving
- Gzip compression
- Security headers

### 5. Backup Strategy

**Automated Backups**:
- Database dump daily (via cron)
- .env file backup
- FreeRADIUS config backup
- Upload folder backup

**Backup Location**: `/var/www/backups/`

**Retention**: 7 daily + 4 weekly + 3 monthly

### 6. VPN Setup for Remote Routers
**Reference**: [VPN_CLIENT_SETUP_GUIDE.md](VPN_CLIENT_SETUP_GUIDE.md)

**Scenario**: MikroTik di lokasi remote â†’ VPN ke VPS â†’ RADIUS authentication

**Steps**:
1. Setup L2TP/IPSec server di MikroTik central
2. Create VPN client di VPS
3. Establish tunnel
4. Add router via VPN IP
5. Test RADIUS auth

**Benefits**:
- Single public IP for all routers
- Secure tunnel
- Centralized management
- No port forwarding needed

---

## ðŸŽ¨ Advanced Features

### 1. Isolation System

**Features**:
- Auto-isolate expired users
- Limited bandwidth (configurable)
- Custom landing page redirect
- WhatsApp/Email notification
- Payment link on landing page
- QR code for payment

**Isolation Templates** (3 types):
1. **WhatsApp**: Notif bahwa akun di-isolir + payment link
2. **Email**: HTML email dengan detail + CTA
3. **HTML Landing Page**: Redirect page dengan payment info

**Variables**:
- `{{customerName}}`, `{{username}}`, `{{expiredDate}}`
- `{{rateLimit}}`, `{{paymentLink}}`, `{{qrCode}}`
- `{{companyName}}`, `{{companyPhone}}`, `{{companyEmail}}`

**Configuration**:
```typescript
isolationEnabled: true
isolationIpPool: "192.168.200.0/24"
isolationRateLimit: "64k/64k"
isolationAllowDns: true
isolationAllowPayment: true
isolationNotifyWhatsapp: true
```

### 2. Multi-Tenancy Support (Planned)

**Features**:
- Multiple companies/ISPs
- Isolated databases per tenant
- Custom branding per tenant
- White-label support
- Tenant admin panel

### 3. API Integration

**Public API Endpoints**:
- `/api/radius/*` - RADIUS integration
- `/api/webhook/*` - Payment gateway webhooks
- `/api/public/check-voucher` - Voucher validation
- `/api/public/check-user` - User status check

**Authentication**: API Key or JWT token

### 4. Custom Reports

**Report Builder**:
- Drag-and-drop fields
- Custom filters
- Date range selection
- Export formats (PDF, Excel, CSV)
- Scheduled reports (email delivery)

**Pre-built Reports**:
- Revenue by period
- Customer acquisition
- Churn rate
- Agent performance
- Payment method distribution
- Top selling products
- Outstanding balances

### 5. Timezone Handling

**Architecture**:
- **Database**: All datetime in UTC
- **FreeRADIUS**: WIB (UTC+7) for session tracking
- **API**: Auto-convert UTC â†” WIB
- **Frontend**: Display in WIB

**Helper Functions**:
```typescript
toWIB(utcDate)      // UTC â†’ WIB
toUTC(wibDate)      // WIB â†’ UTC
nowWIB()            // Current time in WIB
formatWIB(date)     // Format for display
```

**Benefits**:
- Consistent timezone across system
- No timezone confusion
- Accurate session tracking
- Correct invoice dates

---

## ðŸ“š Documentation References

### Getting Started
- [README.md](../README.md) - Project overview & quick start
- [DEPLOYMENT-GUIDE.md](DEPLOYMENT-GUIDE.md) - Installation guide
- [TESTING_GUIDE.md](TESTING_GUIDE.md) - Testing procedures

### Core Systems
- [FREERADIUS-SETUP.md](FREERADIUS-SETUP.md) - RADIUS server setup
- [CRON-SYSTEM.md](CRON-SYSTEM.md) - Automation & scheduled jobs
- [ACTIVITY_LOG_IMPLEMENTATION.md](ACTIVITY_LOG_IMPLEMENTATION.md) - Logging system

### Features
- [PREPAID_POSTPAID_IMPLEMENTATION.md](PREPAID_POSTPAID_IMPLEMENTATION.md) - Billing types
- [AGENT_DEPOSIT_SYSTEM.md](AGENT_DEPOSIT_SYSTEM.md) - Agent/reseller system
- [MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md](MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md) - Payment approval
- [BROADCAST_NOTIFICATION_SYSTEM.md](BROADCAST_NOTIFICATION_SYSTEM.md) - Mass notifications
- [OUTAGE_NOTIFICATION_SYSTEM.md](OUTAGE_NOTIFICATION_SYSTEM.md) - Downtime alerts
- [GENIEACS-GUIDE.md](GENIEACS-GUIDE.md) - TR-069 device management

### Technical
- [MULTIPLE_NAS_SAME_IP.md](MULTIPLE_NAS_SAME_IP.md) - VPN router support
- [IMPORT_PPPOE_USERS.md](IMPORT_PPPOE_USERS.md) - MikroTik sync
- [GPS_LOCATION_FEATURE.md](GPS_LOCATION_FEATURE.md) - Location tracking
- [INVOICE_NUMBER_FORMAT.md](INVOICE_NUMBER_FORMAT.md) - Invoice numbering
- [VPN_CLIENT_SETUP_GUIDE.md](VPN_CLIENT_SETUP_GUIDE.md) - VPN configuration
- [VPS_OPTIMIZATION_GUIDE.md](VPS_OPTIMIZATION_GUIDE.md) - Performance tuning

### Troubleshooting
- [TROUBLESHOOTING.md](TROUBLESHOOTING.md) - Common issues & solutions

### Session Notes
- [SESSION_2025-12-23_BUG_FIXES.md](SESSION_2025-12-23_BUG_FIXES.md) - Recent bug fixes
- [SESSION_2025-12-23_THEME_AND_API_FIXES.md](SESSION_2025-12-23_THEME_AND_API_FIXES.md) - UI/API improvements
- [CHAT_HISTORY_2025-12-23.md](../CHAT_HISTORY_2025-12-23.md) - Development session log

---

## ðŸ”„ Version History

### v2.7.5 (December 23, 2025) - Current
- âœ… Manual extension templates (WhatsApp + Email)
- âœ… Complete database seeding (22 templates)
- âœ… UTF-8 BOM fixes
- âœ… Windows build support (cross-env)
- âœ… Cleanup duplicate seed files
- âœ… Documentation updates

### v2.7.4 (December 2025)
- âœ… Hotspot sync improvements
- âœ… Isolation templates
- âœ… Activity log system
- âœ… Cron job execution tracking

### v2.7.3 (November 2025)
- âœ… VPS build optimization
- âœ… Memory-aware heap sizing
- âœ… Automatic swap creation

### v2.7.0 (October 2025)
- âœ… Manual payment system
- âœ… Prepaid/Postpaid implementation
- âœ… Broadcast notifications
- âœ… Outage notifications

### Earlier Versions
- v2.6.x - Agent deposit system
- v2.5.x - GenieACS integration
- v2.4.x - Multiple NAS same IP
- v2.3.x - GPS location tracking
- v2.2.x - Payment gateway integration
- v2.1.x - Email notification system
- v2.0.x - WhatsApp integration

---

## ðŸŽ¯ Roadmap (Planned Features)

### Q1 2026
- [ ] Multi-tenancy support
- [ ] Mobile app (Flutter)
- [ ] Advanced analytics dashboard
- [ ] 2FA authentication

### Q2 2026
- [ ] API rate limiting
- [ ] Custom report builder
- [ ] Ticket/support system
- [ ] Live chat integration

### Q3 2026
- [ ] Inventory management
- [ ] HR & payroll module
- [ ] CRM features
- [ ] Marketing automation

### Q4 2026
- [ ] AI-powered insights
- [ ] Predictive analytics
- [ ] Auto-scaling support
- [ ] Microservices architecture

---

## ðŸ“ž Support & Contact

**Documentation**: `/docs` folder (20+ guides)  
**Issues**: GitHub Issues (jika open source)  
**Email**: support@yourdomain.com  
**WhatsApp**: +62 xxx-xxxx-xxxx

---

## ðŸ“ License

Proprietary - All Rights Reserved  
Copyright Â© 2025 AIBILL RADIUS

---

**Generated**: December 23, 2025  
**Total Features**: 100+  
**Total Templates**: 22  
**Supported Users**: Unlimited  
**Documentation Pages**: 20+

**ðŸŽ‰ Complete Billing & RADIUS Management Solution untuk ISP/RTRW.NET Indonesia**


## [9] CRON-SYSTEM.md


# SALFANET RADIUS - Cron Job System Documentation

## Overview

SALFANET RADIUS menggunakan **node-cron** untuk automated background tasks. Sistem ini menjalankan 10 scheduled jobs untuk maintenance dan operasional otomatis.

## Architecture

```
src/lib/cron/
â”œâ”€â”€ config.ts           # Job definitions & schedules
â”œâ”€â”€ voucher-sync.ts     # Voucher & session jobs
â”œâ”€â”€ agent.ts            # Agent sales jobs
â”œâ”€â”€ isolir.ts           # Auto isolir jobs
â”œâ”€â”€ invoice.ts          # Invoice generation jobs
â””â”€â”€ whatsapp.ts         # WhatsApp queue jobs

src/app/api/cron/
â””â”€â”€ route.ts            # Manual trigger endpoint

prisma/schema.prisma
â””â”€â”€ cronHistory         # Execution history table
```

## Job Definitions

### 1. Hotspot Sync (`hotspot_sync`) â­ UPDATED v2.7.4

**Schedule:** Every minute (`* * * * *`)

**Function:**
- âœ… Deteksi first login voucher dari tabel `radacct`
- âœ… Update status WAITING â†’ USED saat first login
- âœ… Set `usedAt` dan `expiredAt` berdasarkan validity profile
- âœ… Deteksi voucher expired (USED â†’ EXPIRED)
- âœ… **Reply-Message for Expired Vouchers** (v2.7.4):
  - Set password = "EXPIRED" di `radcheck` (prevent auth)
  - Add Reply-Message = "Kode Voucher Kadaluarsa" di `radreply`
  - Remove from `radusergroup` (remove bandwidth)

**Handler:** `src/lib/cron/hotspot-sync.ts â†’ syncHotspotWithRadius()`

**Database Tables:**
- **Read:** `hotspot_vouchers`, `radacct`, `radusergroup`
- **Write:** `hotspot_vouchers`, `radcheck`, `radreply`, `radusergroup`
- **Log:** `cron_history`

**Result Example:** `"Synced 150 vouchers, expired 5 with Reply-Message"`

**MikroTik Log Output (When Expired):**
```
user WPCTVR login error: Kode Voucher Kadaluarsa
```

---

### 2. Voucher Sync (`voucher_sync`)

**Schedule:** Every 5 minutes (`*/5 * * * *`)

**Function:**
- Sync voucher status with FreeRADIUS radcheck/radacct tables
- Update firstLoginAt, expiresAt, status fields
- Mark WAITING â†’ ACTIVE when first login detected
- Mark ACTIVE â†’ EXPIRED when expiry time reached

**Handler:** `src/lib/cron/voucher-sync.ts â†’ syncVouchersWithRadius()`

**Result Example:** `"Synced 150 vouchers"`

---

### 3. Disconnect Sessions (`disconnect_sessions`) â­ NEW

**Schedule:** Every 5 minutes (`*/5 * * * *`)

**Function:**
- Find expired vouchers with active RADIUS sessions
- Send CoA (Change of Authorization) Disconnect-Request to FreeRADIUS
- Force disconnect users with expired vouchers
- Prevent continued usage after expiration

**Handler:** `src/lib/cron/voucher-sync.ts â†’ disconnectExpiredVoucherSessions()`

**Result Example:** `"Disconnected 5 expired sessions"`

**Technical Details:**
```typescript
// 1. Query expired vouchers with active sessions
const expiredWithSessions = await prisma.hotspotVoucher.findMany({
  where: {
    status: 'EXPIRED',
    expiresAt: { lt: now },
    radacct: { some: { acctstoptime: null } }
  }
})

// 2. Send CoA Disconnect-Request for each session
const coaResult = await disconnectExpiredSessions()

// 3. Record result in cron_history
```

---

### 4. Agent Sales (`agent_sales`)

**Schedule:** Daily at 1 AM (`0 1 * * *`)

**Function:**
- Calculate total sales for each agent
- Update agent statistics
- Reset daily/monthly counters

**Handler:** `src/lib/cron/agent.ts â†’ updateAgentSales()`

---

### 5. Auto Isolir (`auto_isolir`)

**Schedule:** Every hour (`0 * * * *`)

**Function:**
- Find PPPoE users with overdue invoices
- Auto-suspend (isolir) customers beyond grace period
- Send notification via WhatsApp
- Update user status to SUSPENDED

**Handler:** `src/lib/cron/isolir.ts â†’ autoIsolirOverdueUsers()`

**Result Example:** `"Suspended 12 overdue users"`

**Fixed Issues (v2.3.1):**
- âœ… Added missing imports: `nowWIB, formatWIB, startOfDayWIBtoUTC, endOfDayWIBtoUTC`
- âœ… Fixed "nowWIB is not defined" error

---

### 6. Invoice Generation (`invoice_generation`)

**Schedule:** Daily at 2 AM (`0 2 * * *`)

**Function:**
- Generate monthly invoices for active PPPoE users
- Calculate total amount based on profile price
- Set due date based on billing cycle
- Send invoice notification via WhatsApp

**Handler:** `src/lib/cron/invoice.ts â†’ generateMonthlyInvoices()`

---

### 7. Payment Reminder (`payment_reminder`)

**Schedule:** Daily at 8 AM (`0 8 * * *`)

**Function:**
- Find unpaid invoices approaching due date
- Send payment reminder via WhatsApp
- Escalate reminders (first, second, final)

**Handler:** `src/lib/cron/invoice.ts â†’ sendPaymentReminders()`

---

### 8. WhatsApp Queue (`whatsapp_queue`)

**Schedule:** Every 10 minutes (`*/10 * * * *`)

**Function:**
- Process pending WhatsApp messages in queue
- Rate limit: max 20 messages per batch
- Retry failed messages (max 3 attempts)
- Update queue status

**Handler:** `src/lib/cron/whatsapp.ts â†’ processWhatsAppQueue()`

---

### 9. Expired Voucher Cleanup (`expired_voucher_cleanup`)

**Schedule:** Daily at 3 AM (`0 3 * * *`)

**Function:**
- Delete expired vouchers older than 90 days
- Keep vouchers with transaction history
- Clean up unused vouchers

**Handler:** `src/lib/cron/voucher-sync.ts â†’ cleanupExpiredVouchers()`

**Result Example:** `"Deleted 234 expired vouchers"`

---

### 10. Activity Log Cleanup (`activity_log_cleanup`)

**Schedule:** Daily at 2 AM (`0 2 * * *`)

**Function:**
- Delete activity logs older than 30 days
- Maintain database performance
- Keep recent logs for audit trail

**Handler:** `src/lib/activity-log.ts â†’ cleanOldActivities()`

**Result Example:** `"Cleaned 245 old activities (older than 30 days)"`

**Fixed Issues (v2.3.1):**
- âœ… Modified to create/update `cron_history` records
- âœ… Returns proper result message with count

---

### 11. Session Cleanup (`session_cleanup`)

**Schedule:** Daily at 4 AM (`0 4 * * *`)

**Function:**
- Archive old RADIUS session data (radacct)
- Delete sessions older than 6 months
- Optimize radacct table size

**Handler:** `src/lib/cron/session.ts â†’ cleanupOldSessions()`

---

## Execution History

### Database Schema

```prisma
model cronHistory {
  id          String   @id @default(cuid())
  jobType     String   // Job identifier
  status      String   // 'running', 'success', 'error'
  startedAt   DateTime
  completedAt DateTime?
  duration    Int?     // Milliseconds
  result      String?  @db.Text
  error       String?  @db.Text
  createdAt   DateTime @default(now())
  
  @@index([jobType, createdAt])
}
```

### Recording Pattern

All cron jobs follow this pattern:

```typescript
export async function myCronJob() {
  const startedAt = new Date()
  
  // 1. Create history record with 'running' status
  const history = await prisma.cronHistory.create({
    data: {
      id: nanoid(),
      jobType: 'my_job_type',
      status: 'running',
      startedAt,
    }
  })
  
  try {
    // 2. Execute job logic
    const result = await doSomething()
    
    // 3. Update history with success
    const completedAt = new Date()
    await prisma.cronHistory.update({
      where: { id: history.id },
      data: {
        status: 'success',
        completedAt,
        duration: completedAt.getTime() - startedAt.getTime(),
        result: `Processed ${result.count} items`,
      }
    })
    
    return { success: true, count: result.count }
    
  } catch (error: any) {
    // 4. Update history with error
    await prisma.cronHistory.update({
      where: { id: history.id },
      data: {
        status: 'error',
        completedAt: new Date(),
        error: error.message,
      }
    })
    
    return { success: false, error: error.message }
  }
}
```

## Manual Trigger

### Via Admin Panel

1. Navigate to **Settings â†’ Cron**
2. Find the job you want to trigger
3. Click **"Trigger Now"** button
4. Wait for result notification
5. Check **Execution History** table for details

### Via API

```bash
# Trigger specific job
curl -X POST https://your-domain.com/api/cron \
  -H "Content-Type: application/json" \
  -d '{"jobType": "voucher_sync"}'

# Response:
{
  "success": true,
  "synced": 150
}
```

### Job Type IDs

| Job Type | ID for API |
|----------|------------|
| Voucher Sync | `voucher_sync` |
| Disconnect Sessions | `disconnect_sessions` |
| Agent Sales | `agent_sales` |
| Auto Isolir | `auto_isolir` |
| Invoice Generation | `invoice_generation` |
| Payment Reminder | `payment_reminder` |
| WhatsApp Queue | `whatsapp_queue` |
| Expired Voucher | `expired_voucher_cleanup` |
| Activity Log | `activity_log_cleanup` |
| Session Cleanup | `session_cleanup` |

## Frontend UI

### Settings â†’ Cron Page

**Features:**
- Job cards with schedule information
- Enable/disable toggle (coming soon)
- Manual trigger button
- Execution history table with:
  - Job type labels
  - Status badges (success/error/running)
  - Duration display
  - Result/error messages
  - Timestamp (WIB)

**Code Location:** `src/app/admin/settings/cron/page.tsx`

**Type Labels:**
```typescript
const typeLabels: Record<string, string> = {
  voucher_sync: 'Voucher Sync',
  disconnect_sessions: 'Disconnect Sessions',
  agent_sales: 'Agent Sales Update',
  auto_isolir: 'Auto Isolir',
  invoice_generation: 'Invoice Generation',
  payment_reminder: 'Payment Reminder',
  whatsapp_queue: 'WhatsApp Queue',
  expired_voucher_cleanup: 'Expired Voucher Cleanup',
  activity_log_cleanup: 'Activity Log Cleanup',
  session_cleanup: 'Session Cleanup',
}
```

## Troubleshooting

### Cron Jobs Not Running

**Check PM2 logs:**
```bash
pm2 logs salfanet-radius | grep cron
```

**Check node-cron initialization:**
```bash
pm2 logs salfanet-radius | grep "Starting cron"
```

**Verify cron config:**
```typescript
// src/lib/cron/config.ts
export const cronJobs: CronJobConfig[] = [
  {
    type: 'voucher_sync',
    enabled: true,  // âš ï¸ Must be true
    schedule: '*/5 * * * *',
    handler: async () => { ... }
  }
]
```

### "nowWIB is not defined" Error

**Fixed in v2.3.1**

**Solution:** Ensure all cron files import timezone utilities:
```typescript
import { nowWIB, formatWIB, startOfDayWIBtoUTC, endOfDayWIBtoUTC } from '@/lib/timezone'
```

### Cron History Not Recording

**Check function pattern:**
```typescript
// âœ… CORRECT - Records history
export async function myCronJob() {
  const history = await prisma.cronHistory.create({ ... })
  // ... job logic ...
  await prisma.cronHistory.update({ ... })
}

// âŒ WRONG - No history recording
export async function myCronJob() {
  // ... job logic only ...
  return result
}
```

### CoA Disconnect Not Working

**Check FreeRADIUS CoA configuration:**
```bash
# Verify CoA port open
netstat -tulpn | grep 3799

# Check clients.conf
cat /etc/freeradius/3.0/clients.conf
# Must have: coa_server = 127.0.0.1:3799
```

**Check router NAS configuration:**
```sql
SELECT * FROM nas WHERE coa_port IS NOT NULL;
```

**Test CoA manually:**
```bash
echo "User-Name=vouchercode" | radclient -x 127.0.0.1:3799 disconnect testing123
```

## Multi-Timezone Support

### Indonesia Timezone Regions

Indonesia memiliki 3 timezone berbeda:

| Zona | Nama | UTC Offset | Wilayah | TZ Identifier |
|------|------|------------|---------|---------------|
| **WIB** | Waktu Indonesia Barat | UTC+7 | Sumatera, Jawa, Kalimantan Barat/Tengah | `Asia/Jakarta` |
| **WITA** | Waktu Indonesia Tengah | UTC+8 | Kalimantan Selatan/Timur, Sulawesi, Bali, NTB, NTT | `Asia/Makassar` |
| **WIT** | Waktu Indonesia Timur | UTC+9 | Maluku, Papua | `Asia/Jayapura` |

### Configuration Steps for Different Timezone

#### 1. Update Server System Timezone

```bash
# Untuk WIB (Jakarta, Sumatera, Jawa)
sudo timedatectl set-timezone Asia/Jakarta

# Untuk WITA (Makassar, Bali, Sulawesi)
sudo timedatectl set-timezone Asia/Makassar

# Untuk WIT (Papua, Maluku)
sudo timedatectl set-timezone Asia/Jayapura

# Verifikasi
timedatectl
```

#### 2. Update PM2 Environment

Edit `ecosystem.config.js`:

```javascript
module.exports = {
  apps: [{
    name: 'salfanet-radius',
    env: {
      NODE_ENV: 'production',
      PORT: 3000,
      // Pilih sesuai wilayah:
      TZ: 'Asia/Jakarta'   // WIB (UTC+7)
      // TZ: 'Asia/Makassar'  // WITA (UTC+8)
      // TZ: 'Asia/Jayapura'  // WIT (UTC+9)
    }
  }]
}
```

#### 3. Update Application Environment Variables

Edit `.env`:

```bash
# Timezone Configuration
TZ="Asia/Jakarta"                    # Sesuaikan: Jakarta/Makassar/Jayapura
NEXT_PUBLIC_TIMEZONE="Asia/Jakarta"  # Untuk display di frontend

# Date-fns timezone identifier
TIMEZONE_IDENTIFIER="Asia/Jakarta"   # Sesuaikan dengan wilayah
```

#### 4. Update Timezone Utility Constants

Edit `src/lib/timezone.ts`:

```typescript
import { toZonedTime, formatInTimeZone } from 'date-fns-tz'

// Pilih timezone sesuai wilayah:
export const LOCAL_TIMEZONE = 'Asia/Jakarta'   // WIB
// export const LOCAL_TIMEZONE = 'Asia/Makassar'  // WITA
// export const LOCAL_TIMEZONE = 'Asia/Jayapura'  // WIT

// Alias untuk backward compatibility
export const WIB_TIMEZONE = LOCAL_TIMEZONE

// Timezone-aware helper functions
export function nowLocal() {
  return toZonedTime(new Date(), LOCAL_TIMEZONE)
}

export function formatLocal(date: Date, format: string = 'yyyy-MM-dd HH:mm:ss') {
  return formatInTimeZone(date, LOCAL_TIMEZONE, format)
}
```

#### 5. Update API Routes (Contoh: Voucher)

Edit `src/app/api/hotspot/voucher/route.ts`:

```typescript
import { formatInTimeZone } from 'date-fns-tz'
import { LOCAL_TIMEZONE } from '@/lib/timezone'  // Akan otomatis menggunakan timezone yang di-set

const vouchersWithLocalTime = vouchers.map(v => ({
  ...v,
  // Convert UTC â†’ Local Timezone (Jakarta/Makassar/Jayapura)
  createdAt: formatInTimeZone(v.createdAt, LOCAL_TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss.SSS"),
  updatedAt: formatInTimeZone(v.updatedAt, LOCAL_TIMEZONE, "yyyy-MM-dd'T'HH:mm:ss.SSS"),
  // FreeRADIUS already stores in local timezone
  firstLoginAt: v.firstLoginAt ? v.firstLoginAt.toISOString().replace('Z', '') : null,
  expiresAt: v.expiresAt ? v.expiresAt.toISOString().replace('Z', '') : null,
}))
```

#### 6. Restart Services

```bash
# Restart PM2 dengan environment baru
pm2 restart ecosystem.config.js --update-env
pm2 save

# Restart FreeRADIUS
sudo systemctl restart freeradius

# Verify timezone
pm2 env 0 | grep TZ
date
```

### International Timezone Examples

Untuk deployment di luar Indonesia:

| Negara | Timezone | TZ Identifier |
|--------|----------|---------------|
| Singapura | SGT (UTC+8) | `Asia/Singapore` |
| Malaysia | MYT (UTC+8) | `Asia/Kuala_Lumpur` |
| Thailand | ICT (UTC+7) | `Asia/Bangkok` |
| Filipina | PHT (UTC+8) | `Asia/Manila` |
| Vietnam | ICT (UTC+7) | `Asia/Ho_Chi_Minh` |
| Australia (Sydney) | AEDT (UTC+11) | `Australia/Sydney` |
| India | IST (UTC+5:30) | `Asia/Kolkata` |

### Testing Timezone Configuration

```bash
# 1. Test system timezone
date
timedatectl

# 2. Test PM2 environment
pm2 env 0 | grep TZ

# 3. Test Node.js timezone
node -e "console.log(new Date().toString())"

# 4. Test database timezone
mysql -u salfanet_user -psalfanetradius123 salfanet_radius -e "SELECT NOW(), UTC_TIMESTAMP();"

# 5. Test FreeRADIUS logs
tail -f /var/log/freeradius/radius.log
# Log timestamps should match server timezone
```

### Multi-Region Deployment

Jika Anda deploy di multiple region dengan timezone berbeda:

**Option 1: Separate Instances (Recommended)**
```bash
# VPS Jakarta (WIB)
TZ=Asia/Jakarta pm2 start ecosystem.config.js --name SALFANET-wib

# VPS Makassar (WITA)
TZ=Asia/Makassar pm2 start ecosystem.config.js --name SALFANET-wita

# VPS Papua (WIT)
TZ=Asia/Jayapura pm2 start ecosystem.config.js --name SALFANET-wit
```

**Option 2: Single Instance with Dynamic Timezone**
```typescript
// src/lib/timezone.ts
import { toZonedTime, formatInTimeZone } from 'date-fns-tz'

// Get timezone from environment or default to Jakarta
export const LOCAL_TIMEZONE = process.env.TZ || 
                              process.env.TIMEZONE_IDENTIFIER || 
                              'Asia/Jakarta'

console.log(`[TIMEZONE] Using ${LOCAL_TIMEZONE}`)
```

### Troubleshooting Timezone Issues

#### Issue 1: Times still showing wrong after timezone change

**Solution:**
```bash
# 1. Clear PM2 cache
pm2 delete all
pm2 kill

# 2. Update ecosystem.config.js with new TZ
# 3. Restart fresh
pm2 start ecosystem.config.js
pm2 save

# 4. Clear browser cache
# Press Ctrl+Shift+Delete, clear all cache
```

#### Issue 2: Cron jobs running at wrong time

**Cause:** Cron schedule uses server local time, but PM2 environment might be different.

**Solution:**
```bash
# Make sure server timezone matches PM2 TZ
sudo timedatectl set-timezone Asia/Jakarta  # Or your timezone
pm2 restart ecosystem.config.js --update-env

# Verify both match
date
pm2 env 0 | grep TZ
```

#### Issue 3: Database and display times don't match

**Cause:** Database stores UTC, but conversion to local timezone is incorrect.

**Solution:**
```typescript
// Always use formatInTimeZone for UTC â†’ Local conversion
import { formatInTimeZone } from 'date-fns-tz'
import { LOCAL_TIMEZONE } from '@/lib/timezone'

// âœ… CORRECT
const localTime = formatInTimeZone(utcDate, LOCAL_TIMEZONE, 'yyyy-MM-dd HH:mm:ss')

// âŒ WRONG - Assumes WIB
const localTime = formatInTimeZone(utcDate, 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss')
```

### Configuration Checklist

When deploying to a new timezone:

- [ ] Set server system timezone (`timedatectl set-timezone`)
- [ ] Update `ecosystem.config.js` TZ environment variable
- [ ] Update `.env` TZ and NEXT_PUBLIC_TIMEZONE
- [ ] Update `src/lib/timezone.ts` LOCAL_TIMEZONE constant
- [ ] Restart PM2 with `--update-env` flag
- [ ] Restart FreeRADIUS service
- [ ] Test voucher generation time
- [ ] Test dashboard statistics date ranges
- [ ] Test cron job execution times
- [ ] Verify all displayed times match server local time
- [ ] Clear browser cache and re-login

## Best Practices

### 1. Always Record History

Every cron job must create and update `cronHistory` records for visibility and debugging.

### 2. Use Timezone Utilities

Always use timezone-aware functions:
```typescript
import { nowLocal, formatLocal, LOCAL_TIMEZONE } from '@/lib/timezone'

// âœ… CORRECT - Works for any timezone
const now = nowLocal()
const formatted = formatLocal(date, 'yyyy-MM-dd HH:mm:ss')

// âŒ WRONG - Hardcoded WIB
const now = nowWIB()  // Only works for Jakarta timezone
```

### 3. Handle Errors Gracefully

```typescript
try {
  const result = await riskyOperation()
  return { success: true, ...result }
} catch (error: any) {
  console.error('[CRON ERROR]', error)
  return { success: false, error: error.message }
}
```

### 4. Use Batching for Large Operations

```typescript
// Process in batches to prevent memory issues
const BATCH_SIZE = 1000
const total = await prisma.model.count()

for (let offset = 0; offset < total; offset += BATCH_SIZE) {
  const batch = await prisma.model.findMany({
    skip: offset,
    take: BATCH_SIZE
  })
  await processBatch(batch)
}
```

### 5. Add Result Messages

```typescript
// âœ… GOOD - Descriptive result
result: `Disconnected ${count} expired sessions`

// âŒ BAD - Generic result
result: 'Success'
```

## Future Enhancements

- [ ] Enable/disable toggle for each job in UI
- [ ] Email notifications for cron failures
- [ ] Custom schedule configuration via admin panel
- [ ] Job dependency management (run job B after job A)
- [ ] Parallel execution for independent jobs
- [ ] Retry mechanism for failed jobs
- [ ] Job execution statistics (average duration, success rate)

## Related Documentation

- [Timezone Architecture](../README.md#-timezone--date-handling)
- [Activity Log System](./ACTIVITY_LOG_IMPLEMENTATION.md)
- [FreeRADIUS Setup](./FREERADIUS-SETUP.md)
- [Deployment Guide](./DEPLOYMENT-GUIDE.md)

---

**Last Updated:** December 7, 2025  
**Version:** 2.3.1


## [10] ACTIVITY_LOG_IMPLEMENTATION.md


# Activity Log Implementation Guide

## Overview
Sistem activity log mencatat semua aktivitas penting di aplikasi SALFANET RADIUS untuk ditampilkan di dashboard admin.

## Database Schema
```prisma
model activityLog {
  id          String   @id @default(cuid())
  userId      String?
  username    String
  userRole    String?
  action      String
  description String   @db.Text
  module      String   // 'pppoe', 'hotspot', 'voucher', 'invoice', 'payment', 'agent', 'session', 'transaction', 'system', etc
  status      String   @default("success") // 'success', 'warning', 'error'
  ipAddress   String?
  metadata    String?  @db.Text // JSON string for additional data
  createdAt   DateTime @default(now())
}
```

## Helper Functions

### Import
```typescript
import { logActivity } from '@/lib/activity-log';
```

### Basic Usage
```typescript
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  userRole: session.user.role,
  action: 'GENERATE_VOUCHER',
  description: `Generated ${count} vouchers for profile ${profileName}`,
  module: 'voucher',
  status: 'success',
  request: request, // Optional - auto extracts IP
  metadata: { count, profileId, batchCode }, // Optional
});
```

## Implementation Examples

### 1. Hotspot Voucher Generation
**File:** `src/app/api/hotspot/voucher/route.ts`

```typescript
// After successful voucher generation
await logActivity({
  username: 'Admin', // Get from session
  action: 'GENERATE_VOUCHER',
  description: `Generated ${result.count} vouchers (${profile.name}) - Batch: ${batchCode}`,
  module: 'voucher',
  status: 'success',
  metadata: {
    quantity: result.count,
    profileId,
    profileName: profile.name,
    batchCode,
    routerId,
    agentId,
  },
});
```

### 2. Agent Generate Voucher
**File:** `src/app/api/agent/generate-voucher/route.ts`

```typescript
await logActivity({
  username: agent.name,
  userRole: 'AGENT',
  action: 'AGENT_GENERATE_VOUCHER',
  description: `Agent ${agent.name} generated ${quantity} vouchers (${profile.name})`,
  module: 'agent',
  status: 'success',
  metadata: {
    agentId: agent.id,
    quantity,
    profileName: profile.name,
    costPrice: profile.costPrice * quantity,
    newBalance: agent.balance - totalCost,
  },
});
```

### 3. Agent Deposit
**File:** `src/app/api/agent/deposit/webhook/route.ts`

```typescript
// On successful payment
await logActivity({
  username: agent.name,
  userRole: 'AGENT',
  action: 'AGENT_DEPOSIT',
  description: `Agent ${agent.name} deposited Rp ${amount.toLocaleString('id-ID')}`,
  module: 'agent',
  status: 'success',
  metadata: {
    agentId: agent.id,
    amount,
    paymentGateway: deposit.paymentGateway,
    transactionId: deposit.transactionId,
  },
});
```

### 4. PPPoE User Create/Update
**File:** `src/app/api/pppoe/users/route.ts`

```typescript
// Create user
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: 'CREATE_PPPOE_USER',
  description: `Created PPPoE user: ${username}`,
  module: 'pppoe',
  status: 'success',
  metadata: {
    username,
    profileId,
    routerId,
  },
});

// Update user
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: 'UPDATE_PPPOE_USER',
  description: `Updated PPPoE user: ${username}`,
  module: 'pppoe',
  status: 'success',
  metadata: {
    username,
    changes: { status, profileId },
  },
});
```

### 5. Session Disconnect
**File:** `src/app/api/sessions/disconnect/route.ts`

```typescript
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: 'DISCONNECT_SESSION',
  description: `Disconnected user: ${username}`,
  module: 'session',
  status: 'success',
  metadata: {
    username,
    ipAddress: framedIpAddress,
    nasIpAddress,
  },
});
```

### 6. Invoice Generation
**File:** `src/app/api/invoices/generate/route.ts`

```typescript
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: 'GENERATE_INVOICE',
  description: `Generated ${invoices.length} invoices for period ${period}`,
  module: 'invoice',
  status: 'success',
  metadata: {
    count: invoices.length,
    period,
    totalAmount,
  },
});
```

### 7. Payment Received
**File:** `src/app/api/payment/webhook/route.ts`

```typescript
await logActivity({
  username: invoice.customerUsername || 'Customer',
  action: 'PAYMENT_RECEIVED',
  description: `Payment received for invoice ${invoice.invoiceNumber} - Rp ${amount.toLocaleString('id-ID')}`,
  module: 'payment',
  status: 'success',
  metadata: {
    invoiceId: invoice.id,
    invoiceNumber: invoice.invoiceNumber,
    amount,
    paymentMethod,
  },
});
```

### 8. Transaction (Keuangan)
**File:** `src/app/api/keuangan/transactions/route.ts`

```typescript
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: transaction.type === 'INCOME' ? 'ADD_INCOME' : 'ADD_EXPENSE',
  description: `${transaction.type}: ${transaction.description} - Rp ${transaction.amount.toLocaleString('id-ID')}`,
  module: 'transaction',
  status: 'success',
  metadata: {
    transactionId: transaction.id,
    type: transaction.type,
    amount: transaction.amount,
    categoryId: transaction.categoryId,
  },
});
```

### 9. WhatsApp Broadcast
**File:** `src/app/api/whatsapp/broadcast/route.ts`

```typescript
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: 'WHATSAPP_BROADCAST',
  description: `Sent WhatsApp broadcast to ${recipients.length} recipients`,
  module: 'whatsapp',
  status: 'success',
  metadata: {
    recipientCount: recipients.length,
    template,
    filter,
  },
});
```

### 10. Network Router Add/Update
**File:** `src/app/api/network/routers/route.ts`

```typescript
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: 'ADD_ROUTER',
  description: `Added router: ${name} (${ipAddress})`,
  module: 'network',
  status: 'success',
  metadata: {
    routerId: router.id,
    name,
    ipAddress,
    type,
  },
});
```

### 11. System Actions (RADIUS Restart, etc)
**File:** `src/app/api/system/radius/route.ts`

```typescript
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: 'RESTART_RADIUS',
  description: `Restarted FreeRADIUS service`,
  module: 'system',
  status: 'success',
});
```

### 12. User Login
**File:** `src/app/api/auth/[...nextauth]/route.ts` or `src/lib/auth.ts`

```typescript
// In signIn callback
await logActivity({
  userId: user.id,
  username: user.username,
  userRole: user.role,
  action: 'LOGIN',
  description: `User logged in: ${user.username} (${user.role})`,
  module: 'auth',
  status: 'success',
});
```

### 13. PPPoE Sync from MikroTik
**File:** `src/app/api/pppoe/users/sync-mikrotik/route.ts`

```typescript
await logActivity({
  userId: session.user.id,
  username: session.user.username,
  action: 'SYNC_MIKROTIK',
  description: `Synced ${syncedCount} PPPoE users from MikroTik`,
  module: 'pppoe',
  status: 'success',
  metadata: {
    routerId,
    syncedCount,
    addedCount,
    updatedCount,
  },
});
```

## Modules Reference

- **pppoe** - PPPoE user management
- **hotspot** - Hotspot profile/template management
- **voucher** - Voucher generation and management
- **invoice** - Invoice generation and management
- **payment** - Payment processing
- **agent** - Agent voucher generation and deposits
- **session** - Session monitoring and disconnection
- **transaction** - Keuangan (income/expense)
- **system** - System operations (RADIUS restart, etc)
- **network** - Network device management (routers, OLT, etc)
- **whatsapp** - WhatsApp notifications and broadcasts
- **genieacs** - GenieACS TR-069 management
- **settings** - System settings
- **user** - User management
- **auth** - Authentication (login/logout)

## Status Values

- **success** - Operation completed successfully
- **warning** - Operation completed with warnings
- **error** - Operation failed

## API Endpoints to Update

### Priority 1 (High Traffic)
- âœ… Dashboard stats (already updated)
- [ ] Hotspot voucher generation
- [ ] Agent voucher generation
- [ ] Agent deposit
- [ ] Payment webhook
- [ ] Session disconnect
- [ ] PPPoE user CRUD
- [ ] User login/logout

### Priority 2 (Medium Traffic)
- [ ] Invoice generation
- [ ] WhatsApp broadcast
- [ ] Transaction (keuangan) CRUD
- [ ] PPPoE sync MikroTik
- [ ] Network router CRUD
- [ ] System operations

### Priority 3 (Low Traffic)
- [ ] Settings changes
- [ ] User management
- [ ] GenieACS operations
- [ ] Network OLT/ODC/ODP CRUD

## Maintenance

### Clean Old Logs
Run periodically via cron job:

```typescript
import { cleanOldActivities } from '@/lib/activity-log';

// Keep last 30 days
await cleanOldActivities(30);
```

## Dashboard Display

Activity logs are automatically fetched and displayed in the dashboard:

```typescript
// In src/app/api/dashboard/stats/route.ts
import { getRecentActivities } from '@/lib/activity-log';

const activities = await getRecentActivities(10);
```

The dashboard will show:
- Username
- Action description
- Time (formatted in WIB)
- Status badge (success/warning/error)

## Testing

After implementing activity logs, test by:
1. Performing actions (generate voucher, create user, etc)
2. Check dashboard "Aktivitas Terbaru" section
3. Verify logs are appearing with correct info
4. Check different status types (success/warning/error)

## Notes

- Activity logging should NOT break the main flow if it fails
- All log calls are wrapped in try-catch internally
- IP address is automatically extracted from request headers
- Metadata field can store any JSON data for future analysis


## [11] PREPAID_POSTPAID_IMPLEMENTATION.md


# Implementasi Sistem Prepaid & Postpaid

Dokumentasi ini menjelaskan implementasi sistem billing prepaid dan postpaid di AIBILL-RADIUS.

## ðŸ“‹ Overview

Sistem billing kini mendukung 2 jenis subscription:
- **PREPAID**: Bayar dimuka sebelum masa aktif berakhir
- **POSTPAID**: Bayar dibelakang setelah menggunakan layanan

## ðŸ—„ï¸ Database Schema Changes

### Tabel `pppoe_users`
Ditambahkan field baru:

```sql
billingDay              INT DEFAULT 1           -- Tanggal tagihan (1-28) untuk POSTPAID
autoIsolationEnabled    BOOLEAN DEFAULT TRUE    -- Enable/disable auto-isolation
balance                 INT DEFAULT 0           -- Saldo deposit untuk PREPAID
autoRenewal             BOOLEAN DEFAULT FALSE   -- Auto perpanjangan dari saldo
connectionType          ENUM DEFAULT 'PPPOE'    -- Tipe koneksi: PPPOE/HOTSPOT/STATIC_IP
```

### Tabel `invoices`
Ditambahkan field baru:

```sql
invoiceType     ENUM    -- MONTHLY/INSTALLATION/ADDON/TOPUP/RENEWAL
baseAmount      INT     -- Jumlah sebelum pajak
taxRate         DECIMAL -- Persentase pajak
additionalFees  JSON    -- Array biaya tambahan
```

## ðŸ”„ Alur Proses

### 1. Registrasi & Approval

**Endpoint**: `/api/admin/registrations/[id]/approve`

#### POSTPAID Flow:
```
1. User baru dibuat dengan status='isolated'
2. expiredAt = null (tidak ada tanggal kadaluarsa)
3. Generate invoice INSTALLATION (hanya biaya pemasangan)
4. User tetap isolated sampai bayar
5. Setelah bayar â†’ status='active', expiredAt tetap null
```

#### PREPAID Flow:
```
1. User baru dibuat dengan status='isolated'
2. expiredAt = now + validity period
3. Generate invoice INSTALLATION (pemasangan + bulan pertama)
4. User tetap isolated sampai bayar
5. Setelah bayar â†’ status='active', expiredAt diperpanjang
```

### 2. Invoice Generation (Cron Job)

**Endpoint**: `/api/invoices/generate`
**Schedule**: Daily at 00:00 WIB

#### POSTPAID Invoice Generation:
```sql
-- Cari user POSTPAID dengan billingDay = hari ini
SELECT * FROM pppoe_users 
WHERE subscriptionType = 'POSTPAID'
  AND billingDay = DAY(CURDATE())
  AND status IN ('active', 'isolated', 'blocked', 'suspended')
  AND expiredAt IS NULL
```

**Logic**:
- Generate invoice setiap tanggal billing (billingDay)
- dueDate = billingDay + 7 hari (grace period)
- invoiceType = 'MONTHLY'
- Jika H+7 belum bayar â†’ auto isolate

**Contoh**:
- billingDay = 5
- Invoice generate: 5 Januari
- dueDate: 12 Januari
- Jika 13 Januari belum bayar â†’ auto isolate

#### PREPAID Invoice Generation:
```sql
-- Cari user PREPAID yang akan expired dalam 7-30 hari
SELECT * FROM pppoe_users 
WHERE subscriptionType = 'PREPAID'
  AND expiredAt BETWEEN DATE_ADD(CURDATE(), INTERVAL 7 DAY) 
                    AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
  AND status IN ('active', 'isolated', 'blocked', 'suspended')
```

**Logic**:
- Generate invoice H-7 sebelum expiredAt
- dueDate = expiredAt
- invoiceType = 'RENEWAL'
- Jika expiredAt lewat â†’ auto isolate immediately

**Contoh**:
- expiredAt = 15 Januari
- Invoice generate: 8 Januari (H-7)
- dueDate: 15 Januari
- Jika 16 Januari belum bayar â†’ auto isolate

### 3. Payment Processing

**Endpoint**: `/api/payment/webhook`

#### POSTPAID Payment:
```typescript
// Setelah bayar invoice:
1. Invoice status = 'PAID'
2. User status = 'active' (jika sebelumnya isolated)
3. expiredAt = null (tetap null, tidak ada expiry)
4. Generate invoice berikutnya di billingDay bulan depan
```

#### PREPAID Payment:
```typescript
// Setelah bayar invoice:
1. Invoice status = 'PAID'
2. User status = 'active' (jika sebelumnya isolated)
3. expiredAt = expiredAt + validity period
   - Jika sudah expired: expiredAt = now + validity
4. Generate invoice berikutnya H-7 sebelum expiredAt baru
```

### 4. Auto Isolation (Cron Job)

**Endpoint**: `/lib/cron/pppoe-sync.ts`
**Schedule**: Hourly

#### POSTPAID Isolation:
```typescript
// Isolate jika:
1. Ada invoice OVERDUE (lewat dueDate + grace period)
2. Status user = 'active'
3. expiredAt = null

// Action:
- Set status = 'isolated'
- Remove dari RADIUS (radcheck, radusergroup)
- Disconnect session via CoA
```

#### PREPAID Isolation:
```typescript
// Isolate jika:
1. expiredAt < now (masa aktif habis)
2. Status user = 'active'
3. subscriptionType = 'PREPAID'

// Action:
- Set status = 'isolated'
- Remove dari RADIUS (radcheck, radusergroup)
- Disconnect session via CoA
```

## ðŸ“Š Contoh Skenario

### Skenario 1: User Postpaid Baru
```
Timeline:
- 1 Jan: Daftar, pilih POSTPAID, billingDay=5
- 1 Jan: Admin approve â†’ invoice pemasangan Rp 100.000
- 2 Jan: Bayar pemasangan â†’ aktif
- 5 Jan: Auto generate invoice bulan pertama Rp 200.000, dueDate=12 Jan
- 10 Jan: Bayar â†’ lanjut aktif
- 5 Feb: Auto generate invoice bulan kedua, dueDate=12 Feb
- 13 Feb: Belum bayar â†’ auto isolate
- 14 Feb: Bayar â†’ aktif kembali
```

### Skenario 2: User Prepaid Baru
```
Timeline:
- 1 Jan: Daftar, pilih PREPAID
- 1 Jan: Admin approve â†’ invoice pemasangan+bulan pertama Rp 300.000
- 2 Jan: Bayar â†’ aktif, expiredAt = 2 Feb
- 26 Jan: Auto generate invoice perpanjangan (H-7), dueDate=2 Feb
- 1 Feb: Bayar â†’ expiredAt diperpanjang jadi 2 Mar
- 23 Feb: Auto generate invoice perpanjangan (H-7), dueDate=2 Mar
- 3 Mar: Belum bayar, expiredAt lewat â†’ auto isolate
- 4 Mar: Bayar â†’ aktif kembali, expiredAt = 4 Apr
```

## ðŸ”§ Configuration

### Set Billing Day (POSTPAID)
```typescript
// Saat edit user atau approval
await prisma.pppoeUser.update({
  where: { id: userId },
  data: {
    subscriptionType: 'POSTPAID',
    billingDay: 5, // Tagihan tanggal 5 setiap bulan
    expiredAt: null
  }
})
```

### Set Expiry Date (PREPAID)
```typescript
// Saat approval atau payment
const expiredAt = new Date();
expiredAt.setMonth(expiredAt.getMonth() + 1); // +1 bulan

await prisma.pppoeUser.update({
  where: { id: userId },
  data: {
    subscriptionType: 'PREPAID',
    expiredAt: expiredAt,
    billingDay: 1 // Default, tidak dipakai untuk prepaid
  }
})
```

## ðŸ§ª Testing Checklist

### POSTPAID Tests:
- [ ] Registrasi baru POSTPAID â†’ invoice hanya pemasangan
- [ ] Approval POSTPAID â†’ expiredAt = null
- [ ] Bayar invoice POSTPAID â†’ status active, expiredAt tetap null
- [ ] Generate invoice di billingDay
- [ ] Isolate user POSTPAID jika invoice overdue
- [ ] Reactivate user POSTPAID setelah bayar invoice overdue

### PREPAID Tests:
- [ ] Registrasi baru PREPAID â†’ invoice pemasangan + bulan pertama
- [ ] Approval PREPAID â†’ expiredAt = now + validity
- [ ] Bayar invoice PREPAID â†’ status active, expiredAt diperpanjang
- [ ] Generate invoice H-7 sebelum expiredAt
- [ ] Isolate user PREPAID jika expiredAt lewat
- [ ] Reactivate user PREPAID â†’ expiredAt = now + validity

### Edge Cases:
- [ ] User POSTPAID dengan billingDay > 28 (gunakan 28)
- [ ] User PREPAID expired > 7 hari (jangan generate invoice duplikat)
- [ ] User ganti POSTPAID â†’ PREPAID
- [ ] User ganti PREPAID â†’ POSTPAID
- [ ] Invoice manual (admin create)

## ðŸ“ˆ Monitoring Queries

### Check POSTPAID Users Due for Invoice:
```sql
SELECT username, name, billingDay, status, expiredAt
FROM pppoe_users
WHERE subscriptionType = 'POSTPAID'
  AND billingDay = DAY(CURDATE())
  AND status IN ('active', 'isolated', 'blocked', 'suspended');
```

### Check PREPAID Users Expiring Soon:
```sql
SELECT username, name, expiredAt, status
FROM pppoe_users
WHERE subscriptionType = 'PREPAID'
  AND expiredAt BETWEEN DATE_ADD(CURDATE(), INTERVAL 7 DAY) 
                    AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)
  AND status IN ('active', 'isolated', 'blocked', 'suspended');
```

### Check Overdue Invoices:
```sql
SELECT i.invoiceNumber, u.username, u.subscriptionType, 
       i.amount, i.dueDate, i.status
FROM invoices i
JOIN pppoe_users u ON i.userId = u.id
WHERE i.status IN ('PENDING', 'OVERDUE')
  AND i.dueDate < CURDATE()
ORDER BY i.dueDate ASC;
```

## ðŸ› Bug Fixes Applied

### BUG-01: Prepaid/Postpaid Logic Not Implemented
**Status**: âœ… FIXED
- Added conditional logic in approval route
- Different invoice amounts for PREPAID vs POSTPAID
- Different expiredAt handling

### BUG-04: Invoice Generation Doesn't Respect Subscription Type
**Status**: âœ… FIXED
- Split query into PREPAID and POSTPAID
- Different due date calculation
- Different invoice type (MONTHLY vs RENEWAL)

### BUG-05: Wrong Expiry Calculation
**Status**: âœ… FIXED
- POSTPAID: expiredAt = null
- PREPAID: expiredAt = date based on validity
- Payment webhook handles both types correctly

### BUG-03: No billingDay Field
**Status**: âœ… FIXED
- Added billingDay field to schema
- Used in POSTPAID invoice generation
- Default value = 1

### BUG-06: No Balance Field
**Status**: âœ… FIXED (Schema Only)
- Added balance field for future deposit system
- TODO: Implement top-up and auto-deduct logic

### BUG-07: Auto-renewal Not Implemented
**Status**: âœ… FIXED (Schema Only)
- Added autoRenewal field
- TODO: Implement auto-payment from balance

## ðŸš€ Next Steps

1. **Balance & Top-up System**
   - Create `/api/topup` endpoint
   - Auto-deduct from balance on invoice due
   - Balance notification when low

2. **Auto-renewal Logic**
   - Check balance before expiry
   - Auto-pay invoice if balance sufficient
   - Send notification if balance insufficient

3. **Grace Period Configuration**
   - Make grace period configurable per user/profile
   - Different grace periods for PREPAID vs POSTPAID

4. **Flexible Billing Dates**
   - Allow billingDay > 28 (use last day of month)
   - Handle February (28/29 days)

5. **Invoice Templates**
   - Different templates for MONTHLY vs RENEWAL
   - Include breakdown (base + tax + fees)

6. **Email Notifications**
   - Invoice generated email
   - Payment reminder emails (H-3, H-1)
   - Overdue notification

## ðŸ“ Migration Notes

### From Old System:
```sql
-- Users created before this update have subscriptionType = NULL
-- Set default based on expiredAt:
UPDATE pppoe_users 
SET subscriptionType = CASE 
  WHEN expiredAt IS NULL THEN 'POSTPAID'
  ELSE 'PREPAID'
END
WHERE subscriptionType IS NULL;

-- Set default billingDay = 1 for all POSTPAID users
UPDATE pppoe_users 
SET billingDay = 1
WHERE subscriptionType = 'POSTPAID' AND billingDay IS NULL;
```

### Rollback Plan:
```sql
-- If needed to rollback schema changes:
ALTER TABLE pppoe_users 
  DROP COLUMN billingDay,
  DROP COLUMN autoIsolationEnabled,
  DROP COLUMN balance,
  DROP COLUMN autoRenewal,
  DROP COLUMN connectionType;

ALTER TABLE invoices 
  DROP COLUMN invoiceType,
  DROP COLUMN baseAmount,
  DROP COLUMN taxRate,
  DROP COLUMN additionalFees;

DROP TYPE IF EXISTS InvoiceType;
DROP TYPE IF EXISTS ConnectionType;
```

## ðŸ”— Related Files

- Schema: `prisma/schema.prisma`
- Migration: `prisma/migrations/20251223_add_billing_fields.sql`
- Approval: `src/app/api/admin/registrations/[id]/approve/route.ts`
- Payment: `src/app/api/payment/webhook/route.ts`
- Invoice Gen: `src/app/api/invoices/generate/route.ts`
- Cron: `src/lib/cron/voucher-sync.ts`
- Roadmap: `ROADMAP_BILLING_FIX.md`

---

**Version**: 1.0  
**Date**: 2025-12-23  
**Author**: AIBILL Development Team  
**Status**: âœ… Implemented (Core Features)


## [12] MANUAL_PAYMENT_AND_NOTIFICATION_SYSTEM.md


# Manual Payment & Notification System

Sistem ini menangani alur pembayaran manual di mana customer melakukan upload bukti pembayaran dan admin melakukan review.

## Overview

Alur lengkap:
1. Customer memilih invoice yang ingin dibayar
2. Customer memilih metode pembayaran "Manual"
3. Customer upload bukti transfer
4. Admin menerima notifikasi (WhatsApp & Email)
5. Admin review bukti pembayaran
6. Admin approve atau reject
7. Customer menerima notifikasi hasil review

## Features

### 1. Customer Side

#### a. Payment Page
- **URL**: `/payment/{invoiceNumber}`
- Customer dapat melihat detail invoice
- Pilihan metode pembayaran:
  - Payment Gateway (Midtrans/Xendit/etc)
  - Manual Payment

#### b. Manual Payment Form
- Upload bukti transfer (image)
- Nama pengirim
- Bank pengirim
- Nomor rekening pengirim
- Catatan (optional)
- Preview image sebelum submit

#### c. Thank You Page
- Konfirmasi bukti sudah diupload
- Informasi bahwa pembayaran sedang direview
- Estimasi waktu review

### 2. Admin Side

#### a. Review Page
- **URL**: `/admin/payments/review`
- Table semua pembayaran dengan status MANUAL_REVIEW
- Detail:
  - Customer info
  - Invoice info
  - Bukti transfer (full size preview)
  - Bank pengirim dan nama
- Actions:
  - Approve: Update status ke PAID, extend user expiry
  - Reject: Update status ke REJECTED, tambah catatan alasan

#### b. Notification to Admin
Ketika customer upload bukti:
- **WhatsApp**: Kirim ke admin dengan detail pembayaran
- **Email**: Kirim ke admin dengan attachment bukti

### 3. Notification System

#### a. Admin Notification (New Manual Payment)
**Trigger**: Saat customer upload bukti pembayaran

**WhatsApp Template**:
```
ðŸ”” *NOTIFIKASI PEMBAYARAN MANUAL*

ðŸ“‹ *Detail Pembayaran*
â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”
ðŸ“Œ Invoice: {{invoiceNumber}}
ðŸ‘¤ Pelanggan: {{customerName}}
ðŸ†” ID: {{customerId}}
ðŸ’° Jumlah: {{amount}}

ðŸ¦ *Info Transfer*
â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”
Bank: {{senderBank}}
Nama: {{senderName}}
No. Rek: {{senderAccount}}

ðŸ“ Catatan: {{notes}}

â° Waktu: {{uploadTime}}

ðŸ”— Review: {{reviewLink}}

âš ï¸ Silakan cek dan verifikasi pembayaran ini.
```

**Email Template**:
- Subject: "[REVIEW NEEDED] Pembayaran Manual - {invoiceNumber}"
- Body: Detail pembayaran dengan attachment bukti

#### b. Customer Notification (Payment Approved)
**Trigger**: Saat admin approve pembayaran

**WhatsApp Template**:
```
âœ… *PEMBAYARAN DIKONFIRMASI*

Halo {{customerName}},

Terima kasih! Pembayaran Anda telah kami konfirmasi.

ðŸ“‹ *Detail*
â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”
ðŸ“Œ Invoice: {{invoiceNumber}}
ðŸ’° Jumlah: {{amount}}
âœ… Status: LUNAS
ðŸ“… Aktif hingga: {{newExpiry}}

Layanan Anda telah diperpanjang.

Terima kasih telah menjadi pelanggan setia kami! ðŸ™

{{companyName}}
```

#### c. Customer Notification (Payment Rejected)
**Trigger**: Saat admin reject pembayaran

**WhatsApp Template**:
```
âŒ *PEMBAYARAN DITOLAK*

Halo {{customerName}},

Mohon maaf, pembayaran Anda tidak dapat kami proses.

ðŸ“‹ *Detail*
â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”
ðŸ“Œ Invoice: {{invoiceNumber}}
ðŸ’° Jumlah: {{amount}}
âŒ Status: Ditolak
ðŸ“ Alasan: {{rejectionReason}}

Silakan lakukan pembayaran ulang atau hubungi kami jika ada pertanyaan.

{{companyName}}
ðŸ“ž {{companyPhone}}
```

## API Endpoints

### 1. Upload Manual Payment
**Endpoint**: `POST /api/payment/manual`

**Request**:
```json
{
  "invoiceId": 123,
  "proofImage": "base64_image_data",
  "senderName": "John Doe",
  "senderBank": "BCA",
  "senderAccount": "1234567890",
  "notes": "Transfer dari rekening istri"
}
```

**Response**:
```json
{
  "success": true,
  "message": "Bukti pembayaran berhasil diupload",
  "paymentId": 456
}
```

### 2. Get Manual Payments for Review
**Endpoint**: `GET /api/admin/payments/manual`

**Response**:
```json
{
  "payments": [
    {
      "id": 456,
      "invoiceId": 123,
      "invoiceNumber": "INV-2024-0001",
      "amount": 150000,
      "customerName": "John Doe",
      "customerId": "CUST001",
      "proofImageUrl": "/uploads/proofs/xxx.jpg",
      "senderName": "John Doe",
      "senderBank": "BCA",
      "senderAccount": "1234567890",
      "notes": "Transfer dari rekening istri",
      "uploadedAt": "2024-01-15T10:30:00Z",
      "status": "MANUAL_REVIEW"
    }
  ]
}
```

### 3. Approve Manual Payment
**Endpoint**: `POST /api/admin/payments/manual/{id}/approve`

**Request**:
```json
{
  "notes": "Pembayaran sesuai"
}
```

**Response**:
```json
{
  "success": true,
  "message": "Pembayaran berhasil dikonfirmasi",
  "newExpiry": "2024-02-15"
}
```

### 4. Reject Manual Payment
**Endpoint**: `POST /api/admin/payments/manual/{id}/reject`

**Request**:
```json
{
  "reason": "Bukti tidak jelas, nominal tidak sesuai"
}
```

**Response**:
```json
{
  "success": true,
  "message": "Pembayaran ditolak"
}
```

## Database Schema

### ManualPayment Table
```sql
CREATE TABLE manual_payments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  invoice_id INT NOT NULL,
  proof_image_url VARCHAR(255) NOT NULL,
  sender_name VARCHAR(100) NOT NULL,
  sender_bank VARCHAR(50) NOT NULL,
  sender_account VARCHAR(50) NOT NULL,
  notes TEXT,
  status ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING',
  rejection_reason TEXT,
  reviewed_by INT,
  reviewed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (invoice_id) REFERENCES invoices(id),
  FOREIGN KEY (reviewed_by) REFERENCES users(id)
);
```

## Template Variables

### Admin Notification Template
| Variable | Description |
|----------|-------------|
| `{{invoiceNumber}}` | Nomor invoice |
| `{{customerName}}` | Nama pelanggan |
| `{{customerId}}` | ID pelanggan |
| `{{amount}}` | Jumlah pembayaran (formatted) |
| `{{senderBank}}` | Bank pengirim |
| `{{senderName}}` | Nama pengirim |
| `{{senderAccount}}` | Nomor rekening pengirim |
| `{{notes}}` | Catatan dari customer |
| `{{uploadTime}}` | Waktu upload bukti |
| `{{reviewLink}}` | Link ke halaman review |

### Customer Approved Template
| Variable | Description |
|----------|-------------|
| `{{customerName}}` | Nama pelanggan |
| `{{invoiceNumber}}` | Nomor invoice |
| `{{amount}}` | Jumlah pembayaran (formatted) |
| `{{newExpiry}}` | Tanggal expired baru |
| `{{companyName}}` | Nama perusahaan |

### Customer Rejected Template
| Variable | Description |
|----------|-------------|
| `{{customerName}}` | Nama pelanggan |
| `{{invoiceNumber}}` | Nomor invoice |
| `{{amount}}` | Jumlah pembayaran (formatted) |
| `{{rejectionReason}}` | Alasan penolakan |
| `{{companyName}}` | Nama perusahaan |
| `{{companyPhone}}` | Nomor telepon perusahaan |

## Implementation Notes

### 1. Image Upload
- Format: JPEG, PNG
- Max size: 5MB
- Storage: Local `/public/uploads/proofs/` atau S3
- Generate unique filename

### 2. Notification Priority
- WhatsApp dikirim terlebih dahulu
- Email sebagai backup/record

### 3. Security
- Validate image before save
- Admin-only access untuk review page
- Rate limiting untuk upload

### 4. Mobile Responsiveness
- Upload form mobile-friendly
- Review page responsive

## Testing Checklist

- [ ] Customer dapat upload bukti dengan berbagai format image
- [ ] Admin menerima WhatsApp notifikasi
- [ ] Admin menerima Email notifikasi
- [ ] Admin dapat approve pembayaran
- [ ] Customer menerima notifikasi approved
- [ ] User expiry terupdate setelah approved
- [ ] Admin dapat reject dengan alasan
- [ ] Customer menerima notifikasi rejected


## [13] INVOICE_NUMBER_FORMAT.md


# Format Invoice Number Berdasarkan Tanggal

## Perubahan
Invoice number sekarang menggunakan format berdasarkan tanggal, bukan random code lagi.

## Format Baru

### Invoice Number
**Format:** `INV-YYYYMM-XXXX`
**Contoh:** `INV-202512-0001`, `INV-202512-0002`, dll.

- `YYYY` = Tahun (4 digit)
- `MM` = Bulan (2 digit dengan leading zero)
- `XXXX` = Counter sequential per bulan (4 digit dengan leading zero)

### Transaction ID
**Format:** `TRX-YYYYMMDD-HHMMSS-XXXX`
**Contoh:** `TRX-20251219-153045-1234`

- `YYYYMMDD` = Tanggal lengkap
- `HHMMSS` = Waktu lengkap
- `XXXX` = Random 4 digit untuk uniqueness

### Category ID
**Format:** `CAT-YYYYMMDD-HHMMSS`
**Contoh:** `CAT-20251219-153045`

### Invoice ID (Database)
**Format:** `inv-YYYYMMDD-HHMMSS-XXXX`
**Contoh:** `inv-20251219-153045-1234`

## File yang Diupdate

1. **src/lib/invoice-generator.ts** (BARU)
   - `generateInvoiceNumber()` - Generate invoice number dengan format INV-YYYYMM-XXXX
   - `generateTransactionId()` - Generate transaction ID dengan timestamp
   - `generateCategoryId()` - Generate category ID dengan timestamp
   - `generateInvoiceId()` - Generate invoice database ID dengan timestamp

2. **src/app/api/pppoe/users/[id]/extend/route.ts**
   - Update dari: `INV-${Date.now()}-${random}` 
   - Ke: `INV-202512-0001` (dengan counter per bulan)
   
3. **src/app/api/pppoe/users/[id]/mark-paid/route.ts**
   - Update transaction ID dan category ID ke format berdasarkan tanggal
   
4. **src/app/api/manual-payments/[id]/route.ts**
   - Update payment ID ke format berdasarkan tanggal

## Auto-generate Invoice
File **src/app/api/invoices/generate/route.ts** sudah menggunakan format yang benar sejak awal, tidak perlu diubah.

## Testing

### 1. Test Perpanjangan Manual (Extend)
```
1. Login ke admin panel
2. Ke menu PPPoE Users
3. Pilih user, klik "Perpanjang"
4. Cek invoice number di notifikasi WhatsApp/Email
5. Expected: INV-202512-0001, INV-202512-0002, dst.
```

### 2. Test Manual Payment
```
1. User upload bukti pembayaran manual
2. Admin approve payment
3. Cek invoice number di notifikasi
4. Expected: Format INV-202512-XXXX
```

### 3. Test Auto Generate Invoice
```
1. Tunggu cron job atau test manual di /api/cron/test-reminder
2. Cek invoice yang di-generate
3. Expected: Sequential per bulan (INV-202512-0001, 0002, dst.)
```

### 4. Test Counter Reset di Bulan Baru
```
1. Tunggu sampai bulan berikutnya (Januari 2026)
2. Generate invoice baru
3. Expected: INV-202601-0001 (counter reset ke 0001)
```

## Database Query Testing

### Cek Invoice Number Format
```sql
SELECT invoiceNumber, createdAt 
FROM invoice 
ORDER BY createdAt DESC 
LIMIT 10;
```

### Cek Invoice per Bulan
```sql
SELECT 
  DATE_FORMAT(createdAt, '%Y-%m') as bulan,
  COUNT(*) as jumlah_invoice,
  MIN(invoiceNumber) as invoice_pertama,
  MAX(invoiceNumber) as invoice_terakhir
FROM invoice 
WHERE invoiceNumber LIKE 'INV-%'
GROUP BY DATE_FORMAT(createdAt, '%Y-%m')
ORDER BY bulan DESC;
```

### Cek Transaction ID Format
```sql
SELECT id, description, createdAt 
FROM transaction 
WHERE id LIKE 'TRX-%' 
ORDER BY createdAt DESC 
LIMIT 10;
```

## Keuntungan Format Baru

1. **Mudah Dibaca**: Invoice number langsung terlihat bulan pembuatannya
2. **Sequential**: Counter berurutan per bulan, mudah tracking
3. **Konsisten**: Semua API menggunakan format yang sama
4. **Tidak Duplikat**: Counter otomatis increment dari database
5. **Professional**: Format standar invoice bisnis (INV-YYYYMM-XXXX)

## Backward Compatibility

- Invoice lama dengan format `INV-1766139060741-4rf3z6r0j` tetap valid di database
- Tidak ada perubahan pada invoice yang sudah ada
- Hanya invoice baru yang akan menggunakan format tanggal

## Deployment ke VPS

```bash
# 1. Pull latest changes
git pull origin main

# 2. Build
npm run build

# 3. Restart PM2
pm2 restart aibill-radius

# 4. Test perpanjangan manual untuk verifikasi format baru
```

## Troubleshooting

### Invoice Number Duplikat
Jika terjadi duplikat (sangat jarang karena menggunakan database count):
- Fungsi `generateInvoiceNumber()` akan otomatis increment
- Database akan reject jika ada duplikat (invoiceNumber adalah unique)

### Counter Tidak Sequential
Jika ada gap dalam numbering (misal: 0001, 0003, 0005):
- Ini normal jika ada invoice yang di-delete atau failed transaction
- Counter tetap naik berdasarkan COUNT() dari database

### Format Lama Masih Muncul
- Clear cache: `npm run build`
- Restart PM2: `pm2 restart aibill-radius`
- Cek import statement di file API route


## [14] AGENT_DEPOSIT_SYSTEM.md


# Agent Deposit System Implementation Guide

## Overview
Sistem deposit/saldo untuk agent dengan integrasi payment gateway (Midtrans, Xendit, Duitku).

## Database Schema Changes

### 1. Update `agent` table
```sql
ALTER TABLE agents 
ADD COLUMN balance INT DEFAULT 0,
ADD COLUMN minBalance INT DEFAULT 0;
```

### 2. Create `agent_deposits` table
```sql
CREATE TABLE agent_deposits (
  id VARCHAR(191) PRIMARY KEY,
  agentId VARCHAR(191) NOT NULL,
  amount INT NOT NULL,
  status VARCHAR(191) DEFAULT 'PENDING', -- PENDING, PAID, EXPIRED, FAILED
  paymentGateway VARCHAR(191),           -- midtrans, xendit, duitku  
  paymentToken VARCHAR(191) UNIQUE,
  paymentUrl TEXT,
  transactionId VARCHAR(191),
  paidAt DATETIME,
  expiredAt DATETIME,
  createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
  updatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (agentId) REFERENCES agents(id) ON DELETE CASCADE,
  INDEX idx_agentId (agentId),
  INDEX idx_status (status),
  INDEX idx_paymentToken (paymentToken)
);
```

### 3. Update `agent_sales` table
```sql
ALTER TABLE agent_sales 
ADD COLUMN paymentStatus VARCHAR(191) DEFAULT 'UNPAID',
ADD COLUMN paymentDate DATETIME,
ADD COLUMN paymentMethod VARCHAR(191),
ADD COLUMN paymentNote TEXT,
ADD COLUMN paidAmount INT DEFAULT 0,
ADD INDEX idx_paymentStatus (paymentStatus);
```

## Push Schema to Database
```bash
cd /var/www/salfanet-radius
npx prisma db push --accept-data-loss
npx prisma generate
```

## API Endpoints

### 1. Create Deposit (Agent)
```
POST /api/agent/deposit/create
Body: {
  agentId: string,
  amount: number,    // min 10000
  gateway: string    // midtrans, xendit, duitku
}
Response: {
  success: true,
  deposit: {
    id: string,
    token: string,
    amount: number,
    paymentUrl: string,
    expiredAt: datetime
  }
}
```

### 2. Deposit Webhook (Payment Gateway)
```
POST /api/agent/deposit/webhook
Body: (varies by gateway)
- Midtrans: { order_id, transaction_status, transaction_id }
- Xendit: { external_id, status, id }
- Duitku: { merchantOrderId, resultCode, reference }

Action: Updates deposit status and agent balance
```

### 3. Generate Voucher (Updated)
```
POST /api/agent/generate-voucher
Body: {
  agentId: string,
  profileId: string,
  quantity: number
}

New Logic:
1. Calculate totalCost = profile.costPrice * quantity
2. Check agent.balance >= totalCost
3. Check agent.balance - totalCost >= agent.minBalance
4. Generate vouchers
5. Deduct balance: agent.balance -= totalCost
6. Return new balance

Response: {
  success: true,
  vouchers: [...],
  cost: number,
  newBalance: number,
  message: string
}
```

### 4. Agent Dashboard (Updated)
```
GET /api/agent/dashboard?agentId=xxx

Response includes:
{
  stats: { ... },
  profiles: [...],
  vouchers: [...],
  balance: number,        // NEW
  minBalance: number,     // NEW
  deposits: [             // NEW
    {
      id: string,
      amount: number,
      status: string,
      paymentUrl: string,
      createdAt: datetime
    }
  ]
}
```

## Workflow

### Agent Deposit Flow
```
1. Agent login to /agent/dashboard
2. Click "Top Up" button
3. Enter amount (min Rp 10.000)
4. Select payment gateway (Midtrans/Xendit/Duitku)
5. Click "Create Payment"
6. System creates deposit record (status: PENDING)
7. System generates payment URL via gateway API
8. Agent redirected to payment page
9. Agent completes payment
10. Gateway sends webhook to /api/agent/deposit/webhook
11. System updates:
    - deposit.status = 'PAID'
    - deposit.paidAt = now()
    - agent.balance += deposit.amount
12. Agent sees updated balance in dashboard
```

### Generate Voucher Flow
```
1. Agent selects profile
2. Enter quantity
3. System checks:
   - cost = profile.costPrice * quantity
   - agent.balance >= cost ?
   - agent.balance - cost >= minBalance ?
4. If OK:
   - Generate vouchers
   - agent.balance -= cost
   - Return success + new balance
5. If NOT OK:
   - Return error: "Insufficient balance, please top up"
```

### Sales Commission Flow
```
1. Customer uses voucher (status: WAITING â†’ ACTIVE)
2. Cron job (every 5 min) detects ACTIVE vouchers
3. System creates agent_sale record:
   - amount = profile.resellerFee (agent profit)
   - paymentStatus = 'UNPAID' (agent owes admin)
4. Admin sees unpaid sales in /admin/hotspot/agent
5. Agent pays admin (cash/transfer)
6. Admin marks sale as PAID
```

## Admin Features

### Agent Management (/admin/hotspot/agent)
Add columns:
- Balance (current saldo)
- Min Balance (minimum required)
- Actions: "Adjust Balance" button

### Adjust Balance Dialog
```
- Agent: [name]
- Current Balance: Rp xxx
- Adjustment Type: [Add / Deduct / Set]
- Amount: [input]
- Note: [textarea]
- [Save Button]
```

### Sales Payment Tracking
Add filter:
- Payment Status: [All / UNPAID / PAID]

Add bulk action:
- Mark Selected as PAID

## Configuration

### Set Minimum Balance (per agent)
```
Admin can set minBalance for each agent:
- 0 = no minimum
- 50000 = agent must keep at least Rp 50k balance
```

### Payment Gateway Setup
Agent deposits use the same payment gateway config as invoices:
- /admin/payment-gateway
- Configure Midtrans/Xendit/Duitku
- Webhook URL: https://yourdomain.com/api/agent/deposit/webhook

## Testing

### 1. Test Deposit
```bash
curl -X POST http://localhost:3000/api/agent/deposit/create \
  -H "Content-Type: application/json" \
  -d '{"agentId":"xxx","amount":100000,"gateway":"midtrans"}'
```

### 2. Test Generate with Balance Check
```bash
# Should fail if balance < cost
curl -X POST http://localhost:3000/api/agent/generate-voucher \
  -H "Content-Type: application/json" \
  -d '{"agentId":"xxx","profileId":"yyy","quantity":10}'
```

### 3. Test Webhook (Simulated)
```bash
curl -X POST http://localhost:3000/api/agent/deposit/webhook \
  -H "Content-Type: application/json" \
  -d '{
    "order_id":"deposit-id",
    "transaction_status":"settlement",
    "transaction_id":"TRX-xxx"
  }'
```

## Security Notes

1. **Webhook Security**: Add signature validation for production
2. **Balance Validation**: Always check balance before deducting
3. **Transaction Atomicity**: Use Prisma transactions for balance updates
4. **Minimum Balance**: Prevent agent from going below minBalance

## Files Created/Modified

### New Files
- `/src/app/api/agent/deposit/create/route.ts`
- `/src/app/api/agent/deposit/webhook/route.ts`
- `/docs/AGENT_DEPOSIT_SYSTEM.md` (this file)

### Modified Files
- `/prisma/schema.prisma` - Added balance fields and agentDeposit model
- `/src/app/api/agent/generate-voucher/route.ts` - Added balance check and deduction
- `/src/app/api/agent/dashboard/route.ts` - Added balance and deposits data (TODO)
- `/src/app/agent/dashboard/page.tsx` - Added deposit UI (TODO)
- `/src/app/admin/hotspot/agent/page.tsx` - Added balance management (TODO)

## Next Steps

1. Push schema to database: `npx prisma db push`
2. Update agent dashboard to show balance and deposit form
3. Update admin agent page to manage balance
4. Test deposit flow with sandbox payment gateway
5. Configure webhook URLs in payment gateway dashboards
6. Document for end users

## Support

For issues or questions:
- Check logs: `/var/www/salfanet-radius/logs/`
- Check deposit status in database
- Verify webhook is receiving callbacks
- Test payment gateway credentials


## [15] CUSTOMER_PAYMENT_SELF_SERVICE.md


# Customer Self-Service Payment & Package Upgrade

## Overview
Sistem self-service untuk customer yang memungkinkan pembayaran tagihan dan upgrade paket langsung dari dashboard customer tanpa perlu menghubungi admin.

## Fitur yang Ditambahkan

### 1. **Payment Gateway Integration**
- Generate payment link otomatis untuk invoice yang belum dibayar
- Support untuk multiple payment gateway:
  - **Midtrans** (Sandbox & Production)
  - **Xendit** (Invoice API)
- Auto-redirect ke payment page
- Payment link disimpan di database untuk digunakan ulang

### 2. **Invoice Payment Button**
Customer dashboard menampilkan tombol pembayaran:
- **"Bayar Sekarang"** - Jika payment link sudah ada
- **"Generate Link Pembayaran"** - Jika payment link belum ada
- Button disabled saat generating payment link (loading state)
- Auto-open payment link di tab baru

### 3. **Package Upgrade Self-Service**
- Tombol **"Ganti Paket"** di customer dashboard
- Redirect ke `/customer/wifi?tab=upgrade` untuk memilih paket baru
- Flow lengkap:
  1. Pilih paket baru
  2. System create invoice otomatis
  3. Generate payment link
  4. Customer bayar via payment gateway
  5. Auto-upgrade setelah pembayaran confirmed

### 4. **PPPoE Connection Status**
Dashboard customer sekarang menampilkan:
- **Status ONT**: Online/Offline
- **Status PPPoE**: Connected/Disconnected
- **IP PPPoE**: IP address dari PPPoE session
- **RX Power**: Signal strength
- **Temperature**: ONT temperature
- **Uptime**: Device uptime
- **Connected Devices**: Jumlah device terhubung

## API Endpoints

### `/api/customer/invoices/payment`
**Method**: `GET`

**Query Parameters**:
- `invoiceId` - Invoice ID yang akan dibayar

**Response**:
```json
{
  "success": true,
  "paymentLink": "https://app.midtrans.com/snap/v2/...",
  "invoice": {
    "id": "inv_xxx",
    "invoiceNumber": "INV-2025-001",
    "amount": 300000,
    "dueDate": "2025-01-15"
  }
}
```

**Error Responses**:
- `401 Unauthorized` - Token tidak valid
- `400 Bad Request` - Invoice ID tidak diberikan
- `404 Not Found` - Invoice tidak ditemukan atau sudah dibayar
- `503 Service Unavailable` - Payment gateway tidak dikonfigurasi
- `500 Internal Server Error` - Gagal generate payment link

## Payment Gateway Configuration

### Midtrans Setup
1. Login ke Midtrans Dashboard
2. Dapatkan **Server Key** dari Settings â†’ Access Keys
3. Masukkan ke Admin Panel â†’ Settings â†’ Payment Gateway
4. Pilih environment (Sandbox/Production)

### Xendit Setup
1. Login ke Xendit Dashboard
2. Dapatkan **API Key** dari Settings â†’ Developers â†’ API Keys
3. Masukkan ke Admin Panel â†’ Settings â†’ Payment Gateway
4. Set callback URL untuk payment notification

## Database Schema Updates

### Invoice Table
```prisma
model Invoice {
  id            String   @id @default(uuid())
  invoiceNumber String   @unique
  userId        String
  amount        Float
  status        String   // PAID, UNPAID
  dueDate       DateTime
  paidAt        DateTime?
  paymentLink   String?  // NEW: Store payment link
  description   String?
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  
  user          PppoeUser @relation(fields: [userId], references: [id])
}
```

### PaymentGatewaySetting Table
```prisma
model PaymentGatewaySetting {
  id            String   @id @default(uuid())
  gatewayName   String   // MIDTRANS, XENDIT
  apiKey        String
  serverKey     String?  // For Midtrans
  isSandbox     Boolean  @default(false)
  isActive      Boolean  @default(true)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
}
```

## Customer Dashboard Features

### 1. Informasi Akun
- Nama, No HP, Username
- Paket aktif dengan bandwidth
- Status akun (Aktif/Expired)
- Tanggal expired dengan countdown hari

### 2. ONT/WiFi Information
- Model ONT (Manufacturer + Model)
- Status ONT (Online/Offline)
- **PPPoE Connection Status** (Connected/Disconnected)
- IP Address PPPoE
- RX Power (Signal strength)
- Temperature ONT
- Device uptime
- Jumlah device terhubung
- WiFi SSID dan status

### 3. Tagihan (Invoices)
- List semua invoice (Lunas/Belum Bayar/Terlambat)
- Invoice number dan due date
- Amount dalam Rupiah
- Status badge dengan warna:
  - **Hijau**: Lunas
  - **Kuning**: Belum Bayar
  - **Merah**: Terlambat
- Tombol pembayaran:
  - **Bayar Sekarang**: Jika payment link ada
  - **Generate Link Pembayaran**: Jika belum ada payment link

### 4. Package Upgrade Button
- Tombol "Ganti Paket" di dashboard
- Redirect ke halaman WiFi management tab upgrade
- Proses upgrade lengkap dengan payment integration

## User Flow

### Payment Flow
1. Customer login ke dashboard
2. Lihat invoice yang belum dibayar
3. Klik "Generate Link Pembayaran" (jika belum ada link)
4. System call API `/api/customer/invoices/payment`
5. API create transaction di payment gateway
6. Payment link disimpan ke database
7. Link otomatis terbuka di tab baru
8. Customer bayar via payment gateway
9. Payment gateway kirim callback ke system
10. System update invoice status menjadi PAID
11. Auto-extend expiry date customer

### Package Upgrade Flow
1. Customer klik tombol "Ganti Paket"
2. Redirect ke halaman WiFi management
3. Tab "Upgrade Paket" menampilkan list paket available
4. Customer pilih paket baru
5. System create invoice baru dengan amount = harga paket
6. Auto-generate payment link
7. Redirect ke payment page
8. Setelah bayar, package otomatis ter-upgrade

## Error Handling

### Payment Generation Errors
- **No Payment Gateway**: Tampilkan pesan "Payment gateway belum dikonfigurasi"
- **Invalid Invoice**: Tampilkan "Invoice tidak ditemukan atau sudah dibayar"
- **Gateway Error**: Tampilkan "Gagal generate payment link, coba lagi"
- **Network Error**: Tampilkan "Koneksi gagal, periksa internet Anda"

### PPPoE Status Check
- Jika `pppUsername` kosong â†’ Status: Disconnected
- Jika `pppUsername` ada â†’ Status: Connected
- Menggunakan VirtualParameters dari GenieACS

## Security Features

### Token Verification
- Semua API menggunakan CustomerSession authentication
- Token expiry check setiap request
- Auto-logout jika token expired

### Invoice Ownership
- Verify invoice belongs to logged-in customer
- Prevent payment for other customer's invoice
- Check invoice status before generating payment link

### Payment Gateway Security
- Use server-side API calls only
- Never expose API keys to client
- Validate payment callback signature
- Store payment link securely in database

## Testing Checklist

### Dashboard Display
- [ ] PPPoE status shows correctly (Connected/Disconnected)
- [ ] ONT information displays with VirtualParameters data
- [ ] Invoice list shows all invoices with correct status
- [ ] "Ganti Paket" button redirects to upgrade page
- [ ] Payment buttons appear only for unpaid invoices

### Payment Link Generation
- [ ] Generate button shows loading state
- [ ] Payment link opens in new tab
- [ ] Invoice updates with payment link after generation
- [ ] "Bayar Sekarang" button appears after link generated
- [ ] Error messages shown for failed generation

### Package Upgrade
- [ ] Redirect to WiFi page with upgrade tab
- [ ] Available packages displayed correctly
- [ ] Invoice created after package selection
- [ ] Payment link generated automatically
- [ ] Package upgraded after payment confirmed

## Troubleshooting

### Payment Link Not Generated
1. Check payment gateway settings in admin panel
2. Verify API keys and server keys are correct
3. Check payment gateway sandbox/production mode
4. Review server logs for API errors
5. Test payment gateway API manually

### PPPoE Status Not Showing
1. Verify GenieACS connection
2. Check if device has VirtualParameters configured
3. Verify pppUsername virtual parameter exists
4. Check device last inform time
5. Review ONT API response structure

### Package Upgrade Failed
1. Check if invoice was created successfully
2. Verify payment link generation
3. Check payment callback configuration
4. Review package upgrade API logs
5. Verify customer profile update logic

## Next Steps

1. **Auto-Payment Callback**
   - Implement webhook endpoint for payment notifications
   - Auto-update invoice status when payment confirmed
   - Send WhatsApp notification after successful payment

2. **Payment History**
   - Show payment transaction history
   - Display payment receipt/proof
   - Download invoice PDF

3. **Promo Code System**
   - Apply discount/promo code at checkout
   - Validate promo code availability
   - Calculate discount amount

4. **Recurring Payment**
   - Setup auto-debit for monthly payment
   - Save payment method (card/e-wallet)
   - Auto-charge before expiry date

## References

- Midtrans Documentation: https://docs.midtrans.com
- Xendit Invoice API: https://developers.xendit.co/api-reference/#create-invoice
- GenieACS VirtualParameters: https://github.com/genieacs/genieacs/wiki/Virtual-Parameters
- Prisma Client: https://www.prisma.io/docs/concepts/components/prisma-client


## [16] BALANCE_AUTO_RENEWAL.md


# Balance & Auto-Renewal System Documentation

**Version**: 2.8.0  
**Date**: December 23, 2025  
**Status**: âœ… Implemented

---

## ðŸ“‹ Overview

Sistem Balance (Saldo Deposit) dan Auto-Renewal adalah fitur enhancement untuk tipe pelanggan **PREPAID** yang memungkinkan:

1. **Balance/Deposit**: Pelanggan bisa top-up saldo untuk perpanjangan otomatis
2. **Auto-Renewal**: Perpanjangan otomatis dari saldo saat mendekati expired
3. **Auto-Payment**: Invoice otomatis dibayar dari saldo tanpa intervensi manual

---

## ðŸ—ï¸ Architecture

### Database Schema

```prisma
model pppoeUser {
  // ... existing fields
  
  balance              Int        @default(0)     // Saldo deposit (in cents/smallest currency unit)
  autoRenewal          Boolean    @default(false) // Enable auto-renewal from balance
  
  // ... other fields
}
```

### API Endpoints

#### 1. Top-Up Balance
```http
POST /api/admin/pppoe/users/:id/deposit
Content-Type: application/json

{
  "amount": 100000,           // Amount in smallest currency unit (e.g., cents)
  "paymentMethod": "CASH",    // CASH, TRANSFER, etc.
  "note": "Top up via admin"  // Optional note
}
```

**Response:**
```json
{
  "message": "Top up berhasil",
  "data": {
    "username": "user123",
    "previousBalance": 50000,
    "amount": 100000,
    "newBalance": 150000
  }
}
```

#### 2. Get Balance History
```http
GET /api/admin/pppoe/users/:id/deposit
```

**Response:**
```json
{
  "user": {
    "id": "user-123",
    "username": "user123",
    "balance": 150000
  },
  "transactions": [
    {
      "id": "tx-001",
      "amount": 100000,
      "type": "DEPOSIT",
      "category": "DEPOSIT",
      "description": "Top up via admin",
      "paymentMethod": "CASH",
      "status": "SUCCESS",
      "createdAt": "2025-12-23T10:00:00Z"
    }
  ]
}
```

---

## âš™ï¸ Auto-Renewal Logic

### Workflow

```mermaid
graph TD
    A[Cron: Daily 8 AM] --> B{Check PREPAID users}
    B --> C[autoRenewal = true]
    C --> D{expiredAt in 3 days?}
    D -->|Yes| E{balance >= price?}
    E -->|Yes| F[Create/Find Invoice]
    F --> G[Pay from Balance]
    G --> H[Deduct Balance]
    H --> I[Extend expiredAt]
    I --> J[Restore if Isolated]
    J --> K[Send Notification]
    E -->|No| L[Log: Insufficient Balance]
    D -->|No| M[Skip User]
```

### Cron Job Configuration

**File**: `src/lib/cron/config.ts`

```typescript
{
  type: 'auto_renewal',
  name: 'Auto Renewal (Prepaid)',
  description: 'Automatically renew prepaid users from balance if autoRenewal enabled',
  schedule: '0 8 * * *',
  scheduleLabel: 'Daily at 8 AM',
  handler: async () => {
    const { processAutoRenewal } = await import('./auto-renewal');
    return processAutoRenewal();
  },
  enabled: true,
}
```

### Implementation Details

**File**: `src/lib/cron/auto-renewal.ts`

**Key Functions:**

1. **processAutoRenewal()** - Main cron handler
   - Find users with `autoRenewal = true` and `expiredAt` within 3 days
   - Check if balance sufficient
   - Create or find pending invoice
   - Call `payInvoiceFromBalance()`

2. **payInvoiceFromBalance()** - Payment processor
   - Deduct balance from user
   - Mark invoice as PAID
   - Extend `expiredAt` by validity period
   - Create transaction record
   - Restore user in RADIUS if isolated
   - Send WhatsApp notification

3. **restoreUserInRADIUS()** - RADIUS restoration
   - Remove user from 'isolir' group
   - Remove Reply-Message attribute
   - User can connect again

---

## ðŸ“Š Usage Examples

### Example 1: Admin Top-Up Balance

```bash
# Admin top-up balance for user
curl -X POST http://localhost:3000/api/admin/pppoe/users/abc123/deposit \
  -H "Content-Type: application/json" \
  -d '{
    "amount": 200000,
    "paymentMethod": "TRANSFER",
    "note": "Top up via BCA"
  }'
```

### Example 2: Enable Auto-Renewal

```typescript
// Update user to enable auto-renewal
await prisma.pppoeUser.update({
  where: { id: 'user-123' },
  data: {
    autoRenewal: true,
    balance: 100000  // Ensure sufficient balance
  }
})
```

### Example 3: Check Auto-Renewal Eligibility

```sql
-- Query users eligible for auto-renewal
SELECT 
  username,
  balance,
  autoRenewal,
  expiredAt,
  DATEDIFF(expiredAt, NOW()) as days_to_expiry,
  p.price as package_price
FROM pppoe_users pu
JOIN pppoe_profiles p ON p.id = pu.profileId
WHERE 
  pu.subscriptionType = 'PREPAID'
  AND pu.autoRenewal = TRUE
  AND pu.expiredAt BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 3 DAY)
  AND pu.balance >= p.price
```

---

## ðŸ§ª Testing Guide

### Test Case 1: Successful Auto-Renewal

**Prerequisites:**
- User type: PREPAID
- autoRenewal: true
- balance: >= package price
- expiredAt: in 2 days

**Steps:**
1. Set user's expiredAt to 2 days from now
2. Set balance to package price or more
3. Wait for cron to run (or trigger manually)
4. Verify invoice created and paid
5. Verify balance deducted
6. Verify expiredAt extended

**Expected Result:**
```
âœ… Invoice auto-created
âœ… Invoice status = PAID
âœ… Payment method = BALANCE
âœ… Balance reduced by package price
âœ… expiredAt = old expiredAt + validity period
âœ… User status = active (if was isolated)
âœ… WhatsApp notification sent
```

### Test Case 2: Insufficient Balance

**Prerequisites:**
- User type: PREPAID
- autoRenewal: true
- balance: < package price
- expiredAt: in 2 days

**Steps:**
1. Set balance less than package price
2. Wait for cron to run
3. Check logs

**Expected Result:**
```
âŒ Invoice created but not paid
âš ï¸ Log: "Insufficient balance (50000 < 100000)"
ðŸ“§ Manual payment required
```

### Test Case 3: Manual Payment After Auto-Fail

**Prerequisites:**
- Previous auto-renewal failed due to insufficient balance
- Invoice status: PENDING

**Steps:**
1. Admin top-up balance
2. User pays invoice manually OR
3. Wait for next cron run

**Expected Result:**
```
âœ… Next cron run will auto-pay the pending invoice
âœ… expiredAt extended
âœ… User restored
```

---

## ðŸš€ Deployment

### 1. Database Migration

Schema already includes `balance` and `autoRenewal` fields. No migration needed if already on v2.7.5+.

### 2. Code Deployment

```bash
# Pull latest code
git pull origin main

# Install dependencies (if needed)
npm install

# Build application
npm run build

# Restart PM2
pm2 restart all
```

### 3. Verify Cron Job

```bash
# Check if auto-renewal cron is registered
curl http://localhost:3000/api/admin/cron | jq '.jobs[] | select(.type=="auto_renewal")'

# Expected output:
{
  "type": "auto_renewal",
  "name": "Auto Renewal (Prepaid)",
  "enabled": true,
  "schedule": "0 8 * * *",
  "lastRun": null
}
```

### 4. Test Cron Manually (Optional)

```typescript
// In Node.js console or API route
import { processAutoRenewal } from '@/lib/cron/auto-renewal'

const result = await processAutoRenewal()
console.log(result)
// { processed: 5, success: 3, failed: 2 }
```

---

## ðŸ” Monitoring

### Key Metrics

1. **Auto-Renewal Success Rate**
   ```sql
   SELECT 
     COUNT(*) as total_attempts,
     SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful,
     SUM(CASE WHEN status = 'error' THEN 1 ELSE 0 END) as failed
   FROM cron_history
   WHERE job_type = 'auto_renewal'
     AND started_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
   ```

2. **Balance Usage**
   ```sql
   SELECT 
     COUNT(*) as users_with_autorenewal,
     AVG(balance) as avg_balance,
     MIN(balance) as min_balance,
     MAX(balance) as max_balance
   FROM pppoe_users
   WHERE autoRenewal = TRUE
   ```

3. **Upcoming Renewals**
   ```sql
   SELECT 
     COUNT(*) as upcoming_renewals,
     SUM(CASE WHEN balance >= p.price THEN 1 ELSE 0 END) as can_autorenew,
     SUM(CASE WHEN balance < p.price THEN 1 ELSE 0 END) as insufficient_balance
   FROM pppoe_users pu
   JOIN pppoe_profiles p ON p.id = pu.profileId
   WHERE 
     pu.subscriptionType = 'PREPAID'
     AND pu.autoRenewal = TRUE
     AND pu.expiredAt BETWEEN NOW() AND DATE_ADD(NOW(), INTERVAL 3 DAY)
   ```

### Logs

```bash
# Check auto-renewal logs
pm2 logs | grep "Auto-Renewal"

# Example output:
[Auto-Renewal] Starting auto-renewal process...
[Auto-Renewal] Found 5 users eligible for auto-renewal
[Auto-Renewal] Created invoice INV-202512-ABC12345 for user123
[Auto-Payment] âœ… User user123 - Paid 100000 from balance. New balance: 50000
[Auto-Renewal] Completed. Success: 3, Failed: 2
```

---

## âš ï¸ Important Notes

1. **Currency**: Amount harus dalam satuan terkecil (cents/sen). Contoh: Rp 100.000 = 100000 (bukan 100)

2. **Balance Safety**: Tidak ada negative balance. Jika balance < price, auto-renewal akan skip.

3. **Notification**: Auto-renewal akan mengirim notifikasi WhatsApp menggunakan template `payment_approved`.

4. **RADIUS Sync**: Jika user dalam status isolated, auto-renewal akan otomatis restore user di RADIUS.

5. **Transaction History**: Setiap top-up dan auto-payment dicatat di tabel `transactions` dengan category `DEPOSIT` atau `PAYMENT`.

6. **Cron Schedule**: Default jam 8 pagi. Bisa diubah di `src/lib/cron/config.ts`.

7. **Grace Period**: Auto-renewal check 3 hari sebelum expired. Ubah di `auto-renewal.ts` jika perlu.

---

## ðŸ› Troubleshooting

### Issue: Auto-Renewal Not Working

**Checklist:**
- [ ] User `subscriptionType` = 'PREPAID'?
- [ ] User `autoRenewal` = true?
- [ ] User `expiredAt` within 3 days?
- [ ] User `balance` >= package price?
- [ ] Cron job enabled in config?
- [ ] PM2 running and healthy?

**Debug:**
```bash
# Check cron status
curl http://localhost:3000/api/admin/cron

# Check user configuration
SELECT username, subscriptionType, autoRenewal, balance, expiredAt 
FROM pppoe_users 
WHERE id = 'user-id';

# Check cron history
SELECT * FROM cron_history 
WHERE job_type = 'auto_renewal' 
ORDER BY started_at DESC 
LIMIT 10;
```

### Issue: Balance Not Deducted

**Possible Causes:**
1. Transaction failed midway
2. Database deadlock
3. Insufficient balance (edge case: concurrent payment)

**Solution:**
- Check `transactions` table for failed records
- Check `invoices` table - if status = PENDING, retry auto-renewal
- Check PM2 logs for detailed error

---

## ðŸ“š References

- [PREPAID_POSTPAID_IMPLEMENTATION.md](./PREPAID_POSTPAID_IMPLEMENTATION.md) - Main billing system docs
- [ROADMAP_BILLING_FIX.md](../ROADMAP_BILLING_FIX.md) - Complete roadmap
- [Cron System Documentation](./CRON-SYSTEM.md) - Cron job configuration

---

**Last Updated**: December 23, 2025  
**Implemented By**: GitHub Copilot + AI Assistant  
**Status**: âœ… Production Ready


## [17] BROADCAST_NOTIFICATION_SYSTEM.md


# Broadcast Notification System

Sistem untuk mengirim notifikasi massal ke multiple user melalui WhatsApp dan Email dengan 3 jenis notifikasi.

## Overview

Sistem ini memungkinkan admin untuk mengirim notifikasi ke banyak user sekaligus melalui dropdown menu dengan 3 pilihan:
1. **Notifikasi Gangguan** - Informasi maintenance/gangguan jaringan
2. **Kirim Invoice** - Reminder invoice yang belum dibayar
3. **Bukti Pembayaran** - Konfirmasi pembayaran sudah diterima

## Features

### 1. Dropdown Menu di PPPoE Users Page
- Button "Kirim Notifikasi" dengan dropdown
- 3 pilihan: Gangguan, Invoice, Bukti Pembayaran
- Dynamic form sesuai jenis notifikasi

### 2. Multi-Channel Notification
- WhatsApp
- Email
- Both (WhatsApp & Email)

### 3. Bulk Selection
- Pilih multiple users dari table
- Select all option
- Filter by status (Active, Inactive, Expired)

## Usage Flow

### A. Notifikasi Gangguan (Outage)

**Use Case:** Memberitahu customer tentang maintenance atau gangguan jaringan

**Steps:**
1. Buka halaman Admin â†’ PPPoE Users
2. Pilih user yang ingin dikirim notifikasi (checkbox)
3. Klik "Kirim Notifikasi" â†’ Pilih "Notifikasi Gangguan"
4. Isi form:
   - **Jenis Gangguan**: Dropdown (Gangguan Jaringan, Maintenance, Upgrade, Lainnya)
   - **Deskripsi**: Text area (jelaskan detail gangguan)
   - **Estimasi Waktu**: Input waktu (contoh: "2-3 jam", "1 hari")
   - **Area Terdampak**: Input text (contoh: "Seluruh area", "Area A")
5. Pilih metode notifikasi: WhatsApp, Email, atau Both
6. Klik "Kirim"

**Template Variables:**
- `{{customerName}}` - Nama customer
- `{{customerId}}` - ID customer
- `{{username}}` - Username PPPoE
- `{{issueType}}` - Jenis gangguan
- `{{description}}` - Deskripsi gangguan
- `{{estimatedTime}}` - Estimasi waktu penyelesaian
- `{{affectedArea}}` - Area terdampak
- `{{companyName}}` - Nama perusahaan
- `{{companyPhone}}` - Telepon perusahaan
- `{{companyEmail}}` - Email perusahaan

### B. Kirim Invoice

**Use Case:** Mengirim reminder invoice yang belum dibayar ke customer

**Steps:**
1. Buka halaman Admin â†’ PPPoE Users
2. Pilih user yang ingin dikirim invoice (checkbox)
3. Klik "Kirim Notifikasi" â†’ Pilih "Kirim Invoice"
4. (Optional) Tambahkan pesan tambahan
5. Pilih metode notifikasi: WhatsApp, Email, atau Both
6. Klik "Kirim"

**Logic:**
- Sistem akan fetch invoice terakhir untuk setiap user
- Hanya user yang memiliki invoice yang akan dikirimi notifikasi
- User tanpa invoice akan skip dengan error message

**Template Variables:**
- `{{customerName}}` - Nama customer
- `{{customerId}}` - ID customer
- `{{username}}` - Username PPPoE
- `{{invoiceNumber}}` - Nomor invoice
- `{{amount}}` - Total tagihan (formatted Rupiah)
- `{{dueDate}}` - Tanggal jatuh tempo
- `{{profileName}}` - Nama paket
- `{{customerEmail}}` - Email customer
- `{{paymentLink}}` - Link pembayaran
- `{{additionalMessage}}` - Pesan tambahan (optional)
- `{{companyName}}` - Nama perusahaan
- `{{companyPhone}}` - Telepon perusahaan
- `{{companyEmail}}` - Email perusahaan
- `{{baseUrl}}` - Base URL aplikasi

### C. Bukti Pembayaran

**Use Case:** Mengirim konfirmasi pembayaran sudah diterima ke customer

**Steps:**
1. Buka halaman Admin â†’ PPPoE Users
2. Pilih user yang sudah melakukan pembayaran (checkbox)
3. Klik "Kirim Notifikasi" â†’ Pilih "Bukti Pembayaran"
4. (Optional) Tambahkan pesan tambahan
5. Pilih metode notifikasi: WhatsApp, Email, atau Both
6. Klik "Kirim"

**Logic:**
- Sistem akan fetch invoice terakhir yang sudah PAID untuk setiap user
- Hanya user dengan invoice PAID yang akan dikirimi notifikasi
- User tanpa invoice PAID akan skip dengan error message

**Template Variables:**
- `{{customerName}}` - Nama customer
- `{{customerId}}` - ID customer
- `{{username}}` - Username PPPoE
- `{{invoiceNumber}}` - Nomor invoice
- `{{amount}}` - Total pembayaran (formatted Rupiah)
- `{{paidDate}}` - Tanggal pembayaran
- `{{profileName}}` - Nama paket
- `{{customerEmail}}` - Email customer
- `{{expiredDate}}` - Tanggal expired akun (setelah extend)
- `{{additionalMessage}}` - Pesan tambahan (optional)
- `{{companyName}}` - Nama perusahaan
- `{{companyPhone}}` - Telepon perusahaan
- `{{companyEmail}}` - Email perusahaan
- `{{baseUrl}}` - Base URL aplikasi

## API Endpoint

**Endpoint:** `POST /api/pppoe/users/send-notification`

**Request Body:**
```json
{
  "userIds": [1, 2, 3],
  "notificationType": "outage|invoice|payment",
  "notificationMethod": "whatsapp|email|both",
  
  // For notificationType = 'outage'
  "issueType": "Gangguan Jaringan",
  "description": "Detail gangguan...",
  "estimatedTime": "2-3 jam",
  "affectedArea": "Seluruh area"
}
```

**Response Success:**
```json
{
  "message": "Notifikasi berhasil dikirim",
  "totalSent": 10,
  "emailSent": 10,
  "whatsappSent": 10,
  "failedCount": 0
}
```

**Response Error:**
```json
{
  "error": "Error message",
  "failedCount": 2,
  "errors": [
    "User John tidak memiliki invoice",
    "User Jane belum melakukan pembayaran"
  ]
}
```

## Technical Implementation

### Frontend (page.tsx)

**State Management:**
```typescript
const [notificationType, setNotificationType] = useState<'outage' | 'invoice' | 'payment'>('outage');
const [showNotificationMenu, setShowNotificationMenu] = useState(false);
const [isBroadcastDialogOpen, setIsBroadcastDialogOpen] = useState(false);
```

**Dropdown Menu:**
```typescript
const handleOpenNotificationMenu = (type: 'outage' | 'invoice' | 'payment') => {
  setNotificationType(type);
  setShowNotificationMenu(false);
  setIsBroadcastDialogOpen(true);
};
```

**Dynamic Form Rendering:**
- Outage: Form dengan 4 field (issueType, description, estimatedTime, affectedArea)
- Invoice: Info box + optional message field
- Payment: Info box + optional message field

### Backend (route.ts)

**Flow:**
1. Validate request body
2. Check notificationType
3. Fetch users with their invoices
4. Determine template type based on notificationType
5. Get email and WhatsApp templates
6. Loop through users
7. Replace template variables
8. Send via EmailService and/or WhatsApp API
9. Return success/error summary

## Best Practices

1. **Select Users Carefully:** Pastikan user yang dipilih sesuai dengan jenis notifikasi
2. **Test First:** Test dengan 1-2 user dulu sebelum send ke banyak user
3. **Check Templates:** Pastikan template sudah sesuai dan variabel sudah benar
4. **Monitor Errors:** Cek error messages jika ada user yang gagal
5. **Use Appropriate Channel:** 
   - WhatsApp: Lebih cepat, real-time
   - Email: Lebih formal, ada record
   - Both: Maksimal reach

## Troubleshooting

### Problem: User tidak menerima notifikasi
**Solution:**
- Cek phone number dan email user sudah benar
- Cek WhatsApp provider status
- Cek email settings
- Cek template exists

### Problem: Error "User tidak memiliki invoice" (Invoice type)
**Solution:**
- User belum punya invoice, generate invoice dulu
- Atau jangan include user tersebut di selection

### Problem: Error "User belum melakukan pembayaran" (Payment type)
**Solution:**
- User belum bayar invoice
- Atau mark invoice as paid dulu secara manual


## [18] OUTAGE_NOTIFICATION_SYSTEM.md


# Outage Notification System

Sistem untuk mengirim notifikasi gangguan/maintenance ke pelanggan melalui WhatsApp dan Email secara massal.

## Overview

Ketika terjadi gangguan jaringan atau ada jadwal maintenance, admin dapat mengirim notifikasi ke semua pelanggan yang terdampak dengan informasi:
- Jenis gangguan
- Deskripsi gangguan
- Estimasi waktu penyelesaian
- Area yang terdampak

## API Endpoint

**Endpoint**: `POST /api/pppoe/users/send-notification`

**Request Body**:
```json
{
  "userIds": [1, 2, 3, 4, 5],
  "notificationType": "outage",
  "notificationMethod": "whatsapp|email|both",
  "issueType": "Gangguan Jaringan",
  "description": "Terjadi gangguan pada backbone jaringan yang menyebabkan koneksi internet terputus.",
  "estimatedTime": "2-3 jam",
  "affectedArea": "Seluruh wilayah Kecamatan A"
}
```

### Parameter

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `userIds` | number[] | Yes | Array ID user PPPoE yang akan menerima notifikasi |
| `notificationType` | string | Yes | Harus "outage" untuk notifikasi gangguan |
| `notificationMethod` | string | Yes | "whatsapp", "email", atau "both" |
| `issueType` | string | Yes | Jenis gangguan (Gangguan Jaringan, Maintenance, Upgrade, Lainnya) |
| `description` | string | Yes | Deskripsi detail gangguan |
| `estimatedTime` | string | Yes | Estimasi waktu penyelesaian |
| `affectedArea` | string | Yes | Area yang terdampak |

### Issue Types

1. **Gangguan Jaringan** - Untuk masalah teknis seperti fiber cut, device down
2. **Maintenance** - Untuk jadwal maintenance rutin
3. **Upgrade** - Untuk upgrade jaringan/perangkat
4. **Lainnya** - Untuk jenis gangguan lain

### Response

**Success**:
```json
{
  "message": "Notifikasi gangguan berhasil dikirim",
  "totalSent": 50,
  "emailSent": 50,
  "whatsappSent": 50,
  "failedCount": 0
}
```

**Error**:
```json
{
  "error": "Gagal mengirim notifikasi",
  "failedCount": 2,
  "errors": [
    "User John: Nomor WhatsApp tidak valid",
    "User Jane: Email tidak terdaftar"
  ]
}
```

## WhatsApp Template

**Template Name**: `outage_notification`

**Template Content**:
```
âš ï¸ *PEMBERITAHUAN GANGGUAN JARINGAN*

Yth. Pelanggan *{{customerName}}*,
ID Pelanggan: {{customerId}}

Dengan ini kami informasikan bahwa sedang terjadi *{{issueType}}* pada jaringan kami.

ðŸ“‹ *Detail Gangguan:*
â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”â”
ðŸ“ Area Terdampak: {{affectedArea}}
ðŸ“ Keterangan: {{description}}
â±ï¸ Estimasi Perbaikan: {{estimatedTime}}

Kami mohon maaf atas ketidaknyamanan ini. Tim teknisi kami sedang bekerja untuk menyelesaikan masalah ini secepat mungkin.

Untuk informasi lebih lanjut, silakan hubungi:
ðŸ“ž {{companyPhone}}
ðŸ“§ {{companyEmail}}

Terima kasih atas pengertian Anda.

Hormat kami,
*{{companyName}}*
```

### Template Variables

| Variable | Description |
|----------|-------------|
| `{{customerName}}` | Nama pelanggan |
| `{{customerId}}` | ID pelanggan (generated) |
| `{{username}}` | Username PPPoE |
| `{{issueType}}` | Jenis gangguan |
| `{{description}}` | Deskripsi gangguan |
| `{{estimatedTime}}` | Estimasi waktu penyelesaian |
| `{{affectedArea}}` | Area yang terdampak |
| `{{companyName}}` | Nama ISP (dari settings) |
| `{{companyPhone}}` | Nomor telepon ISP |
| `{{companyEmail}}` | Email ISP |

## Email Template

**Template Name**: `outage_notification`

**Subject**: `[Penting] Pemberitahuan {{issueType}} - {{companyName}}`

**Body (HTML)**:
```html
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background: #f44336; color: white; padding: 20px; text-align: center; }
    .content { padding: 20px; background: #f9f9f9; }
    .detail-box { background: white; padding: 15px; border-left: 4px solid #f44336; margin: 15px 0; }
    .footer { padding: 20px; text-align: center; font-size: 12px; color: #666; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h2>âš ï¸ Pemberitahuan Gangguan Jaringan</h2>
    </div>
    <div class="content">
      <p>Yth. Pelanggan <strong>{{customerName}}</strong>,</p>
      <p>ID Pelanggan: {{customerId}}</p>
      
      <p>Dengan ini kami informasikan bahwa sedang terjadi <strong>{{issueType}}</strong> pada jaringan kami.</p>
      
      <div class="detail-box">
        <h4>Detail Gangguan:</h4>
        <ul>
          <li><strong>Area Terdampak:</strong> {{affectedArea}}</li>
          <li><strong>Keterangan:</strong> {{description}}</li>
          <li><strong>Estimasi Perbaikan:</strong> {{estimatedTime}}</li>
        </ul>
      </div>
      
      <p>Kami mohon maaf atas ketidaknyamanan ini. Tim teknisi kami sedang bekerja untuk menyelesaikan masalah ini secepat mungkin.</p>
      
      <p>Untuk informasi lebih lanjut, silakan hubungi:</p>
      <ul>
        <li>Telepon: {{companyPhone}}</li>
        <li>Email: {{companyEmail}}</li>
      </ul>
      
      <p>Terima kasih atas pengertian Anda.</p>
    </div>
    <div class="footer">
      <p>Hormat kami,<br><strong>{{companyName}}</strong></p>
    </div>
  </div>
</body>
</html>
```

## Usage Example (Frontend)

### React Component
```typescript
const sendOutageNotification = async () => {
  const response = await fetch('/api/pppoe/users/send-notification', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      userIds: selectedUsers.map(u => u.id),
      notificationType: 'outage',
      notificationMethod: notificationMethod,
      issueType: issueType,
      description: description,
      estimatedTime: estimatedTime,
      affectedArea: affectedArea
    })
  });
  
  const result = await response.json();
  
  if (result.error) {
    toast.error(result.error);
  } else {
    toast.success(`Notifikasi berhasil dikirim ke ${result.totalSent} pelanggan`);
  }
};
```

### Dialog Form
```typescript
<Dialog open={isOutageDialogOpen} onOpenChange={setIsOutageDialogOpen}>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Kirim Notifikasi Gangguan</DialogTitle>
    </DialogHeader>
    
    <div className="space-y-4">
      <div>
        <Label>Jenis Gangguan</Label>
        <Select value={issueType} onValueChange={setIssueType}>
          <SelectTrigger>
            <SelectValue placeholder="Pilih jenis gangguan" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Gangguan Jaringan">Gangguan Jaringan</SelectItem>
            <SelectItem value="Maintenance">Maintenance</SelectItem>
            <SelectItem value="Upgrade">Upgrade</SelectItem>
            <SelectItem value="Lainnya">Lainnya</SelectItem>
          </SelectContent>
        </Select>
      </div>
      
      <div>
        <Label>Deskripsi Gangguan</Label>
        <Textarea 
          value={description} 
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Jelaskan detail gangguan..."
        />
      </div>
      
      <div>
        <Label>Estimasi Waktu</Label>
        <Input 
          value={estimatedTime} 
          onChange={(e) => setEstimatedTime(e.target.value)}
          placeholder="contoh: 2-3 jam"
        />
      </div>
      
      <div>
        <Label>Area Terdampak</Label>
        <Input 
          value={affectedArea} 
          onChange={(e) => setAffectedArea(e.target.value)}
          placeholder="contoh: Seluruh area, atau Area A"
        />
      </div>
      
      <div>
        <Label>Metode Notifikasi</Label>
        <RadioGroup value={notificationMethod} onValueChange={setNotificationMethod}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="whatsapp" id="wa" />
            <Label htmlFor="wa">WhatsApp</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="email" id="email" />
            <Label htmlFor="email">Email</Label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="both" id="both" />
            <Label htmlFor="both">WhatsApp & Email</Label>
          </div>
        </RadioGroup>
      </div>
    </div>
    
    <DialogFooter>
      <Button variant="outline" onClick={() => setIsOutageDialogOpen(false)}>
        Batal
      </Button>
      <Button onClick={sendOutageNotification}>
        Kirim Notifikasi
      </Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

## Best Practices

1. **Select Target Users Carefully**
   - Filter by area jika hanya area tertentu yang terdampak
   - Filter by status Active untuk hanya kirim ke pelanggan aktif

2. **Provide Clear Information**
   - Deskripsi harus jelas dan mudah dipahami
   - Estimasi waktu realistis
   - Area terdampak spesifik

3. **Choose Appropriate Channel**
   - WhatsApp: Lebih cepat, real-time
   - Email: Lebih formal, ada record
   - Both: Untuk gangguan major

4. **Send Follow-up**
   - Kirim notifikasi update jika ada progress
   - Kirim notifikasi resolved ketika masalah selesai

## Troubleshooting

### Notifikasi tidak terkirim ke beberapa user
- Cek nomor WhatsApp valid (format: 62xxx)
- Cek email valid dan tidak kosong
- Cek WhatsApp provider status

### Error "Template not found"
- Pastikan template `outage_notification` sudah ada di database
- Jalankan seed untuk membuat template default

### Rate limiting
- Jika mengirim ke banyak user, mungkin terkena rate limit
- Sistem akan retry otomatis dengan delay


## [19] AUTO_RENEWAL_NOTIFICATION_SYSTEM.md


# Auto-Renewal & Notification System - Verification Report

## âœ… Cronjob Registration

### Auto-Renewal Job
- **Tipe**: `auto_renewal`
- **Nama**: Auto Renewal (Prepaid)  
- **Jadwal**: `0 8 * * *` (Setiap hari jam 8 pagi WIB)
- **Status**: âœ… Terdaftar di `/admin/settings/cron`
- **Handler**: `processAutoRenewal()` dari `src/lib/cron/auto-renewal.ts`
- **Fitur**:
  - Otomatis perpanjang user PREPAID dengan `autoRenewal=true`
  - Cek user yang akan expired dalam 3 hari
  - Bayar invoice dari saldo jika cukup
  - Update expired date
  - Restore dari isolir jika perlu
  - **BARU**: Kirim notifikasi Email + WhatsApp

### Success Handler di Admin UI
File: `src/app/admin/settings/cron/page.tsx`

```typescript
} else if (jobType === 'auto_renewal') {
  await Swal.fire({
    icon: 'success',
    title: t('common.success'),
    text: `Processed ${data.processed || 0} auto-renewals, paid ${data.paid || 0}`,
    timer: 2000,
    showConfirmButton: false
  });
}
```

---

## âœ… Notification System

### 1. WhatsApp Notification

**File**: `src/lib/whatsapp-notifications.ts`

**Fungsi Baru**: `sendAutoRenewalSuccess()`

**Trigger**: Otomatis setelah auto-renewal berhasil

**Template Variables**:
```
{{customerName}}    - Nama pelanggan
{{username}}        - Username PPPoE
{{profileName}}     - Nama paket internet
{{amount}}          - Biaya perpanjangan (Rp format)
{{newBalance}}      - Saldo tersisa (Rp format)
{{expiredDate}}     - Tanggal expired baru (format Indonesia)
{{companyName}}     - Nama perusahaan
{{companyPhone}}    - Nomor telepon perusahaan
```

**Contoh Template**:
```
âœ… *Auto-Renewal Berhasil*

Halo *Budi Santoso*,

Paket internet Anda telah *diperpanjang otomatis* dari saldo akun.

ðŸ“‹ *Detail:*
â€¢ Username: budi123
â€¢ Paket: Paket 20 Mbps
â€¢ Biaya: Rp 100.000
â€¢ Saldo tersisa: Rp 50.000
â€¢ Masa aktif hingga: 5 Desember 2025

âœ¨ *Auto-renewal* akan terus berjalan selama saldo mencukupi.

ðŸ’¡ Tip: Isi saldo sebelum masa aktif habis agar layanan tidak terputus.
```

---

### 2. Email Notification

**File**: `src/lib/email.ts`

**Fungsi Baru**: `sendAutoRenewalEmail()`

**Trigger**: Otomatis setelah auto-renewal berhasil (jika user punya email)

**Template Variables**: Sama seperti WhatsApp

**Design**: 
- Gradient header (Purple)
- Tabel detail transaksi
- Info box (hijau) untuk status auto-renewal
- Tips box (orange) untuk reminder isi saldo
- Responsive HTML email

---

### 3. Template Database

**File Seed**: `prisma/seeds/auto-renewal-templates.ts`

**WhatsApp Template**:
- Type: `auto-renewal-success`
- Table: `whatsapp_templates`
- Dapat diedit lewat admin UI

**Email Template**:
- Type: `auto-renewal-success`  
- Table: `email_templates`
- Dapat diedit lewat admin UI

**Cara Install Template**:
```bash
npx tsx prisma/seeds/auto-renewal-templates.ts
```

---

## âœ… Auto-Isolir Compatibility

### Update Auto-Isolir Logic

**File**: `src/lib/cron/voucher-sync.ts`

**Fungsi**: `autoIsolateExpiredUsers()`

### Logika Baru (Compatible dengan Prepaid/Postpaid):

Auto-isolir akan mengisolasi user yang:

1. **POSTPAID** - Semua user postpaid yang expired
2. **PREPAID tanpa auto-renewal** - User prepaid dengan `autoRenewal=false`
3. **PREPAID dengan auto-renewal tapi saldo kurang** - User prepaid dengan `autoRenewal=true` tapi gagal auto-renewal karena saldo tidak cukup

### Query Prisma:
```typescript
const expiredUsers = await prisma.pppoeUser.findMany({
  where: {
    status: 'active',
    expiredAt: {
      lt: startOfTodayWIB, // expired before today
    },
    OR: [
      // Postpaid - always isolate if expired
      { subscriptionType: 'POSTPAID' },
      // Prepaid without auto-renewal
      { 
        subscriptionType: 'PREPAID',
        autoRenewal: false 
      },
      // Prepaid with auto-renewal but insufficient balance
      {
        subscriptionType: 'PREPAID',
        autoRenewal: true,
      }
    ]
  }
})
```

### Kenapa Aman?

1. **Auto-renewal runs BEFORE expiry** (3 hari sebelum)
2. **Auto-isolir runs AFTER expiry** (hari berikutnya)
3. User prepaid dengan auto-renewal aktif dan saldo cukup **sudah diperpanjang** sebelum expired
4. Jadi saat auto-isolir jalan, mereka tidak masuk kriteria (expired date sudah di-extend)

---

## ðŸ“ Template Customization Guide

### Cara Edit Template WhatsApp

1. Login ke admin panel
2. Buka **Settings â†’ WhatsApp Templates** (perlu diimplementasi UI)
3. Cari template: **Auto-Renewal Berhasil** (`auto-renewal-success`)
4. Edit field `message` dengan menggunakan variables `{{variableName}}`
5. Klik Save

### Cara Edit Template Email

1. Login ke admin panel
2. Buka **Settings â†’ Email Templates** (perlu diimplementasi UI)  
3. Cari template: **Auto-Renewal Berhasil** (`auto-renewal-success`)
4. Edit field:
   - `subject` - Subject email
   - `htmlBody` - HTML content dengan variables
5. Klik Save

### Variables Yang Tersedia

| Variable | Keterangan | Contoh |
|----------|-----------|---------|
| `{{customerName}}` | Nama pelanggan | Budi Santoso |
| `{{username}}` | Username PPPoE | budi123 |
| `{{profileName}}` | Nama paket | Paket 20 Mbps |
| `{{amount}}` | Biaya (formatted) | Rp 100.000 |
| `{{newBalance}}` | Saldo tersisa | Rp 50.000 |
| `{{expiredDate}}` | Tanggal expired | 5 Desember 2025 |
| `{{companyName}}` | Nama perusahaan | NET INTERNET |
| `{{companyPhone}}` | No telp | 081234567890 |

---

## ðŸ§ª Testing Checklist

### 1. Test Auto-Renewal Cron

```bash
# Manual trigger dari UI
# Buka: /admin/settings/cron
# Klik "Run Now" pada job "Auto Renewal (Prepaid)"
```

**Expected Result**:
- SweetAlert muncul: "Processed X auto-renewals, paid Y"
- Cek cronHistory table untuk log
- Cek user balance berkurang
- Cek expired date bertambah
- **BARU**: Cek WhatsApp terkirim
- **BARU**: Cek Email terkirim

### 2. Test Notifications

**Prerequisites**:
- WhatsApp gateway sudah configured
- SMTP email sudah configured
- Template sudah di-seed ke database

**Test Steps**:
1. Buat user prepaid dengan autoRenewal=true
2. Set expired dalam 2 hari
3. Set balance cukup (>= paket price)
4. Pastikan user punya `phone` dan `email`
5. Run auto-renewal cron
6. Check:
   - WhatsApp log di terminal
   - Email history di database
   - User menerima pesan

### 3. Test Auto-Isolir Compatibility

**Test Case 1: Postpaid Expired**
- User postpaid expired
- Result: âœ… Harus diisolir

**Test Case 2: Prepaid tanpa Auto-Renewal**
- User prepaid, autoRenewal=false, expired
- Result: âœ… Harus diisolir

**Test Case 3: Prepaid dengan Auto-Renewal + Saldo Cukup**
- User prepaid, autoRenewal=true, balance cukup
- Result: âœ… TIDAK diisolir (sudah auto-renewed)

**Test Case 4: Prepaid dengan Auto-Renewal + Saldo Kurang**
- User prepaid, autoRenewal=true, balance < price
- Result: âœ… Harus diisolir (auto-renewal gagal)

---

## ðŸ“‹ Implementation Status

| Fitur | Status | File |
|-------|--------|------|
| Auto-renewal cron registered | âœ… | `src/lib/cron/config.ts` |
| Auto-renewal success handler UI | âœ… | `src/app/admin/settings/cron/page.tsx` |
| WhatsApp notification | âœ… | `src/lib/whatsapp-notifications.ts` |
| Email notification | âœ… | `src/lib/email.ts` |
| Template seeds | âœ… | `prisma/seeds/auto-renewal-templates.ts` |
| Auto-isolir update | âœ… | `src/lib/cron/voucher-sync.ts` |
| Balance column in UI | âœ… | `src/app/admin/pppoe/users/page.tsx` |
| Auto-renewal badge | âœ… | `src/app/admin/pppoe/users/page.tsx` |

---

## ðŸš€ Deployment Steps

### 1. Install Template ke Database

```bash
npx tsx prisma/seeds/auto-renewal-templates.ts
```

### 2. Verify Cron Registration

- Buka `/admin/settings/cron`
- Pastikan "Auto Renewal (Prepaid)" muncul
- Cek schedule: "Daily at 8 AM"

### 3. Configure Notifications

**WhatsApp**:
- Pastikan WhatsApp gateway configured
- Test dengan send test message

**Email**:
- Configure SMTP di Email Settings
- Test dengan send test email

### 4. Enable Auto-Renewal untuk User

- Edit user â†’ Toggle "Auto Renewal" ON
- Top-up balance yang cukup

### 5. Monitor Execution

- Check cron history: `/admin/settings/cron`
- Check logs untuk notification status
- Verify user balance dan expired date

---

## âš ï¸ Important Notes

1. **Auto-renewal runs at 8 AM daily** - Users expiring in next 3 days will be processed
2. **Notifications are optional** - Won't break transaction if failed
3. **Templates customizable** - Can be edited via admin UI (need UI implementation)
4. **Auto-isolir safe** - Won't isolate users that were auto-renewed
5. **Balance required** - User needs balance >= package price for auto-renewal to work

---

## ðŸ†˜ Troubleshooting

### Auto-Renewal Tidak Jalan

**Check**:
1. Cron job enabled? (`/admin/settings/cron`)
2. User `autoRenewal=true`?
3. User `subscriptionType='PREPAID'`?
4. User balance >= package price?
5. User expired dalam 3 hari?

### Notifikasi Tidak Terkirim

**WhatsApp**:
1. Check WhatsApp gateway configuration
2. Check user punya field `phone`
3. Check logs untuk error message
4. Verify template exists di database

**Email**:
1. Check SMTP configuration
2. Check user punya field `email`
3. Check email history table
4. Verify template exists di database

### User Tetap Diisolir Padahal Sudah Auto-Renewal

**Possible Causes**:
1. Auto-renewal failed (check logs)
2. Balance insufficient saat cron jalan
3. Template transaction error

**Debug**:
```sql
-- Check user status
SELECT username, balance, autoRenewal, expiredAt, status 
FROM pppoeUser 
WHERE username = 'target_username';

-- Check cron history
SELECT * FROM cronHistory 
WHERE jobType = 'auto_renewal' 
ORDER BY startedAt DESC 
LIMIT 5;
```

---

## ðŸ“ž Support

Jika ada masalah, cek:
1. Cron history logs
2. Application logs (console)
3. Email history table
4. WhatsApp gateway logs



## [20] GENIEACS-GUIDE.md


# GenieACS TR-069 Integration

Complete guide for GenieACS CPE management integration in SALFANET RADIUS.

## ðŸ“¡ Overview

GenieACS integration allows remote management of customer ONT devices via TR-069 protocol (CWMP). Features include:

- **Device Monitoring** - Real-time device status, uptime, signal strength
- **WiFi Configuration** - Edit SSID, password, security mode
- **Task Management** - Track all TR-069 operations
- **Multi-WLAN Support** - Manage 2.4GHz, 5GHz, Guest networks
- **WiFi Clients** - View connected devices per WLAN

## ðŸ”§ Setup

### 1. GenieACS Server Installation

Install GenieACS on separate server or same VPS:

```bash
# Install MongoDB
sudo apt install -y mongodb

# Install GenieACS
sudo npm install -g genieacs

# Create systemd services
sudo nano /etc/systemd/system/genieacs-cwmp.service
```

**genieacs-cwmp.service:**
```ini
[Unit]
Description=GenieACS CWMP
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/genieacs-cwmp --config /opt/genieacs/config.json
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**genieacs-nbi.service:**
```ini
[Unit]
Description=GenieACS NBI
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/genieacs-nbi --config /opt/genieacs/config.json
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**genieacs-fs.service:**
```ini
[Unit]
Description=GenieACS FS
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/genieacs-fs --config /opt/genieacs/config.json
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

**genieacs-ui.service:**
```ini
[Unit]
Description=GenieACS UI
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/genieacs-ui --config /opt/genieacs/config.json
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 2. GenieACS Configuration

Create `/opt/genieacs/config.json`:

```json
{
  "MONGODB_CONNECTION_URL": "mongodb://127.0.0.1:27017/genieacs",
  "CWMP_INTERFACE": "0.0.0.0",
  "CWMP_PORT": 7547,
  "CWMP_SSL": false,
  "NBI_INTERFACE": "0.0.0.0",
  "NBI_PORT": 7557,
  "FS_INTERFACE": "0.0.0.0",
  "FS_PORT": 7567,
  "UI_INTERFACE": "0.0.0.0",
  "UI_PORT": 3000,
  "LOG_LEVEL": "info"
}
```

### 3. Start Services

```bash
sudo systemctl daemon-reload
sudo systemctl enable genieacs-cwmp genieacs-nbi genieacs-fs genieacs-ui
sudo systemctl start genieacs-cwmp genieacs-nbi genieacs-fs genieacs-ui

# Check status
sudo systemctl status genieacs-*
```

### 4. Configure in SALFANET RADIUS

Go to **Admin â†’ Settings â†’ GenieACS** and configure:

- **GenieACS URL**: `http://YOUR_GENIEACS_IP:7557` (NBI port)
- **Username**: Leave empty (or set if auth enabled)
- **Password**: Leave empty (or set if auth enabled)

Click **Test Connection** to verify.

## ðŸŒ ONT Configuration

### Huawei HG8145V5 Setup

Configure TR-069 client on ONT:

1. Login to ONT web interface (usually `192.168.100.1`)
2. Go to **Management â†’ TR-069 Configuration**
3. Set:
   - **ACS URL**: `http://YOUR_GENIEACS_IP:7547/`
   - **ACS Username**: (leave empty or as required)
   - **ACS Password**: (leave empty or as required)
   - **Periodic Inform Enable**: `Yes`
   - **Periodic Inform Interval**: `300` (5 minutes, can be lower)
   - **Connection Request Username**: `admin`
   - **Connection Request Password**: `admin`

4. Click **Apply** and wait for device to appear in GenieACS

### Connection Request URL

For GenieACS to send commands immediately (not wait periodic inform), device needs proper Connection Request URL:

- **If ONT has public IP**: `http://ONT_PUBLIC_IP:7547`
- **If ONT behind NAT**: Setup port forwarding or use STUN server

âš ï¸ **Important**: If connection request doesn't work, changes will still apply on next periodic inform (every 5 minutes).

## ðŸ“‹ Features

### Device Management

Navigate to **Admin â†’ GenieACS â†’ Devices**

Features:
- View all registered devices
- Real-time status (Online/Offline)
- Device details modal with:
  - Serial number, model, manufacturer
  - PPPoE username and IP
  - TR-069 IP address
  - Uptime, RX power, PON mode
  - WiFi configurations (all WLANs)
  - Connected WiFi clients

Actions:
- **Force Sync** - Trigger connection request immediately
- **Refresh Parameters** - Get latest device data
- **Reboot** - Restart device remotely
- **Edit WiFi** - Configure SSID and password

### WiFi Configuration

Click device â†’ **Edit WiFi** button

Supported parameters:
- **SSID** - Network name (1-32 characters)
- **Security Mode**:
  - None (Open) - No password
  - WPA-PSK - WPA with TKIP
  - WPA2-PSK - WPA2 with AES (recommended)
  - WPA/WPA2-PSK - Mixed mode
- **Password** - 8-63 characters (required for encrypted modes)
- **Enable/Disable** - Turn WiFi on/off

**How it works:**
1. User clicks "Update WiFi"
2. API creates `setParameterValues` task
3. GenieACS sends connection request to device
4. Device connects and receives task
5. Parameters applied instantly
6. API checks task status after 2 seconds
7. Shows success/pending message

**Parameter mapping for Huawei HG8145V5:**
```
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.SSID
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.BeaconType
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.KeyPassphrase
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.IEEE11iAuthenticationMode
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.IEEE11iEncryptionModes
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.Enable
```

### Task Monitoring

Navigate to **Admin â†’ GenieACS â†’ Tasks**

Features:
- Real-time task list with status
- Auto-refresh every 10 seconds (toggle on/off)
- Filter by status: All / Pending / Fault / Done
- Task details:
  - Task ID
  - Device ID
  - Task name (setParameterValues, getParameterValues, etc.)
  - Timestamp
  - Retry count
  - Status badge
  - Error message (if fault)

Actions:
- **Retry** - Re-execute failed tasks
- **Delete** - Remove task from queue
- **Auto-refresh** - Toggle automatic updates

**Task Status:**
- **Pending** (yellow) - Waiting for device to connect
- **Done** (green) - Successfully executed
- **Fault** (red) - Error occurred, check details

## ðŸ”„ API Endpoints

### Device Management

**Get Devices:**
```http
GET /api/settings/genieacs/devices
```

**Get Device Detail:**
```http
GET /api/settings/genieacs/devices/{deviceId}/detail
```

**Refresh Device:**
```http
POST /api/settings/genieacs/devices/{deviceId}/refresh
```

**Reboot Device:**
```http
POST /api/settings/genieacs/devices/{deviceId}/reboot
```

**Delete Device:**
```http
DELETE /api/settings/genieacs/devices/{deviceId}
```

### WiFi Configuration

**Update WiFi:**
```http
POST /api/genieacs/devices/{deviceId}/wifi
Content-Type: application/json

{
  "wlanIndex": 1,
  "ssid": "MyNetwork",
  "password": "MyPassword123",
  "securityMode": "WPA2-PSK",
  "enabled": true
}
```

Response:
```json
{
  "success": true,
  "message": "Konfigurasi WiFi berhasil dikirim ke device",
  "info": "Task berhasil dieksekusi",
  "taskId": "6930ee9736857bde5d1ca3ee",
  "taskStatus": "pending",
  "parameters": {
    "ssid": "MyNetwork",
    "securityMode": "WPA2-PSK",
    "enabled": true,
    "wlanIndex": 1
  }
}
```

### Task Management

**Get Tasks:**
```http
GET /api/genieacs/tasks
```

**Delete Task:**
```http
DELETE /api/genieacs/tasks/{taskId}
```

**Retry Task:**
```http
POST /api/genieacs/tasks/{taskId}/retry
```

### Connection Request

**Trigger Connection Request:**
```http
POST /api/genieacs/devices/{deviceId}/connection-request
```

## ðŸ› Troubleshooting

### Device Not Appearing

**Problem**: ONT not showing in GenieACS devices list

**Solutions**:
1. Check TR-069 configuration on ONT
2. Verify ACS URL is correct: `http://GENIEACS_IP:7547/`
3. Check firewall - port 7547 must be open
4. Check GenieACS CWMP service: `systemctl status genieacs-cwmp`
5. View logs: `journalctl -u genieacs-cwmp -f`

### Task Stuck in Pending

**Problem**: WiFi edit task shows "Pending" forever

**Causes**:
- Connection request URL not working (device behind NAT)
- Firewall blocking connection request
- Device offline

**Solutions**:
1. Wait for periodic inform (5 minutes by default)
2. Setup port forwarding if device behind NAT
3. Reduce periodic inform interval on device
4. Click "Force Sync" to retry connection request

### Error cwmp.9002 - Internal Error

**Problem**: Task fails with `cwmp.9002 Internal error`

**Causes**:
- Wrong parameter path
- Parameter is read-only
- Value doesn't match expected type

**Solutions**:
1. Check device data model in GenieACS UI
2. Verify parameter is writable
3. Use correct path for your device model
4. For Huawei HG8145V5: Use `KeyPassphrase` not `PreSharedKey.1.KeyPassphrase`

### Connection Request Failed

**Problem**: "Force Sync" doesn't trigger device

**Check**:
```bash
# From GenieACS server, test connection to device
curl -v http://DEVICE_IP:7547/

# Expected: HTTP 401 Unauthorized (device responds)
# If timeout: Device not reachable
```

**Solutions**:
1. Verify device Connection Request URL is correct
2. Check device firewall allows incoming on port 7547
3. If behind NAT, setup port forwarding
4. Alternative: Wait for periodic inform instead

## ðŸ“Š Monitoring

### GenieACS Logs

View logs for debugging:

```bash
# CWMP service (device connections)
journalctl -u genieacs-cwmp -f

# NBI service (API)
journalctl -u genieacs-nbi -f

# UI service
journalctl -u genieacs-ui -f
```

### MongoDB Check

```bash
# Connect to MongoDB
mongo

# Use GenieACS database
use genieacs

# Count devices
db.devices.count()

# View recent devices
db.devices.find().limit(5)

# Count tasks
db.tasks.count()

# View pending tasks
db.tasks.find({ status: { $exists: false } })
```

### Network Test

```bash
# Test GenieACS API
curl http://localhost:7557/devices

# Test CWMP port
nc -zv localhost 7547

# Test from device to GenieACS
# (run on device or router)
curl -v http://GENIEACS_IP:7547/
```

## ðŸ” Security

### Best Practices

1. **Use HTTPS** - Setup reverse proxy with SSL
2. **Enable Authentication** - Configure username/password in GenieACS
3. **Firewall Rules** - Only allow necessary ports
4. **VPN** - For devices to reach GenieACS securely
5. **Regular Updates** - Keep GenieACS updated

### Nginx Reverse Proxy (HTTPS)

```nginx
server {
    listen 443 ssl http2;
    server_name genieacs.yourdomain.com;
    
    ssl_certificate /etc/letsencrypt/live/genieacs.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/genieacs.yourdomain.com/privkey.pem;
    
    # GenieACS UI
    location / {
        proxy_pass http://localhost:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
    
    # GenieACS NBI API
    location /api/ {
        proxy_pass http://localhost:7557/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}

# CWMP (TR-069) - HTTP only (device connections)
server {
    listen 7547;
    server_name genieacs.yourdomain.com;
    
    location / {
        proxy_pass http://localhost:7547;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

## ðŸ“š References

- [GenieACS Documentation](https://docs.genieacs.com/)
- [TR-069 CWMP Protocol](https://www.broadband-forum.org/technical/download/TR-069.pdf)
- [Huawei TR-069 Data Model](https://support.huawei.com/)

## ðŸŽ¯ Roadmap

Future enhancements:
- [ ] Firmware upgrade via GenieACS
- [ ] Backup/restore device configuration
- [ ] Custom presets for common settings
- [ ] Bulk operations (multiple devices)
- [ ] Device grouping
- [ ] Scheduled tasks
- [ ] Alert notifications for device offline


## [21] MIKROTIK_RADIUS_COA_COMPLETE_SETUP.md


# Panduan Lengkap: Setup Mikrotik RADIUS untuk CoA Disconnect

## ðŸŽ¯ Tujuan
Setup Mikrotik agar dapat menerima CoA (Change of Authorization) Disconnect dari FreeRADIUS server untuk auto-disconnect user expired.

---

## ðŸ“‹ Prerequisites

- Mikrotik RouterOS versi 6.x atau 7.x
- FreeRADIUS server sudah running (VPS: 103.191.165.156)
- Network connectivity antara Mikrotik dan VPS
- Secret RADIUS: `secret123` (sesuaikan dengan instalasi Anda)

---

## âš™ï¸ Konfigurasi Step-by-Step

### STEP 1: Setup RADIUS Client (Outgoing)

Ini untuk **Mikrotik â†’ FreeRADIUS** (authentication):

```routeros
/radius
add service=hotspot,pppoe \
    address=103.191.165.156 \
    secret="secret123" \
    timeout=5s
    
# Verify
/radius print detail
```

**Output yang benar:**
```
0   service=hotspot,pppoe 
    address=103.191.165.156 
    secret="secret123" 
    timeout=5s
```

---

### STEP 2: Setup RADIUS Incoming (CoA)

Ini untuk **FreeRADIUS â†’ Mikrotik** (CoA disconnect):

```routeros
/radius incoming
set accept=yes
set port=3799

# PENTING: Set secret yang SAMA dengan /radius
# Jika tidak ada parameter default-secret, RouterOS versi lama butuh cara lain
print
```

**Output yang benar:**
```
  accept: yes
    port: 3799
```

**âš ï¸ CATATAN PENTING:**

Beberapa versi RouterOS **tidak punya parameter `default-secret`** di `/radius incoming`.

**Solusinya:**
1. Secret untuk incoming CoA **otomatis pakai secret dari `/radius`**
2. Pastikan secret di `/radius` sudah benar
3. **RESTART Mikrotik** agar setting apply

```routeros
# Restart Mikrotik
/system reboot
```

---

### STEP 3: Konfigurasi Firewall

Allow UDP port 3799 dari VPS RADIUS server:

```routeros
/ip firewall filter

# Cek apakah sudah ada rule untuk port 3799
print where dst-port=3799

# Jika belum ada, tambahkan
add chain=input \
    protocol=udp \
    dst-port=3799 \
    src-address=103.191.165.156 \
    action=accept \
    comment="Allow RADIUS CoA from VPS" \
    place-before=0
    
# Verify
print where dst-port=3799
```

**Output yang benar:**
```
0 X  chain=input action=accept protocol=udp src-address=103.191.165.156 
     dst-port=3799 comment="Allow RADIUS CoA from VPS"
```

---

### STEP 4: Enable RADIUS Logging (Debug)

Untuk troubleshooting, enable logging:

```routeros
/system logging

# Tambahkan topic radius
add topics=radius,debug,!packet action=memory

# Verify
print where topics~"radius"
```

---

### STEP 5: Setup Hotspot untuk RADIUS

Pastikan Hotspot Profile menggunakan RADIUS:

```routeros
/ip hotspot profile

# Cek profile yang digunakan
print

# Set RADIUS untuk profile hotspot (misal profile "default")
set [find name=default] use-radius=yes
```

**Verify RADIUS enabled:**
```routeros
/ip hotspot profile print detail
```

Cari baris: `use-radius: yes`

---

## ðŸ§ª Testing

### Test 1: Koneksi Network

Di VPS, test connectivity ke Mikrotik:

```bash
# Test ping
ping -c 3 172.20.30.11

# Test UDP port 3799
nc -vzu 172.20.30.11 3799
```

**Output yang benar:**
```
Connection to 172.20.30.11 3799 port [udp/*] succeeded!
```

---

### Test 2: Manual CoA Disconnect

Di VPS, jalankan test script:

```bash
ssh -p 9500 root@103.191.165.156 /root/test-coa.sh
```

**Output SUKSES:**
```
Received Disconnect-ACK Id 236 from 172.20.30.11:3799
âœ“ CoA command sent successfully
```

**Output GAGAL:**
```
(0) No reply from server for ID 236 socket 3
âœ— CoA command failed
```

Jika GAGAL, lihat section **Troubleshooting** di bawah.

---

### Test 3: Verify di Mikrotik Logs

Setelah kirim CoA, cek log di Mikrotik:

```routeros
/log print where topics~"radius"
```

**Log yang benar (CoA diterima):**
```
received disconnect request from 103.191.165.156
sending disconnect ack to 103.191.165.156
user YFBRLC disconnected
```

**Log yang salah (CoA ditolak):**
```
received disconnect request from 103.191.165.156
bad radius secret from 103.191.165.156
```

Jika secret salah, **secret di `/radius` harus sama dengan database!**

---

### Test 4: Test Auto-Disconnect Voucher

1. **Buat voucher test** (validity 2 menit):
   - Login ke web admin
   - Hotspot â†’ Voucher â†’ Generate
   - Validity: 2 Minute
   - Generate 1 voucher

2. **Login dengan voucher** dari client hotspot

3. **Tunggu 2 menit** sampai expired

4. **Cek PM2 logs** di VPS:
   ```bash
   ssh -p 9500 root@103.191.165.156 "pm2 logs --lines 50 | grep 'CoA\|Disconnect'"
   ```

5. **Verify user disconnect:**
   - Di Mikrotik: `/ip hotspot active print` â†’ voucher hilang
   - Di web: Admin â†’ Sessions â†’ Hotspot â†’ voucher hilang
   - Client redirect ke login page

---

## ðŸ”§ Troubleshooting

### Problem 1: "No reply from server"

**Diagnosa:**
```routeros
# Di Mikrotik, cek log
/log print where topics~"radius"
```

**Kemungkinan:**

1. **Secret tidak match**
   ```routeros
   # Cek secret di RADIUS client
   /radius print detail
   
   # Secret harus SAMA dengan database nas.secret
   ```

2. **Firewall blocking**
   ```routeros
   # Cek firewall
   /ip firewall filter print where dst-port=3799
   
   # Jika tidak ada rule accept, tambahkan
   add chain=input protocol=udp dst-port=3799 src-address=103.191.165.156 action=accept place-before=0
   ```

3. **RADIUS Incoming tidak enabled**
   ```routeros
   /radius incoming print
   
   # Harus: accept: yes, port: 3799
   ```

4. **Butuh restart**
   ```routeros
   # Restart Mikrotik
   /system reboot
   ```

---

### Problem 2: CoA sent tapi user tidak disconnect

**Diagnosa:**

1. **Session ID tidak match**
   ```routeros
   # Cek active session
   /ip hotspot active print
   
   # Bandingkan session-id dengan yang di database
   ```

2. **IP Address tidak match**
   ```routeros
   # Cek IP yang digunakan user
   /ip hotspot active print
   
   # Kolom "address" harus sama dengan framedipaddress di database
   ```

3. **MAC Address strict mode**
   - Beberapa Mikrotik butuh MAC address di CoA packet
   - Update sudah include Calling-Station-Id (MAC)

---

### Problem 3: "Bad RADIUS secret"

**Fix:**

```routeros
# Verify secret di RADIUS client
/radius print detail

# Harus PERSIS SAMA dengan database
# Di database, cek:
# SELECT secret FROM nas WHERE nasname='172.20.30.11'

# Jika beda, update di Mikrotik
/radius set 0 secret="secret123"

# RESTART
/system reboot
```

---

## ðŸ“Š Monitoring

### Check Active Sessions

```routeros
# Lihat user yang sedang online
/ip hotspot active print

# Detail session
/ip hotspot active print detail

# Lihat berapa lama online
/ip hotspot active print stats
```

### Check RADIUS Statistics

```routeros
# Statistik RADIUS
/radius print stats

# Lihat bad requests (jika ada)
/radius incoming print stats
```

### Check Logs Real-time

```routeros
# Monitor log secara real-time
/log print follow where topics~"radius"
```

**Saat user login:**
```
accepted access request from 103.191.165.156
sending access accept to 103.191.165.156
```

**Saat CoA disconnect:**
```
received disconnect request from 103.191.165.156
sending disconnect ack to 103.191.165.156
```

---

## ðŸŽ¯ Verification Checklist

Pastikan semua ini sudah benar:

- [x] `/radius` configured dengan service=hotspot,pppoe
- [x] Secret di `/radius` = secret di database `nas.secret`
- [x] `/radius incoming` accept=yes port=3799
- [x] Firewall allow UDP 3799 dari VPS
- [x] Hotspot profile use-radius=yes
- [x] Mikrotik sudah restart setelah konfigurasi
- [x] Test CoA manual sukses (Disconnect-ACK received)
- [x] RADIUS logging enabled
- [x] Network connectivity VPS â†” Mikrotik OK

---

## ðŸ’¡ Tips & Best Practices

### 1. Gunakan IP Static untuk VPS

Jangan gunakan dynamic IP untuk RADIUS server. Set di firewall:

```routeros
/ip firewall filter
add chain=input protocol=udp src-address=103.191.165.156 dst-port=1812-1813 action=accept comment="RADIUS Auth"
add chain=input protocol=udp src-address=103.191.165.156 dst-port=3799 action=accept comment="RADIUS CoA"
```

### 2. Backup Konfigurasi

Setelah setup, backup:

```routeros
/export file=radius-config
```

### 3. Monitor Secara Berkala

Cek setiap hari:
- `/log print where topics~"radius" and message~"bad|error|fail"`
- `/radius print stats` â†’ cari bad requests
- `/ip hotspot active print` â†’ pastikan expired user disconnect

### 4. Session Timeout Sebagai Backup

Jika CoA gagal, session tetap disconnect via timeout:

```routeros
# Session akan auto-expire sesuai setting di FreeRADIUS
# Cek di radgroupreply: Session-Timeout attribute
```

---

## ðŸ“š Referensi

- [RFC 5176 - Dynamic Authorization](https://tools.ietf.org/html/rfc5176)
- [Mikrotik Wiki - RADIUS](https://wiki.mikrotik.com/wiki/Manual:RADIUS_Client)
- [FreeRADIUS CoA Documentation](https://networkradius.com/doc/3.0.10/raddb/sites-available/coa.html)

---

## ðŸ†˜ Support

Jika masih bermasalah:

1. Export Mikrotik config: `/export file=debug-config`
2. Cek PM2 logs: `pm2 logs --lines 200 | grep CoA`
3. Run test script: `/root/test-coa.sh`
4. Cek Mikrotik logs: `/log print where topics~"radius"`
5. Screenshot error dan kirim untuk analisis


## [22] MIKROTIK_COA_SETUP.md


# Mikrotik CoA (Change of Authorization) Setup Guide

## Ringkasan
CoA (RFC 5176) memungkinkan RADIUS server untuk **disconnect user secara paksa** ketika:
- Voucher hotspot expired
- User PPPoE di-isolir
- Admin manual disconnect dari Sesi Hotspot/PPPoE

## Verifikasi Masalah

Jika auto-disconnect tidak bekerja, cek dengan command berikut di VPS:

```bash
# Test CoA manual
echo "NAS-IP-Address=172.20.30.11
Framed-IP-Address=192.168.20.254
User-Name=YFBRLC
Acct-Session-Id=80800031" | radclient -x 172.20.30.11:3799 disconnect secret123
```

**Error yang umum:**
```
(0) No reply from server for ID 202 socket 3
```

Artinya: **Mikrotik tidak merespon CoA request**

---

## Langkah Setup di Mikrotik

### 1. Enable RADIUS Incoming

```routeros
/radius incoming
set accept=yes
print
```

**Output yang benar:**
```
  accept: yes
    port: 3799
```

### 2. Verifikasi Secret

Secret di Mikrotik RADIUS Client **HARUS SAMA** dengan secret di database `nas` table.

Cek di aplikasi web: **Admin â†’ Network â†’ Routers** â†’ pilih router â†’ lihat field "Secret"

Atau cek via WinBox/SSH di Mikrotik:
```routeros
/radius
print detail
```

Contoh output:
```
0   service=hotspot,pppoe address=103.191.165.156 secret="secret123"
    timeout=5s00ms
```

**PENTING:** Secret harus **PERSIS SAMA** antara:
- Database `nas.secret`
- Mikrotik `/radius` secret
- Test script CoA

### 3. Enable RADIUS Logging (Untuk Debug)

```routeros
/system logging
add topics=radius,debug,!packet action=memory

# Lihat log
/log print where topics~"radius"
```

### 4. Verifikasi Firewall

Pastikan UDP port 3799 **TIDAK DIBLOK** oleh firewall Mikrotik:

```routeros
# Cek apakah ada rule yang block port 3799
/ip firewall filter
print where dst-port=3799

# Jika tidak ada rule ACCEPT, tambahkan
add chain=input protocol=udp dst-port=3799 \
    src-address=103.191.165.156 \
    action=accept \
    comment="Allow RADIUS CoA from VPS" \
    place-before=0
```

**Catatan:** `103.191.165.156` adalah IP VPS RADIUS server Anda.

### 5. Test Koneksi dari VPS

Di VPS, jalankan:

```bash
# Test ping
ping -c 3 172.20.30.11

# Test UDP port (harus succeed)
nc -vzu 172.20.30.11 3799
```

**Output yang benar:**
```
Connection to 172.20.30.11 3799 port [udp/*] succeeded!
```

---

## Troubleshooting

### Problem: "No reply from server"

**Penyebab Umum:**

1. **RADIUS Incoming tidak enabled**
   ```routeros
   /radius incoming set accept=yes
   ```

2. **Secret tidak match**
   - Cek di Mikrotik: `/radius print detail`
   - Cek di database: `SELECT secret FROM nas WHERE nasname='172.20.30.11'`
   - Harus **IDENTIK** (case-sensitive)

3. **Firewall blocking UDP 3799**
   ```routeros
   /ip firewall filter
   add chain=input protocol=udp dst-port=3799 action=accept place-before=0
   ```

4. **Network routing issue**
   - Pastikan VPS bisa ping ke IP Mikrotik
   - Pastikan tidak ada firewall di tengah (VPN, NAT, dll)

### Problem: CoA sent tapi user tidak disconnect

1. **Session ID tidak match**
   - CoA harus menggunakan `acctsessionid` yang **AKTIF**
   - Cek di Mikrotik: `/ip hotspot active print`
   - Cek di database: `SELECT acctsessionid FROM radacct WHERE acctstoptime IS NULL`

2. **Framed-IP tidak match**
   - Harus pakai IP yang **sedang digunakan** oleh user
   - Cek di Mikrotik: `/ip hotspot active print` â†’ kolom "address"

3. **NAS-IP-Address salah**
   - Harus pakai IP Mikrotik yang **menerima** RADIUS request
   - Biasanya sama dengan `nasipaddress` di tabel `radacct`

---

## Test Script

Gunakan script `/root/test-coa.sh` di VPS untuk test manual:

```bash
ssh -p 9500 root@103.191.165.156 /root/test-coa.sh
```

**Output sukses:**
```
Received Disconnect-ACK Id 236 from 172.20.30.11:3799 to 0.0.0.0:54877 length 20
âœ“ CoA command sent successfully
```

**Output gagal:**
```
(0) No reply from server for ID 236 socket 3
âœ— CoA command failed
```

---

## Verifikasi Auto-Disconnect Bekerja

### 1. Buat voucher test (validity 2 menit)

Di web admin:
- Admin â†’ Hotspot â†’ Voucher â†’ Generate
- Profile: pilih profile hotspot
- Validity: 2 Minute
- Quantity: 1

### 2. Login dengan voucher

Dari client hotspot, login dengan voucher yang baru dibuat.

### 3. Tunggu sampai expired

Setelah 2 menit, voucher akan expired. Cek PM2 logs di VPS:

```bash
ssh -p 9500 root@103.191.165.156 "pm2 logs --lines 50 | grep 'CoA\|Disconnect'"
```

**Output yang benar:**
```
[CRON] Found active session for EXPIRED voucher XXXXXX - disconnecting
[CoA] Disconnecting XXXXXX from 172.20.30.11:3799
[CoA] âœ“ Successfully sent disconnect for XXXXXX
[CRON] âœ“ Disconnected XXXXXX from test (172.20.30.11)
```

### 4. Verifikasi user ter-disconnect

- Cek di Mikrotik: `/ip hotspot active print` â†’ voucher sudah hilang
- Cek di web: Admin â†’ Sessions â†’ Hotspot â†’ voucher sudah hilang
- Client akan otomatis redirect ke login page

---

## Catatan Penting

### Kenapa CoA Penting?

Tanpa CoA, user yang voucher-nya sudah expired bisa **tetap online** sampai:
- Koneksi terputus manual (reboot, logout)
- Session timeout dari Mikrotik
- Network disconnect

Dengan CoA, user **langsung ter-kick** begitu voucher expired.

### Alternatif Jika CoA Tidak Bisa Dipakai

Jika Mikrotik di belakang NAT/firewall yang tidak bisa dibuka port 3799:

1. **Session Timeout di Hotspot Profile**
   - Set `Session Timeout` di Mikrotik Hotspot Profile (misal 1 jam)
   - User akan auto-disconnect setelah timeout
   - **Kekurangan:** Tidak instant, masih bisa online beberapa lama

2. **Idle Timeout**
   - Set `Idle Timeout` di Hotspot Profile
   - User disconnect jika idle (tidak ada traffic)
   - **Kekurangan:** User yang aktif tetap online walau expired

3. **Manual Disconnect via Mikrotik API**
   - Aplikasi connect ke Mikrotik API dan hapus session manual
   - **Kekurangan:** Butuh Mikrotik API enabled, lebih kompleks

**Rekomendasi:** Selalu gunakan CoA untuk hasil terbaik.

---

## Support

Jika masih bermasalah setelah mengikuti guide ini:

1. Export Mikrotik config dan cek bagian `/radius` dan `/radius incoming`
2. Cek PM2 logs: `pm2 logs --lines 200 | grep CoA`
3. Test manual dengan script `/root/test-coa.sh`
4. Screenshoot error dan log untuk troubleshooting lebih lanjut


## [23] COA_TROUBLESHOOTING_WORKFLOW.md


# Solusi CoA Disconnect untuk Hotspot Voucher Expired

## Analisis Masalah

### Status Saat Ini
- âœ… Network connectivity: VPS dapat ping dan reach port 3799 UDP Mikrotik
- âœ… CoA enabled di Mikrotik: `/radius incoming accept=yes port=3799`
- âœ… Secret benar: `secret123`
- âŒ **Mikrotik tidak merespon CoA request:** `No reply from server`

### Root Cause Analysis

Masalah **"No reply from server"** biasanya disebabkan oleh:

1. **Secret di RADIUS Incoming berbeda dengan RADIUS Client**
   - Mikrotik punya 2 tempat konfigurasi RADIUS dengan secret berbeda:
     - `/radius` â†’ secret untuk **outgoing** (Mikrotik â†’ FreeRADIUS)
     - `/radius incoming` â†’ secret untuk **incoming** (FreeRADIUS â†’ Mikrotik)
   - **Keduanya HARUS pakai secret yang SAMA!**

2. **RADIUS Incoming belum fully initialized**
   - Perlu restart Mikrotik atau service RADIUS
   - Beberapa versi RouterOS butuh reboot setelah enable incoming

3. **Attribute mismatch**
   - Mikrotik strict pada attribute matching
   - Butuh Calling-Station-Id (MAC address) untuk beberapa kasus

---

## âœ… SOLUSI EFEKTIF (Tanpa API)

### LANGKAH 1: Verifikasi Secret di Mikrotik

**PENTING:** Secret di `/radius` dan `/radius incoming` HARUS SAMA!

```routeros
# 1. Cek secret di RADIUS Client (outgoing)
/radius print detail

# Output contoh:
# 0   service=hotspot,pppoe address=103.191.165.156 
#     secret="secret123" timeout=5s00ms

# 2. Set secret di RADIUS Incoming (incoming) - HARUS SAMA!
/radius incoming
set accept=yes
set default-secret="secret123"
print

# Output yang BENAR:
#   accept: yes
#     port: 3799
# default-secret: secret123
```

**Catatan Penting:**
- Jika `/radius incoming` tidak punya parameter `default-secret`, tambahkan manual
- Secret harus **PERSIS SAMA** dengan secret di `/radius`
- Setelah set secret, **RESTART Mikrotik** agar efektif

### LANGKAH 2: Restart Mikrotik (PENTING!)

```routeros
# Restart RADIUS service atau reboot Mikrotik
/system reboot
```

Banyak kasus CoA tidak bekerja karena **RADIUS Incoming belum fully initialized** setelah konfigurasi. Restart Mikrotik akan memastikan semua service berjalan dengan benar.

### LANGKAH 3: Test Ulang CoA Setelah Restart

Di VPS, jalankan:

```bash
ssh -p 9500 root@103.191.165.156 /root/test-coa.sh
```

**Jika SUKSES, output:**
```
Received Disconnect-ACK Id 236 from 172.20.30.11:3799
âœ“ CoA command sent successfully
```

**Jika MASIH GAGAL,** lanjut ke Step 4.

---

### LANGKAH 4: Tambahkan Calling-Station-Id (MAC Address)

Beberapa versi Mikrotik membutuhkan **MAC address** sebagai identifier untuk CoA.

Update file `src/lib/services/coaService.ts`:

```typescript
// Tambahkan Calling-Station-Id jika ada MAC address
const coaAttributes = [
  `NAS-IP-Address=${nasIpAddress}`,
  `Framed-IP-Address=${framedIpAddress}`,
  `User-Name=${username}`,
]

if (acctSessionId) {
  coaAttributes.push(`Acct-Session-Id=${acctSessionId}`)
}

// TAMBAHAN: Coba cari MAC address dari radacct
if (acctSessionId) {
  const session = await prisma.radacct.findFirst({
    where: { acctsessionid: acctSessionId },
    select: { callingstationid: true }
  })
  
  if (session?.callingstationid) {
    coaAttributes.push(`Calling-Station-Id=${session.callingstationid}`)
  }
}
```

---

### LANGKAH 5: Gunakan DM (Disconnect-Message) Code

Beberapa Mikrotik lebih responsif terhadap **code 40 (Disconnect-Request)** dengan packet type yang spesifik.

Update command di `coaService.ts`:

```typescript
// Gunakan code 40 explicitly
const command = `radclient -t 3 -r 3 -x ${nasIpAddress}:3799 40 ${nasSecret} < ${tmpFile} 2>&1`
```

Parameter:
- `-t 3` = timeout 3 detik
- `-r 3` = retry 3 kali
- `40` = Disconnect-Request code (explicit)

---

## ðŸ”§ SOLUSI ALTERNATIF (Jika CoA Tetap Gagal)

### Opsi A: Hybrid Session Timeout + CoA

Jika Mikrotik tetap tidak merespon CoA, gunakan **Session Timeout** di Hotspot Profile sebagai backup:

**Di Mikrotik:**
```routeros
# Set session timeout di RADIUS reply
# File: /etc/freeradius/mods-available/sql
```

**Update radgroupreply saat sync voucher:**
```typescript
// Di src/lib/hotspot-radius-sync.ts
await prisma.radgroupreply.create({
  data: {
    groupname: uniqueGroupName,
    attribute: 'Session-Timeout',
    op: ':=',
    value: String(voucher.profile.validityMinutes * 60) // dalam detik
  }
})
```

**Keuntungan:**
- Session otomatis disconnect setelah timeout (tanpa CoA)
- FreeRADIUS yang kontrol, bukan aplikasi
- Lebih reliable untuk network yang unstable

**Kekurangan:**
- User bisa tetap online beberapa menit setelah expired
- Tidak instant seperti CoA

---

### Opsi B: Periodic Session Validation

Tambahkan cron job yang **mark session sebagai stop** di database jika voucher expired:

```typescript
// Di src/lib/cron/voucher-sync.ts

// Setelah mark voucher as EXPIRED
if (activeSession) {
  // Update radacct langsung (tanpa CoA)
  await prisma.radacct.update({
    where: { radacctid: activeSession.radacctid },
    data: {
      acctstoptime: new Date(),
      acctterminatecause: 'Admin-Reset',
      acctsessiontime: Math.floor((Date.now() - new Date(activeSession.acctstarttime).getTime()) / 1000)
    }
  })
  
  console.log(`[CRON] âœ“ Marked session ${voucher.code} as stopped in database`)
}
```

**Update UI untuk check acctterminatecause:**

Di query active sessions, tambahkan filter:
```typescript
where: {
  acctstoptime: null,
  acctterminatecause: { not: 'Admin-Reset' } // Exclude manual stop
}
```

**Keuntungan:**
- Session hilang dari UI immediately
- Tidak perlu CoA bekerja
- Database tetap akurat

**Kekurangan:**
- User fisik masih bisa online (Mikrotik belum disconnect)
- Butuh Mikrotik Idle Timeout untuk force disconnect
- Accounting tidak 100% akurat

---

### Opsi C: Force MAC Binding + Session Count Limit

Jika CoA tidak critical, gunakan **pencegahan** bukan disconnect:

1. **Lock MAC Address:**
   ```typescript
   // Di radcheck, tambahkan MAC binding
   await prisma.radcheck.create({
     data: {
       username: voucher.code,
       attribute: 'Calling-Station-Id',
       op: ':=',
       value: macAddress // dari first login
     }
   })
   ```

2. **Limit Concurrent Sessions:**
   ```typescript
   await prisma.radcheck.create({
     data: {
       username: voucher.code,
       attribute: 'Simultaneous-Use',
       op: ':=',
       value: '1'
     }
   })
   ```

**Keuntungan:**
- User tidak bisa login lagi setelah expired (radcheck deleted)
- Mencegah abuse (1 voucher = 1 device)
- Tidak butuh CoA

**Kekurangan:**
- Session aktif tetap jalan sampai user logout manual
- Butuh kombinasi dengan Session Timeout

---

## ðŸŽ¯ REKOMENDASI WORKFLOW TERBAIK

### Implementasi Bertahap

#### FASE 1: Fix CoA (Priority Tinggi)
1. âœ… Set `default-secret` di `/radius incoming` Mikrotik
2. âœ… Restart Mikrotik
3. âœ… Test dengan `/root/test-coa.sh`
4. âœ… Jika sukses, CoA ready!

#### FASE 2: Tambah Session Timeout (Backup Layer)
1. Update `radgroupreply` untuk include `Session-Timeout`
2. Set timeout = validity voucher (misal 2 jam = 7200 detik)
3. User auto-disconnect setelah timeout (walau CoA gagal)

#### FASE 3: Database Cleanup (Safety Net)
1. Cron mark `acctstoptime` untuk expired vouchers
2. UI filter session yang sudah di-mark
3. Database tetap clean walau Mikrotik belum disconnect

#### FASE 4: Prevention (Long Term)
1. Enable MAC binding untuk voucher
2. Limit concurrent sessions = 1
3. Prevent abuse dan multi-login

---

## ðŸ“‹ Checklist Troubleshooting

Ikuti urutan ini untuk fix CoA:

- [ ] **Step 1:** Verify secret di `/radius incoming` sama dengan `/radius`
- [ ] **Step 2:** Set `default-secret="secret123"` di `/radius incoming`
- [ ] **Step 3:** Restart Mikrotik (reboot)
- [ ] **Step 4:** Test CoA: `/root/test-coa.sh`
- [ ] **Step 5:** Jika sukses, monitor PM2 logs untuk auto-disconnect
- [ ] **Step 6:** Jika gagal, implement Session Timeout (Opsi A)
- [ ] **Step 7:** Implement database cleanup (Opsi B) sebagai backup
- [ ] **Step 8:** Add MAC binding (Opsi C) untuk prevention

---

## ðŸ” Verifikasi di Mikrotik

Setelah semua setup, verify dengan command berikut:

```routeros
# 1. Cek RADIUS Incoming
/radius incoming print

# Output yang BENAR:
#   accept: yes
#     port: 3799
# default-secret: secret123

# 2. Cek RADIUS Client
/radius print detail

# Secret harus SAMA dengan incoming!

# 3. Enable logging untuk debug
/system logging
add topics=radius,debug,!packet action=memory

# 4. Test login dengan voucher, tunggu expired, cek log
/log print where topics~"radius"

# Cari log: "received disconnect request" atau "disconnect ack"
```

---

## ðŸ’¡ Kesimpulan

**Prioritas implementasi:**

1. **Fix CoA** (secret + restart) - 95% masalah selesai di sini
2. **Session Timeout** - Backup jika CoA gagal
3. **Database Cleanup** - Safety net untuk UI consistency
4. **MAC Binding** - Prevention untuk abuse

**Jangan pakai Mikrotik API** karena:
- âŒ Overhead untuk cron job (setiap menit)
- âŒ Butuh RouterOS API library
- âŒ Connection pool management kompleks
- âŒ Security risk (harus expose API port)

**Gunakan FreeRADIUS standard CoA** karena:
- âœ… Lightweight (UDP packet)
- âœ… RFC 5176 standard
- âœ… No extra dependencies
- âœ… Supported semua Mikrotik modern
- âœ… Built-in di FreeRADIUS

---

**Next Steps:**
1. Set secret di Mikrotik `/radius incoming`
2. Reboot Mikrotik
3. Test dengan script yang sudah ada
4. Report hasilnya


## [24] MULTIPLE_NAS_SAME_IP.md


# Multiple NAS with Same IP Address Support

**Date**: December 21, 2025  
**Version**: v2.7.4  
**Module**: Network / Router NAS Management  

---

## ðŸŽ¯ Feature Overview

Sistem sekarang mendukung **multiple router/NAS dengan IP VPN yang sama**, selama kombinasi **port RADIUS** dan **secret** berbeda.

### Use Case

Scenario: Anda punya **beberapa MikroTik** di lokasi berbeda yang terhubung ke VPS melalui **VPN dengan IP yang sama** (misalnya `10.10.10.1`).

**Before (v2.7.3)**:
- âŒ Tidak bisa menambahkan router kedua dengan IP VPN sama
- âŒ Error: `nasname must be unique`
- âŒ Workaround: Harus gunakan IP berbeda

**After (v2.7.4)**:
- âœ… Bisa tambah multiple router dengan IP VPN sama
- âœ… Bedakan dengan **port RADIUS** atau **secret** yang berbeda
- âœ… Setiap router tetap punya konfigurasi API sendiri (username, password, API port)

---

## ðŸ“Š Technical Changes

### 1. Database Schema Update

**File**: `prisma/schema.prisma`

**Before**:
```prisma
model router {
  nasname        String             @unique  // âŒ Tidak allow duplicate IP
  ...
}
```

**After**:
```prisma
model router {
  nasname        String             // âœ… Allow duplicate IP
  ...
  
  @@unique([nasname, ports, secret], name: "unique_nas_config")
  // âœ… Unique combination: IP + port + secret
}
```

### 2. Migration SQL

**File**: `prisma/migrations/20251221004655_allow_duplicate_nas_ip/migration.sql`

```sql
-- Drop unique constraint on nasname
DROP INDEX `nas_nasname_key` ON `nas`;

-- Add composite unique constraint
ALTER TABLE `nas` 
ADD UNIQUE KEY `unique_nas_config` (`nasname`, `ports`, `secret`);
```

### 3. API Validation

**File**: `src/app/api/network/routers/route.ts`

**Added validation before save**:
```typescript
// Check for duplicate NAS configuration
const existingNas = await prisma.router.findFirst({
  where: {
    nasname,
    ports: radiusPort,
    secret: radiusSecret,
  },
});

if (existingNas) {
  return NextResponse.json({
    error: 'Duplicate NAS configuration',
    details: `Router dengan IP ${nasname}, port ${radiusPort}, dan secret yang sama sudah ada`,
  }, { status: 409 });
}
```

**Enhanced error handling**:
```typescript
// Prisma unique constraint error (P2002)
if (error.code === 'P2002') {
  return 'IP VPN bisa sama, tapi kombinasi port RADIUS dan secret harus unik'
}
```

---

## ðŸ”§ Configuration Examples

### Example 1: Same VPN IP, Different Ports

**Router 1**:
```
Name: MikroTik Cabang A
IP Address: 192.168.1.1
NAS IP (VPN): 10.10.10.1
Port API: 8728
Port RADIUS: 1812  â¬…ï¸ Port berbeda
Secret: secret123
```

**Router 2**:
```
Name: MikroTik Cabang B
IP Address: 192.168.2.1
NAS IP (VPN): 10.10.10.1  â¬…ï¸ IP VPN sama!
Port API: 8728
Port RADIUS: 1813  â¬…ï¸ Port berbeda
Secret: secret123
```

âœ… **Allowed** - Port RADIUS berbeda (`1812` vs `1813`)

---

### Example 2: Same VPN IP, Different Secrets

**Router 1**:
```
NAS IP (VPN): 10.10.10.1
Port RADIUS: 1812
Secret: secret123  â¬…ï¸ Secret berbeda
```

**Router 2**:
```
NAS IP (VPN): 10.10.10.1  â¬…ï¸ IP VPN sama!
Port RADIUS: 1812
Secret: secret456  â¬…ï¸ Secret berbeda
```

âœ… **Allowed** - Secret berbeda (`secret123` vs `secret456`)

---

### Example 3: Exact Duplicate (Not Allowed)

**Router 1**:
```
NAS IP (VPN): 10.10.10.1
Port RADIUS: 1812
Secret: secret123
```

**Router 2**:
```
NAS IP (VPN): 10.10.10.1  â¬…ï¸ Semua sama!
Port RADIUS: 1812         â¬…ï¸ Semua sama!
Secret: secret123         â¬…ï¸ Semua sama!
```

âŒ **NOT ALLOWED** - Kombinasi IP + port + secret sudah ada

**Error**:
```
Duplicate NAS configuration
Router dengan IP 10.10.10.1, port 1812, dan secret yang sama sudah ada (MikroTik Cabang A).
Gunakan port atau secret yang berbeda.
```

---

## ðŸŽ¯ How It Works

### 1. FreeRADIUS NAS Table

FreeRADIUS mengidentifikasi client (router) berdasarkan:
- **IP address** (nasname) - IP source request RADIUS
- **Port** (ports) - Port RADIUS yang digunakan
- **Secret** - Shared secret untuk enkripsi

**NAS Table (`nas`)**:
```sql
+----+----------+-----------+-------+--------+
| id | nasname  | ports     | secret| name   |
+----+----------+-----------+-------+--------+
| 1  |10.10.10.1| 1812      | sec123| CabangA|
| 2  |10.10.10.1| 1813      | sec123| CabangB| âœ… Allowed
| 3  |10.10.10.1| 1812      | sec456| CabangC| âœ… Allowed
+----+----------+-----------+-------+--------+
```

### 2. Request Flow

**Router 1 (Port 1812)**:
```
MikroTik 10.10.10.1:1812 
  â†’ FreeRADIUS (match: IP=10.10.10.1, Port=1812, Secret=sec123)
  â†’ CabangA
  â†’ Authorize user
```

**Router 2 (Port 1813)**:
```
MikroTik 10.10.10.1:1813
  â†’ FreeRADIUS (match: IP=10.10.10.1, Port=1813, Secret=sec123)
  â†’ CabangB
  â†’ Authorize user
```

FreeRADIUS menggunakan **kombinasi IP + port** untuk routing request ke router yang tepat.

---

## ðŸ“‹ Deployment Checklist

### Step 1: Update Code
```bash
git pull origin main
```

### Step 2: Run Migration
```bash
cd /var/www/salfanet-radius
npx prisma migrate deploy
```

Expected output:
```
Applying migration `20251221004655_allow_duplicate_nas_ip`
âœ” Generated Prisma Client
```

### Step 3: Verify Schema
```bash
npx prisma db pull
```

Check `schema.prisma`:
```prisma
@@unique([nasname, ports, secret], name: "unique_nas_config")
```

### Step 4: Restart Application
```bash
npm run build
pm2 restart salfanet-radius
```

### Step 5: Test
1. Tambah router pertama dengan IP VPN `10.10.10.1`, port `1812`
2. Tambah router kedua dengan IP VPN `10.10.10.1`, port `1813`
3. Coba tambah router ketiga dengan IP + port + secret sama â†’ harus error

---

## ðŸ§ª Testing Scenarios

### Test 1: Add Router with Same IP, Different Port

**Request**:
```json
POST /api/network/routers
{
  "name": "MikroTik Cabang B",
  "ipAddress": "192.168.2.1",
  "nasIpAddress": "10.10.10.1",
  "username": "admin",
  "password": "password",
  "port": 8728,
  "secret": "secret123"
  // Port RADIUS auto = 1813 (jika 1812 sudah ada)
}
```

**Expected**: âœ… Success

### Test 2: Add Router with Same IP, Same Port, Same Secret

**Request**:
```json
POST /api/network/routers
{
  "name": "Duplicate Router",
  "ipAddress": "192.168.3.1",
  "nasIpAddress": "10.10.10.1",
  "secret": "secret123"
  // Port RADIUS default = 1812
}
```

**Expected**: âŒ Error 409 Conflict
```json
{
  "error": "Duplicate NAS configuration",
  "details": "Router dengan IP 10.10.10.1, port 1812, dan secret yang sama sudah ada",
  "hint": "Gunakan port atau secret yang berbeda untuk IP VPN yang sama"
}
```

### Test 3: Add Router with Same IP, Different Secret

**Request**:
```json
POST /api/network/routers
{
  "name": "MikroTik Cabang C",
  "ipAddress": "192.168.4.1",
  "nasIpAddress": "10.10.10.1",
  "secret": "secret456"  // Secret berbeda
}
```

**Expected**: âœ… Success

---

## ðŸ” Troubleshooting

### Error: "nasname must be unique"

**Problem**: Migration belum running

**Solution**:
```bash
npx prisma migrate deploy
npx prisma generate
pm2 restart salfanet-radius
```

### Error: "P2002: Unique constraint failed"

**Problem**: Router dengan kombinasi IP + port + secret yang sama sudah ada

**Solution**:
- Gunakan port RADIUS berbeda (1813, 1814, dst)
- Atau gunakan secret berbeda
- Atau update router yang sudah ada

### FreeRADIUS tidak authorize user

**Problem**: Port RADIUS di MikroTik tidak match dengan NAS table

**Solution**:
Check MikroTik RADIUS client config:
```routeros
/radius
print
# Pastikan port sama dengan yang di NAS table
```

---

## ðŸ“Š Database Impact

### Before Migration

```sql
SHOW CREATE TABLE nas;

UNIQUE KEY `nas_nasname_key` (`nasname`)  -- âŒ Block duplicate IP
```

### After Migration

```sql
SHOW CREATE TABLE nas;

UNIQUE KEY `unique_nas_config` (`nasname`,`ports`,`secret`)  -- âœ… Allow duplicate IP
```

### Query Performance

**No performance impact** - Index tetap optimal:
- Composite unique index pada `(nasname, ports, secret)`
- Index individual pada `nasname` tetap ada
- FreeRADIUS query tetap fast

---

## ðŸ“š Related Documentation

- **FreeRADIUS NAS Table**: [docs/FREERADIUS-SETUP.md](FREERADIUS-SETUP.md)
- **Router Management**: [docs/DEPLOYMENT-GUIDE.md](DEPLOYMENT-GUIDE.md)
- **Database Schema**: [prisma/schema.prisma](../prisma/schema.prisma)

---

## âœ… Summary

**What Changed**:
- âœ… Database schema: `nasname` unique constraint â†’ composite unique `(nasname, ports, secret)`
- âœ… API validation: Check duplicate sebelum save
- âœ… Error handling: Informative message untuk duplicate config
- âœ… Migration: Automatic database update

**Benefits**:
- âœ… Multiple router dengan IP VPN sama
- âœ… Flexible configuration (port atau secret berbeda)
- âœ… No breaking changes (existing routers tetap work)
- âœ… Better error messages

**Compatibility**:
- âœ… FreeRADIUS 3.x
- âœ… MySQL/MariaDB
- âœ… Existing routers tidak terpengaruh
- âœ… Backward compatible

---

**Updated**: December 21, 2025  
**Version**: v2.7.4  
**Status**: Production Ready âœ…


## [25] GPS_LOCATION_FEATURE.md


# Fitur Lokasi GPS untuk Registrasi Pelanggan

## Deskripsi
Fitur ini memungkinkan pelanggan yang mendaftar untuk menandai lokasi GPS mereka, dan admin dapat melihat lokasi tersebut melalui Google Maps.

## Perubahan yang Dilakukan

### 1. Database Schema
- **File**: `prisma/schema.prisma`
- **Perubahan**: Menambahkan field `latitude` dan `longitude` (Float, nullable) ke model `registrationRequest`

### 2. Migration
- **File**: `prisma/migrations/20251216_add_location_to_registration/migration.sql`
- **SQL**: 
  ```sql
  ALTER TABLE `registration_requests` 
  ADD COLUMN `latitude` DOUBLE NULL,
  ADD COLUMN `longitude` DOUBLE NULL;
  ```

### 3. Halaman Pendaftaran Pelanggan
- **File**: `src/app/daftar/page.tsx`
- **Fitur Baru**:
  - Input lokasi GPS (opsional)
  - Button "Pilih Lokasi di Peta" untuk membuka MapPicker
  - Menampilkan koordinat yang dipilih
  - Menggunakan komponen `MapPicker` yang sudah ada

### 4. API Endpoint
- **File**: `src/app/api/registrations/route.ts`
- **Perubahan**: Menerima dan menyimpan `latitude` dan `longitude` dari form pendaftaran

### 5. Halaman Admin
- **File**: `src/app/admin/pppoe/registrations/page.tsx`
- **Fitur Baru**:
  - Kolom "Lokasi" di tabel registrasi
  - Tombol "Lihat Lokasi" yang membuka Google Maps di tab baru
  - Menampilkan koordinat saat hover pada tombol
  - Jika tidak ada lokasi GPS, tampilkan "-"

## Cara Menggunakan

### Untuk Pelanggan
1. Buka halaman pendaftaran (`/daftar`)
2. Isi form pendaftaran seperti biasa
3. Klik tombol "Pilih Lokasi di Peta" (opsional)
4. Pilih lokasi dengan mengklik pada peta
5. Klik "Select Location" untuk menyimpan
6. Submit form pendaftaran

### Untuk Admin
1. Buka halaman Registrations (`/admin/pppoe/registrations`)
2. Di tabel, lihat kolom "Lokasi"
3. Jika pelanggan mengisi lokasi GPS, akan tampil tombol "Lihat Lokasi"
4. Klik tombol tersebut untuk membuka lokasi di Google Maps
5. Hover pada tombol untuk melihat koordinat lengkap

## Komponen yang Digunakan
- **MapPicker**: Komponen yang sudah ada di `src/components/MapPicker.tsx`
- Menggunakan Leaflet untuk menampilkan peta interaktif
- Support multiple basemap (street, satellite)
- Support marker drag untuk memilih lokasi

## Database Field
- **latitude**: DOUBLE NULL - Koordinat latitude lokasi pelanggan
- **longitude**: DOUBLE NULL - Koordinat longitude lokasi pelanggan
- Kedua field bersifat opsional (nullable)

## Link Google Maps
Format URL: `https://www.google.com/maps?q={latitude},{longitude}`
- Membuka di tab baru
- Langsung menampilkan marker di lokasi yang dipilih


## [26] IMPORT_PPPOE_USERS.md


# Fitur Import User PPPoE dari Excel/CSV

## Deskripsi
Fitur ini memungkinkan admin untuk mengimpor data user PPPoE dalam jumlah banyak (bulk import) menggunakan file Excel (.xlsx) atau CSV.

## File yang Diubah

### 1. Backend API
- **File**: `src/app/api/pppoe/users/bulk/route.ts`
- **Perubahan**:
  - Menambahkan library `xlsx` untuk membaca file Excel
  - Support download template dalam format Excel (.xlsx) dan CSV
  - Support upload dan parsing file Excel (.xlsx, .xls) dan CSV
  - Validasi dan import data user ke database
  - Sync otomatis ke RADIUS (radcheck dan radusergroup)

### 2. Frontend
- **File**: `src/app/admin/pppoe/users/page.tsx`
- **Perubahan**:
  - Tombol "Template Excel" untuk download template XLSX
  - Dialog import yang support file Excel dan CSV
  - Update file input untuk accept `.csv,.xlsx,.xls`
  - Informasi format file yang didukung

### 3. Dependencies
- **Package**: `xlsx` (sudah terinstall)
- Digunakan untuk membaca dan menulis file Excel

## Cara Menggunakan

### Download Template
1. Buka halaman PPPoE Users (`/admin/pppoe/users`)
2. Klik tombol **"Template Excel"** untuk download template dalam format XLSX
3. File `pppoe-users-template.xlsx` akan terdownload

### Format Template Excel
Template berisi kolom-kolom berikut:

| Kolom | Wajib | Deskripsi | Contoh |
|-------|-------|-----------|---------|
| username | Ya | Username PPPoE (unique) | user001 |
| password | Ya | Password PPPoE | pass123 |
| name | Ya | Nama lengkap pelanggan | John Doe |
| phone | Ya | Nomor telepon | 08123456789 |
| email | Tidak | Email pelanggan | john@example.com |
| address | Tidak | Alamat lengkap | Jl. Example No. 123 |
| ipAddress | Tidak | IP Address static | 10.10.10.2 |
| expiredAt | Tidak | Tanggal expired (YYYY-MM-DD) | 2025-12-31 |
| latitude | Tidak | Koordinat GPS latitude | -6.200000 |
| longitude | Tidak | Koordinat GPS longitude | 106.816666 |

### Import Data
1. Klik tombol **"Import"**
2. Dialog import akan terbuka
3. **Pilih File**: Upload file Excel (.xlsx, .xls) atau CSV
4. **Pilih Profile**: Pilih profile PPPoE untuk semua user yang diimport
5. **Pilih NAS** (opsional): Pilih router/NAS atau biarkan "Global"
6. Klik tombol **"Import"**
7. Sistem akan memproses dan menampilkan hasil:
   - Jumlah user berhasil diimport
   - Jumlah user gagal (jika ada)
   - Detail error untuk setiap baris yang gagal

## Validasi Import

### Validasi File
- File harus berformat CSV atau Excel (.xlsx, .xls)
- Minimal harus ada 1 baris data (selain header)
- Header harus mengandung kolom wajib: username, password, name, phone

### Validasi Data
Per baris data akan divalidasi:
1. **Field Wajib**: username, password, name, phone harus diisi
2. **Username Unique**: Username tidak boleh sudah ada di database
3. **Format Tanggal**: expiredAt harus format YYYY-MM-DD
4. **Format Koordinat**: latitude dan longitude harus berupa angka desimal

### Error Handling
Jika ada error, sistem akan:
- Tetap import data yang valid
- Skip data yang error
- Menampilkan detail error:
  - Nomor baris yang error
  - Username yang error
  - Pesan error

## Proses Import

### Alur Proses
1. **Upload File** â†’ File Excel/CSV diupload ke server
2. **Parse File** â†’ Data dibaca dan di-parse (xlsx untuk Excel, text parsing untuk CSV)
3. **Validasi** â†’ Setiap baris data divalidasi
4. **Generate Customer ID** â†’ Generate ID pelanggan unik (8 karakter)
5. **Create User** â†’ Insert ke tabel `pppoe_users`
6. **Sync RADIUS** â†’ Insert/update ke tabel `radcheck` dan `radusergroup`
7. **Result** â†’ Tampilkan hasil import (success/failed count)

### Data yang Tersimpan
Untuk setiap user yang berhasil diimport:
- **pppoe_users**: Data user lengkap
- **radcheck**: Password untuk autentikasi RADIUS
- **radusergroup**: Group/profile untuk authorization RADIUS

## Keunggulan Format Excel

### Dibanding CSV:
1. **User-Friendly**: Lebih mudah diedit dengan Excel/LibreOffice
2. **Format Preserved**: Format tanggal, angka, dll tetap terjaga
3. **Styling**: Template bisa diberi warna, border, dll untuk panduan
4. **Multiple Sheets**: Bisa menambah sheet untuk dokumentasi/referensi
5. **Column Width**: Lebar kolom sudah diatur otomatis

### Template Excel Features:
- Header dengan nama kolom yang jelas
- 2 baris contoh data sebagai referensi
- Lebar kolom sudah dioptimalkan untuk kemudahan baca
- Format professional

## Testing

### Test Case 1: Import Excel Valid
- Upload file template.xlsx dengan data valid
- Semua user berhasil diimport
- Status "active" by default

### Test Case 2: Import dengan Username Duplicate
- Upload file dengan username yang sudah ada
- User duplicate akan di-skip
- User lain tetap diimport

### Test Case 3: Import CSV
- Upload file CSV dengan format sama
- Sistem tetap bisa membaca dan import data

### Test Case 4: Import dengan Field Opsional Kosong
- Email, address, ipAddress kosong
- Import tetap berhasil dengan nilai NULL

## Troubleshooting

### File tidak bisa dibaca
- Pastikan format file .xlsx, .xls, atau .csv
- Cek apakah file corrupt atau password-protected

### Import gagal semua
- Cek apakah header file sesuai template
- Pastikan ada data di baris kedua (bukan hanya header)

### Beberapa user gagal diimport
- Lihat detail error di hasil import


## [27] CUSTOMER_WIFI_SELFSERVICE.md


# Customer WiFi Self-Service Documentation

## ðŸ“‹ Overview

Fitur WiFi Self-Service memungkinkan pelanggan untuk mengelola konfigurasi WiFi mereka sendiri tanpa perlu menghubungi admin. Sistem ini terintegrasi dengan GenieACS untuk manajemen perangkat ONT/CPE secara real-time.

## âœ¨ Features

### 1. WiFi Information Dashboard
- **View WiFi Networks**: Melihat semua jaringan WiFi (2.4GHz dan 5GHz)
- **Device Status**: Status online/offline perangkat ONT
- **Connected Devices**: Jumlah device yang terhubung ke WiFi
- **Network Details**: SSID, Channel, Security, Standard (802.11n/ac/ax)
- **Signal Information**: RX Power, TX Power, Temperature

### 2. WiFi Management
- **Edit SSID**: Mengubah nama WiFi (1-32 karakter)
- **Change Password**: Mengubah password WiFi (8-63 karakter)
- **Security Mode**: Support WPA2-PSK encryption
- **Auto Reboot**: Device otomatis restart setelah perubahan
- **Real-time Update**: Perubahan langsung apply ke perangkat

### 3. Connected Devices Management
- **Device List**: Daftar semua device yang terhubung
- **Device Info**: MAC Address, IP Address, Hostname
- **Device Type Detection**: Auto-detect Android, iPhone, Laptop, Desktop
- **Active Status**: Status aktif/idle setiap device
- **Signal Strength**: Kekuatan sinyal WiFi per device

### 4. Package Upgrade via Payment Gateway
- **View Packages**: Lihat semua paket internet available
- **Compare Plans**: Bandingkan kecepatan dan harga
- **Upgrade Request**: Request upgrade paket
- **Auto Invoice**: Generate invoice otomatis
- **Payment Gateway**: Redirect ke payment gateway (Midtrans)
- **Auto Apply**: Paket otomatis aktif setelah pembayaran

## ðŸŽ¨ User Interface

### WiFi Dashboard
```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  Manajemen WiFi              [Refresh]  â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  ðŸ“Š Status Perangkat                    â”‚
â”‚  Model: Huawei HG8145V5                 â”‚
â”‚  Serial: 48575443C7XXXXXX               â”‚
â”‚  Status: â— Online                       â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  ðŸ“¡ WiFi 2.4GHz          ðŸ”§ [Edit]     â”‚
â”‚  SSID: MyWiFi                           â”‚
â”‚  Band: 2.4GHz | Channel: 6              â”‚
â”‚  Security: WPA2-PSK | Devices: 3        â”‚
â”‚â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”‚
â”‚  ðŸ“¡ WiFi 5GHz            ðŸ”§ [Edit]     â”‚
â”‚  SSID: MyWiFi-5G                        â”‚
â”‚  Band: 5GHz | Channel: 149              â”‚
â”‚  Security: WPA2-PSK | Devices: 2        â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  ðŸ“± Perangkat Terhubung (5)             â”‚
â”‚  â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â” â”‚
â”‚  â”‚ ðŸ“± Samsung Galaxy | 192.168.1.10   â”‚ â”‚
â”‚  â”‚ ðŸ’» MacBook Pro    | 192.168.1.11   â”‚ â”‚
â”‚  â”‚ ðŸ“± iPhone 13      | 192.168.1.12   â”‚ â”‚
â”‚  â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜ â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  âš¡ Upgrade Paket Internet              â”‚
â”‚  [10Mbps] [20Mbps] [50Mbps]            â”‚
â”‚  [Lanjutkan ke Pembayaran]             â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

### WiFi Edit Form
```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚  Edit WiFi Configuration                â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  SSID Baru                              â”‚
â”‚  [MyNewWiFi____________]                â”‚
â”‚                                         â”‚
â”‚  Password Baru                          â”‚
â”‚  [â€¢â€¢â€¢â€¢â€¢â€¢â€¢â€¢â€¢â€¢] ðŸ‘                        â”‚
â”‚                                         â”‚
â”‚  âš ï¸ Perangkat akan restart.             â”‚
â”‚  Koneksi WiFi akan terputus sementara.  â”‚
â”‚                                         â”‚
â”‚  [Simpan Perubahan] [Batal]            â”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

## ðŸ”§ Technical Implementation

### Frontend
**File**: `src/app/customer/wifi/page.tsx`

**Features**:
- React hooks for state management
- Real-time data fetching
- Form validation
- SweetAlert2 for confirmations
- Responsive design (mobile-first)
- Dark mode support

**Key Components**:
```tsx
- WiFi Information Card
- WiFi Edit Form
- Connected Devices Table
- Package Selection Grid
- Device Status Indicators
```

### Backend APIs

#### 1. Get WiFi Info
**Endpoint**: `GET /api/customer/wifi`

**Headers**:
```json
{
  "Authorization": "Bearer <customer_token>"
}
```

**Response**:
```json
{
  "success": true,
  "device": {
    "_id": "00-50-56-XX-XX-XX",
    "pppUsername": "customer1@realm",
    "serialNumber": "48575443C7XXXXXX",
    "model": "EchoLife HG8145V5",
    "manufacturer": "Huawei",
    "status": "Online",
    "wlanConfigs": [
      {
        "index": 1,
        "ssid": "MyWiFi",
        "enabled": true,
        "channel": "6",
        "standard": "802.11n",
        "security": "WPA2-PSK",
        "password": "********",
        "band": "2.4GHz",
        "totalAssociations": 3,
        "bssid": "XX:XX:XX:XX:XX:XX"
      }
    ],
    "connectedHosts": [
      {
        "macAddress": "XX:XX:XX:XX:XX:XX",
        "ipAddress": "192.168.1.10",
        "hostname": "Samsung-Galaxy",
        "associatedDevice": "MyWiFi",
        "active": true,
        "signalStrength": "-45 dBm"
      }
    ]
  }
}
```

#### 2. Update WiFi
**Endpoint**: `POST /api/customer/wifi`

**Headers**:
```json
{
  "Authorization": "Bearer <customer_token>",
  "Content-Type": "application/json"
}
```

**Request Body**:
```json
{
  "deviceId": "00-50-56-XX-XX-XX",
  "wlanIndex": 1,
  "ssid": "MyNewWiFi",
  "password": "NewPassword123",
  "securityMode": "WPA2-PSK",
  "enabled": true
}
```

**Response**:
```json
{
  "success": true,
  "message": "WiFi configuration updated successfully"
}
```

#### 3. Get Packages
**Endpoint**: `GET /api/customer/packages`

**Response**:
```json
{
  "success": true,
  "packages": [
    {
      "id": "pkg-001",
      "name": "Paket 10Mbps",
      "downloadSpeed": 10,
      "uploadSpeed": 10,
      "price": 150000,
      "description": "Paket hemat untuk browsing"
    }
  ]
}
```

#### 4. Upgrade Package
**Endpoint**: `POST /api/customer/upgrade-package`

**Request Body**:
```json
{
  "packageId": "pkg-002"
}
```

**Response**:
```json
{
  "success": true,
  "invoice": {
    "id": "inv-xxx",
    "invoiceNumber": "INV/2025/01/15/0001",
    "amount": 250000,
    "dueDate": "2025-01-22T00:00:00.000Z",
    "paymentLink": "https://app.midtrans.com/snap/v2/..."
  },
  "paymentLink": "https://app.midtrans.com/snap/v2/..."
}
```

## ðŸ”Œ GenieACS Integration

### TR-069 Parameters Used

#### WiFi Configuration
```
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.SSID
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.Enable
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.BeaconType
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.KeyPassphrase
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.PreSharedKey.1.KeyPassphrase
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.Channel
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.Standard
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.TotalAssociations
```

#### Device Information
```
InternetGatewayDevice.DeviceInfo.SerialNumber
InternetGatewayDevice.DeviceInfo.ModelName
InternetGatewayDevice.DeviceInfo.Manufacturer
InternetGatewayDevice.DeviceInfo.SoftwareVersion
```

#### Connected Devices
```
InternetGatewayDevice.LANDevice.1.Hosts.Host.{index}.MACAddress
InternetGatewayDevice.LANDevice.1.Hosts.Host.{index}.IPAddress
InternetGatewayDevice.LANDevice.1.Hosts.Host.{index}.HostName
InternetGatewayDevice.LANDevice.1.WLANConfiguration.{index}.AssociatedDevice.{index}
```

### GenieACS Tasks

#### Set WiFi Parameters
```javascript
{
  "name": "setParameterValues",
  "parameterValues": [
    ["InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.SSID", "NewSSID", "xsd:string"],
    ["InternetGatewayDevice.LANDevice.1.WLANConfiguration.1.KeyPassphrase", "NewPassword", "xsd:string"]
  ]
}
```

#### Reboot Device
```javascript
{
  "name": "reboot"
}
```

## ðŸ” Security Features

### Customer Authentication
- JWT token-based authentication
- Token expiry (24 hours default)
- Secure password hashing (bcrypt)
- IP address logging

### WiFi Security
- WPA2-PSK encryption
- Password complexity validation (8-63 characters)
- SSID length validation (1-32 characters)
- XSS protection on inputs

### API Security
- Rate limiting per customer
- CORS protection
- Request validation
- Error sanitization

## ðŸ“± Responsive Design

### Mobile (< 768px)
- Stacked WiFi cards
- Full-width forms
- Simplified device list
- Touch-optimized buttons

### Tablet (768px - 1024px)
- 2-column WiFi grid
- Compact device table
- Side-by-side package cards

### Desktop (> 1024px)
- 2-column WiFi grid
- Full device table with all columns
- 3-column package grid
- Enhanced hover effects

## ðŸŽ¨ UI/UX Best Practices

### Colors
- **Primary**: Teal (#0d9488) - Actions, WiFi 2.4GHz
- **Secondary**: Purple (#9333ea) - WiFi 5GHz
- **Success**: Green (#22c55e) - Online, Active
- **Warning**: Yellow (#eab308) - Alerts
- **Danger**: Red (#ef4444) - Offline, Error

### Icons
- ðŸ“¡ Wifi - WiFi networks
- ðŸ“± Smartphone - Mobile devices
- ðŸ’» Laptop - Laptops
- ðŸ–¥ï¸ Monitor - Desktops
- âš¡ Zap - Package upgrade
- ðŸ”„ RefreshCw - Refresh data
- âœï¸ Edit2 - Edit WiFi
- ðŸ’¾ Save - Save changes

### Feedback
- **Loading**: Spinner animation
- **Success**: SweetAlert2 success dialog
- **Error**: SweetAlert2 error dialog with details
- **Confirmation**: SweetAlert2 confirmation before actions

## ðŸš€ Usage Flow

### Change WiFi Name/Password

1. Customer login ke customer portal
2. Navigate ke "WiFi Management" menu
3. Click "Edit" button pada WiFi card
4. Input SSID dan password baru
5. Click "Simpan Perubahan"
6. Confirm perubahan pada dialog
7. System kirim task ke GenieACS
8. Device restart otomatis
9. Customer re-connect dengan WiFi baru

### Upgrade Package

1. Customer login ke customer portal
2. Navigate ke "WiFi Management" menu
3. Scroll ke "Upgrade Paket Internet" section
4. Pilih paket yang diinginkan
5. Click "Lanjutkan ke Pembayaran"
6. Confirm upgrade pada dialog
7. System create invoice
8. Redirect ke payment gateway
9. Complete payment
10. Package otomatis aktif setelah payment

## âš™ï¸ Configuration

### Environment Variables
```env
# GenieACS Configuration (already configured)
GENIEACS_URL=http://localhost:7557
GENIEACS_USERNAME=admin
GENIEACS_PASSWORD=password

# JWT Secret
JWT_SECRET=your-secret-key-change-in-production

# Midtrans Payment Gateway (optional)
MIDTRANS_SERVER_KEY=your-server-key
MIDTRANS_CLIENT_KEY=your-client-key
MIDTRANS_IS_PRODUCTION=false

# App URL
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

### GenieACS Setup

Ensure GenieACS is configured with:
1. Device provisioning enabled
2. TR-069 parameters configured
3. Virtual parameters for PPPoE username matching

### Database Schema

No additional schema changes required. Uses existing tables:
- `pppoe_users` - Customer data
- `internet_profiles` - Package data
- `invoices` - Upgrade invoices
- `activity_logs` - Customer actions
- `genieacs_settings` - GenieACS config

## ðŸ› Troubleshooting

### Device Not Found
**Cause**: Device not in GenieACS or PPPoE username mismatch

**Solution**:
1. Check GenieACS device list
2. Verify Virtual Parameter `pppUsername` is set
3. Ensure device has contacted GenieACS recently

### WiFi Update Failed
**Cause**: GenieACS task timeout or device offline

**Solution**:
1. Check device status (must be Online)
2. Verify GenieACS connection
3. Check device supports TR-069 WiFi parameters
4. Review GenieACS logs

### Connected Devices Not Showing
**Cause**: Device doesn't support AssociatedDevice parameter

**Solution**:
1. Check device TR-069 capabilities
2. Use Hosts.Host parameter as fallback
3. Update device firmware if needed

### Payment Gateway Not Working
**Cause**: Midtrans not configured or keys invalid

**Solution**:
1. Configure Midtrans keys in Company settings
2. Verify Midtrans account is active
3. Check Midtrans server/client keys
4. Review Midtrans logs

## ðŸ“Š Metrics & Monitoring

### Customer Actions Logged
- `update_wifi` - WiFi configuration changed
- `package_upgrade_request` - Package upgrade requested
- `wifi_view` - Customer viewed WiFi page

### Success Metrics
- WiFi update success rate
- Package upgrade conversion rate
- Average time to change WiFi
- Customer self-service adoption

## ðŸ”® Future Enhancements

### Planned Features
1. **WiFi Scheduling**: Set WiFi on/off times
2. **Guest Network**: Create temporary guest WiFi
3. **Parental Control**: Block specific devices/websites
4. **Speed Test**: Built-in speedtest integration
5. **Usage Statistics**: WiFi usage per device
6. **QR Code**: Generate QR for WiFi sharing
7. **Multiple Devices**: Support multiple ONTs per customer
8. **Notification**: Push notification on WiFi changes

## ðŸ“š References

- **GenieACS Documentation**: https://genieacs.com/docs/
- **TR-069 Protocol**: ITU-T Recommendation
- **gembok-bill Reference**: https://github.com/alijayanet/gembok-bill
- **Midtrans Snap**: https://docs.midtrans.com/

## ðŸ“ž Support

For technical support or feature requests:
- Email: support@yourcompany.com
- Documentation: /docs/CUSTOMER_WIFI_SELFSERVICE.md
- GitHub Issues: Create issue with label `customer-portal`

---

**Version**: 2.8.0  
**Last Updated**: December 24, 2025  
**Status**: âœ… Ready for Production


## [28] CUSTOMER_LOGIN_BYPASS.md


# Customer Login Bypass System

## ðŸ“‹ Overview

Sistem login customer mendukung dua mode:
1. **Login dengan OTP** - Customer harus verifikasi kode OTP yang dikirim via WhatsApp
2. **Login tanpa OTP (Bypass)** - Customer dapat login langsung tanpa OTP

## ðŸ”§ Konfigurasi

### Mengaktifkan/Menonaktifkan OTP

1. Login ke **Admin Panel**
2. Navigate ke **WhatsApp** > **Notifications**
3. Toggle **"Enable Customer OTP Login"**

**Status OTP ON (Default)**:
- âœ… Customer harus input kode OTP dari WhatsApp
- âœ… Lebih secure
- âœ… Validasi nomor WhatsApp aktif
- âŒ Bergantung pada layanan WhatsApp

**Status OTP OFF (Bypass Mode)**:
- âœ… Customer login langsung tanpa OTP
- âœ… Tidak bergantung WhatsApp
- âœ… Login lebih cepat
- âŒ Kurang secure (hanya validasi nomor terdaftar)

## ðŸŽ¯ Use Cases

### 1. WhatsApp Service Down
Jika layanan WhatsApp sedang bermasalah dan customer tidak bisa terima OTP, admin dapat:
- Nonaktifkan OTP di settings
- Customer langsung bisa login tanpa OTP
- Aktifkan kembali OTP setelah WhatsApp normal

### 2. High Volume Login
Untuk periode dengan banyak customer login bersamaan:
- Nonaktifkan OTP untuk mengurangi beban WhatsApp API
- Hindari rate limiting
- Customer experience lebih smooth

### 3. Development/Testing
Untuk testing atau development:
- Nonaktifkan OTP untuk bypass verification
- Testing lebih cepat tanpa tunggu WhatsApp

## ðŸ” Security Features

### OTP Enabled (Secure Mode)
```
Customer Input Phone â†’ Validate User â†’ Send OTP via WhatsApp
â†’ Customer Input OTP â†’ Verify OTP â†’ Create Session â†’ Login Success
```

**Protection:**
- Rate limiting: Max 3 OTP per 15 menit
- OTP expiry: Default 5 menit (configurable)
- 6-digit random code
- Session verification required

### OTP Disabled (Bypass Mode)
```
Customer Input Phone â†’ Validate User â†’ Create Session â†’ Login Success
```

**Protection:**
- Validate phone number exists in database
- Create verified session immediately
- Activity logging for audit trail
- IP address tracking

## ðŸ“± Customer Login Flow

### With OTP Enabled

1. Customer buka `/login`
2. Input nomor WhatsApp atau Customer ID (8 digit)
3. System check apakah OTP enabled
4. Jika enabled: send OTP via WhatsApp
5. Customer input 6-digit OTP code
6. System verify OTP
7. Jika valid: create session, redirect ke `/customer`

### With OTP Disabled

1. Customer buka `/login`
2. Input nomor WhatsApp atau Customer ID (8 digit)
3. System check apakah OTP enabled
4. Jika disabled: langsung create session
5. Redirect ke `/customer` (no OTP required)

### Fallback: OTP Send Failed

Jika OTP enabled tapi WhatsApp gagal kirim OTP:
1. Customer lihat error message
2. Muncul button **"Masuk Tanpa OTP (WhatsApp Bermasalah)"**
3. Customer klik button bypass
4. System check apakah OTP benar-benar disabled
5. Jika OTP masih enabled: return error (security)
6. Jika OTP disabled: create session, login success

## ðŸ› ï¸ Technical Implementation

### API Endpoints

#### 1. `/api/customer/auth/login` (POST)
Check user dan tentukan apakah perlu OTP atau tidak.

**Request:**
```json
{
  "identifier": "08123456789" // or "12345678" (8-digit customer ID)
}
```

**Response (OTP Disabled):**
```json
{
  "success": true,
  "otpEnabled": false,
  "requireOTP": false,
  "token": "xxx...xxx",
  "user": { ... }
}
```

**Response (OTP Enabled):**
```json
{
  "success": true,
  "otpEnabled": true,
  "requireOTP": true,
  "user": {
    "phone": "628123456789"
  },
  "token": null
}
```

#### 2. `/api/customer/auth/send-otp` (POST)
Kirim OTP code via WhatsApp (hanya jika OTP enabled).

**Request:**
```json
{
  "phone": "628123456789"
}
```

**Response:**
```json
{
  "success": true,
  "message": "OTP sent successfully",
  "expiresIn": 5
}
```

#### 3. `/api/customer/auth/verify-otp` (POST)
Verify OTP code dan create session.

**Request:**
```json
{
  "phone": "628123456789",
  "otpCode": "123456"
}
```

**Response:**
```json
{
  "success": true,
  "token": "xxx...xxx",
  "user": { ... }
}
```

#### 4. `/api/customer/auth/bypass-login` (POST) **[NEW]**
Login tanpa OTP (hanya jika OTP disabled).

**Request:**
```json
{
  "phone": "628123456789"
}
```

**Response (OTP Disabled):**
```json
{
  "success": true,
  "token": "xxx...xxx",
  "user": { ... }
}
```

**Response (OTP Enabled - Security Block):**
```json
{
  "success": false,
  "error": "OTP is required. Please contact admin if WhatsApp service is unavailable."
}
```

### Database Schema

**whatsapp_reminder_settings**
```sql
CREATE TABLE whatsapp_reminder_settings (
  id VARCHAR PRIMARY KEY,
  enabled BOOLEAN DEFAULT TRUE,
  otpEnabled BOOLEAN DEFAULT TRUE,  -- Toggle OTP ON/OFF
  otpExpiry INT DEFAULT 5,          -- OTP expiry in minutes
  ...
);
```

**customerSession**
```sql
CREATE TABLE customer_sessions (
  id VARCHAR PRIMARY KEY,
  userId VARCHAR,
  phone VARCHAR,
  otpCode VARCHAR NULL,      -- NULL if bypass login
  otpExpiry TIMESTAMP NULL,  -- NULL if bypass login
  token VARCHAR UNIQUE,
  expiresAt TIMESTAMP,
  verified BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP,
  updatedAt TIMESTAMP
);
```

### Frontend Logic

**src/app/login/page.tsx**
```typescript
const handleSendOTP = async () => {
  // Step 1: Check if OTP required
  const checkRes = await fetch('/api/customer/auth/login', {
    method: 'POST',
    body: JSON.stringify({ identifier })
  });
  
  const checkData = await checkRes.json();
  
  // Step 2: If OTP not required, login directly
  if (!checkData.requireOTP) {
    localStorage.setItem('customer_token', checkData.token);
    router.push('/customer');
    return;
  }
  
  // Step 3: Send OTP via WhatsApp
  const res = await fetch('/api/customer/auth/send-otp', {
    method: 'POST',
    body: JSON.stringify({ phone: userPhone })
  });
  
  const data = await res.json();
  
  // Step 4a: OTP sent successfully
  if (data.success) {
    setStep('otp');
  } 
  // Step 4b: OTP send failed - show bypass button
  else {
    setError(data.error);
    setOtpSendFailed(true); // Show bypass option
  }
};
```

## ðŸ“Š Activity Logging

Semua login activity dicatat di `activity_logs`:

**OTP Login:**
```json
{
  "module": "customer_auth",
  "action": "verify_otp",
  "description": "Customer user123@realm logged in via OTP",
  "metadata": "{\"phone\":\"628123456789\"}"
}
```

**Bypass Login:**
```json
{
  "module": "customer_auth",
  "action": "bypass_login",
  "description": "Customer user123@realm logged in without OTP (OTP disabled)",
  "metadata": "{\"phone\":\"628123456789\"}"
}
```

## âš ï¸ Best Practices

### Security Recommendations

1. **Enable OTP untuk Production**
   - OTP mode lebih secure untuk production
   - Validasi nomor WhatsApp aktif

2. **Disable OTP hanya saat Darurat**
   - WhatsApp service down
   - Mass login event (promo, dll)
   - Maintenance WhatsApp API

3. **Monitor Activity Logs**
   - Track bypass login frequency
   - Detect suspicious patterns
   - Audit customer access

4. **Configure OTP Expiry**
   - Default: 5 menit
   - Recommended: 3-5 menit
   - Max: 10 menit

5. **Rate Limiting**
   - Max 3 OTP per 15 menit per phone
   - Prevent OTP spam/abuse

### Operational Guidelines

**Before Disabling OTP:**
- âœ… Verify WhatsApp service benar-benar down
- âœ… Inform customer via broadcast
- âœ… Set time limit untuk bypass mode
- âœ… Monitor login activity

**After Enabling OTP Back:**
- âœ… Test OTP delivery working
- âœ… Announce via broadcast
- âœ… Review bypass login logs

## ðŸ› Troubleshooting

### Customer Cannot Login (OTP Enabled)

**Symptoms:**
- OTP tidak terkirim
- OTP expired terus
- Error "WhatsApp service unavailable"

**Solutions:**
1. Check WhatsApp API status
2. Verify WhatsApp credentials di settings
3. Check rate limiting (max 3 OTP/15min)
4. Sementara disable OTP untuk emergency access

### Customer Cannot Login (OTP Disabled)

**Symptoms:**
- Nomor valid tapi tidak bisa login
- Error "Phone not registered"

**Solutions:**
1. Verify nomor di database `pppoe_users`
2. Check phone format (62xxx vs 08xxx)
3. Verify user status = 'active'
4. Check session table untuk duplicate

### Bypass Button Not Showing

**Symptoms:**
- OTP send gagal tapi no bypass button

**Solutions:**
1. Clear browser cache
2. Check console for JavaScript errors
3. Verify API `/api/customer/auth/bypass-login` exists
4. Update frontend code

## ðŸ“ž Support

**For Admins:**
- Toggle OTP: Admin Panel > WhatsApp > Notifications
- View Logs: Admin Panel > Activity Logs > Filter "customer_auth"

**For Customers:**
- Login Page: `/login`
- Contact admin jika gagal login
- Gunakan Customer ID 8-digit sebagai alternatif

---

**Version**: 2.8.0  
**Last Updated**: December 24, 2025  
**Status**: âœ… Production Ready


## [29] DYNAMIC_VIRTUAL_PARAMETERS.md


# Dynamic Virtual Parameters Extraction

## Overview
Sistem pengambilan Virtual Parameters yang dinamis dari GenieACS, sehingga semua Virtual Parameters yang ditambahkan di GenieACS akan otomatis ter-ekstrak tanpa perlu update kode.

## Perubahan yang Dilakukan

### 1. **API ONT Route** (`/api/customer/ont`)

#### Sebelum (Static):
```typescript
const deviceInfo = {
  ipAddress: vp.pppoeIP?._value || 'N/A',
  rxPower: vp.RXPower?._value || 'N/A',
  temperature: vp.gettemp?._value || 'N/A',
  // Harus manual tambah setiap VP baru
};
```

#### Sesudah (Dynamic):
```typescript
// Extract ALL Virtual Parameters dynamically
const vp = device.VirtualParameters || {};
const virtualParams: Record<string, any> = {};

if (vp && typeof vp === 'object') {
  Object.keys(vp).forEach(key => {
    const value = vp[key];
    virtualParams[key] = value?._value !== undefined ? value._value : value;
  });
}

// Use with fallback
const deviceInfo = {
  pppUsername: virtualParams.pppoeUsername || virtualParams.pppoeUsername2 || 'N/A',
  ipAddress: virtualParams.pppoeIP || virtualParams.wanIP || 'N/A',
  rxPower: virtualParams.RXPower || virtualParams.rxPower || 'N/A',
  temperature: virtualParams.gettemp || virtualParams.temperature || 'N/A',
  uptime: virtualParams.getdeviceuptime || virtualParams.uptime || 'N/A',
  // Return semua VP untuk flexibilitas
  allVirtualParams: virtualParams
};
```

### 2. **API WiFi Route** (`/api/customer/wifi`)

Sama seperti ONT API, ekstraksi VP dilakukan secara dinamis dengan multiple fallback untuk nama VP yang berbeda-beda antar manufacturer.

#### Fitur Dynamic Extraction:
- Auto-detect semua VP yang ada
- Extract `_value` dari object VP GenieACS
- Fallback ke multiple nama alternatif (pppoeIP / wanIP / pppoeUsername / pppoeUsername2)
- Return raw VP data untuk custom usage

## Virtual Parameters yang Didukung

### PPPoE Information
- `pppoeUsername`, `pppoeUsername2` - Username PPPoE
- `pppoeIP`, `wanIP` - IP Address PPPoE
- Connection status berdasarkan keberadaan username

### Signal & Performance
- `RXPower`, `rxPower` - Receive power signal
- `TXPower`, `txPower` - Transmit power
- `gettemp`, `temperature` - ONT temperature

### Device Info
- `getSerialNumber`, `serialNumber` - Serial number ONT
- `getdeviceuptime`, `uptime` - Device uptime
- `getponmode`, `ponMode` - PON mode (GPON/EPON)

### WiFi Parameters
- `WlanPassword`, `wifiPassword` - WiFi password
- Other WLAN configs from standard parameters

## Cara Kerja

### 1. Extraction Process
```typescript
Object.keys(vp).forEach(key => {
  const value = vp[key];
  // Extract _value if exists, otherwise use raw value
  virtualParams[key] = value?._value !== undefined ? value._value : value;
});
```

### 2. Multiple Fallback Strategy
```typescript
// Try multiple possible names
ipAddress: virtualParams.pppoeIP || virtualParams.wanIP || 'N/A'
username: virtualParams.pppoeUsername || virtualParams.pppoeUsername2 || 'N/A'
```

### 3. Type Safety
- Always return string or 'N/A'
- Check for null/undefined before display
- Convert object values to primitive types

## Benefits

### âœ… Auto-Adapt to New VPs
Ketika admin menambahkan Virtual Parameter baru di GenieACS (misal: `bandwidth`, `upSpeed`, `downSpeed`), sistem langsung bisa mengakses data tersebut via `allVirtualParams` tanpa update kode.

### âœ… Multi-Manufacturer Support
Berbeda manufacturer menggunakan nama VP berbeda:
- Fiberhome: `pppoeUsername`
- ZTE: `pppoeUsername2`
- Huawei: `wanUsername`

Sistem mencoba semua kemungkinan dengan fallback.

### âœ… Backward Compatible
Data yang sudah ada tetap berfungsi, hanya ditambahkan field `allVirtualParams` untuk flexibilitas.

### âœ… Easy Debugging
Admin bisa lihat semua VP yang available di object `allVirtualParams`.

## Customer Dashboard Display

### Status Connection
```typescript
PPPoE: Connected/Disconnected
- Based on pppUsername existence
- Green badge if connected
- Gray badge if disconnected
```

### Device Information
- Model: Manufacturer + ProductClass
- Status ONT: Online/Offline
- IP PPPoE: From virtualParams.pppoeIP
- RX Power: From virtualParams.RXPower
- Temperature: From virtualParams.gettemp
- Uptime: From virtualParams.getdeviceuptime
- Connected Devices: Count from connectedHosts

## API Response Structure

### GET /api/customer/ont
```json
{
  "success": true,
  "device": {
    "serialNumber": "ZTEG12345678",
    "manufacturer": "ZTE",
    "model": "F660",
    "pppUsername": "user001",
    "ipAddress": "10.10.10.1",
    "uptime": "3 days 2 hours",
    "status": "Online",
    "rxPower": "-23.45 dBm",
    "txPower": "2.34 dBm",
    "temperature": "45Â°C",
    "ponMode": "GPON",
    "connectedHosts": 3,
    "wifiSSID": "MyWiFi",
    "wifiPassword": "********",
    "wifiEnabled": true,
    "wifiChannel": "6",
    "allVirtualParams": {
      "pppoeUsername": "user001",
      "pppoeIP": "10.10.10.1",
      "RXPower": "-23.45 dBm",
      "gettemp": "45Â°C",
      "getdeviceuptime": "3 days 2 hours",
      "customParam1": "value1",
      "customParam2": "value2"
    }
  }
}
```

## GenieACS Virtual Parameters Setup

### Example Virtual Parameters Script

```javascript
// PPPoE Username
const pppUsername = declare("VirtualParameters.pppoeUsername", {value: Date.now()}, {value: true});
const wanPPP = declare("InternetGatewayDevice.WANDevice.1.WANConnectionDevice.1.WANPPPConnection.*", {path: 1}, {path: 1});
pppUsername.value = wanPPP.Username;

// PPPoE IP
const pppIP = declare("VirtualParameters.pppoeIP", {value: Date.now()}, {value: true});
pppIP.value = wanPPP.ExternalIPAddress;

// RX Power
const rxPower = declare("VirtualParameters.RXPower", {value: Date.now()}, {value: true});
const gpon = declare("InternetGatewayDevice.WANDevice.1.X_GponInterafceConfig.*", {path: 1}, {path: 1});
rxPower.value = gpon.RXPower;

// Temperature
const temp = declare("VirtualParameters.gettemp", {value: Date.now()}, {value: true});
temp.value = gpon.TransceiverTemperature;

// Uptime
const uptime = declare("VirtualParameters.getdeviceuptime", {value: Date.now()}, {value: true});
const devInfo = declare("InternetGatewayDevice.DeviceInfo.*", {path: 1}, {path: 1});
uptime.value = devInfo.UpTime;

// Custom Parameter Example
const bandwidth = declare("VirtualParameters.currentBandwidth", {value: Date.now()}, {value: true});
bandwidth.value = calculateBandwidth(); // Your custom logic
```

## Error Handling

### NULL/Undefined Checks
```typescript
// Always check before display
{ontDevice.pppUsername && ontDevice.pppUsername !== 'N/A' 
  ? 'Connected' 
  : 'Disconnected'}

{ontDevice.ipAddress && ontDevice.ipAddress !== 'N/A' 
  ? ontDevice.ipAddress 
  : '-'}
```

### Graceful Degradation
Jika VP tidak ada, sistem fallback ke:
1. Alternative VP name
2. Standard parameter path
3. 'N/A' or '-'

## Testing

### Test Scenarios
1. âœ… ONT dengan full Virtual Parameters
2. âœ… ONT tanpa Virtual Parameters (fallback to standard)
3. âœ… ONT dengan partial VPs (some missing)
4. âœ… Multiple manufacturers (ZTE, Fiberhome, Huawei)
5. âœ… PPPoE connected vs disconnected
6. âœ… Device online vs offline

### Expected Behavior
- No crashes on missing data
- Display 'N/A' or '-' for unavailable data
- Connection status accurate based on username
- All VPs accessible via allVirtualParams

## Future Enhancements

### 1. Custom VP Display
Admin bisa configure di UI VP mana yang mau ditampilkan ke customer:
```json
{
  "displayVPs": ["bandwidth", "upSpeed", "downSpeed", "signal"],
  "hideVPs": ["serialNumber", "internalIP"]
}
```

### 2. VP Alerts
Alert customer jika VP tertentu abnormal:
```typescript
if (rxPower < -27) {
  alert("Signal lemah, hubungi teknisi");
}
```

### 3. Historical VP Data
Store VP data over time untuk graph/trending:
- RX Power trend
- Temperature history
- Bandwidth usage

## Troubleshooting

### VP Not Showing
1. Check GenieACS Virtual Parameters configuration
2. Verify device last inform is recent (< 5 min)
3. Check VP name spelling in GenieACS
4. Test with allVirtualParams to see raw data
5. Check browser console for API errors

### Wrong Data Display
1. Verify VP value type in GenieACS
2. Check _value extraction logic
3. Test with different manufacturers
4. Review fallback chain order

### Performance Issues
1. Limit VP extraction to needed fields only
2. Cache allVirtualParams data
3. Use pagination for large device lists
4. Optimize GenieACS refresh interval

## Summary

Sistem dynamic Virtual Parameters extraction memberikan:
- âœ… **Flexibility**: Auto-adapt ke VP baru
- âœ… **Compatibility**: Multi-manufacturer support
- âœ… **Reliability**: Multiple fallback mechanisms
- âœ… **Maintainability**: Less code changes needed
- âœ… **Scalability**: Easy to add new data points

Customer sekarang mendapat informasi lengkap tentang device mereka secara real-time tanpa perlu intervensi admin.


## [30] VOUCHER_EXPIRATION_TIMEZONE_FIX.md


# Timezone Consistency & Voucher Expiration Fix

**Date:** December 28, 2025  
**Version:** 2.9.2  
**Issue:** Vouchers yang sudah expired masih menampilkan status "AKTIF" di sistem  
**Root Cause:** Timezone inconsistency antara database storage (WIB) dan query comparison (UTC)

---

## ðŸ—ï¸ Timezone Consistency Architecture

### Overview
Untuk memastikan waktu konsisten di seluruh sistem, SEMUA komponen harus menggunakan timezone yang sama:

```
â”Œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”
â”‚                    TIMEZONE CONSISTENCY                          â”‚
â”œâ”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”¤
â”‚  1. SYSTEM (timedatectl)     â†’  Asia/Jakarta (WIB, UTC+7)       â”‚
â”‚  2. MySQL (time_zone)        â†’  +07:00 (matching system)        â”‚
â”‚  3. Node.js/PM2 (TZ env)     â†’  Asia/Jakarta                    â”‚
â”‚  4. FreeRADIUS (uses system) â†’  Asia/Jakarta (automatic)        â”‚
â”‚  5. Application (.env)       â†’  NEXT_PUBLIC_TIMEZONE=Asia/Jakartaâ”‚
â””â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”˜
```

### Configuration Locations

| Component | Config File | Setting |
|-----------|-------------|---------|
| System | timedatectl | `timedatectl set-timezone Asia/Jakarta` |
| MySQL | `/etc/mysql/mysql.conf.d/timezone.cnf` | `default-time-zone = '+07:00'` |
| Node.js | `.env` | `TZ="Asia/Jakarta"` |
| PM2 | `ecosystem.config.js` | `env: { TZ: 'Asia/Jakarta' }` |
| App | `.env` | `NEXT_PUBLIC_TIMEZONE="Asia/Jakarta"` |
| NTP | `/etc/chrony/chrony.conf` | Indonesian NTP servers |

---

## Problem Analysis

### Symptom
- Voucher dengan `expiresAt` yang sudah lewat masih menunjukkan status `ACTIVE`
- User melaporkan voucher dengan "Berlaku Sampai" yang sudah lewat masih tampil sebagai "AKTIF"

### Root Cause
1. **Database timezone**: MySQL menggunakan `SYSTEM` timezone = WIB (UTC+7)
2. **Storage behavior**: `firstLoginAt` dan `expiresAt` disimpan dalam WIB (server local time)
   - Line 59-90 di `src/lib/cron/voucher-sync.ts`
   - Data dari FreeRADIUS `radacct.acctstarttime` sudah dalam WIB
3. **Query comparison**: Line 262-265 menggunakan `UTC_TIMESTAMP()` untuk check expiration
   - Membandingkan WIB datetime dengan UTC datetime
   - Selisih 7 jam menyebabkan voucher kelihatan belum expired

### Example
Voucher `ELRQNC`:
- First Login: `2025-12-28 05:23:16` (WIB)
- Expires At: `2025-12-28 07:23:16` (WIB) 
- Current Time: `2025-12-28 09:41` (WIB)
- UTC Time: `2025-12-28 02:41` (UTC)

**OLD Query (SALAH):**
```sql
WHERE expiresAt < UTC_TIMESTAMP()
-- 07:23 < 02:41 = FALSE âŒ
```

**NEW Query (BENAR):**
```sql
WHERE expiresAt < NOW()
-- 07:23 < 09:41 = TRUE âœ…
```

## Solution

### File Changed
**`src/lib/cron/voucher-sync.ts`** - Line 259-267

### Change Made
```diff
-    // Method 1: Expired by validity time (expiresAt < NOW)
+    // Method 1: Expired by validity time (expiresAt < NOW)
+    // IMPORTANT: Use NOW() not UTC_TIMESTAMP() because expiresAt is stored in server local time (WIB)
+    // firstLoginAt comes from FreeRADIUS radacct which uses server local time
     const expiredByValidity = await prisma.$queryRaw<Array<{code: string; id: string}>>`
       SELECT code, id FROM hotspot_vouchers
       WHERE status = 'ACTIVE'
-        AND expiresAt < UTC_TIMESTAMP()
+        AND expiresAt < NOW()
     `
```

## Testing Results

### Before Fix
```sql
SELECT code, status, expiresAt FROM hotspot_vouchers WHERE code = 'ELRQNC';
-- code   | status | expiresAt
-- ELRQNC | ACTIVE | 2025-12-28 07:23:16.000
-- (Status masih ACTIVE padahal sudah expired 2+ jam!)
```

### After Fix
```sql
SELECT code, status, expiresAt FROM hotspot_vouchers WHERE code = 'ELRQNC';
-- code   | status  | expiresAt
-- ELRQNC | EXPIRED | 2025-12-28 07:23:16.000
-- âœ… Status sudah EXPIRED dengan benar!
```

### Verification Query
```sql
-- Test query untuk menemukan expired vouchers
SELECT code, status, expiresAt, NOW() as now_time
FROM hotspot_vouchers
WHERE status = 'ACTIVE'
  AND expiresAt < NOW();
-- âœ… Query ini sekarang menemukan vouchers yang benar-benar expired
```

## Deployment Steps

1. **Update source code:**
   ```bash
   # Edit src/lib/cron/voucher-sync.ts (line 259-267)
   ```

2. **Upload to VPS:**
   ```powershell
   scp -P 9500 src/lib/cron/voucher-sync.ts root@103.191.165.156:/var/www/salfanet-radius/src/lib/cron/
   ```

3. **Rebuild aplikasi:**
   ```bash
   cd /var/www/salfanet-radius
   npm run build
   ```

4. **Restart PM2:**
   ```bash
   pm2 restart salfanet-radius
   ```

5. **Verify:**
   ```bash
   # Check cron logs
   pm2 logs salfanet-radius --lines 50
   
   # Or manually check database
   mysql -usalfanet_user -psalfanetradius123 salfanet_radius \
     -e "SELECT COUNT(*) FROM hotspot_vouchers WHERE status='ACTIVE' AND expiresAt < NOW()"
   ```

## Impact

âœ… **Fixed Issues:**
- Vouchers yang expired akan otomatis diupdate statusnya menjadi EXPIRED setiap cron run (setiap menit)
- Status yang ditampilkan di UI sekarang akurat
- User tidak bisa login dengan voucher expired
- Disconnect otomatis via CoA untuk session yang masih aktif

âœ… **No Breaking Changes:**
- Existing voucher data tidak perlu diubah
- Cron schedule tetap sama (every minute)
- API endpoints tetap berfungsi normal

## Notes

### Timezone Consistency Rules
Untuk menghindari issue serupa di masa depan:

1. **Database Storage:**
   - MySQL timezone = SYSTEM (WIB)
   - Store datetime AS-IS dari FreeRADIUS (sudah WIB)
   - Use `NOW()` for local time comparisons

2. **Date Comparisons:**
   - Always use `NOW()` when comparing with stored datetimes
   - Use `UTC_TIMESTAMP()` only if storing UTC explicitly
   - Document timezone in code comments

3. **FreeRADIUS Integration:**
   - `radacct.acctstarttime` is in server local time (WIB)
   - No conversion needed when storing to database
   - Use directly for `firstLoginAt` and `expiresAt` calculation

### Related Files
- `src/lib/cron/voucher-sync.ts` - Main voucher sync cron (FIXED)
- `src/lib/timezone.ts` - Timezone utility functions
- `src/app/api/hotspot/vouchers/validate/route.ts` - Voucher validation API

## Author
Fixed by: GitHub Copilot  
Date: December 28, 2025  
VPS: 103.191.165.156:9500  
Application Path: `/var/www/salfanet-radius`


## [31] TESTING_GUIDE.md


# Testing Guide - Prepaid & Postpaid System

## ðŸŽ¯ Tujuan Testing
Memastikan sistem prepaid dan postpaid berfungsi dengan benar setelah implementasi billing_day dan perbaikan logic.

## âœ… Perubahan yang Sudah Dilakukan

### 1. Database Schema
- âœ… Added `billingDay` (1-28) to pppoe_users
- âœ… Added `subscriptionType` (PREPAID/POSTPAID)
- âœ… Added `balance`, `autoRenewal`, `autoIsolationEnabled`
- âœ… Added `invoiceType` enum to invoices
- âœ… Schema applied via `npx prisma db push`

### 2. Frontend Forms
- âœ… Form approval registrasi: tambah input billing day (untuk POSTPAID)
- âœ… Form tambah/edit user: tambah input billing day (untuk POSTPAID)
- âœ… Conditional display: billing day hanya muncul jika POSTPAID

### 3. Backend API
- âœ… `/api/admin/registrations/[id]/approve`: handle billingDay
- âœ… `/api/pppoe/users` (POST): handle subscriptionType & billingDay saat create
- âœ… `/api/pppoe/users` (PUT): handle subscriptionType & billingDay saat update
- âœ… `/api/payment/webhook`: logic berbeda untuk PREPAID vs POSTPAID
- âœ… `/api/invoices/generate`: generate invoice berbeda untuk PREPAID vs POSTPAID

## ðŸ§ª Test Cases

### Test 1: Registrasi User Baru POSTPAID
**Steps:**
1. Buka menu "Registrasi Pelanggan"
2. Klik tombol "Approve" pada registrasi pending
3. Pilih "ðŸ“… Postpaid"
4. Pilih "Tanggal Tagihan" = 5 (atau tanggal lain 1-28)
5. Isi biaya pemasangan (misal: 100000)
6. Klik "Approve"

**Expected:**
- âœ… User dibuat dengan `subscriptionType = 'POSTPAID'`
- âœ… User memiliki `billingDay = 5`
- âœ… User memiliki `expiredAt = null`
- âœ… Invoice dibuat hanya untuk biaya pemasangan (bukan pemasangan + bulan pertama)
- âœ… User status = 'isolated' sampai bayar invoice

**Verification Query:**
```sql
SELECT username, subscriptionType, billingDay, expiredAt, status 
FROM pppoe_users 
WHERE username = 'nama-phone';
```

### Test 2: Registrasi User Baru PREPAID
**Steps:**
1. Buka menu "Registrasi Pelanggan"
2. Klik tombol "Approve" pada registrasi pending
3. Pilih "â° Prepaid"
4. Isi biaya pemasangan (misal: 100000)
5. Klik "Approve"

**Expected:**
- âœ… User dibuat dengan `subscriptionType = 'PREPAID'`
- âœ… User memiliki `billingDay = 1` (default)
- âœ… User memiliki `expiredAt = now + validity period`
- âœ… Invoice = biaya pemasangan + biaya paket (total lebih besar)
- âœ… User status = 'isolated' sampai bayar invoice

**Verification Query:**
```sql
SELECT username, subscriptionType, billingDay, expiredAt, status 
FROM pppoe_users 
WHERE username = 'nama-phone';
```

### Test 3: Payment Invoice POSTPAID
**Steps:**
1. Gunakan user POSTPAID dari Test 1
2. Bayar invoice via payment gateway (atau manual payment)
3. Tunggu webhook/approval

**Expected:**
- âœ… Invoice status = 'PAID'
- âœ… User status = 'active'
- âœ… User `expiredAt` tetap `null` (tidak berubah)
- âœ… User dapat login PPPoE

**Verification Query:**
```sql
SELECT u.username, u.subscriptionType, u.expiredAt, u.status, i.status as invoice_status
FROM pppoe_users u
JOIN invoices i ON u.id = i.userId
WHERE u.username = 'nama-phone';
```

### Test 4: Payment Invoice PREPAID
**Steps:**
1. Gunakan user PREPAID dari Test 2
2. Bayar invoice via payment gateway (atau manual payment)
3. Tunggu webhook/approval

**Expected:**
- âœ… Invoice status = 'PAID'
- âœ… User status = 'active'
- âœ… User `expiredAt` diperpanjang (+1 bulan dari sekarang atau dari expiredAt sebelumnya)
- âœ… User dapat login PPPoE

**Verification Query:**
```sql
SELECT u.username, u.subscriptionType, u.expiredAt, u.status, i.status as invoice_status
FROM pppoe_users u
JOIN invoices i ON u.id = i.userId
WHERE u.username = 'nama-phone';
```

### Test 5: Invoice Generation POSTPAID (Cron)
**Steps:**
1. Set tanggal sistem = billingDay user POSTPAID (misal tanggal 5)
2. Jalankan cron job: `POST /api/invoices/generate`
3. Atau tunggu cron otomatis jam 00:00

**Expected:**
- âœ… Invoice baru dibuat dengan `invoiceType = 'MONTHLY'`
- âœ… `dueDate = billingDay + 7 hari` (grace period)
- âœ… Amount = harga paket (bukan pemasangan)
- âœ… Hanya 1 invoice per user (tidak duplikat)

**Verification Query:**
```sql
SELECT i.invoiceNumber, i.invoiceType, i.amount, i.dueDate, i.status, u.username, u.billingDay
FROM invoices i
JOIN pppoe_users u ON i.userId = u.id
WHERE u.subscriptionType = 'POSTPAID'
  AND i.createdAt >= CURDATE()
ORDER BY i.createdAt DESC;
```

### Test 6: Invoice Generation PREPAID (Cron)
**Steps:**
1. Set tanggal sistem = 7 hari sebelum expiredAt user PREPAID
2. Jalankan cron job: `POST /api/invoices/generate`
3. Atau tunggu cron otomatis jam 00:00

**Expected:**
- âœ… Invoice baru dibuat dengan `invoiceType = 'RENEWAL'`
- âœ… `dueDate = expiredAt` user
- âœ… Amount = harga paket
- âœ… Hanya 1 invoice per user (tidak duplikat)

**Verification Query:**
```sql
SELECT i.invoiceNumber, i.invoiceType, i.amount, i.dueDate, i.status, u.username, u.expiredAt
FROM invoices i
JOIN pppoe_users u ON i.userId = u.id
WHERE u.subscriptionType = 'PREPAID'
  AND i.createdAt >= CURDATE()
ORDER BY i.createdAt DESC;
```

### Test 7: Auto Isolation POSTPAID
**Steps:**
1. Gunakan user POSTPAID dengan invoice overdue (lewat dueDate)
2. Jalankan cron job auto-isolation (atau tunggu cron hourly)

**Expected:**
- âœ… User status berubah ke 'isolated'
- âœ… User tidak bisa login PPPoE
- âœ… Radcheck & radusergroup dihapus

**Verification Query:**
```sql
SELECT u.username, u.status, i.invoiceNumber, i.dueDate, i.status as invoice_status
FROM pppoe_users u
JOIN invoices i ON u.id = i.userId
WHERE u.subscriptionType = 'POSTPAID'
  AND i.status IN ('PENDING', 'OVERDUE')
  AND i.dueDate < CURDATE();
```

### Test 8: Auto Isolation PREPAID
**Steps:**
1. Gunakan user PREPAID dengan expiredAt sudah lewat
2. Jalankan cron job auto-isolation (atau tunggu cron hourly)

**Expected:**
- âœ… User status berubah ke 'isolated'
- âœ… User tidak bisa login PPPoE
- âœ… Radcheck & radusergroup dihapus

**Verification Query:**
```sql
SELECT username, status, expiredAt, subscriptionType
FROM pppoe_users
WHERE subscriptionType = 'PREPAID'
  AND expiredAt < NOW()
  AND status = 'isolated';
```

### Test 9: Edit User - Ganti Billing Day
**Steps:**
1. Buka menu "PPPoE Users"
2. Edit user POSTPAID
3. Ubah "Tanggal Tagihan" dari 5 ke 15
4. Save

**Expected:**
- âœ… `billingDay` berubah jadi 15
- âœ… Invoice berikutnya akan generate tanggal 15

**Verification Query:**
```sql
SELECT username, billingDay, subscriptionType 
FROM pppoe_users 
WHERE username = 'user-test';
```

### Test 10: Edit User - Ganti POSTPAID ke PREPAID
**Steps:**
1. Buka menu "PPPoE Users"
2. Edit user POSTPAID
3. Ubah subscription type ke PREPAID
4. Set expiredAt = 1 bulan dari sekarang
5. Save

**Expected:**
- âœ… `subscriptionType` berubah ke 'PREPAID'
- âœ… `expiredAt` diset sesuai input
- âœ… Invoice berikutnya akan mengikuti logic PREPAID (H-7 sebelum expiry)

**Verification Query:**
```sql
SELECT username, subscriptionType, expiredAt, billingDay 
FROM pppoe_users 
WHERE username = 'user-test';
```

## ðŸ“Š Monitoring Queries

### Check User by Subscription Type
```sql
SELECT subscriptionType, COUNT(*) as total
FROM pppoe_users
GROUP BY subscriptionType;
```

### Check POSTPAID Users Ready for Invoice
```sql
SELECT username, name, billingDay, status, expiredAt
FROM pppoe_users
WHERE subscriptionType = 'POSTPAID'
  AND billingDay = DAY(CURDATE())
  AND status IN ('active', 'isolated');
```

### Check PREPAID Users Expiring Soon
```sql
SELECT username, name, expiredAt, status,
       DATEDIFF(expiredAt, CURDATE()) as days_until_expiry
FROM pppoe_users
WHERE subscriptionType = 'PREPAID'
  AND expiredAt BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
  AND status IN ('active', 'isolated')
ORDER BY expiredAt ASC;
```

### Check All Unpaid Invoices
```sql
SELECT i.invoiceNumber, i.invoiceType, u.username, u.subscriptionType, 
       i.amount, i.dueDate, i.status,
       DATEDIFF(CURDATE(), i.dueDate) as days_overdue
FROM invoices i
JOIN pppoe_users u ON i.userId = u.id
WHERE i.status IN ('PENDING', 'OVERDUE')
ORDER BY i.dueDate ASC;
```

## ðŸ› Common Issues & Solutions

### Issue 1: Date Picker Error
**Symptom:** Error saat pilih tanggal di form
**Solution:** 
- Pastikan format date: `yyyy-MM-dd`
- Check timezone conversion (WIB to UTC)
- Gunakan `endOfDayWIBtoUTC()` helper

### Issue 2: Invoice Duplikat
**Symptom:** User dapat 2+ invoice untuk bulan yang sama
**Solution:**
- Check query di `/api/invoices/generate`
- Pastikan ada check `existingInvoice` sebelum create
- Filter by status `IN ('PENDING', 'OVERDUE')`

### Issue 3: Billing Day > 28
**Symptom:** User pilih tanggal 29-31
**Solution:**
- Frontend: limit dropdown sampai 28
- Backend: validasi `Math.min(Math.max(billingDay, 1), 28)`

### Issue 4: POSTPAID User Punya expiredAt
**Symptom:** User POSTPAID tidak bisa login padahal sudah bayar
**Solution:**
- Set `expiredAt = null` untuk POSTPAID
- Check payment webhook - pastikan logic set null

### Issue 5: PREPAID expiredAt Tidak Diperpanjang
**Symptom:** Setelah bayar, expiredAt tetap sama
**Solution:**
- Check payment webhook logic
- Pastikan calculate `newExpiredAt` based on validity

## ðŸ“ Manual Testing Script

Jalankan di browser console atau API testing tool (Postman):

```javascript
// Test 1: Create POSTPAID user via approval
fetch('/api/admin/registrations/REG123/approve', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    installationFee: 100000,
    subscriptionType: 'POSTPAID',
    billingDay: 5
  })
}).then(r => r.json()).then(console.log);

// Test 2: Create PREPAID user via approval
fetch('/api/admin/registrations/REG456/approve', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    installationFee: 100000,
    subscriptionType: 'PREPAID'
  })
}).then(r => r.json()).then(console.log);

// Test 3: Generate invoices (manual trigger)
fetch('/api/invoices/generate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' }
}).then(r => r.json()).then(console.log);
```

## âœ… Testing Checklist

### Frontend
- [ ] Form approval: dropdown billing day (1-28) muncul untuk POSTPAID
- [ ] Form approval: dropdown billing day hidden untuk PREPAID
- [ ] Form add user: dropdown billing day (1-28) muncul untuk POSTPAID
- [ ] Form edit user: dropdown billing day (1-28) muncul untuk POSTPAID
- [ ] Form edit user: load billingDay value dari database
- [ ] Tidak ada error console saat submit form

### Backend API
- [ ] POST /api/admin/registrations/[id]/approve: terima billingDay
- [ ] POST /api/pppoe/users: simpan subscriptionType & billingDay
- [ ] PUT /api/pppoe/users: update subscriptionType & billingDay
- [ ] POST /api/invoices/generate: POSTPAID check billingDay
- [ ] POST /api/invoices/generate: PREPAID check expiredAt
- [ ] POST /api/payment/webhook: POSTPAID set expiredAt = null
- [ ] POST /api/payment/webhook: PREPAID extend expiredAt

### Database
- [ ] Schema pppoe_users: field billingDay ada (INT, default 1)
- [ ] Schema pppoe_users: field subscriptionType ada (ENUM)
- [ ] Schema invoices: field invoiceType ada (ENUM)
- [ ] Data existing user: migrasi subscriptionType (null â†’ POSTPAID/PREPAID)
- [ ] Data existing user: set default billingDay = 1

### Cron Jobs
- [ ] Invoice generation: POSTPAID generate on billingDay
- [ ] Invoice generation: PREPAID generate H-7 before expiredAt
- [ ] Auto isolation: POSTPAID isolate on overdue invoice
- [ ] Auto isolation: PREPAID isolate on expiredAt passed
- [ ] Cron history: log berhasil/gagal

### Edge Cases
- [ ] BillingDay = 31 â†’ auto convert to 28
- [ ] User ganti POSTPAID â†’ PREPAID
- [ ] User ganti PREPAID â†’ POSTPAID
- [ ] Invoice manual create (bukan auto generate)
- [ ] Payment webhook retry (idempotency)

## ðŸŽ¯ Success Criteria

Semua test case passed:
- âœ… POSTPAID user: invoice generate di billingDay
- âœ… PREPAID user: invoice generate H-7 before expiredAt
- âœ… Payment: logic berbeda POSTPAID vs PREPAID
- âœ… Isolation: trigger berbeda POSTPAID vs PREPAID
- âœ… Form: billing day field muncul/hidden sesuai tipe
- âœ… API: handle billingDay dengan validasi 1-28

---

**Version**: 1.0  
**Date**: 2025-12-23  
**Status**: Ready for Testing


## [32] TROUBLESHOOTING.md


# SALFANET RADIUS - Troubleshooting Guide

## Common Installation Issues

### 1. "bad interpreter: No such file or directory" - Shell Script Error

**Error Message:**
```bash
./vps-install-local.sh: /bin/bash^M: bad interpreter: No such file or directory
```

**Cause:**
File memiliki Windows line endings (CRLF - `\r\n`) sedangkan Linux membutuhkan Unix line endings (LF - `\n`).

**Quick Fix (On Server):**
```bash
# Fix single file
sed -i 's/\r$//' vps-install-local.sh
chmod +x vps-install-local.sh

# Fix all shell scripts
find . -name "*.sh" -exec sed -i 's/\r$//' {} \;
find . -name "*.sh" -exec chmod +x {} \;
```

**Prevention (On Development Machine):**

1. **Add `.gitattributes` file** (already included in repo):
   ```
   *.sh text eol=lf
   ```

2. **Configure Git globally:**
   ```bash
   # On Windows
   git config --global core.autocrlf input
   
   # On Linux/Mac
   git config --global core.autocrlf false
   ```

3. **Convert existing files (Windows PowerShell):**
   ```powershell
   Get-ChildItem -Filter "*.sh" -Recurse | ForEach-Object {
     $content = Get-Content $_.FullName -Raw
     $content = $content -replace "`r`n", "`n"
     [System.IO.File]::WriteAllText($_.FullName, $content, [System.Text.UTF8Encoding]::new($false))
   }
   ```

---

## FreeRADIUS Issues

### 2. RADIUS Authentication Failed

**Test Authentication:**
```bash
# Test PPPoE user
echo "User-Name=testuser,User-Password=testpass" | radclient localhost:1812 auth secret123

# Check RADIUS debug mode
sudo systemctl stop freeradius
sudo freeradius -X
```

**Common Causes:**
- Secret mismatch between RADIUS and NAS
- User not synced to RADIUS
- Database connection issue

**Solutions:**
```bash
# Check RADIUS client config
sudo cat /etc/freeradius/3.0/clients.conf

# Check SQL connection
sudo mysql -u radius_user -p radius_db

# Restart RADIUS
sudo systemctl restart freeradius
```

---

## Database Issues

### 3. Database Connection Failed

**Check Connection:**
```bash
# Test MySQL connection
mysql -u salfanet_user -p salfanet_radius

# Check if MySQL is running
sudo systemctl status mysql
```

**Fix Permissions:**
```bash
# Grant all privileges
sudo mysql -e "GRANT ALL PRIVILEGES ON salfanet_radius.* TO 'salfanet_user'@'localhost'; FLUSH PRIVILEGES;"
```

---

## PM2 Issues

### 4. Application Won't Start

**Check PM2 Logs:**
```bash
pm2 logs salfanet-radius --lines 50
pm2 status
```

**Common Issues:**

1. **Port Already in Use:**
   ```bash
   # Check what's using port 3005
   sudo lsof -i :3005
   
   # Kill process
   sudo kill -9 <PID>
   ```

2. **Missing Dependencies:**
   ```bash
   cd /var/www/salfanet-radius
   npm install
   npm run build
   ```

3. **Environment Variables:**
   ```bash
   # Check .env file
   cat /var/www/salfanet-radius/.env
   
   # Verify DATABASE_URL, NEXTAUTH_URL, NEXTAUTH_SECRET
   ```

---

## Network Issues

### 5. MikroTik Connection Failed

**Test RouterOS API:**
```bash
# From server
telnet <mikrotik-ip> 8728

# Check firewall
sudo iptables -L -n -v
```

**MikroTik Side:**
```routeros
# Enable API
/ip service set api port=8728 disabled=no

# Add firewall rule
/ip firewall filter add chain=input protocol=tcp dst-port=8728 action=accept
```

---

## SSL/HTTPS Issues

### 6. Certificate Errors

**Generate New Self-Signed Certificate:**
```bash
sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout /etc/ssl/private/salfanet.key \
  -out /etc/ssl/certs/salfanet.crt
```

**Update Nginx:**
```bash
sudo nano /etc/nginx/sites-available/salfanet-radius
sudo nginx -t
sudo systemctl reload nginx
```

---

## Build Issues

### 7. Next.js Build Failures

**Clear Cache and Rebuild:**
```bash
cd /var/www/salfanet-radius
sudo rm -rf .next
sudo rm -rf node_modules
sudo npm install
sudo npm run build
```

**Check Node.js Version:**
```bash
node --version  # Should be 18.x or higher
npm --version
```

---

## Permission Issues

### 8. File Permission Errors

**Fix Ownership:**
```bash
# Set correct owner
sudo chown -R www-data:www-data /var/www/salfanet-radius

# Set correct permissions
sudo find /var/www/salfanet-radius -type d -exec chmod 755 {} \;
sudo find /var/www/salfanet-radius -type f -exec chmod 644 {} \;
sudo chmod +x /var/www/salfanet-radius/*.sh
```

---

## Monitoring & Debugging

### Useful Commands

**System Resources:**
```bash
# Memory usage
free -h

# Disk usage
df -h

# CPU usage
top

# PM2 monitoring
pm2 monit
```

**Logs:**
```bash
# Application logs
pm2 logs salfanet-radius

# Nginx access log
sudo tail -f /var/log/nginx/access.log

# Nginx error log
sudo tail -f /var/log/nginx/error.log

# FreeRADIUS log
sudo tail -f /var/log/freeradius/radius.log

# MySQL log
sudo tail -f /var/log/mysql/error.log
```

**Service Status:**
```bash
# Check all services
sudo systemctl status nginx
sudo systemctl status mysql
sudo systemctl status freeradius
pm2 status
```

---

## Getting Help

If issues persist:

1. **Check Logs First:**
   - Application: `pm2 logs salfanet-radius`
   - System: `/var/log/syslog`
   - Nginx: `/var/log/nginx/error.log`

2. **Verify Configuration:**
   - Database: Check `.env` file
   - RADIUS: Check `/etc/freeradius/3.0/`
   - Nginx: Check `/etc/nginx/sites-available/`

3. **Test Components Individually:**
   - Database connection
   - RADIUS authentication
   - API endpoints
   - Frontend access

4. **Documentation:**
   - `docs/DEPLOYMENT-GUIDE.md`
   - `docs/FREERADIUS-SETUP.md`
   - `CHANGELOG.md` (recent changes)
   - `CHAT_MEMORY.md` (session notes)

---

## Timezone Issues

### 12. Session Start Time Shows Different Time from Voucher First Login

**Symptoms:**
- Start Time di Sesi Hotspot menampilkan waktu berbeda 7 jam dari First Login di Voucher
- Contoh: First Login 08:28, tapi Start Time 15:28

**Cause:**
- Sessions API mengirim datetime dengan 'Z' suffix (UTC marker)
- Browser menginterpretasi sebagai UTC dan mengkonversi ke timezone lokal (+7 WIB)
- Voucher API mengirim tanpa 'Z' suffix sehingga tidak dikonversi

**Solution (Fixed in v2.6.4):**
```typescript
// Di sessions/route.ts - hapus 'Z' suffix
const startTimeFormatted = session.acctstarttime 
  ? session.acctstarttime.toISOString().replace('Z', '') 
  : null;
```

**Verification:**
- Start Time dan First Login sekarang menampilkan waktu yang sama (WIB)

---

## Quick Health Check

Run this complete health check:

```bash
#!/bin/bash
echo "=== SALFANET RADIUS Health Check ==="
echo ""
echo "1. Services Status:"
sudo systemctl is-active nginx mysql freeradius
pm2 list | grep salfanet-radius
echo ""
echo "2. Ports:"
sudo netstat -tlnp | grep -E '(80|443|3005|1812|1813|3799)'
echo ""
echo "3. Disk Space:"
df -h /var/www/salfanet-radius
echo ""
echo "4. Memory:"
free -h
echo ""
echo "5. Database:"
mysql -u salfanet_user -p -e "SELECT COUNT(*) FROM radcheck;" salfanet_radius
echo ""
echo "6. Application URL:"
curl -I http://localhost:3005
```

---

**Last Updated:** December 18, 2025
**Version:** 2.6.4
