import type { NextConfig } from "next";
import path from "path";

const nextConfig: NextConfig = {
  /* config options here */
  reactCompiler: true,
  typescript: {
    ignoreBuildErrors: true,
  },
  // Optimize for low-resource VPS (2GB RAM)
  experimental: {
    // Reduce memory usage during build
    workerThreads: false,
    cpus: 1, // Use single CPU for build to reduce memory
  },
  // Fix workspace root detection issue
  turbopack: {
    root: path.resolve(__dirname),
  },
  // Disable source maps in production to save memory
  productionBrowserSourceMaps: false,
  // SWC minification is default in Next.js 13+ (no need to specify)
};

export default nextConfig;
