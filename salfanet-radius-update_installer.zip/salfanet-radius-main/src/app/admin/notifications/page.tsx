'use client';

import { useState, useEffect } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import { Bell, Check, CheckCheck, Trash2, Loader2, Filter } from 'lucide-react';
import { formatWIB } from '@/lib/timezone';
import Link from 'next/link';

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  link: string | null;
  isRead: boolean;
  createdAt: Date;
}

export default function NotificationsPage() {
  const { t } = useTranslation();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread'>('all');
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    loadNotifications();
  }, [filter]);

  const loadNotifications = async () => {
    setLoading(true);
    try {
      const url = filter === 'unread' 
        ? '/api/notifications?unreadOnly=true&limit=100'
        : '/api/notifications?limit=100';
      
      const res = await fetch(url);
      const data = await res.json();
      
      if (data.success) {
        setNotifications(data.notifications);
        setUnreadCount(data.unreadCount);
      }
    } catch (error) {
      console.error('Load notifications error:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationIds: string[]) => {
    try {
      await fetch('/api/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notificationIds }),
      });
      loadNotifications();
    } catch (error) {
      console.error('Mark as read error:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      await fetch('/api/notifications', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ markAll: true }),
      });
      loadNotifications();
    } catch (error) {
      console.error('Mark all as read error:', error);
    }
  };

  const deleteNotification = async (id: string) => {
    try {
      await fetch(`/api/notifications?id=${id}`, {
        method: 'DELETE',
      });
      loadNotifications();
    } catch (error) {
      console.error('Delete notification error:', error);
    }
  };

  const getNotificationStyle = (type: string) => {
    switch (type) {
      case 'invoice_overdue':
        return 'border-l-destructive bg-destructive/10';
      case 'new_registration':
        return 'border-l-info bg-info/10';
      case 'payment_received':
        return 'border-l-success bg-success/10';
      case 'user_expired':
        return 'border-l-warning bg-warning/10';
      case 'system_alert':
        return 'border-l-primary bg-primary/10';
      default:
        return 'border-l-border bg-muted/50';
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'invoice_overdue': return '💸';
      case 'new_registration': return '👤';
      case 'payment_received': return '✅';
      case 'user_expired': return '⏰';
      case 'system_alert': return '⚠️';
      default: return '📢';
    }
  };

  return (
    <div className="min-h-screen bg-[#1a0f35] relative overflow-hidden p-4 sm:p-6 lg:p-8">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#bc13fe]/20 rounded-full blur-3xl"></div>
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-[#00f7ff]/20 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-[#ff44cc]/20 rounded-full blur-3xl"></div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(188,19,254,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(188,19,254,0.03)_1px,transparent_1px)] bg-[size:50px_50px]"></div>
      </div>
      <div className="relative z-10 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#bc13fe] to-[#ff44cc] rounded-xl p-4 text-white shadow-[0_0_30px_rgba(188,19,254,0.3)]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            <div>
              <h1 className="text-2xl font-bold">{t('notifications.title')}</h1>
              <p className="text-sm text-white/80 mt-1">{t('notifications.manageAll')}</p>
            </div>
          </div>
          {unreadCount > 0 && (
            <span className="px-1.5 py-0.5 text-[10px] font-medium bg-white/20 rounded">
              {unreadCount} {t('notifications.unread')}
            </span>
          )}
        </div>
      </div>

      {/* Stats & Filters */}
      <div className="bg-card rounded-lg border border-border p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <div className="text-center">
              <p className="text-[10px] text-muted-foreground">{t('common.total')}</p>
              <p className="text-lg font-bold text-foreground">{notifications.length}</p>
            </div>
            <div className="h-8 w-px bg-border"></div>
            <div className="text-center">
              <p className="text-[10px] text-muted-foreground">{t('notifications.unread')}</p>
              <p className="text-lg font-bold text-primary">{unreadCount}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex bg-muted rounded-lg p-0.5">
              <button
                onClick={() => setFilter('all')}
                className={`px-2.5 py-1 text-[10px] font-medium rounded-md transition ${
                  filter === 'all'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('common.all')}
              </button>
              <button
                onClick={() => setFilter('unread')}
                className={`px-2.5 py-1 text-[10px] font-medium rounded-md transition ${
                  filter === 'unread'
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('notifications.unread')}
              </button>
            </div>
            {unreadCount > 0 && (
              <button
                onClick={markAllAsRead}
                className="flex items-center gap-1 px-2 py-1 bg-success hover:bg-success/90 text-success-foreground text-[10px] font-medium rounded-lg transition"
              >
                <CheckCheck className="w-3 h-3" />
                {t('notifications.markAllRead')}
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Notifications List */}
      <div className="bg-card rounded-lg border border-border overflow-hidden">
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 animate-spin text-primary" />
          </div>
        ) : notifications.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Bell className="w-10 h-10 mx-auto mb-2 opacity-30" />
            <p className="text-sm font-medium">{t('notifications.noNotifications')}</p>
            <p className="text-[10px] mt-0.5">
              {filter === 'unread' ? t('notifications.allRead') : t('notifications.noNotificationsYet')}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-border">
            {notifications.map((notif) => (
              <div
                key={notif.id}
                className={`p-3 border-l-3 transition-colors ${getNotificationStyle(notif.type)} ${!notif.isRead ? '' : 'opacity-60'}`}
              >
                <div className="flex items-start gap-2.5">
                  <div className="text-lg flex-shrink-0">{getNotificationIcon(notif.type)}</div>
                  
                  <div className="flex-1 min-w-0">
                    {notif.link ? (
                      <Link
                        href={notif.link}
                        onClick={() => {
                          if (!notif.isRead) {
                            markAsRead([notif.id]);
                          }
                        }}
                        className="block group"
                      >
                        <h3 className="text-sm font-semibold text-foreground group-hover:text-primary transition line-clamp-1">
                          {notif.title}
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                          {notif.message}
                        </p>
                        <p className="text-[10px] text-muted-foreground mt-1">
                          {formatWIB(notif.createdAt, 'dd MMM yyyy HH:mm')}
                        </p>
                      </Link>
                    ) : (
                      <>
                        <h3 className="text-sm font-semibold text-foreground line-clamp-1">
                          {notif.title}
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                          {notif.message}
                        </p>
                        <p className="text-[10px] text-muted-foreground mt-1">
                          {formatWIB(notif.createdAt, 'dd MMM yyyy HH:mm')}
                        </p>
                      </>
                    )}
                  </div>

                  <div className="flex items-center gap-1 flex-shrink-0">
                    {!notif.isRead && (
                      <button
                        onClick={() => markAsRead([notif.id])}
                        className="p-1 hover:bg-primary/10 rounded transition"
                        title={t('notifications.markRead')}
                      >
                        <Check className="w-3.5 h-3.5 text-primary" />
                      </button>
                    )}
                    <button
                      onClick={() => deleteNotification(notif.id)}
                      className="p-1 hover:bg-destructive/10 rounded transition"
                      title={t('common.delete')}
                    >
                      <Trash2 className="w-3.5 h-3.5 text-destructive" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      </div>
    </div>
  );
}




