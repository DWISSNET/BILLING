'use client';

import { useState, useEffect } from 'react';
import { useTranslation } from '@/hooks/useTranslation';
import {
  Copy,
  Download,
  CheckCircle,
  AlertCircle,
  Code,
  BookOpen,
  Server,
  Wifi,
  Shield,
  RefreshCw,
  Loader2
} from 'lucide-react';
import Swal from 'sweetalert2';

interface IsolationSettings {
  isolationIpPool: string;
  isolationRateLimit: string;
  baseUrl: string;
}

export default function MikroTikSetupPage() {
  const { t } = useTranslation();
  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState<IsolationSettings>({
    isolationIpPool: '192.168.200.0/24',
    isolationRateLimit: '64k/64k',
    baseUrl: '',
  });
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await fetch('/api/settings/isolation');
      const data = await response.json();

      if (data.success) {
        setSettings({
          isolationIpPool: data.data.isolationIpPool || '192.168.200.0/24',
          isolationRateLimit: data.data.isolationRateLimit || '64k/64k',
          baseUrl: data.data.baseUrl || '',
        });
      }
    } catch (error) {
      console.error('Failed to fetch settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(null), 2000);
    } catch (error) {
      Swal.fire({
        icon: 'error',
        title: 'Gagal!',
        text: 'Gagal menyalin ke clipboard',
      });
    }
  };

  const downloadScript = (script: string, filename: string) => {
    const blob = new Blob([script], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Extract IP range from CIDR
  const getIpRange = (cidr: string) => {
    const [network, mask] = cidr.split('/');
    const parts = network.split('.');
    const lastOctet = parts[3];
    parts[3] = '2';
    const start = parts.join('.');
    parts[3] = '254';
    const end = parts.join('.');
    return `${start}-${end}`;
  };

  const getNetworkAddress = (cidr: string) => {
    return cidr.split('/')[0].replace(/\.\d+$/, '.0/24');
  };

  // Script 1: IP Pool
  const ipPoolScript = `/ip pool
add name=pool-isolir ranges=${getIpRange(settings.isolationIpPool)} comment="IP Pool untuk user yang diisolir"`;

  // Script 2: PPP Profile
  const pppProfileScript = `/ppp profile
add name=isolir \\
    local-address=pool-isolir \\
    remote-address=pool-isolir \\
    rate-limit=${settings.isolationRateLimit} \\
    comment="Profile untuk user yang diisolir"`;

  // Script 3: Firewall Filter (Allow DNS & Payment)
  const firewallFilterScript = `/ip firewall filter
# Allow DNS untuk user isolir
add chain=forward \\
    src-address=${getNetworkAddress(settings.isolationIpPool)} \\
    protocol=udp dst-port=53 \\
    action=accept \\
    comment="Allow DNS for isolated users"

# Allow ICMP (ping)
add chain=forward \\
    src-address=${getNetworkAddress(settings.isolationIpPool)} \\
    protocol=icmp \\
    action=accept \\
    comment="Allow ping for isolated users"

# Allow akses ke server (payment page)
add chain=forward \\
    src-address=${getNetworkAddress(settings.isolationIpPool)} \\
    dst-address=${settings.baseUrl ? new URL(settings.baseUrl).hostname : 'YOUR_SERVER_IP'} \\
    action=accept \\
    comment="Allow access to payment server"

# Block semua akses internet lainnya
add chain=forward \\
    src-address=${getNetworkAddress(settings.isolationIpPool)} \\
    action=drop \\
    comment="Block internet for isolated users"`;

  // Script 4: Firewall NAT (Redirect to Landing Page)
  const firewallNatScript = `/ip firewall nat
# Redirect HTTP ke landing page isolir
add chain=dstnat \\
    src-address=${getNetworkAddress(settings.isolationIpPool)} \\
    protocol=tcp dst-port=80 \\
    dst-address=!${settings.baseUrl ? new URL(settings.baseUrl).hostname : 'YOUR_SERVER_IP'} \\
    action=dst-nat \\
    to-addresses=${settings.baseUrl ? new URL(settings.baseUrl).hostname : 'YOUR_SERVER_IP'} \\
    to-ports=80 \\
    comment="Redirect HTTP to isolation page"

# Redirect HTTPS ke landing page isolir (optional)
add chain=dstnat \\
    src-address=${getNetworkAddress(settings.isolationIpPool)} \\
    protocol=tcp dst-port=443 \\
    dst-address=!${settings.baseUrl ? new URL(settings.baseUrl).hostname : 'YOUR_SERVER_IP'} \\
    action=dst-nat \\
    to-addresses=${settings.baseUrl ? new URL(settings.baseUrl).hostname : 'YOUR_SERVER_IP'} \\
    to-ports=443 \\
    comment="Redirect HTTPS to isolation page"`;

  // Script 5: Address List (Alternative approach)
  const addressListScript = `/ip firewall address-list
add list=isolated-users address=${getNetworkAddress(settings.isolationIpPool)} comment="User yang diisolir"

/ip firewall filter
add chain=forward src-address-list=isolated-users dst-address=!${settings.baseUrl ? new URL(settings.baseUrl).hostname : 'YOUR_SERVER_IP'} action=drop comment="Block internet for isolated users"`;

  // Complete Script
  const completeScript = `# ============================================
# MIKROTIK ISOLATION SYSTEM SETUP
# Auto-generated script from SALFANET RADIUS
# Generated: ${new Date().toLocaleString('id-ID')}
# ============================================

${ipPoolScript}

${pppProfileScript}

${firewallFilterScript}

${firewallNatScript}

# ============================================
# SETUP COMPLETED!
# ============================================
# Setelah menjalankan script ini:
# 1. User yang diisolir akan dapat IP dari pool-isolir
# 2. Bandwidth dibatasi sesuai rate-limit
# 3. Hanya bisa akses DNS dan payment server
# 4. HTTP/HTTPS redirect ke landing page isolir
# ============================================`;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#1a0f35] relative overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none"><div className="absolute top-0 left-1/4 w-96 h-96 bg-[#bc13fe]/20 rounded-full blur-3xl"></div><div className="absolute top-1/3 right-1/4 w-96 h-96 bg-[#00f7ff]/20 rounded-full blur-3xl"></div><div className="absolute bottom-0 left-1/2 w-96 h-96 bg-[#ff44cc]/20 rounded-full blur-3xl"></div><div className="absolute inset-0 bg-[linear-gradient(rgba(188,19,254,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(188,19,254,0.03)_1px,transparent_1px)] bg-[size:50px_50px]"></div></div>
        <Loader2 className="w-12 h-12 animate-spin text-[#00f7ff] drop-shadow-[0_0_20px_rgba(0,247,255,0.6)] relative z-10" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#1a0f35] relative overflow-hidden p-4 sm:p-6 lg:p-8">
      <div className="absolute inset-0 overflow-hidden pointer-events-none"><div className="absolute top-0 left-1/4 w-96 h-96 bg-[#bc13fe]/20 rounded-full blur-3xl"></div><div className="absolute top-1/3 right-1/4 w-96 h-96 bg-[#00f7ff]/20 rounded-full blur-3xl"></div><div className="absolute bottom-0 left-1/2 w-96 h-96 bg-[#ff44cc]/20 rounded-full blur-3xl"></div><div className="absolute inset-0 bg-[linear-gradient(rgba(188,19,254,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(188,19,254,0.03)_1px,transparent_1px)] bg-[size:50px_50px]"></div></div>
      <div className="relative z-10 max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-4">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-[#00f7ff] via-white to-[#ff44cc] bg-clip-text text-transparent drop-shadow-[0_0_30px_rgba(0,247,255,0.5)] mb-1.5">
            <Server className="w-6 h-6 text-[#00f7ff] drop-shadow-[0_0_20px_rgba(0,247,255,0.6)] inline mr-2" />
            {t('isolation.mikrotikTitle')}
          </h1>
          <p className="text-sm text-[#e0d0ff]/80">
            {t('isolation.mikrotikSubtitle')}
          </p>
        </div>

        {/* Info Banner */}
        <div className="bg-primary/10 dark:bg-primary/20 border border-primary/30 dark:border-primary/40 rounded-lg p-3 mb-4">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-primary dark:text-violet-200 flex-shrink-0 mt-0.5" />
            <div className="text-xs text-foreground dark:text-violet-100">
              <p className="font-semibold mb-0.5">{t('isolation.autoScriptBanner')}</p>
              <p>
                {t('isolation.autoScriptDesc')}
              </p>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-4">
          {/* Current Settings */}
          <div className="bg-card rounded-lg border border-border p-4">
            <h3 className="font-semibold text-sm text-foreground mb-3 flex items-center gap-1.5">
              <Shield className="w-4 h-4" />
              {t('isolation.currentSettings')}
            </h3>
            <div className="space-y-2 text-xs">
              <div>
                <span className="text-muted-foreground dark:text-muted-foreground">IP Pool:</span>
                <p className="font-mono font-semibold">{settings.isolationIpPool}</p>
              </div>
              <div>
                <span className="text-muted-foreground dark:text-muted-foreground">Rate Limit:</span>
                <p className="font-mono font-semibold">{settings.isolationRateLimit}</p>
              </div>
              <div>
                <span className="text-muted-foreground dark:text-muted-foreground">Base URL:</span>
                <p className="font-mono font-semibold text-primary">{settings.baseUrl || 'Not configured'}</p>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-card rounded-lg border border-border p-4">
            <h3 className="font-semibold text-sm text-foreground mb-3">{t('isolation.quickActions')}</h3>
            <div className="space-y-2">
              <button
                onClick={() => downloadScript(completeScript, 'mikrotik-isolation-setup.rsc')}
                className="w-full flex items-center justify-center gap-1.5 bg-primary hover:bg-primary/90 text-primary-foreground text-white font-medium py-1.5 px-3 text-sm rounded-lg transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                {t('isolation.downloadCompleteScript')}
              </button>
              <button
                onClick={() => copyToClipboard(completeScript, 'complete')}
                className="w-full flex items-center justify-center gap-1.5 bg-muted hover:bg-muted/80 text-foreground font-medium py-1.5 px-3 text-sm rounded-lg transition-colors"
              >
                {copied === 'complete' ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5" />
                    {t('common.copied')}
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    {t('isolation.copyAllScripts')}
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Scripts */}
        <div className="space-y-6">
          {/* Script 1: IP Pool */}
          <ScriptCard
            title={t('isolation.createIpPool')}
            description={t('isolation.createIpPoolDesc')}
            script={ipPoolScript}
            icon={<Wifi className="w-5 h-5" />}
            copied={copied === 'pool'}
            onCopy={() => copyToClipboard(ipPoolScript, 'pool')}
            onDownload={() => downloadScript(ipPoolScript, '01-ip-pool.rsc')}
          />

          {/* Script 2: PPP Profile */}
          <ScriptCard
            title={t('isolation.createPppProfile')}
            description={t('isolation.createPppProfileDesc')}
            script={pppProfileScript}
            icon={<Server className="w-5 h-5" />}
            copied={copied === 'profile'}
            onCopy={() => copyToClipboard(pppProfileScript, 'profile')}
            onDownload={() => downloadScript(pppProfileScript, '02-ppp-profile.rsc')}
          />

          {/* Script 3: Firewall Filter */}
          <ScriptCard
            title={t('isolation.firewallFilter')}
            description={t('isolation.firewallFilterDesc')}
            script={firewallFilterScript}
            icon={<Shield className="w-5 h-5" />}
            copied={copied === 'filter'}
            onCopy={() => copyToClipboard(firewallFilterScript, 'filter')}
            onDownload={() => downloadScript(firewallFilterScript, '03-firewall-filter.rsc')}
          />

          {/* Script 4: Firewall NAT */}
          <ScriptCard
            title={t('isolation.firewallNat')}
            description={t('isolation.firewallNatDesc')}
            script={firewallNatScript}
            icon={<Code className="w-5 h-5" />}
            copied={copied === 'nat'}
            onCopy={() => copyToClipboard(firewallNatScript, 'nat')}
            onDownload={() => downloadScript(firewallNatScript, '04-firewall-nat.rsc')}
          />
        </div>

        {/* Tutorial Section */}
        <div className="mt-8 bg-card rounded-lg border border-border p-6">
          <h2 className="text-xl font-bold text-foreground mb-4 flex items-center gap-2">
            <BookOpen className="w-6 h-6" />
            {t('isolation.tutorialTitle')}
          </h2>

          <div className="space-y-6">
            <TutorialStep
              number={1}
              title={t('isolation.tutorialStep1')}
              description={t('isolation.tutorialStep1Desc')}
              code="ssh admin@192.168.1.1"
            />

            <TutorialStep
              number={2}
              title={t('isolation.tutorialStep2')}
              description={t('isolation.tutorialStep2Desc')}
              code="/import file=mikrotik-isolation-setup.rsc"
            />

            <TutorialStep
              number={3}
              title={t('isolation.tutorialStep3')}
              description={t('isolation.tutorialStep3Desc')}
              code={`/ip pool print
/ppp profile print
/ip firewall filter print
/ip firewall nat print`}
            />

            <TutorialStep
              number={4}
              title={t('isolation.tutorialStep4')}
              description={t('isolation.tutorialStep4Desc')}
              code={`# Di aplikasi, set user ke expired
# Tunggu cron job jalan atau trigger manual
# User akan dapat IP dari pool-isolir dan dibatasi aksesnya`}
            />

            <TutorialStep
              number={5}
              title={t('isolation.tutorialStep5')}
              description={t('isolation.tutorialStep5Desc')}
              code={`/ppp active print
/log print where topics~"ppp"
/ip firewall connection print where src-address~"192.168.200"`}
            />
          </div>
        </div>

        {/* Tips */}
        <div className="mt-6 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
          <h3 className="font-semibold text-amber-800 dark:text-amber-300 mb-2">💡 {t('isolation.tipsTitle')}</h3>
          <ul className="text-sm text-amber-700 dark:text-amber-400 space-y-1 list-disc list-inside">
            <li>{t('isolation.tipBackup')}</li>
            <li>{t('isolation.tipTestFirst')}</li>
            <li>{t('isolation.tipMonitorLog')}</li>
            <li>{t('isolation.tipAdjustFirewall')}</li>
            <li>{t('isolation.tipCheckBaseUrl')}</li>
          </ul>
        </div>
      </div>
    </div>
  );
}

interface ScriptCardProps {
  title: string;
  description: string;
  script: string;
  icon: React.ReactNode;
  copied: boolean;
  onCopy: () => void;
  onDownload: () => void;
}

function ScriptCard({ title, description, script, icon, copied, onCopy, onDownload }: ScriptCardProps) {
  return (
    <div className="bg-card rounded-lg border border-border overflow-hidden">
      <div className="p-4 border-b border-border">
        <div className="flex items-start justify-between">
          <div className="flex items-start gap-3">
            <div className="text-primary dark:text-primary mt-1">
              {icon}
            </div>
            <div>
              <h3 className="font-semibold text-foreground">{title}</h3>
              <p className="text-sm text-muted-foreground dark:text-muted-foreground mt-1">{description}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={onCopy}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
              title="Copy to clipboard"
            >
              {copied ? (
                <CheckCircle className="w-4 h-4 text-success" />
              ) : (
                <Copy className="w-4 h-4 text-muted-foreground dark:text-muted-foreground" />
              )}
            </button>
            <button
              onClick={onDownload}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg transition-colors"
              title="Download script"
            >
              <Download className="w-4 h-4 text-muted-foreground dark:text-muted-foreground" />
            </button>
          </div>
        </div>
      </div>
      <div className="p-4 bg-muted/50">
        <pre className="text-xs font-mono text-foreground overflow-x-auto whitespace-pre-wrap break-all">
          {script}
        </pre>
      </div>
    </div>
  );
}

interface TutorialStepProps {
  number: number;
  title: string;
  description: string;
  code?: string;
}

function TutorialStep({ number, title, description, code }: TutorialStepProps) {
  return (
    <div className="flex gap-4">
      <div className="flex-shrink-0">
        <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
          {number}
        </div>
      </div>
      <div className="flex-1">
        <h4 className="font-semibold text-foreground mb-1">{title}</h4>
        <p className="text-sm text-muted-foreground dark:text-muted-foreground mb-2">{description}</p>
        {code && (
          <pre className="text-xs font-mono bg-muted p-3 rounded-lg overflow-x-auto">
            {code}
          </pre>
        )}
      </div>
    </div>
  );
}
