'use client';

import { useState, useEffect, useCallback, Suspense } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useSession, signOut, SessionProvider } from 'next-auth/react';
import {
  LayoutDashboard,
  Users,
  Wifi,
  Receipt,
  CreditCard,
  Wallet,
  Clock,
  MessageSquare,
  Network,
  Settings,
  Menu,
  X,
  ChevronDown,
  Shield,
  Search,
  LogOut,

  Router,
  AlertTriangle,
  Timer,
  Server,
  Bell,
  Package,
  UserCheck,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAppStore } from '@/lib/store';
import NotificationDropdown from '@/components/NotificationDropdown';
import { LanguageSwitcher } from '@/components/LanguageSwitcher';
import { useTranslation } from '@/hooks/useTranslation';
import { useIdleTimeout } from '@/hooks/useIdleTimeout';

interface MenuItem {
  titleKey: string;
  icon: React.ReactNode;
  href?: string;
  children?: { titleKey: string; href: string; badge?: string; requiredPermission?: string }[];
  badge?: string;
  requiredPermission?: string;
}

const menuItems: MenuItem[] = [
  {
    titleKey: 'nav.dashboard',
    icon: <LayoutDashboard className="w-4 h-4" />,
    href: '/admin',
    requiredPermission: 'dashboard.view',
  },
  {
    titleKey: 'nav.notifications',
    icon: <Bell className="w-4 h-4" />,
    href: '/admin/notifications',
    badge: 'notifications',
    requiredPermission: 'dashboard.view',
  },
  {
    titleKey: 'nav.pppoe',
    icon: <Users className="w-4 h-4" />,
    requiredPermission: 'customers.view',
    children: [
      { titleKey: 'nav.users', href: '/admin/pppoe/users', requiredPermission: 'customers.view' },
      { titleKey: 'nav.profiles', href: '/admin/pppoe/profiles', requiredPermission: 'customers.view' },
      { titleKey: 'nav.areas', href: '/admin/pppoe/areas', requiredPermission: 'customers.view' },
      { titleKey: 'nav.stopSubscription', href: '/admin/pppoe/stopped', requiredPermission: 'customers.view' },
      { titleKey: 'nav.registrations', href: '/admin/pppoe/registrations', badge: 'pending', requiredPermission: 'registrations.view' },
    ],
  },
  {
    titleKey: 'nav.hotspot',
    icon: <Wifi className="w-4 h-4" />,
    requiredPermission: 'hotspot.view',
    children: [
      { titleKey: 'nav.voucher', href: '/admin/hotspot/voucher', requiredPermission: 'vouchers.view' },
      { titleKey: 'nav.rekapVoucher', href: '/admin/hotspot/rekap-voucher', requiredPermission: 'vouchers.view' },
      { titleKey: 'nav.profile', href: '/admin/hotspot/profile', requiredPermission: 'hotspot.view' },
      { titleKey: 'nav.template', href: '/admin/hotspot/template', requiredPermission: 'hotspot.view' },
      { titleKey: 'nav.agent', href: '/admin/hotspot/agent', requiredPermission: 'hotspot.view' },
      { titleKey: 'nav.evoucher', href: '/admin/hotspot/evoucher', requiredPermission: 'vouchers.view' },
    ],
  },
  {
    titleKey: 'nav.invoices',
    icon: <Receipt className="w-4 h-4" />,
    href: '/admin/invoices',
    requiredPermission: 'invoices.view',
  },
  {
    titleKey: 'nav.payment',
    icon: <CreditCard className="w-4 h-4" />,
    requiredPermission: 'settings.payment',
    children: [
      { titleKey: 'nav.paymentGateway', href: '/admin/payment-gateway', requiredPermission: 'settings.payment' },
      { titleKey: 'nav.manualPayments', href: '/admin/manual-payments', badge: 'manualPayments', requiredPermission: 'invoices.view' },
    ],
  },
  {
    titleKey: 'nav.transaksi',
    icon: <Wallet className="w-4 h-4" />,
    href: '/admin/keuangan',
    requiredPermission: 'keuangan.view',
  },
  {
    titleKey: 'nav.sessions',
    icon: <Clock className="w-4 h-4" />,
    requiredPermission: 'sessions.view',
    children: [
      { titleKey: 'nav.pppoeSessions', href: '/admin/sessions/pppoe', requiredPermission: 'sessions.view' },
      { titleKey: 'nav.hotspotSessions', href: '/admin/sessions/hotspot', requiredPermission: 'sessions.view' },
    ],
  },

  {
    titleKey: 'nav.router',
    icon: <Router className="w-4 h-4" />,
    requiredPermission: 'routers.view',
    children: [
      { titleKey: 'nav.routerNas', href: '/admin/network/routers', requiredPermission: 'routers.view' },
      { titleKey: 'nav.vpnServer', href: '/admin/network/vpn-server', requiredPermission: 'routers.view' },
      { titleKey: 'nav.vpnClient', href: '/admin/network/vpn-client', requiredPermission: 'routers.view' },
    ],
  },
  {
    titleKey: 'nav.network',
    icon: <Network className="w-4 h-4" />,
    requiredPermission: 'network.view',
    children: [
      { titleKey: 'nav.networkMap', href: '/admin/network/map', requiredPermission: 'network.view' },
      { titleKey: 'nav.olt', href: '/admin/network/olts', requiredPermission: 'network.view' },
      { titleKey: 'nav.odc', href: '/admin/network/odcs', requiredPermission: 'network.view' },
      { titleKey: 'nav.odp', href: '/admin/network/odps', requiredPermission: 'network.view' },
      { titleKey: 'nav.odpCustomer', href: '/admin/network/customers', requiredPermission: 'network.view' },
    ],
  },
  {
    titleKey: 'nav.genieacs',
    icon: <Router className="w-4 h-4" />,
    requiredPermission: 'settings.genieacs',
    children: [
      { titleKey: 'nav.devices', href: '/admin/genieacs/devices', requiredPermission: 'settings.genieacs' },
      { titleKey: 'nav.tasks', href: '/admin/genieacs/tasks', requiredPermission: 'settings.genieacs' },
      { titleKey: 'nav.virtualParameters', href: '/admin/genieacs/virtual-parameters', requiredPermission: 'settings.genieacs' },
      { titleKey: 'nav.parameterConfig', href: '/admin/genieacs/parameter-config', requiredPermission: 'settings.genieacs' },
    ],
  },
  {
    titleKey: 'nav.freeradius',
    icon: <Server className="w-4 h-4" />,
    requiredPermission: 'settings.view',
    children: [
      { titleKey: 'nav.radiusStatus', href: '/admin/freeradius/status', requiredPermission: 'settings.view' },
      { titleKey: 'nav.radiusConfig', href: '/admin/freeradius/config', requiredPermission: 'settings.view' },
      { titleKey: 'nav.radTest', href: '/admin/freeradius/radtest', requiredPermission: 'settings.view' },
      { titleKey: 'nav.radCheck', href: '/admin/freeradius/radcheck', requiredPermission: 'settings.view' },
      { titleKey: 'nav.radiusLogs', href: '/admin/freeradius/logs', requiredPermission: 'settings.view' },
    ],
  },
  {
    titleKey: 'nav.inventory',
    icon: <Package className="w-4 h-4" />,
    requiredPermission: 'settings.view',
    children: [
      { titleKey: 'nav.inventoryItems', href: '/admin/inventory/items', requiredPermission: 'settings.view' },
      { titleKey: 'nav.inventoryMovements', href: '/admin/inventory/movements', requiredPermission: 'settings.view' },
      { titleKey: 'nav.inventoryCategories', href: '/admin/inventory/categories', requiredPermission: 'settings.view' },
      { titleKey: 'nav.inventorySuppliers', href: '/admin/inventory/suppliers', requiredPermission: 'settings.view' },
    ],
  },
  {
    titleKey: 'nav.technician',
    icon: <Users className="w-4 h-4" />,
    requiredPermission: 'dashboard.view',
    children: [
      { titleKey: 'nav.technicianLogin', href: '/technician/login', requiredPermission: 'dashboard.view' },
      { titleKey: 'nav.manageTechnicians', href: '/admin/technicians', requiredPermission: 'users.view' },
    ],
  },
  {
    titleKey: 'nav.coordinator',
    icon: <UserCheck className="w-4 h-4" />,
    requiredPermission: 'dashboard.view',
    children: [
      { titleKey: 'nav.coordinatorLogin', href: '/coordinator/login', requiredPermission: 'dashboard.view' },
      { titleKey: 'nav.manageCoordinators', href: '/admin/coordinators', requiredPermission: 'users.view' },
    ],
  },
  {
    titleKey: 'nav.tickets',
    icon: <MessageSquare className="w-4 h-4" />,
    requiredPermission: 'dashboard.view',
    children: [
      { titleKey: 'nav.allTickets', href: '/admin/tickets', requiredPermission: 'dashboard.view' },
      { titleKey: 'nav.ticketCategories', href: '/admin/tickets/categories', requiredPermission: 'settings.view' },
    ],
  },
  {
    titleKey: 'nav.management',
    icon: <Shield className="w-4 h-4" />,
    href: '/admin/management',
    requiredPermission: 'users.view',
  },
  {
    titleKey: 'nav.isolation',
    icon: <Shield className="w-4 h-4" />,
    requiredPermission: 'settings.view',
    children: [
      { titleKey: 'nav.isolationSettings', href: '/admin/settings/isolation', requiredPermission: 'settings.view' },
      { titleKey: 'nav.isolationTemplates', href: '/admin/settings/isolation/templates', requiredPermission: 'settings.view' },
      { titleKey: 'nav.mikrotikSetup', href: '/admin/settings/isolation/mikrotik', requiredPermission: 'settings.view' },
    ],
  },
  {
    titleKey: 'nav.settingsMenu',
    icon: <Settings className="w-4 h-4" />,
    requiredPermission: 'settings.view',
    children: [
      { titleKey: 'nav.company', href: '/admin/settings/company', requiredPermission: 'settings.company' },
      { titleKey: 'nav.email', href: '/admin/settings/email', requiredPermission: 'settings.view' },
      { titleKey: 'nav.whatsapp', href: '/admin/settings/whatsapp', requiredPermission: 'whatsapp.view' },
      { titleKey: 'nav.database', href: '/admin/settings/database', requiredPermission: 'settings.view' },
      { titleKey: 'nav.cronJobs', href: '/admin/settings/cron', requiredPermission: 'settings.cron' },
      { titleKey: 'nav.genieacs', href: '/admin/settings/genieacs', requiredPermission: 'settings.genieacs' },
    ],
  },
];

function NavItem({ item, pendingCount, manualPaymentsCount, unreadNotifications, collapsed, t, onNavigate }: { item: MenuItem; pendingCount: number; manualPaymentsCount: number; unreadNotifications: number; collapsed?: boolean; t: (key: string, params?: Record<string, string | number>) => string; onNavigate?: () => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const pathname = usePathname();
  const isActive = item.href === pathname || item.children?.some(c => c.href === pathname);

  if (item.children) {
    return (
      <div>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            'w-full flex items-center gap-2.5 px-2.5 py-2.5 text-xs font-bold rounded-xl transition-all duration-300 group',
            isActive
              ? 'text-cyan-400 bg-cyan-500/10 border border-cyan-400/30 shadow-[0_0_15px_rgba(0,255,255,0.15),inset_0_1px_0_rgba(255,255,255,0.05)]'
              : 'text-muted-foreground hover:text-foreground hover:bg-primary/10 border border-transparent hover:border-primary/20',
          )}
        >
          <span className={cn(
            'flex-shrink-0 p-1.5 rounded-lg transition-all duration-300',
            isActive ? 'text-cyan-400 bg-cyan-500/10 drop-shadow-[0_0_8px_rgba(0,255,255,0.8)]' : 'text-muted-foreground group-hover:text-cyan-400'
          )}>
            {item.icon}
          </span>
          {!collapsed && (
            <>
              <span className="flex-1 text-left truncate tracking-wide uppercase">{t(item.titleKey)}</span>
              <ChevronDown className={cn('w-3.5 h-3.5 transition-transform duration-300', isOpen && 'rotate-180')} />
            </>
          )}
        </button>
        {!collapsed && (
          <div className={cn(
            'overflow-hidden transition-all duration-300 ease-in-out',
            isOpen ? 'max-h-96 opacity-100 mt-1' : 'max-h-0 opacity-0'
          )}>
            <div className="ml-4 pl-3 border-l-2 border-cyan-500/20 space-y-1">
              {item.children.map((child) => (
                <Link
                  key={child.href}
                  href={child.href}
                  onClick={onNavigate}
                  className={cn(
                    'flex items-center justify-between px-3 py-2 text-xs rounded-lg transition-all duration-200 group/item',
                    pathname === child.href
                      ? 'text-cyan-400 bg-cyan-500/10 border border-cyan-400/20 shadow-[0_0_10px_rgba(0,255,255,0.1)]'
                      : 'text-muted-foreground hover:text-foreground hover:bg-primary/10'
                  )}
                >
                  <span className="tracking-wide">{t(child.titleKey)}</span>
                  {child.badge === 'pending' && pendingCount > 0 && (
                    <span className="bg-red-500 text-white text-[9px] px-1.5 py-0.5 rounded-md font-bold min-w-[18px] text-center shadow-[0_0_8px_rgba(255,0,0,0.5)] animate-pulse">
                      {pendingCount}
                    </span>
                  )}
                  {child.badge === 'manualPayments' && manualPaymentsCount > 0 && (
                    <span className="bg-amber-500 text-black text-[9px] px-1.5 py-0.5 rounded-md font-bold min-w-[18px] text-center shadow-[0_0_8px_rgba(245,158,11,0.5)] animate-pulse">
                      {manualPaymentsCount}
                    </span>
                  )}
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  // Get badge count based on badge type
  const getBadgeCount = () => {
    if (item.badge === 'notifications') return unreadNotifications;
    return 0;
  };

  const badgeCount = getBadgeCount();

  return (
    <Link
      href={item.href!}
      onClick={onNavigate}
      className={cn(
        'flex items-center gap-2.5 px-2.5 py-2.5 text-xs font-bold rounded-xl transition-all duration-300 group',
        pathname === item.href
          ? 'text-cyan-400 bg-cyan-500/10 border border-cyan-400/30 shadow-[0_0_15px_rgba(0,255,255,0.15),inset_0_1px_0_rgba(255,255,255,0.05)]'
          : 'text-muted-foreground hover:text-foreground hover:bg-primary/10 border border-transparent hover:border-primary/20',
      )}
    >
      <span className={cn(
        'flex-shrink-0 p-1.5 rounded-lg transition-all duration-300',
        pathname === item.href ? 'text-cyan-400 bg-cyan-500/10 drop-shadow-[0_0_8px_rgba(0,255,255,0.8)]' : 'text-muted-foreground group-hover:text-cyan-400'
      )}>
        {item.icon}
      </span>
      {!collapsed && (
        <>
          <span className="truncate tracking-wide uppercase">{t(item.titleKey)}</span>
          {badgeCount > 0 && (
            <span className="ml-auto flex-shrink-0 bg-red-500 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-md min-w-[18px] text-center shadow-[0_0_8px_rgba(255,0,0,0.5)] animate-pulse">
              {badgeCount > 99 ? '99+' : badgeCount}
            </span>
          )}
        </>
      )}
    </Link>
  );
}

function AdminLayoutContent({
  children,
}: {
  children: React.ReactNode;
}) {
  const { data: session, status } = useSession();
  const pathname = usePathname();
  const [sidebarOpen, setSidebarOpen] = useState(false); // Default FALSE untuk mobile
  const [mounted, setMounted] = useState(false);
  const [pendingRegistrations, setPendingRegistrations] = useState(0);
  const [pendingManualPayments, setPendingManualPayments] = useState(0);
  const [unreadNotifications, setUnreadNotifications] = useState(0);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [userPermissions, setUserPermissions] = useState<string[]>([]);
  const [showIdleWarning, setShowIdleWarning] = useState(false);
  const [idleCountdown, setIdleCountdown] = useState(60);
  const { company, setCompany } = useAppStore();
  const { t } = useTranslation();

  const isLoginPage = pathname === '/admin/login';

  // Set sidebar state based on screen size
  useEffect(() => {
    const handleResize = () => {
      // Open sidebar by default on desktop (lg breakpoint = 1024px)
      if (window.innerWidth >= 1024) {
        setSidebarOpen(true);
      } else {
        setSidebarOpen(false);
      }
    };

    // Set initial state
    handleResize();

    // Listen for resize events
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Idle timeout - 30 minutes with 1 minute warning
  const { extendSession } = useIdleTimeout({
    timeout: 30 * 60 * 1000, // 30 minutes
    warningTime: 60 * 1000, // 1 minute warning
    enabled: !isLoginPage && status === 'authenticated',
    onWarning: () => {
      setShowIdleWarning(true);
      setIdleCountdown(60);
    },
  });

  // Countdown timer for idle warning
  useEffect(() => {
    if (!showIdleWarning) return;

    const interval = setInterval(() => {
      setIdleCountdown(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [showIdleWarning]);

  // Handle stay logged in
  const handleStayLoggedIn = useCallback(() => {
    setShowIdleWarning(false);
    setIdleCountdown(60);
    extendSession();
  }, [extendSession]);

  // Handle logout - use redirect: false to avoid NEXTAUTH_URL issues
  const handleLogout = useCallback(async () => {
    // Log logout activity before signing out
    if (session?.user) {
      try {
        await fetch('/api/auth/logout-log', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: (session.user as any).id,
            username: (session.user as any).username,
            role: (session.user as any).role,
          }),
        });
      } catch (error) {
        console.error('Failed to log logout:', error);
      }
    }

    await signOut({ redirect: false });
    // Manual redirect to current origin
    window.location.href = `${window.location.origin}/admin/login`;
  }, [session]);

  useEffect(() => {
    setMounted(true);
    // Force dark mode only
    document.documentElement.classList.add('dark');
  }, []);

  // Load user permissions when session is available
  useEffect(() => {
    if (status !== 'authenticated' || !session?.user) return;

    const userId = (session.user as any).id;
    if (userId) {
      fetch(`/api/admin/users/${userId}/permissions`)
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            setUserPermissions(data.permissions);
          }
        })
        .catch(console.error);
    }
  }, [session, status]);

  // Load company data
  useEffect(() => {
    fetch('/api/company')
      .then((res) => res.json())
      .then((data) => {
        if (data.name) {
          setCompany({
            name: data.name,
            email: data.email,
            phone: data.phone,
            address: data.address,
            baseUrl: data.baseUrl || window.location.origin,
            adminPhone: data.phone,
          });
        }
      })
      .catch(console.error);
  }, [setCompany]);

  // Load pending registrations
  useEffect(() => {
    if (status !== 'authenticated') return;

    const loadPending = () => {
      fetch('/api/admin/registrations?status=PENDING')
        .then((res) => res.json())
        .then((data) => {
          if (data.stats) setPendingRegistrations(data.stats.pending || 0);
        })
        .catch(console.error);
    };

    loadPending();
    const interval = setInterval(loadPending, 30000);
    return () => clearInterval(interval);
  }, [status]);

  // Load pending manual payments
  useEffect(() => {
    if (status !== 'authenticated') return;

    const loadPendingPayments = () => {
      fetch('/api/manual-payments?status=PENDING')
        .then((res) => res.json())
        .then((data) => {
          if (data.success) setPendingManualPayments(data.data?.length || 0);
        })
        .catch(console.error);
    };

    loadPendingPayments();
    const interval = setInterval(loadPendingPayments, 30000);
    return () => clearInterval(interval);
  }, [status]);

  // Load unread notifications
  useEffect(() => {
    if (status !== 'authenticated') return;

    const loadUnreadNotifications = () => {
      fetch('/api/notifications?limit=1')
        .then((res) => res.json())
        .then((data) => {
          if (data.success) setUnreadNotifications(data.unreadCount || 0);
        })
        .catch(console.error);
    };

    loadUnreadNotifications();
    const interval = setInterval(loadUnreadNotifications, 30000);
    return () => clearInterval(interval);
  }, [status]);



  // Show login page without layout
  if (isLoginPage) {
    return <>{children}</>;
  }

  // Show loading while checking session
  if (status === 'loading' || !mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[100px] animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-500/10 rounded-full blur-[100px] animate-pulse delay-1000" />
        </div>

        <div className="flex flex-col items-center gap-4 relative z-10">
          <div className="relative">
            <div className="w-12 h-12 border-3 border-cyan-500/30 border-t-cyan-400 rounded-full animate-spin shadow-[0_0_20px_rgba(0,255,255,0.3)]" />
            <div className="absolute inset-0 w-12 h-12 border-3 border-pink-500/20 border-b-pink-400 rounded-full animate-spin animate-reverse" style={{ animationDuration: '1.5s' }} />
          </div>
          <p className="text-sm text-cyan-400/80 font-medium tracking-wider uppercase animate-pulse">{t('common.loading')}</p>
        </div>
      </div>
    );
  }

  // Redirect to login if not authenticated
  if (status === 'unauthenticated') {
    if (typeof window !== 'undefined') {
      window.location.href = `${window.location.origin}/admin/login`;
    }
    return (
      <div className="min-h-screen bg-background flex items-center justify-center relative overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[100px] animate-pulse" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-500/10 rounded-full blur-[100px] animate-pulse delay-1000" />
        </div>

        <div className="flex flex-col items-center gap-4 relative z-10">
          <div className="relative">
            <div className="w-12 h-12 border-3 border-cyan-500/30 border-t-cyan-400 rounded-full animate-spin shadow-[0_0_20px_rgba(0,255,255,0.3)]" />
            <div className="absolute inset-0 w-12 h-12 border-3 border-pink-500/20 border-b-pink-400 rounded-full animate-spin animate-reverse" style={{ animationDuration: '1.5s' }} />
          </div>
          <p className="text-sm text-cyan-400/80 font-medium tracking-wider uppercase animate-pulse">{t('common.redirectingToLogin')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      {/* Cyberpunk Background Effects */}
      <div className="fixed inset-0 pointer-events-none z-0">
        {/* Primary glow orbs */}
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cyan-500/5 rounded-full blur-[100px] animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-pink-500/5 rounded-full blur-[100px] animate-pulse delay-1000" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[60%] h-[60%] bg-purple-500/3 rounded-full blur-[120px]" />

        {/* Scan lines overlay */}
        <div className="absolute inset-0 bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.01)_2px,rgba(0,255,255,0.01)_4px)]" />

        {/* Grid pattern */}
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,255,0.02)_1px,transparent_1px)] bg-[size:50px_50px]" />
      </div>

      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/80 backdrop-blur-md z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        'fixed top-0 left-0 z-50 h-screen w-64 transition-transform duration-300 ease-out',
        'bg-background/95 backdrop-blur-xl',
        'border-r border-cyan-500/20',
        'shadow-[5px_0_30px_rgba(0,255,255,0.1),inset_-1px_0_0_rgba(255,255,255,0.05)]',
        sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
      )}>
        {/* Top neon line */}
        <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />

        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-between px-6 py-5 border-b border-cyan-500/20 bg-gradient-to-r from-cyan-500/5 via-transparent to-pink-500/5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-cyan-500 to-cyan-400 flex items-center justify-center border border-cyan-400/50 shadow-[0_0_20px_rgba(0,255,255,0.4),inset_0_1px_0_rgba(255,255,255,0.2)] animate-[neonPulse_3s_ease-in-out_infinite]">
                <span className="text-black font-black text-sm">{company.name.charAt(0)}</span>
              </div>
              <div>
                <h1 className="text-xs font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-cyan-300 to-pink-400 drop-shadow-[0_0_10px_rgba(0,255,255,0.5)] truncate max-w-[110px]">
                  {company.name}
                </h1>
                <p className="text-[10px] text-cyan-400/60 tracking-[0.2em] uppercase font-medium">{t('common.billingSystem')}</p>
              </div>
            </div>
            <button
              onClick={() => setSidebarOpen(false)}
              className="lg:hidden p-1.5 hover:bg-primary/20 rounded-md text-muted-foreground hover:text-primary transition-colors border border-transparent hover:border-primary/30"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-3 space-y-1 custom-scrollbar">
            {menuItems
              .filter((item) => {
                if (!item.requiredPermission) return true;
                return userPermissions.includes(item.requiredPermission);
              })
              .map((item) => {
                const filteredItem = {
                  ...item,
                  children: item.children?.filter((child) => {
                    if (!child.requiredPermission) return true;
                    return userPermissions.includes(child.requiredPermission);
                  }),
                };

                if (filteredItem.children && filteredItem.children.length === 0) {
                  return null;
                }

                return (
                  <NavItem
                    key={item.titleKey}
                    item={filteredItem}
                    pendingCount={pendingRegistrations}
                    manualPaymentsCount={pendingManualPayments}
                    unreadNotifications={unreadNotifications}
                    t={t}
                    onNavigate={() => setSidebarOpen(false)}
                  />
                );
              })}
          </nav>

          {/* User */}
          <div className="p-4 border-t border-cyan-500/20 bg-gradient-to-r from-cyan-500/5 via-transparent to-pink-500/5">
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-primary/20 transition-all duration-300 border border-transparent hover:border-primary/30 group"
              >
                <div className="w-9 h-9 bg-gradient-to-br from-cyan-500 to-pink-500 rounded-lg flex items-center justify-center text-white text-sm font-black shadow-[0_0_15px_rgba(0,255,255,0.3)] group-hover:shadow-[0_0_20px_rgba(0,255,255,0.5)] transition-shadow">
                  {session?.user?.name?.charAt(0).toUpperCase() || 'A'}
                </div>
                <div className="flex-1 min-w-0 text-left">
                  <p className="text-xs font-bold text-foreground truncate tracking-wide">
                    {session?.user?.name || 'Admin'}
                  </p>
                  <p className="text-[10px] text-cyan-400 truncate font-medium tracking-wider uppercase">
                    {(session?.user as any)?.role || 'admin'}
                  </p>
                </div>
                <ChevronDown className={cn('w-3.5 h-3.5 text-muted-foreground group-hover:text-cyan-400 transition-all duration-300', showUserMenu && 'rotate-180')} />
              </button>

              {showUserMenu && (
                <div className="absolute bottom-full left-0 right-0 mb-2 bg-background/95 backdrop-blur-xl rounded-xl shadow-[0_0_30px_rgba(0,0,0,0.5),0_0_10px_rgba(0,255,255,0.1)] border border-cyan-500/20 overflow-hidden animate-in slide-in-from-bottom-2 duration-200">
                  <div className="absolute top-0 left-2 right-2 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />
                  <div className="p-3 border-b border-cyan-500/20 bg-gradient-to-r from-cyan-500/10 via-transparent to-pink-500/10">
                    <p className="text-[9px] text-muted-foreground uppercase tracking-[0.2em] font-medium">{t('auth.signedInAs')}</p>
                    <p className="text-xs font-bold text-cyan-400 truncate mt-1">
                      {(session?.user as any)?.username}
                    </p>
                  </div>
                  <button
                    onClick={handleLogout}
                    className="w-full flex items-center gap-2 px-4 py-3 text-xs font-bold text-red-400 hover:text-red-300 hover:bg-red-500/10 transition-colors uppercase tracking-wider"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    {t('auth.signOut')}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <div className="lg:pl-64 min-h-screen flex flex-col relative z-10 transition-all duration-300">
        {/* Header */}
        <header className="sticky top-0 z-30 bg-background/80 backdrop-blur-xl border-b border-cyan-500/20 shadow-[0_4px_30px_rgba(0,0,0,0.3),0_0_15px_rgba(0,255,255,0.05)]">
          {/* Top neon line */}
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />

          <div className="flex items-center gap-4 px-6 py-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 hover:bg-primary/20 rounded-lg text-foreground hover:text-primary transition-colors border border-transparent hover:border-primary/30"
            >
              <Menu className="w-5 h-5" />
            </button>

            {/* Search */}
            <div className="hidden sm:flex flex-1 max-w-md">
              <div className="relative w-full group">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground group-focus-within:text-accent transition-colors" />
                <input
                  type="text"
                  placeholder={t('common.search')}
                  className="w-full pl-10 pr-4 py-2.5 bg-card/50 border-2 border-primary/20 rounded-xl text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-accent/50 focus:ring-2 focus:ring-accent/20 focus:bg-card/80 focus:shadow-[0_0_20px_rgba(0,247,255,0.1)] transition-all duration-300"
                />
                {/* Bottom focus line */}
                <div className="absolute bottom-0 left-3 right-3 h-px bg-gradient-to-r from-transparent via-accent/0 to-transparent group-focus-within:via-accent transition-all duration-300" />
              </div>
            </div>

            <div className="flex-1" />

            {/* Actions */}
            <div className="flex items-center gap-2">
              <NotificationDropdown />

              <LanguageSwitcher variant="compact" />
            </div>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 p-4 sm:p-6 animate-in fade-in duration-500">{children}</main>
      </div>

      {/* Idle Timeout Warning Modal */}
      {showIdleWarning && (
        <div className="fixed inset-0 z-[100] bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          {/* Scan lines */}
          <div className="absolute inset-0 pointer-events-none bg-[repeating-linear-gradient(0deg,transparent,transparent_2px,rgba(0,255,255,0.02)_2px,rgba(0,255,255,0.02)_4px)]" />

          <div className="relative bg-background/95 backdrop-blur-xl border-2 border-cyan-500/30 rounded-2xl shadow-[0_0_50px_rgba(0,255,255,0.2),0_0_100px_rgba(255,0,255,0.1)] max-w-sm w-full p-6 animate-in zoom-in-95 duration-300">
            {/* Top neon line */}
            <div className="absolute top-0 left-4 right-4 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent" />

            {/* Corner accents */}
            <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-400 rounded-tl-lg" />
            <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-400 rounded-tr-lg" />
            <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-pink-400 rounded-bl-lg" />
            <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-pink-400 rounded-br-lg" />

            <div className="flex items-center gap-4 mb-6">
              <div className="p-3 bg-amber-500/10 rounded-xl border border-amber-500/30 shadow-[0_0_15px_rgba(245,158,11,0.3)] animate-pulse">
                <Timer className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <h3 className="text-lg font-black text-foreground tracking-wider uppercase drop-shadow-[0_0_10px_rgba(0,255,255,0.3)]">
                  {t('common.sessionTimeout')}
                </h3>
                <p className="text-[10px] text-cyan-400/60 tracking-[0.2em] uppercase font-medium">
                  {t('common.securityProtocolActive')}
                </p>
              </div>
            </div>

            <div className="mb-8 text-center">
              <p className="text-sm text-muted-foreground mb-4">
                {t('common.autoLogoutInactivity')}
              </p>
              <div className="inline-flex items-center justify-center gap-3 px-6 py-4 bg-amber-500/10 border border-amber-500/30 rounded-xl shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]">
                <AlertTriangle className="w-5 h-5 text-amber-400 animate-pulse" />
                <span className="text-4xl font-mono font-black text-amber-400 tabular-nums drop-shadow-[0_0_10px_rgba(245,158,11,0.5)]">
                  {idleCountdown}
                </span>
                <span className="text-xs text-amber-400 uppercase font-bold tracking-wider">{t('common.seconds')}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleLogout}
                className="flex-1 px-4 py-3 text-sm font-bold text-muted-foreground hover:text-destructive bg-card/50 hover:bg-destructive/10 border-2 border-border hover:border-destructive/30 rounded-xl transition-all duration-300 uppercase tracking-wider"
              >
                {t('auth.logout')}
              </button>
              <button
                onClick={handleStayLoggedIn}
                className="flex-1 px-4 py-3 text-sm font-black text-black bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 border-2 border-cyan-400 shadow-[0_0_20px_rgba(0,255,255,0.4)] hover:shadow-[0_0_30px_rgba(0,255,255,0.6)] rounded-xl transition-all duration-300 uppercase tracking-wider"
              >
                {t('common.stayActive')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <SessionProvider refetchInterval={5 * 60} refetchOnWindowFocus={true}>
      <Suspense fallback={
        <div className="min-h-screen flex items-center justify-center bg-background relative overflow-hidden">
          {/* Background effects */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[100px] animate-pulse" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-500/10 rounded-full blur-[100px] animate-pulse delay-1000" />
          </div>

          <div className="relative">
            <div className="w-12 h-12 border-3 border-cyan-500/30 border-t-cyan-400 rounded-full animate-spin shadow-[0_0_20px_rgba(0,255,255,0.3)]" />
          </div>
        </div>
      }>
        <AdminLayoutContent>{children}</AdminLayoutContent>
      </Suspense>
    </SessionProvider>
  );
}
