'use client';
import { showSuccess, showError, showConfirm } from '@/lib/sweetalert';
import { formatWIB } from '@/lib/timezone';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import {
  TrendingUp,
  Calendar,
  Ticket,
  LogOut,
  Zap,
  Check,
  X as CloseIcon,
  MessageCircle,
  Wallet,
  Plus,
  RefreshCcw,
  Search,
  ChevronLeft,
  ChevronRight,
  Filter,
  Copy,
} from 'lucide-react';

interface AgentData {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  balance: number;
  minBalance: number;
  lastLogin?: string | null;
  voucherStock?: number;
}

interface Deposit {
  id: string;
  amount: number;
  status: string;
  paymentGateway: string | null;
  paymentUrl: string | null;
  paidAt: string | null;
  expiredAt: string | null;
  createdAt: string;
}

interface Profile {
  id: string;
  name: string;
  costPrice: number;
  resellerFee: number;
  sellingPrice: number;
  downloadSpeed: number;
  uploadSpeed: number;
  validityValue: number;
  validityUnit: string;
}

interface Voucher {
  id: string;
  code: string;
  batchCode: string;
  status: string;
  profileName: string;
  sellingPrice: number;
  resellerFee: number;
  routerName: string | null;
  firstLoginAt: string | null;
  expiresAt: string | null;
  createdAt: string;
}

export default function AgentDashboardPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [agent, setAgent] = useState<AgentData | null>(null);
  const [stats, setStats] = useState({
    currentMonth: { total: 0, count: 0, income: 0 },
    allTime: { total: 0, count: 0, income: 0 },
    generated: 0,
    waiting: 0,
    sold: 0,
    used: 0,
  });
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [vouchers, setVouchers] = useState<Voucher[]>([]);
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [generating, setGenerating] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [generatedVouchers, setGeneratedVouchers] = useState<Voucher[]>([]);
  const [showVouchersModal, setShowVouchersModal] = useState(false);

  // Deposit functionality
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [depositAmount, setDepositAmount] = useState('');
  const [depositGateway, setDepositGateway] = useState('');
  const [creatingDeposit, setCreatingDeposit] = useState(false);
  const [paymentGateways, setPaymentGateways] = useState<{ provider: string; name: string }[]>([]);

  // WhatsApp functionality
  const [selectedVouchers, setSelectedVouchers] = useState<string[]>([]);
  const [showWhatsAppDialog, setShowWhatsAppDialog] = useState(false);
  const [whatsappPhone, setWhatsappPhone] = useState('');
  const [sendingWhatsApp, setSendingWhatsApp] = useState(false);

  // Filter & Pagination
  const [filterStatus, setFilterStatus] = useState('');
  const [filterProfile, setFilterProfile] = useState('');
  const [searchCode, setSearchCode] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pagination, setPagination] = useState({ page: 1, limit: 20, total: 0, totalPages: 0 });

  useEffect(() => {
    const agentDataStr = localStorage.getItem('agentData');
    if (!agentDataStr) {
      router.push('/agent');
      return;
    }

    const agentData = JSON.parse(agentDataStr);
    setAgent(agentData);
    loadDashboard(agentData.id);
  }, [router]);

  const loadDashboard = async (agentId: string, page = 1, status = '', profileId = '', search = '') => {
    try {
      const params = new URLSearchParams({
        agentId,
        page: page.toString(),
        limit: '20',
      });
      if (status) params.append('status', status);
      if (profileId) params.append('profileId', profileId);
      if (search) params.append('search', search);

      const res = await fetch(`/api/agent/dashboard?${params.toString()}`);
      const data = await res.json();

      if (res.ok) {
        setAgent(data.agent);
        setStats(data.stats || {
          currentMonth: { total: 0, count: 0, income: 0 },
          allTime: { total: 0, count: 0, income: 0 },
          generated: 0,
          waiting: 0,
          sold: 0,
          used: 0,
        });
        setProfiles(data.profiles || []);
        setVouchers(data.vouchers || []);
        setDeposits(data.deposits || []);
        setPaymentGateways(data.paymentGateways || []);
        setPagination(data.pagination || { page: 1, limit: 20, total: 0, totalPages: 0 });
        if (data.paymentGateways && data.paymentGateways.length > 0) {
          setDepositGateway(data.paymentGateways[0].provider);
        }
        if (data.profiles && data.profiles.length > 0 && !selectedProfile) {
          setSelectedProfile(data.profiles[0].id);
        }
      }
    } catch (error) {
      console.error('Load dashboard error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleFilter = () => {
    setCurrentPage(1);
    if (agent) {
      loadDashboard(agent.id, 1, filterStatus, filterProfile, searchCode);
    }
  };

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
    if (agent) {
      loadDashboard(agent.id, newPage, filterStatus, filterProfile, searchCode);
    }
  };

  const handleClearFilter = () => {
    setFilterStatus('');
    setFilterProfile('');
    setSearchCode('');
    setCurrentPage(1);
    if (agent) {
      loadDashboard(agent.id, 1, '', '', '');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('agentData');
    router.push('/agent');
  };

  const handleSelectVoucher = (voucherId: string) => {
    setSelectedVouchers(prev =>
      prev.includes(voucherId)
        ? prev.filter(id => id !== voucherId)
        : [...prev, voucherId]
    );
  };

  const handleSelectAll = () => {
    const waitingVouchers = vouchers.filter(v => v.status === 'WAITING').map(v => v.id);
    setSelectedVouchers(waitingVouchers.length === selectedVouchers.length ? [] : waitingVouchers);
  };

  const handleSendWhatsApp = async () => {
    if (selectedVouchers.length === 0) {
      await showError('Pilih voucher terlebih dahulu');
      return;
    }
    setShowWhatsAppDialog(true);
  };

  const handleWhatsAppSubmit = async () => {
    if (!whatsappPhone) {
      await showError('Masukkan nomor WhatsApp');
      return;
    }

    setSendingWhatsApp(true);
    try {
      const vouchersToSend = vouchers.filter(v => selectedVouchers.includes(v.id));

      const vouchersData = vouchersToSend.map(v => {
        const profile = profiles.find(p => p.name === v.profileName);
        return {
          code: v.code,
          profileName: v.profileName,
          price: profile?.sellingPrice || 0,
          validity: profile ? `${profile.validityValue} ${profile.validityUnit.toLowerCase()}` : '-'
        };
      });

      const res = await fetch('/api/hotspot/voucher/send-whatsapp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: whatsappPhone,
          vouchers: vouchersData
        })
      });

      const data = await res.json();

      if (data.success) {
        await showSuccess(`WhatsApp berhasil dikirim ke ${whatsappPhone}!`);
        setShowWhatsAppDialog(false);
        setWhatsappPhone('');
        setSelectedVouchers([]);
      } else {
        await showError('Gagal: ' + data.error);
      }
    } catch (error) {
      console.error('Send WhatsApp error:', error);
      await showError('Gagal mengirim WhatsApp');
    } finally {
      setSendingWhatsApp(false);
    }
  };

  const handleGenerate = async () => {
    if (!agent || !selectedProfile) return;

    const profile = profiles.find(p => p.id === selectedProfile);
    if (!profile) return;

    const totalCost = profile.costPrice * quantity;

    if (agent.balance < totalCost) {
      const deficit = totalCost - agent.balance;
      const result = await showConfirm(
        `Saldo tidak cukup!\n\nSaldo Anda: ${formatCurrency(agent.balance)}\nDibutuhkan: ${formatCurrency(totalCost)}\nKurang: ${formatCurrency(deficit)}\n\nTop up sekarang?`,
        'Saldo Tidak Cukup'
      );
      if (result) {
        setShowDepositModal(true);
        setDepositAmount(Math.ceil(deficit / 10000) * 10000 + '');
      }
      return;
    }

    const confirmed = await showConfirm(
      `Generate ${quantity} voucher(s) ${profile.name}?\n\nTotal Harga: ${formatCurrency(totalCost)}\nSaldo Sekarang: ${formatCurrency(agent.balance)}\nSaldo Setelah: ${formatCurrency(agent.balance - totalCost)}`,
      'Generate Voucher'
    );

    if (!confirmed) return;

    setGenerating(true);
    try {
      const res = await fetch('/api/agent/generate-voucher', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: agent.id,
          profileId: selectedProfile,
          quantity,
        }),
      });

      const data = await res.json();

      if (res.ok) {
        setGeneratedVouchers(data.vouchers);
        setShowVouchersModal(true);
        if (data.newBalance !== undefined && agent) {
          setAgent({ ...agent, balance: data.newBalance });
        }
        loadDashboard(agent.id);
        await showSuccess(`${data.vouchers.length} voucher berhasil digenerate!\n\nSaldo baru: ${formatCurrency(data.newBalance || 0)}`);
      } else {
        if (data.error === 'Insufficient balance') {
          const deficit = data.deficit || 0;
          const result = await showConfirm(
            `Saldo tidak cukup!\n\nSaldo Anda: ${formatCurrency(data.current || 0)}\nDibutuhkan: ${formatCurrency(data.required || 0)}\nKurang: ${formatCurrency(deficit)}\n\nTop up sekarang?`,
            'Saldo Tidak Cukup'
          );
          if (result) {
            setShowDepositModal(true);
            setDepositAmount(Math.ceil(deficit / 10000) * 10000 + '');
          }
        } else {
          await showError('Error: ' + data.error);
        }
      }
    } catch (error) {
      console.error('Generate error:', error);
      await showError('Gagal generate voucher');
    } finally {
      setGenerating(false);
    }
  };

  const handleCreateDeposit = async () => {
    if (!agent) return;

    if (paymentGateways.length === 0) {
      await showError('Payment gateway belum dikonfigurasi. Hubungi admin.');
      return;
    }

    const amount = parseInt(depositAmount);
    if (isNaN(amount) || amount < 10000) {
      await showError('Minimum deposit Rp 10.000');
      return;
    }

    if (!depositGateway) {
      await showError('Pilih metode pembayaran');
      return;
    }

    setCreatingDeposit(true);
    try {
      const res = await fetch('/api/agent/deposit/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agentId: agent.id,
          amount,
          gateway: depositGateway,
        }),
      });

      const data = await res.json();

      if (res.ok && data.success) {
        if (data.deposit.paymentUrl) {
          window.open(data.deposit.paymentUrl, '_blank');
          await showSuccess('Link pembayaran dibuka di tab baru. Silakan selesaikan pembayaran.');
          setShowDepositModal(false);
          setDepositAmount('');
          setTimeout(() => loadDashboard(agent.id), 3000);
        }
      } else {
        await showError('Error: ' + data.error);
      }
    } catch (error) {
      console.error('Create deposit error:', error);
      await showError('Gagal membuat deposit');
    } finally {
      setCreatingDeposit(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(amount || 0);
  };

  const selectedProfileData = profiles.find(p => p.id === selectedProfile);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#1a0f35] relative overflow-hidden flex items-center justify-center">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-[#bc13fe]/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-[#00f7ff]/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
        <div className="text-center relative z-10">
          <div className="w-10 h-10 border-4 border-[#00f7ff] border-t-transparent rounded-full animate-spin mx-auto mb-3 shadow-[0_0_20px_rgba(0,247,255,0.5)]"></div>
          <p className="text-[#e0d0ff]/70">Loading...</p>
        </div>
      </div>
    );
  }

  if (!agent) {
    return null;
  }

  return (
    <div className="min-h-screen bg-[#1a0f35] relative overflow-hidden">
      {/* Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-[#bc13fe]/15 rounded-full blur-3xl"></div>
        <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-[#00f7ff]/15 rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 left-1/2 w-96 h-96 bg-[#ff44cc]/15 rounded-full blur-3xl"></div>
        <div className="absolute inset-0 bg-[linear-gradient(rgba(188,19,254,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(188,19,254,0.02)_1px,transparent_1px)] bg-[size:50px_50px]"></div>
      </div>

      {/* Header */}
      <div className="relative z-10 bg-gradient-to-r from-[#bc13fe] to-[#00f7ff] shadow-[0_5px_30px_rgba(188,19,254,0.4)]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">Agent Dashboard</h1>
              <p className="text-sm text-white/80 mt-0.5">{agent.name}</p>
            </div>
            <button
              onClick={handleLogout}
              className="flex items-center px-4 py-2 text-sm bg-white/10 hover:bg-white/20 backdrop-blur rounded-xl transition border border-white/20"
            >
              <LogOut className="h-4 w-4 mr-1.5" />
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
        {/* Balance Card */}
        <div className="bg-gradient-to-r from-[#bc13fe] to-[#00f7ff] rounded-2xl shadow-[0_0_40px_rgba(188,19,254,0.3)] p-5 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm opacity-90 uppercase tracking-wider">Saldo Anda</p>
              <p className="text-3xl font-bold mt-1 drop-shadow-[0_0_20px_rgba(255,255,255,0.5)]">{formatCurrency(agent.balance || 0)}</p>
              {agent.minBalance > 0 && (
                <p className="text-xs opacity-75 mt-1">Min. saldo: {formatCurrency(agent.minBalance)}</p>
              )}
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setShowDepositModal(true)}
                className="flex items-center px-4 py-2 bg-white/20 hover:bg-white/30 rounded-xl text-sm transition backdrop-blur border border-white/20"
              >
                <Plus className="h-4 w-4 mr-1.5" />
                Deposit
              </button>
              <button
                onClick={() => agent && loadDashboard(agent.id)}
                className="flex items-center px-3 py-2 bg-white/20 hover:bg-white/30 rounded-xl text-sm transition backdrop-blur border border-white/20"
              >
                <RefreshCcw className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Statistics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-[#1a0f35]/80 backdrop-blur-xl rounded-xl border-2 border-[#00ff88]/30 p-4 shadow-[0_0_20px_rgba(0,255,136,0.1)]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#e0d0ff]/70">Komisi Bulan Ini</p>
                <p className="text-lg font-bold mt-0.5 text-[#00ff88]">
                  {formatCurrency(stats.currentMonth?.total || 0)}
                </p>
              </div>
              <TrendingUp className="h-6 w-6 text-[#00ff88] drop-shadow-[0_0_10px_rgba(0,255,136,0.5)]" />
            </div>
          </div>

          <div className="bg-[#1a0f35]/80 backdrop-blur-xl rounded-xl border-2 border-[#bc13fe]/30 p-4 shadow-[0_0_20px_rgba(188,19,254,0.1)]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#e0d0ff]/70">Total Komisi</p>
                <p className="text-lg font-bold mt-0.5 text-[#bc13fe]">
                  {formatCurrency(stats.allTime?.total || 0)}
                </p>
              </div>
              <Calendar className="h-6 w-6 text-[#bc13fe] drop-shadow-[0_0_10px_rgba(188,19,254,0.5)]" />
            </div>
          </div>

          <div className="bg-[#1a0f35]/80 backdrop-blur-xl rounded-xl border-2 border-[#00f7ff]/30 p-4 shadow-[0_0_20px_rgba(0,247,255,0.1)]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#e0d0ff]/70">Voucher Tersedia</p>
                <p className="text-lg font-bold mt-0.5 text-white">{stats.waiting || 0}</p>
              </div>
              <Ticket className="h-6 w-6 text-[#00f7ff] drop-shadow-[0_0_10px_rgba(0,247,255,0.5)]" />
            </div>
          </div>

          <div className="bg-[#1a0f35]/80 backdrop-blur-xl rounded-xl border-2 border-[#ff44cc]/30 p-4 shadow-[0_0_20px_rgba(255,68,204,0.1)]">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-[#e0d0ff]/70">Voucher Terpakai</p>
                <p className="text-lg font-bold mt-0.5 text-white">{stats.used || 0}</p>
              </div>
              <Check className="h-6 w-6 text-[#ff44cc] drop-shadow-[0_0_10px_rgba(255,68,204,0.5)]" />
            </div>
          </div>
        </div>

        {/* Quick Generate */}
        <div className="bg-[#1a0f35]/80 backdrop-blur-xl rounded-2xl border-2 border-[#bc13fe]/30 p-5 shadow-[0_0_30px_rgba(188,19,254,0.15)]">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-2 bg-[#ff44cc]/20 rounded-lg border border-[#ff44cc]/30">
              <Zap className="h-5 w-5 text-[#ff44cc] drop-shadow-[0_0_10px_rgba(255,68,204,0.6)]" />
            </div>
            <h2 className="text-base font-bold text-white">Generate Voucher</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-[#e0d0ff]/80 mb-1.5">Pilih Paket</label>
              <select
                value={selectedProfile}
                onChange={(e) => setSelectedProfile(e.target.value)}
                className="w-full px-3 py-2.5 text-sm bg-[#0a0520] border-2 border-[#bc13fe]/30 rounded-xl text-white focus:border-[#00f7ff] outline-none"
              >
                {profiles.map((profile) => (
                  <option key={profile.id} value={profile.id} className="bg-[#0a0520]">
                    {profile.name} - {formatCurrency(profile.sellingPrice)} - {profile.downloadSpeed}/{profile.uploadSpeed} Mbps
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#e0d0ff]/80 mb-1.5">Jumlah</label>
              <input
                type="number"
                min="1"
                max="50"
                value={quantity}
                onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2.5 text-sm bg-[#0a0520] border-2 border-[#bc13fe]/30 rounded-xl text-white focus:border-[#00f7ff] outline-none"
              />
            </div>
          </div>

          {selectedProfileData && (
            <div className="mt-3 p-4 bg-gradient-to-br from-[#bc13fe]/10 to-[#00f7ff]/10 rounded-xl border border-[#bc13fe]/20">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div>
                  <p className="text-xs text-[#e0d0ff]/60">Harga Beli</p>
                  <p className="font-semibold text-white">{formatCurrency(selectedProfileData.costPrice)}</p>
                </div>
                <div>
                  <p className="text-xs text-[#e0d0ff]/60">Keuntungan/pcs</p>
                  <p className="font-semibold text-[#00ff88]">{formatCurrency(selectedProfileData.resellerFee)}</p>
                </div>
                <div>
                  <p className="text-xs text-[#e0d0ff]/60">Speed</p>
                  <p className="font-semibold text-white">{selectedProfileData.downloadSpeed}/{selectedProfileData.uploadSpeed} Mbps</p>
                </div>
                <div>
                  <p className="text-xs text-[#e0d0ff]/60">Total Bayar</p>
                  <p className="font-semibold text-[#00f7ff]">{formatCurrency(selectedProfileData.costPrice * quantity)}</p>
                </div>
              </div>
            </div>
          )}

          <button
            onClick={handleGenerate}
            disabled={generating || !selectedProfile}
            className="mt-4 w-full flex items-center justify-center px-4 py-3 bg-gradient-to-r from-[#bc13fe] to-[#00f7ff] hover:from-[#a010e0] hover:to-[#00d4dd] text-white text-sm font-bold rounded-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-[0_0_25px_rgba(188,19,254,0.4)] hover:shadow-[0_0_35px_rgba(188,19,254,0.6)]"
          >
            {generating ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                Generating...
              </>
            ) : (
              <>
                <Zap className="h-4 w-4 mr-2" />
                Generate Voucher
              </>
            )}
          </button>
        </div>

        {/* Vouchers List */}
        <div className="bg-[#1a0f35]/80 backdrop-blur-xl rounded-2xl border-2 border-[#bc13fe]/30 overflow-hidden shadow-[0_0_30px_rgba(188,19,254,0.15)]">
          <div className="px-5 py-4 border-b border-[#bc13fe]/20">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h2 className="text-base font-bold text-white">Daftar Voucher</h2>
                <p className="text-xs text-[#e0d0ff]/60 mt-0.5">Total: {pagination.total} voucher</p>
              </div>
              {selectedVouchers.length > 0 && (
                <button
                  onClick={handleSendWhatsApp}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-[#00ff88] hover:bg-[#00dd77] text-black rounded-lg text-xs transition font-bold shadow-[0_0_15px_rgba(0,255,136,0.4)]"
                >
                  <MessageCircle className="h-3.5 w-3.5" />
                  Kirim WA ({selectedVouchers.length})
                </button>
              )}
            </div>

            {/* Filter Controls */}
            <div className="flex flex-wrap gap-2 items-center">
              <div className="relative flex-1 min-w-[150px]">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[#e0d0ff]/50" />
                <input
                  type="text"
                  placeholder="Cari kode voucher..."
                  value={searchCode}
                  onChange={(e) => setSearchCode(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleFilter()}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-[#0a0520] border-2 border-[#bc13fe]/30 rounded-lg text-white focus:border-[#00f7ff] outline-none"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 text-xs bg-[#0a0520] border-2 border-[#bc13fe]/30 rounded-lg text-white min-w-[100px] outline-none"
              >
                <option value="">Semua Status</option>
                <option value="WAITING">Waiting</option>
                <option value="ACTIVE">Active</option>
                <option value="EXPIRED">Expired</option>
              </select>
              <select
                value={filterProfile}
                onChange={(e) => setFilterProfile(e.target.value)}
                className="px-3 py-2 text-xs bg-[#0a0520] border-2 border-[#bc13fe]/30 rounded-lg text-white min-w-[120px] outline-none"
              >
                <option value="">Semua Paket</option>
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>{p.name}</option>
                ))}
              </select>
              <button
                onClick={handleFilter}
                className="flex items-center gap-1 px-3 py-2 bg-gradient-to-r from-[#bc13fe] to-[#00f7ff] text-white rounded-lg text-xs transition font-bold"
              >
                <Filter className="h-3 w-3" />
                Filter
              </button>
              {(filterStatus || filterProfile || searchCode) && (
                <button
                  onClick={handleClearFilter}
                  className="px-3 py-2 text-xs text-[#e0d0ff]/70 hover:bg-[#bc13fe]/10 rounded-lg transition"
                >
                  Reset
                </button>
              )}
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#0a0520]/50">
                <tr>
                  <th className="px-4 py-3 w-10">
                    <input
                      type="checkbox"
                      checked={selectedVouchers.length > 0 && selectedVouchers.length === vouchers.filter(v => v.status === 'WAITING').length}
                      onChange={handleSelectAll}
                      className="rounded border-[#bc13fe]/50 bg-[#0a0520]"
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-[#00f7ff] uppercase tracking-wider">Kode Voucher</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-[#00f7ff] uppercase tracking-wider">Batch</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-[#00f7ff] uppercase tracking-wider">Paket</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-[#00f7ff] uppercase tracking-wider">Router</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-[#00f7ff] uppercase tracking-wider">Status</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-[#00f7ff] uppercase tracking-wider">Dibuat</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#bc13fe]/10">
                {vouchers.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="px-4 py-10 text-center text-sm text-[#e0d0ff]/60">
                      Belum ada voucher. Generate voucher pertama Anda di atas.
                    </td>
                  </tr>
                ) : (
                  vouchers.map((voucher) => (
                    <tr key={voucher.id} className="hover:bg-[#bc13fe]/5 transition">
                      <td className="px-4 py-3">
                        {voucher.status === 'WAITING' && (
                          <input
                            type="checkbox"
                            checked={selectedVouchers.includes(voucher.id)}
                            onChange={() => handleSelectVoucher(voucher.id)}
                            className="rounded border-[#bc13fe]/50 bg-[#0a0520]"
                          />
                        )}
                      </td>
                      <td className="px-4 py-3 font-mono font-bold text-sm text-white">{voucher.code}</td>
                      <td className="px-4 py-3 text-xs text-[#e0d0ff]/60">{voucher.batchCode || '-'}</td>
                      <td className="px-4 py-3 text-xs text-white">{voucher.profileName}</td>
                      <td className="px-4 py-3 text-xs text-[#e0d0ff]/60">{voucher.routerName || '-'}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-bold ${voucher.status === 'ACTIVE'
                            ? 'bg-[#00ff88]/20 text-[#00ff88] border border-[#00ff88]/40 shadow-[0_0_10px_rgba(0,255,136,0.2)]'
                            : voucher.status === 'EXPIRED'
                              ? 'bg-[#ff4466]/20 text-[#ff6b8a] border border-[#ff4466]/40'
                              : voucher.status === 'SOLD'
                                ? 'bg-[#00f7ff]/20 text-[#00f7ff] border border-[#00f7ff]/40'
                                : 'bg-[#ff44cc]/20 text-[#ff44cc] border border-[#ff44cc]/40'
                          }`}>
                          {voucher.status}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-[#e0d0ff]/60">
                        {voucher.createdAt ? formatWIB(new Date(voucher.createdAt), 'dd MMM yyyy HH:mm') : '-'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="px-5 py-3 border-t border-[#bc13fe]/20 flex items-center justify-between">
              <p className="text-xs text-[#e0d0ff]/60">
                Menampilkan {((currentPage - 1) * pagination.limit) + 1} - {Math.min(currentPage * pagination.limit, pagination.total)} dari {pagination.total}
              </p>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="p-1.5 rounded hover:bg-[#bc13fe]/10 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <ChevronLeft className="h-4 w-4 text-[#e0d0ff]" />
                </button>
                {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                  let pageNum;
                  if (pagination.totalPages <= 5) {
                    pageNum = i + 1;
                  } else if (currentPage <= 3) {
                    pageNum = i + 1;
                  } else if (currentPage >= pagination.totalPages - 2) {
                    pageNum = pagination.totalPages - 4 + i;
                  } else {
                    pageNum = currentPage - 2 + i;
                  }
                  return (
                    <button
                      key={pageNum}
                      onClick={() => handlePageChange(pageNum)}
                      className={`px-3 py-1 text-xs rounded-lg transition ${currentPage === pageNum
                          ? 'bg-gradient-to-r from-[#bc13fe] to-[#00f7ff] text-white font-bold'
                          : 'text-[#e0d0ff]/70 hover:bg-[#bc13fe]/10'
                        }`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === pagination.totalPages}
                  className="p-1.5 rounded hover:bg-[#bc13fe]/10 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <ChevronRight className="h-4 w-4 text-[#e0d0ff]" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Generated Vouchers Modal */}
      {showVouchersModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#1a0f35] border-2 border-[#00ff88]/50 rounded-2xl shadow-[0_0_50px_rgba(0,255,136,0.3)] max-w-lg w-full max-h-[80vh] overflow-hidden">
            <div className="px-5 py-4 border-b border-[#00ff88]/20 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-[#00ff88]/20 rounded-lg">
                  <Check className="h-5 w-5 text-[#00ff88]" />
                </div>
                <h2 className="text-base font-bold text-white">Voucher Berhasil Dibuat!</h2>
              </div>
              <button
                onClick={() => { setShowVouchersModal(false); setGeneratedVouchers([]); }}
                className="p-1.5 hover:bg-[#bc13fe]/20 rounded-lg transition"
              >
                <CloseIcon className="h-4 w-4 text-[#e0d0ff]" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto max-h-[calc(80vh-80px)]">
              <p className="text-xs text-[#e0d0ff]/70 mb-3">
                Salin kode voucher di bawah ini untuk pelanggan Anda
              </p>
              <div className="space-y-2">
                {generatedVouchers.map((voucher, index) => (
                  <div
                    key={voucher.id}
                    className="flex items-center justify-between p-4 bg-[#0a0520] rounded-xl border border-[#bc13fe]/20"
                  >
                    <div>
                      <p className="text-xs text-[#e0d0ff]/60">Voucher {index + 1}</p>
                      <p className="text-xl font-mono font-bold text-[#00f7ff]">{voucher.code}</p>
                    </div>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(voucher.code);
                        showSuccess('Kode disalin!');
                      }}
                      className="px-4 py-2 text-xs bg-gradient-to-r from-[#bc13fe] to-[#00f7ff] text-white rounded-lg transition font-bold flex items-center gap-1.5"
                    >
                      <Copy className="h-3.5 w-3.5" />
                      Copy
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* WhatsApp Dialog */}
      {showWhatsAppDialog && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#1a0f35] border-2 border-[#00ff88]/50 rounded-2xl shadow-[0_0_50px_rgba(0,255,136,0.3)] max-w-sm w-full">
            <div className="px-5 py-4 border-b border-[#00ff88]/20">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-[#00ff88]" />
                Kirim Voucher via WhatsApp
              </h2>
              <p className="text-xs text-[#e0d0ff]/60 mt-0.5">Kirim {selectedVouchers.length} voucher ke customer</p>
            </div>

            <div className="p-5">
              <label className="block text-xs font-medium text-[#e0d0ff] mb-1.5">Nomor WhatsApp</label>
              <input
                type="tel"
                placeholder="628123456789"
                value={whatsappPhone}
                onChange={(e) => setWhatsappPhone(e.target.value)}
                className="w-full px-3 py-2.5 text-sm bg-[#0a0520] border-2 border-[#bc13fe]/30 rounded-xl text-white focus:border-[#00f7ff] outline-none"
              />
              <p className="text-xs text-[#e0d0ff]/50 mt-1">Masukkan nomor dengan kode negara</p>
            </div>

            <div className="px-5 py-4 border-t border-[#bc13fe]/20 flex gap-2 justify-end">
              <button
                onClick={() => { setShowWhatsAppDialog(false); setWhatsappPhone(''); }}
                className="px-4 py-2 text-sm text-[#e0d0ff]/70 hover:bg-[#bc13fe]/10 rounded-xl transition"
              >
                Batal
              </button>
              <button
                onClick={handleWhatsAppSubmit}
                disabled={sendingWhatsApp || !whatsappPhone}
                className="px-4 py-2 text-sm bg-[#00ff88] hover:bg-[#00dd77] text-black rounded-xl transition disabled:opacity-50 flex items-center gap-1.5 font-bold"
              >
                {sendingWhatsApp ? (
                  <><div className="w-3.5 h-3.5 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>Mengirim...</>
                ) : (
                  <><MessageCircle className="h-3.5 w-3.5" />Kirim WhatsApp</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Deposit Modal */}
      {showDepositModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#1a0f35] border-2 border-[#bc13fe]/50 rounded-2xl shadow-[0_0_50px_rgba(188,19,254,0.3)] max-w-sm w-full">
            <div className="px-5 py-4 border-b border-[#bc13fe]/20">
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Wallet className="h-5 w-5 text-[#00f7ff]" />
                Top Up Saldo
              </h2>
            </div>

            <div className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#e0d0ff] mb-1.5">Jumlah Deposit</label>
                <input
                  type="number"
                  placeholder="Minimum Rp 10.000"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  className="w-full px-3 py-2.5 text-sm bg-[#0a0520] border-2 border-[#bc13fe]/30 rounded-xl text-white focus:border-[#00f7ff] outline-none"
                  min="10000"
                  step="10000"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#e0d0ff] mb-1.5">Metode Pembayaran</label>
                {paymentGateways.length > 0 ? (
                  <select
                    value={depositGateway}
                    onChange={(e) => setDepositGateway(e.target.value)}
                    className="w-full px-3 py-2.5 text-sm bg-[#0a0520] border-2 border-[#bc13fe]/30 rounded-xl text-white focus:border-[#00f7ff] outline-none"
                  >
                    {paymentGateways.map((gw) => (
                      <option key={gw.provider} value={gw.provider} className="bg-[#0a0520]">{gw.name}</option>
                    ))}
                  </select>
                ) : (
                  <div className="text-sm text-[#ff6b8a] p-3 bg-[#ff4466]/10 rounded-xl border border-[#ff4466]/30">
                    Belum ada payment gateway yang dikonfigurasi. Hubungi admin.
                  </div>
                )}
              </div>

              {depositAmount && parseInt(depositAmount) >= 10000 && (
                <div className="bg-gradient-to-br from-[#bc13fe]/20 to-[#00f7ff]/20 p-4 rounded-xl border border-[#bc13fe]/30">
                  <p className="text-sm text-white">
                    Total: <span className="font-bold text-[#00f7ff]">{formatCurrency(parseInt(depositAmount))}</span>
                  </p>
                </div>
              )}
            </div>

            <div className="px-5 py-4 border-t border-[#bc13fe]/20 flex gap-2 justify-end">
              <button
                onClick={() => { setShowDepositModal(false); setDepositAmount(''); }}
                className="px-4 py-2 text-sm text-[#e0d0ff]/70 hover:bg-[#bc13fe]/10 rounded-xl transition"
                disabled={creatingDeposit}
              >
                Batal
              </button>
              <button
                onClick={handleCreateDeposit}
                disabled={creatingDeposit || !depositAmount || parseInt(depositAmount) < 10000 || paymentGateways.length === 0}
                className="px-4 py-2 text-sm bg-gradient-to-r from-[#bc13fe] to-[#00f7ff] text-white rounded-xl transition disabled:opacity-50 flex items-center gap-1.5 font-bold shadow-[0_0_15px_rgba(188,19,254,0.3)]"
              >
                {creatingDeposit ? (
                  <><div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>Memproses...</>
                ) : (
                  <><Plus className="h-3.5 w-3.5" />Bayar Sekarang</>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
