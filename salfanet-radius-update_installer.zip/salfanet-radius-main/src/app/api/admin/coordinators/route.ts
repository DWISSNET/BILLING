import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get('search') || '';
    const isActive = searchParams.get('isActive');

    const where: any = {};

    if (search) {
      where.OR = [
        { name: { contains: search } },
        { phoneNumber: { contains: search } },
        { email: { contains: search } },
      ];
    }

    if (isActive !== null && isActive !== '') {
      where.isActive = isActive === 'true';
    }

    const coordinators = await prisma.coordinator.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      select: {
        id: true,
        name: true,
        phoneNumber: true,
        email: true,
        isActive: true,
        requireOtp: true,
        createdAt: true,
        lastLoginAt: true,
      },
    });

    return NextResponse.json(coordinators);
  } catch (error) {
    console.error('List coordinators error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch coordinators' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name, phoneNumber, email, isActive, requireOtp } = await req.json();

    if (!name || !phoneNumber) {
      return NextResponse.json(
        { error: 'Name and phone number are required' },
        { status: 400 }
      );
    }

    // Normalize phone number
    const normalizedPhone = phoneNumber.replace(/\D/g, '');
    const formattedPhone = normalizedPhone.startsWith('62')
      ? normalizedPhone
      : normalizedPhone.startsWith('0')
      ? '62' + normalizedPhone.substring(1)
      : '62' + normalizedPhone;

    // Check if phone number already exists
    const existing = await prisma.coordinator.findUnique({
      where: { phoneNumber: formattedPhone },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'Phone number already registered' },
        { status: 400 }
      );
    }

    // Create coordinator
    const coordinator = await prisma.coordinator.create({
      data: {
        name,
        phoneNumber: formattedPhone,
        email: email || null,
        isActive: isActive !== undefined ? isActive : true,
        requireOtp: requireOtp !== undefined ? requireOtp : true,
      },
    });

    return NextResponse.json(coordinator);
  } catch (error) {
    console.error('Create coordinator error:', error);
    return NextResponse.json(
      { error: 'Failed to create coordinator' },
      { status: 500 }
    );
  }
}

export async function PUT(req: NextRequest) {
  try {
    const { id, name, phoneNumber, email, isActive, requireOtp } = await req.json();

    if (!id) {
      return NextResponse.json(
        { error: 'Coordinator ID is required' },
        { status: 400 }
      );
    }

    // Check if coordinator exists
    const existing = await prisma.coordinator.findUnique({
      where: { id },
    });

    if (!existing) {
      return NextResponse.json(
        { error: 'Coordinator not found' },
        { status: 404 }
      );
    }

    // Build update data
    const updateData: any = {};

    if (name !== undefined) updateData.name = name;
    if (email !== undefined) updateData.email = email || null;
    if (isActive !== undefined) updateData.isActive = isActive;
    if (requireOtp !== undefined) updateData.requireOtp = requireOtp;

    if (phoneNumber !== undefined && phoneNumber !== existing.phoneNumber) {
      // Normalize phone number
      const normalizedPhone = phoneNumber.replace(/\D/g, '');
      const formattedPhone = normalizedPhone.startsWith('62')
        ? normalizedPhone
        : normalizedPhone.startsWith('0')
        ? '62' + normalizedPhone.substring(1)
        : '62' + normalizedPhone;

      // Check if new phone number already exists
      const phoneExists = await prisma.coordinator.findUnique({
        where: { phoneNumber: formattedPhone },
      });

      if (phoneExists && phoneExists.id !== id) {
        return NextResponse.json(
          { error: 'Phone number already registered' },
          { status: 400 }
        );
      }

      updateData.phoneNumber = formattedPhone;
    }

    // Update coordinator
    const coordinator = await prisma.coordinator.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json(coordinator);
  } catch (error) {
    console.error('Update coordinator error:', error);
    return NextResponse.json(
      { error: 'Failed to update coordinator' },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'Coordinator ID is required' },
        { status: 400 }
      );
    }

    // Check if coordinator exists
    const coordinator = await prisma.coordinator.findUnique({
      where: { id },
    });

    if (!coordinator) {
      return NextResponse.json(
        { error: 'Coordinator not found' },
        { status: 404 }
      );
    }

    // Delete coordinator (OTPs will be cascade deleted)
    await prisma.coordinator.delete({
      where: { id },
    });

    return NextResponse.json({ success: true, message: 'Coordinator deleted successfully' });
  } catch (error) {
    console.error('Delete coordinator error:', error);
    return NextResponse.json(
      { error: 'Failed to delete coordinator' },
      { status: 500 }
    );
  }
}
