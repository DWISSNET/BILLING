import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

// GET - List all categories
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const isActiveParam = searchParams.get('isActive');

    const where: any = {};

    if (isActiveParam !== null) {
      where.isActive = isActiveParam === 'true';
    }

    const categories = await prisma.ticketCategory.findMany({
      where,
      orderBy: { name: 'asc' },
      include: {
        _count: {
          select: { tickets: true },
        },
      },
    });

    return NextResponse.json(categories);
  } catch (error) {
    console.error('Error fetching categories:', error);
    return NextResponse.json(
      { error: 'Failed to fetch categories' },
      { status: 500 }
    );
  }
}

// POST - Create category
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, description, color, isActive } = body;

    if (!name) {
      return NextResponse.json(
        { error: 'Category name is required' },
        { status: 400 }
      );
    }

    // Check if name already exists
    const existing = await prisma.ticketCategory.findUnique({
      where: { name },
    });

    if (existing) {
      return NextResponse.json(
        { error: 'Category with this name already exists' },
        { status: 409 }
      );
    }

    const category = await prisma.ticketCategory.create({
      data: {
        id: `cat_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`,
        name,
        description: description || null,
        color: color || '#3B82F6',
        isActive: isActive !== undefined ? isActive : true,
      },
    });

    return NextResponse.json(category);
  } catch (error) {
    console.error('Error creating category:', error);
    return NextResponse.json(
      { error: 'Failed to create category' },
      { status: 500 }
    );
  }
}

// PUT - Update category
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, name, description, color, isActive } = body;

    if (!id) {
      return NextResponse.json(
        { error: 'Category ID is required' },
        { status: 400 }
      );
    }

    // Check if new name conflicts with existing
    if (name) {
      const existing = await prisma.ticketCategory.findFirst({
        where: {
          name,
          id: { not: id },
        },
      });

      if (existing) {
        return NextResponse.json(
          { error: 'Category with this name already exists' },
          { status: 409 }
        );
      }
    }

    const updateData: any = {
      updatedAt: new Date(),
    };

    if (name !== undefined) updateData.name = name;
    if (description !== undefined) updateData.description = description;
    if (color !== undefined) updateData.color = color;
    if (isActive !== undefined) updateData.isActive = isActive;

    const category = await prisma.ticketCategory.update({
      where: { id },
      data: updateData,
    });

    return NextResponse.json(category);
  } catch (error) {
    console.error('Error updating category:', error);
    return NextResponse.json(
      { error: 'Failed to update category' },
      { status: 500 }
    );
  }
}

// DELETE - Delete category
export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'Category ID is required' },
        { status: 400 }
      );
    }

    // Check if category has tickets
    const ticketCount = await prisma.ticket.count({
      where: { categoryId: id },
    });

    if (ticketCount > 0) {
      return NextResponse.json(
        { error: `Cannot delete category with ${ticketCount} tickets. Reassign tickets first.` },
        { status: 400 }
      );
    }

    await prisma.ticketCategory.delete({
      where: { id },
    });

    return NextResponse.json({ message: 'Category deleted successfully' });
  } catch (error) {
    console.error('Error deleting category:', error);
    return NextResponse.json(
      { error: 'Failed to delete category' },
      { status: 500 }
    );
  }
}
