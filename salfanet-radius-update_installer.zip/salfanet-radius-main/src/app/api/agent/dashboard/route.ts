import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient, Prisma } from '@prisma/client';
import { toWIB, nowWIB } from '@/lib/timezone';

const prisma = new PrismaClient();

// GET - Get agent dashboard data
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const agentId = searchParams.get('agentId');
    
    // Pagination & filter params
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const status = searchParams.get('status') || '';
    const search = searchParams.get('search') || '';
    const profileId = searchParams.get('profileId') || '';

    if (!agentId) {
      return NextResponse.json(
        { error: 'Agent ID is required' },
        { status: 400 }
      );
    }

    // Get agent and update lastLogin
    const agent = await prisma.agent.update({
      where: { id: agentId },
      data: { lastLogin: new Date() },
    });

    if (!agent) {
      return NextResponse.json({ error: 'Agent not found' }, { status: 404 });
    }

    // Build voucher filter
    const voucherWhere: Prisma.HotspotVoucherWhereInput = {
      agentId: agentId,
    };
    
    if (status && status !== 'ALL') {
      voucherWhere.status = status as any;
    }
    
    if (search) {
      voucherWhere.code = { contains: search };
    }
    
    if (profileId) {
      voucherWhere.profileId = profileId;
    }

    // Get total count for pagination
    const totalVouchers = await prisma.hotspotVoucher.count({
      where: voucherWhere,
    });

    // Get paginated vouchers
    const allVouchers = await prisma.hotspotVoucher.findMany({
      where: voucherWhere,
      include: {
        profile: true,
        router: true,
      },
      orderBy: {
        createdAt: 'desc',
      },
      skip: (page - 1) * limit,
      take: limit,
    });
    
    // Get all vouchers for stats (without pagination)
    const allVouchersForStats = await prisma.hotspotVoucher.findMany({
      where: { agentId: agentId },
      include: { profile: true },
    });

    // Calculate statistics from all vouchers (not paginated)
    // Use WIB timezone for month calculation (UTC stored in DB)
    const now = nowWIB();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    // Calculate voucher statistics based on status
    const soldVouchers = allVouchersForStats.filter((v) => v.status === 'SOLD' || v.status === 'ACTIVE' || v.status === 'EXPIRED');
    const usedVouchers = allVouchersForStats.filter((v) => v.status === 'ACTIVE' || v.status === 'EXPIRED');
    
    // Current month sold vouchers - Convert UTC to WIB before comparison
    const currentMonthSold = soldVouchers.filter((v) => {
      const usedDate = v.firstLoginAt ? toWIB(v.firstLoginAt) : null;
      if (!usedDate) return false;
      return (
        usedDate.getMonth() === currentMonth &&
        usedDate.getFullYear() === currentYear
      );
    });
    
    // Calculate income from sold vouchers (use sellingPrice)
    const currentMonthIncome = currentMonthSold.reduce((sum, v) => sum + (v.profile?.sellingPrice || 0), 0);
    const allTimeIncome = soldVouchers.reduce((sum, v) => sum + (v.profile?.sellingPrice || 0), 0);
    
    // Calculate commission earned (resellerFee from sold vouchers)
    const currentMonthCommission = currentMonthSold.reduce((sum, v) => sum + (v.profile?.resellerFee || 0), 0);
    const allTimeCommission = soldVouchers.reduce((sum, v) => sum + (v.profile?.resellerFee || 0), 0);

    const stats = {
      currentMonth: {
        total: currentMonthCommission, // Commission agent bulan ini
        count: currentMonthSold.length, // Voucher terjual bulan ini
        income: currentMonthIncome, // Total penjualan bulan ini
      },
      allTime: {
        total: allTimeCommission, // Total komisi agent
        count: soldVouchers.length, // Total voucher terjual
        income: allTimeIncome, // Total penjualan sepanjang waktu
      },
      generated: allVouchersForStats.length,
      waiting: allVouchersForStats.filter((v) => v.status === 'WAITING').length,
      sold: soldVouchers.length,
      used: usedVouchers.length,
    };

    // Get profiles with agentAccess enabled
    const profiles = await prisma.hotspotProfile.findMany({
      where: {
        agentAccess: true,
        isActive: true,
      },
      orderBy: { name: 'asc' },
    });

    // Get recent deposits
    const deposits = await prisma.agentDeposit.findMany({
      where: { agentId },
      orderBy: { createdAt: 'desc' },
      take: 10,
    });

    // Get active payment gateways for deposit
    const paymentGateways = await prisma.paymentGateway.findMany({
      where: { isActive: true },
      select: {
        provider: true,
        name: true,
      },
    });

    return NextResponse.json({
      agent: {
        id: agent.id,
        name: agent.name,
        phone: agent.phone,
        email: agent.email,
        balance: agent.balance,
        minBalance: agent.minBalance,
        lastLogin: agent.lastLogin,
        voucherStock: stats.waiting,
      },
      stats,
      profiles,
      deposits: deposits.map((d) => ({
        id: d.id,
        amount: d.amount,
        status: d.status,
        paymentGateway: d.paymentGateway,
        paymentUrl: d.paymentUrl,
        paidAt: d.paidAt,
        expiredAt: d.expiredAt,
        createdAt: d.createdAt,
      })),
      paymentGateways: paymentGateways.map((g) => ({
        provider: g.provider,
        name: g.name,
      })),
      vouchers: allVouchers.map((v) => ({
        id: v.id,
        code: v.code,
        batchCode: v.batchCode,
        status: v.status,
        profileName: v.profile?.name || 'Unknown',
        sellingPrice: v.profile?.sellingPrice || 0,
        resellerFee: v.profile?.resellerFee || 0,
        routerName: v.router?.name || null,
        firstLoginAt: v.firstLoginAt,
        expiresAt: v.expiresAt,
        createdAt: v.createdAt,
      })),
      pagination: {
        page,
        limit,
        total: totalVouchers,
        totalPages: Math.ceil(totalVouchers / limit),
      },
    });
  } catch (error) {
    console.error('Get agent dashboard error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
