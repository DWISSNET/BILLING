import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { jwtVerify } from 'jose';

// Verify coordinator JWT
async function verifyCoordinatorAuth(req: NextRequest) {
  try {
    const token = req.cookies.get('coordinator-token')?.value;
    if (!token) {
      return null;
    }

    const secret = new TextEncoder().encode(
      process.env.JWT_SECRET || 'your-secret-key-change-this-in-production'
    );

    const { payload } = await jwtVerify(token, secret);
    const coordinator = await prisma.coordinator.findUnique({
      where: { id: payload.id as string, isActive: true },
    });

    return coordinator;
  } catch (error) {
    return null;
  }
}

// GET - List work orders for coordinator
export async function GET(req: NextRequest) {
  try {
    const coordinator = await verifyCoordinatorAuth(req);
    if (!coordinator) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');
    const priority = searchParams.get('priority');
    const technicianId = searchParams.get('technicianId');
    const search = searchParams.get('search');

    const where: any = {};

    // Filter by coordinator's assigned tasks
    if (searchParams.get('myTasks') === 'true') {
      where.coordinatorId = coordinator.id;
    }

    if (status) {
      where.status = status;
    }

    if (priority) {
      where.priority = priority;
    }

    if (technicianId) {
      where.technicianId = technicianId;
    }

    if (search) {
      where.OR = [
        { customerName: { contains: search } },
        { customerPhone: { contains: search } },
        { description: { contains: search } },
      ];
    }

    const workOrders = await prisma.workOrder.findMany({
      where,
      include: {
        technician: {
          select: {
            id: true,
            name: true,
            phoneNumber: true,
          },
        },
        coordinator: {
          select: {
            id: true,
            name: true,
            phoneNumber: true,
          },
        },
      },
      orderBy: [
        { priority: 'desc' },
        { createdAt: 'desc' },
      ],
    });

    return NextResponse.json(workOrders);
  } catch (error) {
    console.error('Error fetching work orders:', error);
    return NextResponse.json(
      { error: 'Failed to fetch work orders' },
      { status: 500 }
    );
  }
}

// POST - Create new work order
export async function POST(req: NextRequest) {
  try {
    const coordinator = await verifyCoordinatorAuth(req);
    if (!coordinator) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      customerName,
      customerPhone,
      customerAddress,
      issueType,
      description,
      priority,
      technicianId,
      scheduledDate,
      estimatedHours,
      notes,
    } = body;

    // Validate required fields
    if (!customerName || !customerPhone || !customerAddress || !issueType || !description) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // If technician assigned, verify technician exists and is active
    if (technicianId) {
      const technician = await prisma.technician.findUnique({
        where: { id: technicianId },
      });

      if (!technician || !technician.isActive) {
        return NextResponse.json(
          { error: 'Invalid or inactive technician' },
          { status: 400 }
        );
      }
    }

    const workOrder = await prisma.workOrder.create({
      data: {
        customerName,
        customerPhone,
        customerAddress,
        issueType,
        description,
        priority: priority || 'MEDIUM',
        status: technicianId ? 'ASSIGNED' : 'OPEN',
        technicianId: technicianId || null,
        coordinatorId: coordinator.id,
        scheduledDate: scheduledDate ? new Date(scheduledDate) : null,
        estimatedHours: estimatedHours ? parseFloat(estimatedHours) : null,
        notes,
        assignedAt: technicianId ? new Date() : null,
      },
      include: {
        technician: {
          select: {
            id: true,
            name: true,
            phoneNumber: true,
          },
        },
        coordinator: {
          select: {
            id: true,
            name: true,
            phoneNumber: true,
          },
        },
      },
    });

    // TODO: Send WhatsApp notification to technician if assigned

    return NextResponse.json(workOrder);
  } catch (error) {
    console.error('Error creating work order:', error);
    return NextResponse.json(
      { error: 'Failed to create work order' },
      { status: 500 }
    );
  }
}

// PUT - Update work order (assign, update status, etc)
export async function PUT(req: NextRequest) {
  try {
    const coordinator = await verifyCoordinatorAuth(req);
    if (!coordinator) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const {
      id,
      technicianId,
      status,
      priority,
      scheduledDate,
      estimatedHours,
      notes,
      customerName,
      customerPhone,
      customerAddress,
      issueType,
      description,
    } = body;

    if (!id) {
      return NextResponse.json(
        { error: 'Work order ID is required' },
        { status: 400 }
      );
    }

    // Check if work order exists
    const existingWorkOrder = await prisma.workOrder.findUnique({
      where: { id },
    });

    if (!existingWorkOrder) {
      return NextResponse.json(
        { error: 'Work order not found' },
        { status: 404 }
      );
    }

    // If assigning/changing technician, verify technician exists and is active
    if (technicianId !== undefined) {
      if (technicianId) {
        const technician = await prisma.technician.findUnique({
          where: { id: technicianId },
        });

        if (!technician || !technician.isActive) {
          return NextResponse.json(
            { error: 'Invalid or inactive technician' },
            { status: 400 }
          );
        }
      }
    }

    const updateData: any = {
      updatedAt: new Date(),
    };

    // Update coordinator if not set
    if (!existingWorkOrder.coordinatorId) {
      updateData.coordinatorId = coordinator.id;
    }

    // Update fields
    if (technicianId !== undefined) {
      updateData.technicianId = technicianId || null;
      if (technicianId && existingWorkOrder.status === 'OPEN') {
        updateData.status = 'ASSIGNED';
        updateData.assignedAt = new Date();
      }
      if (technicianId && !existingWorkOrder.assignedAt) {
        updateData.assignedAt = new Date();
      }
    }

    if (status !== undefined) {
      updateData.status = status;
      if (status === 'COMPLETED' && !existingWorkOrder.completedAt) {
        updateData.completedAt = new Date();
      }
    }

    if (priority !== undefined) updateData.priority = priority;
    if (notes !== undefined) updateData.notes = notes;
    if (customerName !== undefined) updateData.customerName = customerName;
    if (customerPhone !== undefined) updateData.customerPhone = customerPhone;
    if (customerAddress !== undefined) updateData.customerAddress = customerAddress;
    if (issueType !== undefined) updateData.issueType = issueType;
    if (description !== undefined) updateData.description = description;

    if (scheduledDate !== undefined) {
      updateData.scheduledDate = scheduledDate ? new Date(scheduledDate) : null;
    }

    if (estimatedHours !== undefined) {
      updateData.estimatedHours = estimatedHours ? parseFloat(estimatedHours) : null;
    }

    const workOrder = await prisma.workOrder.update({
      where: { id },
      data: updateData,
      include: {
        technician: {
          select: {
            id: true,
            name: true,
            phoneNumber: true,
          },
        },
        coordinator: {
          select: {
            id: true,
            name: true,
            phoneNumber: true,
          },
        },
      },
    });

    // TODO: Send WhatsApp notification if technician assigned/changed

    return NextResponse.json(workOrder);
  } catch (error) {
    console.error('Error updating work order:', error);
    return NextResponse.json(
      { error: 'Failed to update work order' },
      { status: 500 }
    );
  }
}

// DELETE - Delete work order
export async function DELETE(req: NextRequest) {
  try {
    const coordinator = await verifyCoordinatorAuth(req);
    if (!coordinator) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json(
        { error: 'Work order ID is required' },
        { status: 400 }
      );
    }

    // Check if work order exists
    const workOrder = await prisma.workOrder.findUnique({
      where: { id },
    });

    if (!workOrder) {
      return NextResponse.json(
        { error: 'Work order not found' },
        { status: 404 }
      );
    }

    // Don't allow deleting completed work orders (optional business rule)
    if (workOrder.status === 'COMPLETED') {
      return NextResponse.json(
        { error: 'Cannot delete completed work order' },
        { status: 400 }
      );
    }

    await prisma.workOrder.delete({
      where: { id },
    });

    return NextResponse.json({ message: 'Work order deleted successfully' });
  } catch (error) {
    console.error('Error deleting work order:', error);
    return NextResponse.json(
      { error: 'Failed to delete work order' },
      { status: 500 }
    );
  }
}
