import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { jwtVerify } from 'jose';

async function verifyCoordinatorAuth(req: NextRequest) {
  try {
    const token = req.cookies.get('coordinator-token')?.value;
    if (!token) {
      return null;
    }

    const secret = new TextEncoder().encode(
      process.env.JWT_SECRET || 'your-secret-key-change-this-in-production'
    );

    const { payload } = await jwtVerify(token, secret);
    const coordinator = await prisma.coordinator.findUnique({
      where: { id: payload.id as string, isActive: true },
    });

    return coordinator;
  } catch (error) {
    return null;
  }
}

// GET - Get task statistics for coordinator dashboard
export async function GET(req: NextRequest) {
  try {
    const coordinator = await verifyCoordinatorAuth(req);
    if (!coordinator) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get task counts by status
    const [
      totalTasks,
      openTasks,
      assignedTasks,
      inProgressTasks,
      completedTasks,
      urgentTasks,
      myTasks,
    ] = await Promise.all([
      prisma.workOrder.count(),
      prisma.workOrder.count({ where: { status: 'OPEN' } }),
      prisma.workOrder.count({ where: { status: 'ASSIGNED' } }),
      prisma.workOrder.count({ where: { status: 'IN_PROGRESS' } }),
      prisma.workOrder.count({ where: { status: 'COMPLETED' } }),
      prisma.workOrder.count({ where: { priority: 'URGENT' } }),
      prisma.workOrder.count({ where: { coordinatorId: coordinator.id } }),
    ]);

    // Get active technicians count
    const activeTechnicians = await prisma.technician.count({
      where: { isActive: true },
    });

    // Get technicians with their task counts
    const techniciansWithTasks = await prisma.technician.findMany({
      where: { isActive: true },
      select: {
        id: true,
        name: true,
        phoneNumber: true,
        _count: {
          select: {
            workOrders: {
              where: {
                status: { in: ['ASSIGNED', 'IN_PROGRESS'] },
              },
            },
          },
        },
      },
      orderBy: { name: 'asc' },
    });

    // Get recent tasks
    const recentTasks = await prisma.workOrder.findMany({
      take: 10,
      where: {
        coordinatorId: coordinator.id,
      },
      include: {
        technician: {
          select: {
            id: true,
            name: true,
            phoneNumber: true,
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      stats: {
        total: totalTasks,
        open: openTasks,
        assigned: assignedTasks,
        inProgress: inProgressTasks,
        completed: completedTasks,
        urgent: urgentTasks,
        myTasks,
      },
      activeTechnicians,
      technicians: techniciansWithTasks.map(tech => ({
        id: tech.id,
        name: tech.name,
        phoneNumber: tech.phoneNumber,
        activeTasks: tech._count.workOrders,
      })),
      recentTasks,
    });
  } catch (error) {
    console.error('Error fetching task stats:', error);
    return NextResponse.json(
      { error: 'Failed to fetch task statistics' },
      { status: 500 }
    );
  }
}
