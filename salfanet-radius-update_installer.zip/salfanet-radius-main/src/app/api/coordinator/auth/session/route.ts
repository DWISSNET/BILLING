import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { jwtVerify } from 'jose';

export async function GET(req: NextRequest) {
  try {
    const token = req.cookies.get('coordinator-token')?.value;

    if (!token) {
      return NextResponse.json(
        { error: 'Not authenticated' },
        { status: 401 }
      );
    }

    const secret = new TextEncoder().encode(
      process.env.JWT_SECRET || 'your-secret-key-change-this-in-production'
    );

    const { payload } = await jwtVerify(token, secret);

    // Get coordinator details
    const coordinator = await prisma.coordinator.findUnique({
      where: { id: payload.id as string },
      select: {
        id: true,
        name: true,
        phoneNumber: true,
        email: true,
        isActive: true,
      },
    });

    if (!coordinator || !coordinator.isActive) {
      return NextResponse.json(
        { error: 'Coordinator not found or inactive' },
        { status: 404 }
      );
    }

    return NextResponse.json({ coordinator });
  } catch (error) {
    console.error('Session check error:', error);
    return NextResponse.json(
      { error: 'Invalid session' },
      { status: 401 }
    );
  }
}
