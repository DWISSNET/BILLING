import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const { phoneNumber } = await req.json();

    if (!phoneNumber) {
      return NextResponse.json(
        { error: 'Phone number is required' },
        { status: 400 }
      );
    }

    // Normalize phone number
    const normalizedPhone = phoneNumber.replace(/\D/g, '');
    const formattedPhone = normalizedPhone.startsWith('62') 
      ? normalizedPhone 
      : normalizedPhone.startsWith('0')
      ? '62' + normalizedPhone.substring(1)
      : '62' + normalizedPhone;

    // Find coordinator
    let coordinator = await prisma.coordinator.findUnique({
      where: { phoneNumber: formattedPhone },
    });

    if (!coordinator) {
      return NextResponse.json(
        { error: 'Coordinator not found. Please contact admin.' },
        { status: 404 }
      );
    }

    if (!coordinator.isActive) {
      return NextResponse.json(
        { error: 'Coordinator account is inactive' },
        { status: 403 }
      );
    }

    // Check if OTP is required
    if (!coordinator.requireOtp) {
      return NextResponse.json(
        { 
          message: 'OTP not required for this account',
          requireOtp: false,
          coordinator: {
            id: coordinator.id,
            name: coordinator.name,
            phoneNumber: coordinator.phoneNumber,
          }
        },
        { status: 200 }
      );
    }

    // Generate 6-digit OTP
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();

    // Set expiration to 5 minutes from now
    const expiresAt = new Date();
    expiresAt.setMinutes(expiresAt.getMinutes() + 5);

    // Mark all previous OTPs as used
    await prisma.coordinatorOtp.updateMany({
      where: {
        coordinatorId: coordinator.id,
        isUsed: false,
      },
      data: {
        isUsed: true,
      },
    });

    // Create new OTP
    await prisma.coordinatorOtp.create({
      data: {
        coordinatorId: coordinator.id,
        phoneNumber: formattedPhone,
        otpCode,
        expiresAt,
      },
    });

    // Send OTP via WhatsApp
    try {
      const whatsappProvider = await prisma.whatsapp_providers.findFirst({
        where: { 
          isActive: true,
        },
        orderBy: {
          priority: 'desc',
        },
      });

      if (whatsappProvider) {
        const message = `Kode OTP Login Koordinator Anda: *${otpCode}*\n\nKode ini berlaku selama 5 menit.\n\n_Jangan bagikan kode ini kepada siapapun._`;
        
        await fetch(`${whatsappProvider.apiUrl}/send-message`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${whatsappProvider.apiKey}`,
          },
          body: JSON.stringify({
            to: formattedPhone,
            text: message,
          }),
        });

        await prisma.whatsapp_providers.update({
          where: { id: whatsappProvider.id },
          data: { updatedAt: new Date() },
        });
      }
    } catch (error) {
      console.error('Failed to send WhatsApp OTP:', error);
    }

    return NextResponse.json({
      message: 'OTP sent successfully',
      expiresAt,
      // Return OTP in development for testing
      ...(process.env.NODE_ENV === 'development' && { otpCode }),
    });
  } catch (error) {
    console.error('Request OTP error:', error);
    return NextResponse.json(
      { error: 'Failed to send OTP' },
      { status: 500 }
    );
  }
}
