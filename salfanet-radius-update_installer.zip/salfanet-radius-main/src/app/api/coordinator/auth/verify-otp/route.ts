import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { SignJWT } from 'jose';

export async function POST(req: NextRequest) {
  try {
    const { phoneNumber, otpCode, skipOtp } = await req.json();

    if (!phoneNumber) {
      return NextResponse.json(
        { error: 'Phone number is required' },
        { status: 400 }
      );
    }

    if (!skipOtp && !otpCode) {
      return NextResponse.json(
        { error: 'OTP code is required' },
        { status: 400 }
      );
    }

    // Normalize phone number
    const normalizedPhone = phoneNumber.replace(/\D/g, '');
    const formattedPhone = normalizedPhone.startsWith('62') 
      ? normalizedPhone 
      : normalizedPhone.startsWith('0')
      ? '62' + normalizedPhone.substring(1)
      : '62' + normalizedPhone;

    // Find coordinator
    const coordinator = await prisma.coordinator.findUnique({
      where: { phoneNumber: formattedPhone },
    });

    if (!coordinator) {
      return NextResponse.json(
        { error: 'Coordinator not found' },
        { status: 404 }
      );
    }

    if (!coordinator.isActive) {
      return NextResponse.json(
        { error: 'Coordinator account is inactive' },
        { status: 403 }
      );
    }

    // Skip OTP verification if not required
    if (!skipOtp) {
      // Find valid OTP
      const otpToken = await prisma.coordinatorOtp.findFirst({
        where: {
          coordinatorId: coordinator.id,
          otpCode,
          isUsed: false,
          expiresAt: {
            gte: new Date(),
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
      });

      if (!otpToken) {
        return NextResponse.json(
          { error: 'Invalid or expired OTP code' },
          { status: 401 }
        );
      }

      // Mark OTP as used
      await prisma.coordinatorOtp.update({
        where: { id: otpToken.id },
        data: { isUsed: true },
      });
    }

    // Update last login
    await prisma.coordinator.update({
      where: { id: coordinator.id },
      data: { lastLoginAt: new Date() },
    });

    // Create JWT token
    const secret = new TextEncoder().encode(
      process.env.JWT_SECRET || 'your-secret-key-change-this-in-production'
    );

    const token = await new SignJWT({
      id: coordinator.id,
      phoneNumber: coordinator.phoneNumber,
      name: coordinator.name,
      role: 'coordinator',
    })
      .setProtectedHeader({ alg: 'HS256' })
      .setIssuedAt()
      .setExpirationTime('7d')
      .sign(secret);

    // Create response with token in cookie
    const response = NextResponse.json({
      success: true,
      message: 'Login successful',
      coordinator: {
        id: coordinator.id,
        name: coordinator.name,
        phoneNumber: coordinator.phoneNumber,
        email: coordinator.email,
      },
    });

    response.cookies.set('coordinator-token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      maxAge: 60 * 60 * 24 * 7, // 7 days
      path: '/',
    });

    return response;
  } catch (error) {
    console.error('Verify OTP error:', error);
    return NextResponse.json(
      { error: 'Failed to verify OTP' },
      { status: 500 }
    );
  }
}
