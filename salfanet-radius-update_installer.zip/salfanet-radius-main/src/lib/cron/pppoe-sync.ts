import { prisma } from '@/lib/prisma'
import { nanoid } from 'nanoid'
import { RouterOSAPI } from 'node-routeros'

let isPPPoESyncRunning = false

/**
 * Disconnect PPPoE user via MikroTik API as fallback when CoA fails
 */
async function disconnectViaMikrotikAPI(username: string) {
  try {
    // Get active session from radacct to find NAS IP
    const session = await prisma.radacct.findFirst({
      where: {
        username: username,
        acctstoptime: null
      },
      select: {
        nasipaddress: true,
        acctsessionid: true
      }
    })

    if (!session) {
      console.log(`[MikroTik API] No active session for ${username}`)
      return
    }

    // Get router configuration from DB (model router -> table nas)
    const router = await prisma.router.findFirst({
      where: {
        OR: [
          { nasname: session.nasipaddress },
          { ipAddress: session.nasipaddress },
        ],
      },
      select: {
        name: true,
        nasname: true,
        ipAddress: true,
        username: true,
        password: true,
        port: true,
        apiPort: true,
      },
    })

    if (!router) {
      console.log(`[MikroTik API] Router not found for NAS IP ${session.nasipaddress}`)
      return
    }

    const host = router.ipAddress || router.nasname
    const primaryPort = router.port || 8728
    const fallbackPort = router.apiPort || 8729

    const tryDisconnect = async (port: number) => {
      const api = new RouterOSAPI({
        host,
        port,
        user: router.username,
        password: router.password,
        timeout: 15,
      })

      try {
        await api.connect()
        console.log(`[MikroTik API] Connected to ${router.name} (${host}:${port})`)

        const activeSessions = await api.write('/ppp/active/print', [`?name=${username}`])
        console.log(`[MikroTik API] Found ${activeSessions.length} PPPoE active session(s) for ${username}`)

        if (activeSessions.length === 0) {
          await api.close()
          return { success: false, error: 'User not found in PPPoE active list' }
        }

        for (const s of activeSessions) {
          await api.write('/ppp/active/remove', [`=.id=${s['.id']}`])
        }

        await api.close()
        return { success: true }
      } catch (e: any) {
        try { await api.close() } catch {}
        return { success: false, error: e?.message || String(e) }
      }
    }

    // Try plaintext API first (8728), then API-SSL (8729)
    const first = await tryDisconnect(primaryPort)
    if (first.success) {
      console.log(`[MikroTik API] ✅ Disconnected ${username} on ${router.name} (${host}:${primaryPort})`)
      return
    }

    if (fallbackPort !== primaryPort) {
      console.log(`[MikroTik API] Retry disconnect on fallback port ${fallbackPort} (reason: ${first.error})`)
      const second = await tryDisconnect(fallbackPort)
      if (second.success) {
        console.log(`[MikroTik API] ✅ Disconnected ${username} on ${router.name} (${host}:${fallbackPort})`)
        return
      }
      throw new Error(`Disconnect failed (8728: ${first.error}) (8729: ${second.error})`)
    }

    throw new Error(`Disconnect failed on port ${primaryPort}: ${first.error}`)
  } catch (error: any) {
    console.error(`[MikroTik API] Error disconnecting ${username}:`, error.message)
    throw error
  }
}

/**
 * PPPoE Auto-Isolir Expired Users
 * 
 * Runs every hour to check and isolate expired PPPoE users:
 * 1. Find ACTIVE users with expiredAt < TODAY
 * 2. Update user status to SUSPENDED
 * 3. Keep password in radcheck
 * 4. Move user to 'isolir' group in radusergroup
 * 5. Remove static IP from radreply (get IP from pool-isolir instead)
 * 6. Send CoA disconnect to force re-authentication
 */
export async function autoIsolatePPPoEUsers(): Promise<{ 
  success: boolean
  isolated: number
  error?: string 
}> {
  if (isPPPoESyncRunning) {
    console.log('[PPPoE Auto-Isolir] Already running, skipping...')
    return { success: false, isolated: 0, error: 'Already running' }
  }

  isPPPoESyncRunning = true
  const startedAt = new Date()
  
  // Create history record
  const history = await prisma.cronHistory.create({
    data: {
      id: nanoid(),
      jobType: 'pppoe_auto_isolir',
      status: 'running',
      startedAt,
    },
  })
  
  try {
    console.log('[PPPoE Auto-Isolir] Checking for expired users...')

    // Enforce: all SUSPENDED users must be rejected by RADIUS (covers users suspended in the past)
    try {
      await prisma.$executeRaw`
        DELETE rc
        FROM radcheck rc
        INNER JOIN pppoe_users pu ON pu.username = rc.username
        WHERE pu.status = 'SUSPENDED'
          AND rc.attribute = 'Auth-Type'
      `
      await prisma.$executeRaw`
        INSERT INTO radcheck (username, attribute, op, value)
        SELECT pu.username, 'Auth-Type', ':=', 'Reject'
        FROM pppoe_users pu
        WHERE pu.status = 'SUSPENDED'
      `

      await prisma.$executeRaw`
        DELETE rr
        FROM radreply rr
        INNER JOIN pppoe_users pu ON pu.username = rr.username
        WHERE pu.status = 'SUSPENDED'
          AND rr.attribute = 'Reply-Message'
      `
      await prisma.$executeRaw`
        INSERT INTO radreply (username, attribute, op, value)
        SELECT pu.username, 'Reply-Message', ':=', 'Akun Ditangguhkan - Hubungi Admin'
        FROM pppoe_users pu
        WHERE pu.status = 'SUSPENDED'
      `
    } catch (enforceErr: any) {
      console.error('[PPPoE Auto-Isolir] Failed to enforce SUSPENDED reject rules:', enforceErr?.message)
    }

    // Best-effort: disconnect any PPPoE sessions that are still active for SUSPENDED users
    try {
      const stillOnlineSuspended = await prisma.$queryRaw<Array<{ username: string }>>`
        SELECT DISTINCT ra.username
        FROM radacct ra
        INNER JOIN pppoe_users pu ON pu.username = ra.username
        WHERE pu.status = 'SUSPENDED'
          AND ra.acctstoptime IS NULL
        LIMIT 50
      `

      for (const s of stillOnlineSuspended) {
        try {
          await disconnectViaMikrotikAPI(s.username)
        } catch {}

        try {
          const { disconnectPPPoEUser } = await import('../services/coaService')
          await disconnectPPPoEUser(s.username)
        } catch {}

        await prisma.$executeRaw`
          UPDATE radacct
          SET acctstoptime = NOW(),
              acctterminatecause = 'Admin-Reset'
          WHERE username = ${s.username}
            AND acctstoptime IS NULL
        `
      }
    } catch (cleanupErr: any) {
      console.error('[PPPoE Auto-Isolir] Failed to cleanup active sessions for SUSPENDED users:', cleanupErr?.message)
    }

    // Find active users with expiredAt before today
    const expiredUsers = await prisma.$queryRaw<Array<{
      id: string
      username: string
      password: string
      status: string
      expiredAt: Date
      profileId: string
    }>>`
      SELECT id, username, password, status, expiredAt, profileId
      FROM pppoe_users
      WHERE status = 'ACTIVE'
        AND expiredAt < CURDATE()
    `

    if (expiredUsers.length === 0) {
      console.log('[PPPoE Auto-Isolir] No expired users found')
      
      const duration = new Date().getTime() - startedAt.getTime()
      await prisma.cronHistory.update({
        where: { id: history.id },
        data: {
          status: 'success',
          result: 'No expired users found',
          duration,
          completedAt: new Date(),
        },
      })
      
      return { success: true, isolated: 0 }
    }

    console.log(`[PPPoE Auto-Isolir] Found ${expiredUsers.length} expired user(s) to isolate`)

    let isolatedCount = 0

    for (const user of expiredUsers) {
      try {
        // 1. Update user status to SUSPENDED
        await prisma.pppoeUser.update({
          where: { id: user.id },
          data: { status: 'SUSPENDED' },
        })

        // 2. Keep password in radcheck (upsert)
        await prisma.$executeRaw`
          INSERT INTO radcheck (username, attribute, op, value)
          VALUES (${user.username}, 'Cleartext-Password', ':=', ${user.password})
          ON DUPLICATE KEY UPDATE value = ${user.password}
        `

        // 2b. Force reject authentication for suspended users (do not allow login)
        await prisma.$executeRaw`
          INSERT INTO radcheck (username, attribute, op, value)
          VALUES (${user.username}, 'Auth-Type', ':=', 'Reject')
          ON DUPLICATE KEY UPDATE value = 'Reject'
        `

        // Add human-readable reject message
        await prisma.$executeRaw`
          INSERT INTO radreply (username, attribute, op, value)
          VALUES (${user.username}, 'Reply-Message', ':=', 'Akun Ditangguhkan - Hubungi Admin')
          ON DUPLICATE KEY UPDATE value = 'Akun Ditangguhkan - Hubungi Admin'
        `

        // 3. Move to isolir group (kept for tracking/config)
        await prisma.$executeRaw`
          DELETE FROM radusergroup WHERE username = ${user.username}
        `
        await prisma.$executeRaw`
          INSERT INTO radusergroup (username, groupname, priority)
          VALUES (${user.username}, 'isolir', 1)
        `

        // 4. Remove static IP (user will get IP from pool-isolir)
        await prisma.$executeRaw`
          DELETE FROM radreply 
          WHERE username = ${user.username} 
            AND attribute = 'Framed-IP-Address'
        `

        // 5. Disconnect via MikroTik API (primary method)
        try {
          await disconnectViaMikrotikAPI(user.username)
          console.log(`[PPPoE Auto-Isolir] ✅ MikroTik API disconnect for ${user.username}`)
          
          // Also send CoA disconnect for RADIUS accounting
          try {
            const { disconnectPPPoEUser } = await import('../services/coaService')
            await disconnectPPPoEUser(user.username)
            console.log(`[PPPoE Auto-Isolir] 📡 CoA sent for ${user.username}`)
          } catch (coaError: any) {
            console.log(`[PPPoE Auto-Isolir] ⚠️ CoA failed but MikroTik disconnect OK: ${coaError.message}`)
          }
          
          // Close session in radacct
          await prisma.$executeRaw`
            UPDATE radacct 
            SET acctstoptime = NOW(), 
                acctterminatecause = 'Admin-Reset'
            WHERE username = ${user.username} 
              AND acctstoptime IS NULL
          `
          console.log(`[PPPoE Auto-Isolir] 📝 Session closed in radacct for ${user.username}`)
        } catch (apiError: any) {
          console.error(`[PPPoE Auto-Isolir] ❌ MikroTik API failed for ${user.username}:`, apiError.message)
          
          // Fallback to CoA only
          try {
            const { disconnectPPPoEUser } = await import('../services/coaService')
            const coaResult = await disconnectPPPoEUser(user.username)
            
            await prisma.$executeRaw`
              UPDATE radacct 
              SET acctstoptime = NOW(), 
                  acctterminatecause = 'Admin-Reset'
              WHERE username = ${user.username} 
                AND acctstoptime IS NULL
            `
            
            if (coaResult.success) {
              console.log(`[PPPoE Auto-Isolir] 📡 Fallback: CoA disconnect OK for ${user.username}`)
            } else {
              console.log(`[PPPoE Auto-Isolir] ⚠️ Fallback: CoA also failed, only radacct closed for ${user.username}`)
            }
          } catch (fallbackError: any) {
            console.error(`[PPPoE Auto-Isolir] ❌ All disconnect methods failed for ${user.username}:`, fallbackError.message)
          }
        }

        isolatedCount++
        console.log(
          `✅ [PPPoE Auto-Isolir] User ${user.username} isolated (expired: ${
            user.expiredAt ? new Date(user.expiredAt).toISOString().split('T')[0] : 'N/A'
          })`
        )
      } catch (error: any) {
        console.error(`❌ [PPPoE Auto-Isolir] Failed to isolate ${user.username}:`, error.message)
      }
    }

    const duration = new Date().getTime() - startedAt.getTime()
    const message = `Isolated ${isolatedCount}/${expiredUsers.length} users`
    
    await prisma.cronHistory.update({
      where: { id: history.id },
      data: {
        status: 'success',
        result: message,
        duration,
        completedAt: new Date(),
      },
    })

    console.log(`[PPPoE Auto-Isolir] ✅ Completed: ${message}`)

    return { 
      success: true, 
      isolated: isolatedCount 
    }
  } catch (error: any) {
    console.error('[PPPoE Auto-Isolir] ❌ Error:', error)
    
    const duration = new Date().getTime() - startedAt.getTime()
    await prisma.cronHistory.update({
      where: { id: history.id },
      data: {
        status: 'failed',
        result: `Error: ${error.message}`,
        duration,
        completedAt: new Date(),
      },
    })
    
    return { success: false, isolated: 0, error: error.message }
  } finally {
    isPPPoESyncRunning = false
  }
}
