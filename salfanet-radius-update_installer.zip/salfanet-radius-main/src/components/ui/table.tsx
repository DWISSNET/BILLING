"use client"

import * as React from "react"

import { cn } from "@/lib/utils"

function Table({ className, ...props }: React.ComponentProps<"table">) {
  return (
    <div
      data-slot="table-container"
      className={cn(
        "relative w-full overflow-x-auto rounded-xl",
        "border-2 border-cyan-500/20",
        "shadow-[0_0_20px_rgba(0,255,255,0.1)]",
        "hover:border-cyan-500/30 hover:shadow-[0_0_25px_rgba(0,255,255,0.15)]",
        "transition-all duration-300 backdrop-blur-sm"
      )}
    >
      <table
        data-slot="table"
        className={cn("w-full caption-bottom text-sm", className)}
        {...props}
      />
    </div>
  )
}

function TableHeader({ className, ...props }: React.ComponentProps<"thead">) {
  return (
    <thead
      data-slot="table-header"
      className={cn(
        "bg-gradient-to-r from-cyan-500/10 via-purple-500/5 to-pink-500/10",
        "[&_tr]:border-b-2 [&_tr]:border-cyan-500/20",
        className
      )}
      {...props}
    />
  )
}

function TableBody({ className, ...props }: React.ComponentProps<"tbody">) {
  return (
    <tbody
      data-slot="table-body"
      className={cn("[&_tr:last-child]:border-0 bg-background/50", className)}
      {...props}
    />
  )
}

function TableFooter({ className, ...props }: React.ComponentProps<"tfoot">) {
  return (
    <tfoot
      data-slot="table-footer"
      className={cn(
        "bg-cyan-500/5 border-t-2 border-cyan-500/20 font-medium [&>tr]:last:border-b-0",
        className
      )}
      {...props}
    />
  )
}

function TableRow({ className, ...props }: React.ComponentProps<"tr">) {
  return (
    <tr
      data-slot="table-row"
      className={cn(
        "border-b border-white/5 transition-all duration-300",
        "hover:bg-gradient-to-r hover:from-cyan-500/5 hover:via-transparent hover:to-pink-500/5",
        "hover:shadow-[inset_0_0_30px_rgba(0,255,255,0.03)]",
        "data-[state=selected]:bg-cyan-500/10 data-[state=selected]:border-cyan-500/30",
        className
      )}
      {...props}
    />
  )
}

function TableHead({ className, ...props }: React.ComponentProps<"th">) {
  return (
    <th
      data-slot="table-head"
      className={cn(
        "h-11 sm:h-12 px-3 sm:px-4 text-left align-middle",
        "font-bold text-xs uppercase tracking-wider",
        "text-cyan-400 drop-shadow-[0_0_10px_rgba(0,255,255,0.3)]",
        "whitespace-nowrap",
        "[&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
        className
      )}
      {...props}
    />
  )
}

function TableCell({ className, ...props }: React.ComponentProps<"td">) {
  return (
    <td
      data-slot="table-cell"
      className={cn(
        "p-3 sm:p-4 align-middle text-foreground",
        "[&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
        className
      )}
      {...props}
    />
  )
}

function TableCaption({
  className,
  ...props
}: React.ComponentProps<"caption">) {
  return (
    <caption
      data-slot="table-caption"
      className={cn("text-muted-foreground mt-4 text-sm", className)}
      {...props}
    />
  )
}

export {
  Table,
  TableHeader,
  TableBody,
  TableFooter,
  TableHead,
  TableRow,
  TableCell,
  TableCaption,
}
