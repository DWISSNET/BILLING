# This is a symbolic link placeholder
# On Linux VPS, create symbolic links with:
# ln -s /etc/freeradius/3.0/sites-available/default /etc/freeradius/3.0/sites-enabled/default
# ln -s /etc/freeradius/3.0/sites-available/coa /etc/freeradius/3.0/sites-enabled/coa
