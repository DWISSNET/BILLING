# This is a symbolic link placeholder
# On Linux VPS, create symbolic link with:
# ln -s /etc/freeradius/3.0/mods-available/sql /etc/freeradius/3.0/mods-enabled/sql
