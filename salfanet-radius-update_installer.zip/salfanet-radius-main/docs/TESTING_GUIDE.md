# Testing Guide - Prepaid & Postpaid System

## 🎯 Tujuan Testing
Memastikan sistem prepaid dan postpaid berfungsi dengan benar setelah implementasi billing_day dan perbaikan logic.

## ✅ Perubahan yang Sudah Dilakukan

### 1. Database Schema
- ✅ Added `billingDay` (1-28) to pppoe_users
- ✅ Added `subscriptionType` (PREPAID/POSTPAID)
- ✅ Added `balance`, `autoRenewal`, `autoIsolationEnabled`
- ✅ Added `invoiceType` enum to invoices
- ✅ Schema applied via `npx prisma db push`

### 2. Frontend Forms
- ✅ Form approval registrasi: tambah input billing day (untuk POSTPAID)
- ✅ Form tambah/edit user: tambah input billing day (untuk POSTPAID)
- ✅ Conditional display: billing day hanya muncul jika POSTPAID

### 3. Backend API
- ✅ `/api/admin/registrations/[id]/approve`: handle billingDay
- ✅ `/api/pppoe/users` (POST): handle subscriptionType & billingDay saat create
- ✅ `/api/pppoe/users` (PUT): handle subscriptionType & billingDay saat update
- ✅ `/api/payment/webhook`: logic berbeda untuk PREPAID vs POSTPAID
- ✅ `/api/invoices/generate`: generate invoice berbeda untuk PREPAID vs POSTPAID

## 🧪 Test Cases

### Test 1: Registrasi User Baru POSTPAID
**Steps:**
1. Buka menu "Registrasi Pelanggan"
2. Klik tombol "Approve" pada registrasi pending
3. Pilih "📅 Postpaid"
4. Pilih "Tanggal Tagihan" = 5 (atau tanggal lain 1-28)
5. Isi biaya pemasangan (misal: 100000)
6. Klik "Approve"

**Expected:**
- ✅ User dibuat dengan `subscriptionType = 'POSTPAID'`
- ✅ User memiliki `billingDay = 5`
- ✅ User memiliki `expiredAt = null`
- ✅ Invoice dibuat hanya untuk biaya pemasangan (bukan pemasangan + bulan pertama)
- ✅ User status = 'isolated' sampai bayar invoice

**Verification Query:**
```sql
SELECT username, subscriptionType, billingDay, expiredAt, status 
FROM pppoe_users 
WHERE username = 'nama-phone';
```

### Test 2: Registrasi User Baru PREPAID
**Steps:**
1. Buka menu "Registrasi Pelanggan"
2. Klik tombol "Approve" pada registrasi pending
3. Pilih "⏰ Prepaid"
4. Isi biaya pemasangan (misal: 100000)
5. Klik "Approve"

**Expected:**
- ✅ User dibuat dengan `subscriptionType = 'PREPAID'`
- ✅ User memiliki `billingDay = 1` (default)
- ✅ User memiliki `expiredAt = now + validity period`
- ✅ Invoice = biaya pemasangan + biaya paket (total lebih besar)
- ✅ User status = 'isolated' sampai bayar invoice

**Verification Query:**
```sql
SELECT username, subscriptionType, billingDay, expiredAt, status 
FROM pppoe_users 
WHERE username = 'nama-phone';
```

### Test 3: Payment Invoice POSTPAID
**Steps:**
1. Gunakan user POSTPAID dari Test 1
2. Bayar invoice via payment gateway (atau manual payment)
3. Tunggu webhook/approval

**Expected:**
- ✅ Invoice status = 'PAID'
- ✅ User status = 'active'
- ✅ User `expiredAt` tetap `null` (tidak berubah)
- ✅ User dapat login PPPoE

**Verification Query:**
```sql
SELECT u.username, u.subscriptionType, u.expiredAt, u.status, i.status as invoice_status
FROM pppoe_users u
JOIN invoices i ON u.id = i.userId
WHERE u.username = 'nama-phone';
```

### Test 4: Payment Invoice PREPAID
**Steps:**
1. Gunakan user PREPAID dari Test 2
2. Bayar invoice via payment gateway (atau manual payment)
3. Tunggu webhook/approval

**Expected:**
- ✅ Invoice status = 'PAID'
- ✅ User status = 'active'
- ✅ User `expiredAt` diperpanjang (+1 bulan dari sekarang atau dari expiredAt sebelumnya)
- ✅ User dapat login PPPoE

**Verification Query:**
```sql
SELECT u.username, u.subscriptionType, u.expiredAt, u.status, i.status as invoice_status
FROM pppoe_users u
JOIN invoices i ON u.id = i.userId
WHERE u.username = 'nama-phone';
```

### Test 5: Invoice Generation POSTPAID (Cron)
**Steps:**
1. Set tanggal sistem = billingDay user POSTPAID (misal tanggal 5)
2. Jalankan cron job: `POST /api/invoices/generate`
3. Atau tunggu cron otomatis jam 00:00

**Expected:**
- ✅ Invoice baru dibuat dengan `invoiceType = 'MONTHLY'`
- ✅ `dueDate = billingDay + 7 hari` (grace period)
- ✅ Amount = harga paket (bukan pemasangan)
- ✅ Hanya 1 invoice per user (tidak duplikat)

**Verification Query:**
```sql
SELECT i.invoiceNumber, i.invoiceType, i.amount, i.dueDate, i.status, u.username, u.billingDay
FROM invoices i
JOIN pppoe_users u ON i.userId = u.id
WHERE u.subscriptionType = 'POSTPAID'
  AND i.createdAt >= CURDATE()
ORDER BY i.createdAt DESC;
```

### Test 6: Invoice Generation PREPAID (Cron)
**Steps:**
1. Set tanggal sistem = 7 hari sebelum expiredAt user PREPAID
2. Jalankan cron job: `POST /api/invoices/generate`
3. Atau tunggu cron otomatis jam 00:00

**Expected:**
- ✅ Invoice baru dibuat dengan `invoiceType = 'RENEWAL'`
- ✅ `dueDate = expiredAt` user
- ✅ Amount = harga paket
- ✅ Hanya 1 invoice per user (tidak duplikat)

**Verification Query:**
```sql
SELECT i.invoiceNumber, i.invoiceType, i.amount, i.dueDate, i.status, u.username, u.expiredAt
FROM invoices i
JOIN pppoe_users u ON i.userId = u.id
WHERE u.subscriptionType = 'PREPAID'
  AND i.createdAt >= CURDATE()
ORDER BY i.createdAt DESC;
```

### Test 7: Auto Isolation POSTPAID
**Steps:**
1. Gunakan user POSTPAID dengan invoice overdue (lewat dueDate)
2. Jalankan cron job auto-isolation (atau tunggu cron hourly)

**Expected:**
- ✅ User status berubah ke 'isolated'
- ✅ User tidak bisa login PPPoE
- ✅ Radcheck & radusergroup dihapus

**Verification Query:**
```sql
SELECT u.username, u.status, i.invoiceNumber, i.dueDate, i.status as invoice_status
FROM pppoe_users u
JOIN invoices i ON u.id = i.userId
WHERE u.subscriptionType = 'POSTPAID'
  AND i.status IN ('PENDING', 'OVERDUE')
  AND i.dueDate < CURDATE();
```

### Test 8: Auto Isolation PREPAID
**Steps:**
1. Gunakan user PREPAID dengan expiredAt sudah lewat
2. Jalankan cron job auto-isolation (atau tunggu cron hourly)

**Expected:**
- ✅ User status berubah ke 'isolated'
- ✅ User tidak bisa login PPPoE
- ✅ Radcheck & radusergroup dihapus

**Verification Query:**
```sql
SELECT username, status, expiredAt, subscriptionType
FROM pppoe_users
WHERE subscriptionType = 'PREPAID'
  AND expiredAt < NOW()
  AND status = 'isolated';
```

### Test 9: Edit User - Ganti Billing Day
**Steps:**
1. Buka menu "PPPoE Users"
2. Edit user POSTPAID
3. Ubah "Tanggal Tagihan" dari 5 ke 15
4. Save

**Expected:**
- ✅ `billingDay` berubah jadi 15
- ✅ Invoice berikutnya akan generate tanggal 15

**Verification Query:**
```sql
SELECT username, billingDay, subscriptionType 
FROM pppoe_users 
WHERE username = 'user-test';
```

### Test 10: Edit User - Ganti POSTPAID ke PREPAID
**Steps:**
1. Buka menu "PPPoE Users"
2. Edit user POSTPAID
3. Ubah subscription type ke PREPAID
4. Set expiredAt = 1 bulan dari sekarang
5. Save

**Expected:**
- ✅ `subscriptionType` berubah ke 'PREPAID'
- ✅ `expiredAt` diset sesuai input
- ✅ Invoice berikutnya akan mengikuti logic PREPAID (H-7 sebelum expiry)

**Verification Query:**
```sql
SELECT username, subscriptionType, expiredAt, billingDay 
FROM pppoe_users 
WHERE username = 'user-test';
```

## 📊 Monitoring Queries

### Check User by Subscription Type
```sql
SELECT subscriptionType, COUNT(*) as total
FROM pppoe_users
GROUP BY subscriptionType;
```

### Check POSTPAID Users Ready for Invoice
```sql
SELECT username, name, billingDay, status, expiredAt
FROM pppoe_users
WHERE subscriptionType = 'POSTPAID'
  AND billingDay = DAY(CURDATE())
  AND status IN ('active', 'isolated');
```

### Check PREPAID Users Expiring Soon
```sql
SELECT username, name, expiredAt, status,
       DATEDIFF(expiredAt, CURDATE()) as days_until_expiry
FROM pppoe_users
WHERE subscriptionType = 'PREPAID'
  AND expiredAt BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
  AND status IN ('active', 'isolated')
ORDER BY expiredAt ASC;
```

### Check All Unpaid Invoices
```sql
SELECT i.invoiceNumber, i.invoiceType, u.username, u.subscriptionType, 
       i.amount, i.dueDate, i.status,
       DATEDIFF(CURDATE(), i.dueDate) as days_overdue
FROM invoices i
JOIN pppoe_users u ON i.userId = u.id
WHERE i.status IN ('PENDING', 'OVERDUE')
ORDER BY i.dueDate ASC;
```

## 🐛 Common Issues & Solutions

### Issue 1: Date Picker Error
**Symptom:** Error saat pilih tanggal di form
**Solution:** 
- Pastikan format date: `yyyy-MM-dd`
- Check timezone conversion (WIB to UTC)
- Gunakan `endOfDayWIBtoUTC()` helper

### Issue 2: Invoice Duplikat
**Symptom:** User dapat 2+ invoice untuk bulan yang sama
**Solution:**
- Check query di `/api/invoices/generate`
- Pastikan ada check `existingInvoice` sebelum create
- Filter by status `IN ('PENDING', 'OVERDUE')`

### Issue 3: Billing Day > 28
**Symptom:** User pilih tanggal 29-31
**Solution:**
- Frontend: limit dropdown sampai 28
- Backend: validasi `Math.min(Math.max(billingDay, 1), 28)`

### Issue 4: POSTPAID User Punya expiredAt
**Symptom:** User POSTPAID tidak bisa login padahal sudah bayar
**Solution:**
- Set `expiredAt = null` untuk POSTPAID
- Check payment webhook - pastikan logic set null

### Issue 5: PREPAID expiredAt Tidak Diperpanjang
**Symptom:** Setelah bayar, expiredAt tetap sama
**Solution:**
- Check payment webhook logic
- Pastikan calculate `newExpiredAt` based on validity

## 📝 Manual Testing Script

Jalankan di browser console atau API testing tool (Postman):

```javascript
// Test 1: Create POSTPAID user via approval
fetch('/api/admin/registrations/REG123/approve', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    installationFee: 100000,
    subscriptionType: 'POSTPAID',
    billingDay: 5
  })
}).then(r => r.json()).then(console.log);

// Test 2: Create PREPAID user via approval
fetch('/api/admin/registrations/REG456/approve', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    installationFee: 100000,
    subscriptionType: 'PREPAID'
  })
}).then(r => r.json()).then(console.log);

// Test 3: Generate invoices (manual trigger)
fetch('/api/invoices/generate', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' }
}).then(r => r.json()).then(console.log);
```

## ✅ Testing Checklist

### Frontend
- [ ] Form approval: dropdown billing day (1-28) muncul untuk POSTPAID
- [ ] Form approval: dropdown billing day hidden untuk PREPAID
- [ ] Form add user: dropdown billing day (1-28) muncul untuk POSTPAID
- [ ] Form edit user: dropdown billing day (1-28) muncul untuk POSTPAID
- [ ] Form edit user: load billingDay value dari database
- [ ] Tidak ada error console saat submit form

### Backend API
- [ ] POST /api/admin/registrations/[id]/approve: terima billingDay
- [ ] POST /api/pppoe/users: simpan subscriptionType & billingDay
- [ ] PUT /api/pppoe/users: update subscriptionType & billingDay
- [ ] POST /api/invoices/generate: POSTPAID check billingDay
- [ ] POST /api/invoices/generate: PREPAID check expiredAt
- [ ] POST /api/payment/webhook: POSTPAID set expiredAt = null
- [ ] POST /api/payment/webhook: PREPAID extend expiredAt

### Database
- [ ] Schema pppoe_users: field billingDay ada (INT, default 1)
- [ ] Schema pppoe_users: field subscriptionType ada (ENUM)
- [ ] Schema invoices: field invoiceType ada (ENUM)
- [ ] Data existing user: migrasi subscriptionType (null → POSTPAID/PREPAID)
- [ ] Data existing user: set default billingDay = 1

### Cron Jobs
- [ ] Invoice generation: POSTPAID generate on billingDay
- [ ] Invoice generation: PREPAID generate H-7 before expiredAt
- [ ] Auto isolation: POSTPAID isolate on overdue invoice
- [ ] Auto isolation: PREPAID isolate on expiredAt passed
- [ ] Cron history: log berhasil/gagal

### Edge Cases
- [ ] BillingDay = 31 → auto convert to 28
- [ ] User ganti POSTPAID → PREPAID
- [ ] User ganti PREPAID → POSTPAID
- [ ] Invoice manual create (bukan auto generate)
- [ ] Payment webhook retry (idempotency)

## 🎯 Success Criteria

Semua test case passed:
- ✅ POSTPAID user: invoice generate di billingDay
- ✅ PREPAID user: invoice generate H-7 before expiredAt
- ✅ Payment: logic berbeda POSTPAID vs PREPAID
- ✅ Isolation: trigger berbeda POSTPAID vs PREPAID
- ✅ Form: billing day field muncul/hidden sesuai tipe
- ✅ API: handle billingDay dengan validasi 1-28

---

**Version**: 1.0  
**Date**: 2025-12-23  
**Status**: Ready for Testing
